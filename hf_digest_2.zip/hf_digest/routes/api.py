"""JSON API: используется модалкой поиска на главной странице."""
from flask import Blueprint, current_app, jsonify, request

api_bp = Blueprint("api", __name__)


@api_bp.route("/search")
def search():
    query = request.args.get("q", "").strip()
    if not query:
        return jsonify([])

    limit = current_app.config.get("SEARCH_RESULTS_LIMIT", 30)
    results = current_app.digest_service.search(query, limit=limit)
    return jsonify(results)
