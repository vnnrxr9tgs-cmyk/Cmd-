"""Маршруты, отдающие HTML-страницы."""
from flask import Blueprint, abort, current_app, render_template, request

views_bp = Blueprint("views", __name__)

SORT_KEYS = {
    "articles": lambda d: d.articles_count,
    "chars": lambda d: d.chars_count,
}


@views_bp.route("/")
def index():
    service = current_app.digest_service
    all_digests = service.list_digests()  # уже отсортированы по дате, новые впереди

    languages = sorted({d.language for d in all_digests})

    lang = request.args.get("lang", "").strip().lower()
    digests = [d for d in all_digests if d.language.lower() == lang] if lang else all_digests

    sort = request.args.get("sort", "date")
    if sort in SORT_KEYS:
        digests = sorted(digests, key=SORT_KEYS[sort], reverse=True)

    return render_template(
        "index.html",
        digests=digests,
        languages=languages,
        current_lang=lang,
        current_sort=sort,
        stats=_build_stats(all_digests),
    )


def _build_stats(all_digests) -> dict:
    """Сводка по всей коллекции (не зависит от текущих фильтров) для мини-статистики."""
    total = len(all_digests)
    if total == 0:
        return {"total": 0, "total_articles": 0, "languages": []}

    counts: dict[str, int] = {}
    for d in all_digests:
        counts[d.language] = counts.get(d.language, 0) + 1

    languages = [
        {"code": lang, "count": count, "percent": round(count / total * 100)}
        for lang, count in sorted(counts.items(), key=lambda kv: kv[1], reverse=True)
    ]

    return {
        "total": total,
        "total_articles": sum(d.articles_count for d in all_digests),
        "languages": languages,
    }


@views_bp.route("/news/<digest_id>")
def detail(digest_id):
    digest = current_app.digest_service.get_digest(digest_id)
    if digest is None:
        abort(404)
    return render_template("detail.html", digest=digest)
