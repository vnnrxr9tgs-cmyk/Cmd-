"""Слой доступа к данным дайджестов новостей.

Отвечает за:
  * чтение JSON-файлов из каталога outputs/ (формат файлов не меняется);
  * разбор текста дайджеста на структурированные блоки-статьи;
  * автоматическую чистку данных (в исходных файлах иногда попадаются
    полностью продублированные абзацы — это баг апстрима, здесь он
    сглаживается);
  * кэширование разобранных дайджестов по времени изменения файла,
    чтобы не перечитывать и не парсить всё заново на каждый запрос;
  * полнотекстовый поиск.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import markdown
from werkzeug.utils import secure_filename

logger = logging.getLogger(__name__)

_TITLE_RE = re.compile(r"^\*\*(.*?)\*\*\s*", re.DOTALL)
_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")

WORDS_PER_MINUTE = 200


@dataclass
class Block:
    """Один смысловой блок (статья) внутри дайджеста."""

    index: int
    title: str          # заголовок блока (или "Блок N", если в тексте его не было)
    has_title: bool      # был ли в исходном тексте настоящий заголовок (**...**)
    html: str            # тело блока, отрендеренное из Markdown
    text: str            # тело блока в виде обычного текста — для поиска и сниппетов


@dataclass
class Digest:
    """Один обработанный дайджест новостей (один JSON-файл в outputs/)."""

    id: str                     # имя файла — используется как идентификатор в URL
    original_filename: str
    title: str
    processed_at: datetime
    language: str
    blocks: list[Block]
    is_old: bool = False

    @property
    def articles_count(self) -> int:
        return len(self.blocks)

    @property
    def chars_count(self) -> int:
        return sum(len(b.text) for b in self.blocks)

    @property
    def reading_time_min(self) -> int:
        words = sum(len(b.text.split()) for b in self.blocks)
        return max(1, round(words / WORDS_PER_MINUTE))

    @property
    def date_label(self) -> str:
        return self.processed_at.strftime("%d.%m.%Y %H:%M")

    @property
    def topics(self) -> list[Block]:
        """Блоки с настоящими заголовками — используются как теги-превью на карточке."""
        return [b for b in self.blocks if b.has_title][:5]


class DigestService:
    """Читает, парсит, кэширует и ищет дайджесты в каталоге outputs/."""

    def __init__(self, outputs_dir: str | Path, old_threshold_hours: int = 24):
        self.outputs_dir = Path(outputs_dir)
        self.old_threshold = timedelta(hours=old_threshold_hours)
        # Кэш: имя файла -> (mtime на момент разбора, готовый Digest)
        self._cache: dict[str, tuple[float, Digest]] = {}

    # ------------------------------------------------------------------ #
    # Публичное API
    # ------------------------------------------------------------------ #

    def list_digests(self) -> list[Digest]:
        """Возвращает все дайджесты, отсортированные от новых к старым."""
        digests = []
        for path in self._iter_json_files():
            digest = self._load(path)
            if digest is not None:
                digests.append(digest)
        digests.sort(key=lambda d: d.processed_at, reverse=True)
        return digests

    def get_digest(self, digest_id: str) -> Optional[Digest]:
        """Возвращает один дайджест по его id (имени файла на диске)."""
        safe_id = secure_filename(digest_id)
        if not safe_id or safe_id != digest_id:
            return None
        path = self.outputs_dir / safe_id
        if not path.is_file():
            return None
        return self._load(path)

    def search(self, query: str, limit: int = 30) -> list[dict]:
        """Полнотекстовый поиск по всем дайджестам.

        Документ считается совпадением, если все слова запроса встречаются
        в его тексте (не обязательно в одном блоке). Результат содержит
        готовый сниппет и индекс блока-якоря — чтобы вести пользователя
        сразу на нужный фрагмент детальной страницы (/news/<id>#block-N).
        """
        terms = [t for t in query.lower().split() if t]
        if not terms:
            return []

        results = []
        for digest in self.list_digests():  # уже отсортированы по дате (новые впереди)
            matched_blocks = [
                b for b in digest.blocks
                if all(term in b.text.lower() for term in terms)
            ]
            whole_text = " ".join(b.text.lower() for b in digest.blocks)
            if not matched_blocks and not all(term in whole_text for term in terms):
                continue

            anchor_block = matched_blocks[0] if matched_blocks else digest.blocks[0]
            results.append({
                "id": digest.id,
                "title": digest.title,
                "language": digest.language,
                "date": digest.date_label,
                "articles_count": digest.articles_count,
                "block_index": anchor_block.index,
                "snippet": self._make_snippet(anchor_block.text, terms),
                "score": len(matched_blocks),
            })

        # сортировка стабильна: при равном score порядок "по дате" сохраняется
        results.sort(key=lambda r: r["score"], reverse=True)
        return results[:limit]

    # ------------------------------------------------------------------ #
    # Внутренняя кухня
    # ------------------------------------------------------------------ #

    def _iter_json_files(self):
        if not self.outputs_dir.is_dir():
            return
        yield from sorted(self.outputs_dir.glob("*.json"))

    def _load(self, path: Path) -> Optional[Digest]:
        """Отдаёт дайджест из кэша, если файл не менялся, иначе парсит заново."""
        try:
            mtime = path.stat().st_mtime
        except OSError:
            return None

        cached = self._cache.get(path.name)
        if cached and cached[0] == mtime:
            return cached[1]

        digest = self._parse_file(path)
        if digest is not None:
            self._cache[path.name] = (mtime, digest)
        return digest

    def _parse_file(self, path: Path) -> Optional[Digest]:
        try:
            with path.open("r", encoding="utf-8") as fh:
                data = json.load(fh)

            processed_at = datetime.fromisoformat(data["processed_at"])
            blocks = self._parse_blocks(data["processed_text"])
            original_filename = data.get("original_filename", path.name)

            return Digest(
                id=path.name,
                original_filename=original_filename,
                title=re.sub(r"\.docx$", "", original_filename, flags=re.IGNORECASE),
                processed_at=processed_at,
                language=data.get("language", "unknown"),
                blocks=blocks,
                is_old=(datetime.now() - processed_at) > self.old_threshold,
            )
        except (json.JSONDecodeError, KeyError, ValueError, OSError) as exc:
            logger.warning("Не удалось разобрать файл %s: %s", path.name, exc)
            return None

    @staticmethod
    def _parse_blocks(raw_text: str) -> list[Block]:
        """Разбивает текст дайджеста на блоки, отбрасывая точные дубликаты тела.

        В исходных данных иногда один и тот же абзац повторяется несколько
        раз подряд (в том числе с обрезанным заголовком) — это артефакт
        апстрима, а не полезная информация, поэтому такие повторы
        схлопываются в один блок.
        """
        raw_blocks = [b.strip() for b in raw_text.split("\n\n") if b.strip()]
        blocks: list[Block] = []
        seen_bodies: set[str] = set()

        for raw in raw_blocks:
            match = _TITLE_RE.match(raw)
            title = match.group(1).strip() if match else ""
            body_md = raw[match.end():].strip() if match else raw

            normalized_body = _WS_RE.sub(" ", body_md).strip().lower()
            if normalized_body and normalized_body in seen_bodies:
                continue  # дубликат уже встречавшегося содержимого — пропускаем
            if normalized_body:
                seen_bodies.add(normalized_body)

            html = markdown.markdown(body_md, extensions=["extra"]) if body_md else ""
            plain = _TAG_RE.sub(" ", html)
            text = f"{title} {plain}".strip() if title else plain

            blocks.append(Block(
                index=len(blocks),
                title=title or f"Блок {len(blocks) + 1}",
                has_title=bool(title),
                html=html,
                text=_WS_RE.sub(" ", text).strip(),
            ))
        return blocks

    @staticmethod
    def _make_snippet(text: str, terms: list[str], radius: int = 90) -> str:
        """Вырезает фрагмент текста вокруг первого найденного термина."""
        lower = text.lower()
        pos = -1
        for term in terms:
            p = lower.find(term)
            if p != -1 and (pos == -1 or p < pos):
                pos = p
        if pos == -1:
            pos = 0

        start = max(0, pos - radius)
        end = min(len(text), pos + radius)
        snippet = text[start:end]
        if start > 0:
            snippet = "…" + snippet
        if end < len(text):
            snippet += "…"
        return snippet
