/**
 * Логика главной страницы:
 *  - модалка полнотекстового поиска (ходит на /api/search, с дебаунсом);
 *  - клавиша "/" открывает поиск, Esc закрывает активную модалку;
 *  - автоотправка формы фильтров при смене языка/сортировки;
 *  - клик по тегу темы ведёт сразу на нужный блок детальной страницы.
 */
document.addEventListener('DOMContentLoaded', () => {
    setupSearchModal();
    setupAboutModal();
    setupTopicTags();
    setupAutosubmit();
});

function setupSearchModal() {
    const modal = document.getElementById('searchModal');
    const openBtn = document.getElementById('searchModalBtn');
    const closeBtn = document.getElementById('closeSearchModalBtn');
    const input = document.getElementById('searchQuery');
    const resultsBox = document.getElementById('searchResultsContainer');
    if (!modal) return;

    let debounceTimer = null;

    function open() {
        modal.classList.add('active');
        document.body.classList.add('modal-open');
        setTimeout(() => input.focus(), 80);
    }
    function close() {
        modal.classList.remove('active');
        document.body.classList.remove('modal-open');
        input.value = '';
        resultsBox.innerHTML = '';
    }

    openBtn.addEventListener('click', open);
    closeBtn.addEventListener('click', close);
    modal.querySelector('.modal-overlay').addEventListener('click', close);

    document.addEventListener('keydown', (e) => {
        const typingSomewhere = ['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName);
        if (e.key === '/' && !typingSomewhere) {
            e.preventDefault();
            open();
        }
        if (e.key === 'Escape' && modal.classList.contains('active')) close();
    });

    input.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        const query = input.value.trim();
        if (!query) {
            resultsBox.innerHTML = '';
            return;
        }
        debounceTimer = setTimeout(() => runSearch(query), 250);
    });

    function renderSkeleton() {
        resultsBox.innerHTML = Array.from({ length: 3 }).map(() => `
            <div class="skeleton-item">
                <div class="skeleton-line" style="width: 55%"></div>
                <div class="skeleton-line" style="width: 90%"></div>
                <div class="skeleton-line" style="width: 35%"></div>
            </div>
        `).join('');
    }

    async function runSearch(query) {
        renderSkeleton();
        try {
            const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const results = await res.json();
            renderResults(results, query);
        } catch (err) {
            resultsBox.innerHTML = '<div class="no-results-modal">Ошибка поиска. Попробуйте ещё раз.</div>';
        }
    }

    function renderResults(results, query) {
        if (!results.length) {
            resultsBox.innerHTML = `<div class="no-results-modal">Ничего не найдено по запросу «${hfEscapeHtml(query)}»</div>`;
            return;
        }
        resultsBox.innerHTML = results.map((r) => `
            <a href="/news/${encodeURIComponent(r.id)}#block-${r.block_index}" class="result-item">
                <div class="result-title">${hfEscapeHtml(r.title)}</div>
                <div class="result-snippet">${hfEscapeHtml(r.snippet)}</div>
                <div class="result-meta">
                    <span>${hfEscapeHtml(r.language.toUpperCase())}</span>
                    <span>${hfEscapeHtml(r.date)}</span>
                    <span>${r.articles_count} статей</span>
                </div>
            </a>
        `).join('');
    }
}

function setupAboutModal() {
    const modal = document.getElementById('aboutModal');
    const openBtn = document.getElementById('aboutBtn');
    const closeBtn = document.getElementById('closeAboutModalBtn');
    if (!modal) return;

    function open() {
        modal.classList.add('active');
        document.body.classList.add('modal-open');
    }
    function close() {
        modal.classList.remove('active');
        document.body.classList.remove('modal-open');
    }

    openBtn.addEventListener('click', open);
    closeBtn.addEventListener('click', close);
    modal.querySelector('.modal-overlay').addEventListener('click', close);

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) close();
    });
}

function setupTopicTags() {
    document.querySelectorAll('.topic-tag').forEach((tag) => {
        tag.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            window.location.href = tag.dataset.href;
        });
    });
}

function setupAutosubmit() {
    document.querySelectorAll('[data-autosubmit]').forEach((el) => {
        el.addEventListener('change', () => el.form.submit());
    });
}
