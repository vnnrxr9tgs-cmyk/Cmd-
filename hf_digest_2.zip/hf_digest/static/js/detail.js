/**
 * Логика детальной страницы:
 *  - копирование отдельного блока или всего дайджеста в буфер обмена;
 *  - при заходе по ссылке с якорем (#block-N) — плавный скролл и подсветка.
 */
document.addEventListener('DOMContentLoaded', () => {
    const sourceName = document.querySelector('.main-container')?.dataset.sourceName || 'HF Digest';

    document.querySelectorAll('.copy-block-btn').forEach((btn) => {
        btn.addEventListener('click', () => copyBlock(btn, sourceName));
    });

    const copyAllBtn = document.getElementById('copyAllBtn');
    if (copyAllBtn) {
        copyAllBtn.addEventListener('click', () => copyAllBlocks(copyAllBtn, sourceName));
    }

    scrollToHashOnLoad();
});

async function copyBlock(btn, sourceName) {
    const block = btn.closest('.article-block');
    const text = block.querySelector('.block-content').innerText.trim();
    await writeToClipboard(`${text}\n\nИсточник: ${sourceName}`, btn, 'Скопировано');
}

async function copyAllBlocks(btn, sourceName) {
    const parts = [...document.querySelectorAll('.article-block .block-content')]
        .map((el) => el.innerText.trim());
    const text = `${parts.join('\n\n')}\n\nИсточник: ${sourceName}`;
    await writeToClipboard(text, btn, 'Дайджест скопирован');
}

async function writeToClipboard(text, btn, doneLabel) {
    const label = btn.querySelector('.btn-label');
    try {
        await navigator.clipboard.writeText(text);
        hfShowToast('Скопировано в буфер обмена');

        const original = label.textContent;
        btn.classList.add('copied');
        label.textContent = doneLabel;
        setTimeout(() => {
            btn.classList.remove('copied');
            label.textContent = original;
        }, 1800);
    } catch (err) {
        hfShowToast('Не удалось скопировать текст');
    }
}

function scrollToHashOnLoad() {
    if (!window.location.hash) return;
    const target = document.querySelector(window.location.hash);
    if (!target) return;

    setTimeout(() => {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        target.classList.add('highlight-scroll');
        setTimeout(() => target.classList.remove('highlight-scroll'), 2000);
    }, 150);
}
