/**
 * Общие утилиты, используемые на всех страницах:
 *  - переключатель светлой/тёмной темы (сохраняется в localStorage);
 *  - тосты-уведомления;
 *  - экранирование HTML при вставке текста через innerHTML.
 */
(function initTheme() {
    // Иконки солнца/луны переключаются чистым CSS по [data-theme] — здесь
    // только сохраняем выбор пользователя и переключаем сам атрибут.
    const root = document.documentElement;
    const stored = localStorage.getItem('hf-theme');
    if (stored) root.dataset.theme = stored;

    const toggleBtn = document.getElementById('themeToggle');
    if (!toggleBtn) return;

    toggleBtn.addEventListener('click', () => {
        root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
        localStorage.setItem('hf-theme', root.dataset.theme);
    });
})();

/** Общий набор inline-иконок для использования в JS-генерируемой разметке. */
const HF_ICONS = {
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" width="13" height="13"><polyline points="20 6 9 17 4 12"/></svg>',
};

function hfEscapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m]));
}

function hfShowToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2200);
}
