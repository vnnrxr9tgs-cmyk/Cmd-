"""HF Digest — точка входа приложения.

Локальный веб-дайджест новостей: читает обработанные JSON-файлы из
каталога outputs/, показывает их списком с фильтрами и полнотекстовым
поиском, отрисовывает детальную страницу с постатейной разбивкой.

Работает в локальной сети без авторизации — этого достаточно для
внутреннего инструмента, для которого написан проект.

Запуск:
    python app.py

Конфигурация — через переменные окружения, см. config.py.
"""
import logging
import os

from flask import Flask, render_template

from config import Config
from services import DigestService


def create_app(config_class: type[Config] = Config) -> Flask:
    app = Flask(__name__)
    app.config.from_object(config_class)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    os.makedirs(app.config["OUTPUTS_DIR"], exist_ok=True)
    app.digest_service = DigestService(
        outputs_dir=app.config["OUTPUTS_DIR"],
        old_threshold_hours=app.config["OLD_THRESHOLD_HOURS"],
    )

    from routes.api import api_bp
    from routes.views import views_bp

    app.register_blueprint(views_bp)
    app.register_blueprint(api_bp, url_prefix="/api")

    @app.errorhandler(404)
    def not_found(_error):
        return render_template("404.html"), 404

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host=app.config["HOST"], port=app.config["PORT"], debug=app.config["DEBUG"])
