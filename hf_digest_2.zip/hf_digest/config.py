"""Конфигурация приложения. Все параметры можно переопределить через переменные окружения."""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


class Config:
    # Каталог с обработанными JSON-дайджестами
    OUTPUTS_DIR = os.environ.get("OUTPUTS_DIR", os.path.join(BASE_DIR, "outputs"))

    # Через сколько часов карточка считается "устаревшей" в интерфейсе
    OLD_THRESHOLD_HOURS = int(os.environ.get("OLD_THRESHOLD_HOURS", "24"))

    # Сеть (по умолчанию слушаем во всей локальной сети)
    HOST = os.environ.get("HOST", "0.0.0.0")
    PORT = int(os.environ.get("PORT", "5000"))
    DEBUG = os.environ.get("FLASK_DEBUG", "1") == "1"

    # Максимум результатов в выдаче поиска
    SEARCH_RESULTS_LIMIT = int(os.environ.get("SEARCH_RESULTS_LIMIT", "30"))
