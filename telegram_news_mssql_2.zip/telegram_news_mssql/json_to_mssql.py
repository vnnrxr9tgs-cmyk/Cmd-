#!/usr/bin/env python3
"""
Импортёр JSON → Microsoft SQL Server 2008+.

Запуск:
  python json_to_mssql.py --once
  python json_to_mssql.py --interval 30

Параметры подключения (по приоритету):
  1) аргументы CLI
  2) файл settings/importer.ini
  3) переменные окружения MSSQL_*

importer.ini пример:
  [mssql]
  server = 192.168.1.10
  database = TelegramNews
  auth = windows          # windows | sql
  user =
  password =
  driver = SQL Server     # или {SQL Server Native Client 10.0}

  [paths]
  data_dir = ./data
"""

from __future__ import annotations

import argparse
import configparser
import hashlib
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import pyodbc
except ImportError:
    print("Установите pyodbc:  pip install pyodbc")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

if getattr(sys, "frozen", False):
    BASE_DIR = Path(sys.executable).resolve().parent
else:
    BASE_DIR = Path(__file__).resolve().parent

DEFAULT_DATA_DIR = BASE_DIR / "data"
DEFAULT_INI = BASE_DIR / "settings" / "importer.ini"

DATE_FORMATS = (
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S",
    "%d.%m.%Y %H:%M",
    "%Y-%m-%d %H:%M",
    "%d.%m.%Y %H:%M:%S",
)


def parse_dt(text: str) -> Tuple[float, str]:
    if not text:
        return 0.0, ""
    text = str(text).strip()
    for fmt in DATE_FORMATS:
        try:
            dt = datetime.strptime(text, fmt)
            return dt.timestamp(), text
        except ValueError:
            continue
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00").split("+")[0])
        return dt.timestamp(), text
    except Exception:
        return 0.0, text


def checksum(channel: str, date_str: str, title: str, body: str) -> str:
    raw = f"{channel}|{date_str}|{title or ''}|{body}".encode("utf-8")
    return hashlib.md5(raw).hexdigest()


def file_quick_hash(path: Path) -> str:
    try:
        size = path.stat().st_size
        with path.open("rb") as f:
            head = f.read(4096)
            if size > 8192:
                f.seek(-4096, 2)
                tail = f.read(4096)
            else:
                tail = b""
        return hashlib.md5(head + tail + str(size).encode()).hexdigest()
    except Exception:
        return ""


def load_ini(path: Path) -> Dict[str, str]:
    cfg: Dict[str, str] = {}
    if not path.exists():
        return cfg
    p = configparser.ConfigParser()
    p.read(str(path), encoding="utf-8")
    if p.has_section("mssql"):
        for k in ("server", "database", "auth", "user", "password", "driver"):
            if p.has_option("mssql", k):
                cfg[k] = p.get("mssql", k).strip()
    if p.has_section("paths") and p.has_option("paths", "data_dir"):
        cfg["data_dir"] = p.get("paths", "data_dir").strip()
    return cfg


def build_conn_str(
    server: str,
    database: str,
    auth: str = "windows",
    user: str = "",
    password: str = "",
    driver: str = "SQL Server",
) -> str:
    # SQL Server 2008: "SQL Server" или "SQL Server Native Client 10.0"
    drv = driver if driver.startswith("{") else f"{{{driver}}}"
    parts = [
        f"DRIVER={drv}",
        f"SERVER={server}",
        f"DATABASE={database}",
    ]
    if auth.lower() in ("windows", "trusted", "sspi", "domain"):
        parts.append("Trusted_Connection=yes")
    else:
        parts.append(f"UID={user}")
        parts.append(f"PWD={password}")
    # Для старых драйверов
    parts.append("TrustServerCertificate=yes")
    return ";".join(parts)


def connect(conn_str: str):
    return pyodbc.connect(conn_str, timeout=30, autocommit=False)


def ensure_schema_hint(conn) -> None:
    """Проверка, что таблицы существуют (создание — через schema_mssql.sql)."""
    cur = conn.cursor()
    cur.execute(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'news'"
    )
    if cur.fetchone()[0] == 0:
        raise RuntimeError(
            "Таблица dbo.news не найдена. Сначала выполните schema_mssql.sql на SQL Server."
        )


def get_or_create_channel(cur, name: str) -> int:
    cur.execute("SELECT id FROM dbo.channels WHERE name = ?", (name,))
    row = cur.fetchone()
    if row:
        return int(row[0])
    cur.execute("INSERT INTO dbo.channels (name) VALUES (?)", (name,))
    cur.execute("SELECT id FROM dbo.channels WHERE name = ?", (name,))
    return int(cur.fetchone()[0])


def get_file_cache(cur) -> Dict[str, str]:
    cur.execute("SELECT [key], value FROM dbo.meta WHERE [key] LIKE 'file_hash:%'")
    out = {}
    for k, v in cur.fetchall():
        out[k[len("file_hash:") :]] = v or ""
    return out


def set_file_hash(cur, channel: str, fhash: str) -> None:
    key = f"file_hash:{channel}"
    cur.execute("SELECT 1 FROM dbo.meta WHERE [key] = ?", (key,))
    if cur.fetchone():
        cur.execute("UPDATE dbo.meta SET value = ? WHERE [key] = ?", (fhash, key))
    else:
        cur.execute("INSERT INTO dbo.meta ([key], value) VALUES (?, ?)", (key, fhash))


def load_json_items(path: Path) -> List[Dict[str, Any]]:
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception as e:
        print(f"  [!] {path.name}: {e}")
        return []


def import_channel(cur, channel_name: str, items: List[Dict[str, Any]]) -> Tuple[int, int]:
    channel_id = get_or_create_channel(cur, channel_name)
    inserted = 0
    skipped = 0

    for item in items:
        date_raw = item.get("dateTime") or item.get("date") or ""
        body = item.get("text") or item.get("body") or ""
        if not body or not str(body).strip():
            skipped += 1
            continue
        body = str(body)
        title = str(item.get("title") or "") or None
        date_ts, date_str = parse_dt(str(date_raw))
        cs = checksum(channel_name, date_str, title or "", body)

        try:
            cur.execute(
                """
                INSERT INTO dbo.news (channel_id, date_str, date_ts, title, body, checksum)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (channel_id, date_str, date_ts, title, body, cs),
            )
            inserted += 1
        except pyodbc.IntegrityError:
            # UNIQUE (channel_id, checksum) — дубль
            skipped += 1
        except Exception as e:
            # на случай другого текста ошибки уникальности
            msg = str(e).lower()
            if "unique" in msg or "duplicate" in msg or "2627" in msg or "2601" in msg:
                skipped += 1
            else:
                raise

    # метаданные канала
    cur.execute(
        """
        SELECT TOP 1 date_str, date_ts, body
        FROM dbo.news
        WHERE channel_id = ?
        ORDER BY date_ts DESC, id DESC
        """,
        (channel_id,),
    )
    last = cur.fetchone()
    cur.execute("SELECT COUNT(*) FROM dbo.news WHERE channel_id = ?", (channel_id,))
    count = int(cur.fetchone()[0])

    if last:
        preview = (last[2] or "")[:500]
        cur.execute(
            """
            UPDATE dbo.channels
            SET last_date = ?, last_date_ts = ?, last_text = ?, news_count = ?
            WHERE id = ?
            """,
            (last[0], float(last[1] or 0), preview, count, channel_id),
        )
    else:
        cur.execute(
            """
            UPDATE dbo.channels
            SET last_date = NULL, last_date_ts = 0, last_text = NULL, news_count = 0
            WHERE id = ?
            """,
            (channel_id,),
        )

    return inserted, skipped


def run_import(
    data_dir: Path,
    conn_str: str,
    verbose: bool = True,
) -> Dict[str, Any]:
    data_dir = data_dir.resolve()
    if not data_dir.is_dir():
        print(f"[!] Папка не найдена: {data_dir}")
        return {"inserted": 0, "skipped": 0, "unchanged": 0, "channels": 0}

    conn = connect(conn_str)
    ensure_schema_hint(conn)
    cur = conn.cursor()
    # быстрые хинты
    try:
        cur.execute("SET NOCOUNT ON")
    except Exception:
        pass

    file_cache = get_file_cache(cur)
    json_files = sorted(data_dir.glob("*.json"))

    total_ins = total_sk = unchanged = touched = 0
    t0 = time.time()
    if verbose:
        print(f"[{datetime.now():%H:%M:%S}] Импорт {data_dir} → SQL Server")
        print(f"  JSON-файлов: {len(json_files)}")

    for path in json_files:
        channel_name = path.stem.replace("/", "_").replace("\\", "_")
        fhash = file_quick_hash(path)
        if file_cache.get(channel_name) == fhash:
            unchanged += 1
            continue

        items = load_json_items(path)
        ins, sk = import_channel(cur, channel_name, items)
        set_file_hash(cur, channel_name, fhash)
        total_ins += ins
        total_sk += sk
        touched += 1
        if verbose and (ins or sk):
            print(f"  {channel_name}: +{ins}, skip {sk}")

    cur.execute(
        """
        IF EXISTS (SELECT 1 FROM dbo.meta WHERE [key] = N'last_import_ts')
            UPDATE dbo.meta SET value = ? WHERE [key] = N'last_import_ts'
        ELSE
            INSERT INTO dbo.meta ([key], value) VALUES (N'last_import_ts', ?)
        """,
        (str(time.time()), str(time.time())),
    )
    conn.commit()
    conn.close()

    elapsed = time.time() - t0
    if verbose:
        print(
            f"  готово за {elapsed:.2f}s | каналов: {touched}, "
            f"новых: {total_ins}, без изменений: {unchanged}"
        )
    return {
        "channels": touched,
        "inserted": total_ins,
        "skipped": total_sk,
        "unchanged": unchanged,
        "elapsed": round(elapsed, 2),
    }


def resolve_config(args) -> Tuple[str, Path]:
    ini = load_ini(Path(args.ini) if args.ini else DEFAULT_INI)

    server = args.server or ini.get("server") or os.environ.get("MSSQL_SERVER", "")
    database = args.database or ini.get("database") or os.environ.get("MSSQL_DATABASE", "TelegramNews")
    auth = (args.auth or ini.get("auth") or os.environ.get("MSSQL_AUTH", "windows")).lower()
    user = args.user or ini.get("user") or os.environ.get("MSSQL_USER", "")
    password = args.password or ini.get("password") or os.environ.get("MSSQL_PASSWORD", "")
    driver = args.driver or ini.get("driver") or os.environ.get("MSSQL_DRIVER", "SQL Server")
    data_dir = Path(
        args.data_dir
        or ini.get("data_dir")
        or os.environ.get("MSSQL_DATA_DIR", str(DEFAULT_DATA_DIR))
    )

    if not server:
        print(
            "Не указан server.\n"
            "  --server HOST  или  settings/importer.ini  или  MSSQL_SERVER="
        )
        sys.exit(1)

    conn_str = build_conn_str(server, database, auth, user, password, driver)
    return conn_str, data_dir


def main():
    parser = argparse.ArgumentParser(description="JSON → SQL Server importer")
    parser.add_argument("--ini", type=str, default=str(DEFAULT_INI))
    parser.add_argument("--server", type=str)
    parser.add_argument("--database", type=str)
    parser.add_argument("--auth", choices=["windows", "sql"], help="windows=Trusted, sql=UID/PWD")
    parser.add_argument("--user", type=str)
    parser.add_argument("--password", type=str)
    parser.add_argument("--driver", type=str, default=None)
    parser.add_argument("--data-dir", type=str)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--interval", type=float, default=30.0)
    parser.add_argument("-q", "--quiet", action="store_true")
    args = parser.parse_args()

    conn_str, data_dir = resolve_config(args)
    verbose = not args.quiet

    if args.once:
        run_import(data_dir, conn_str, verbose=verbose)
        return

    print(f"Цикл импорта каждые {args.interval}s. Ctrl+C — стоп.")
    print(f"  data: {data_dir}")
    try:
        while True:
            try:
                run_import(data_dir, conn_str, verbose=verbose)
            except Exception as e:
                print(f"[!] Ошибка импорта: {e}")
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nОстановлено.")


if __name__ == "__main__":
    main()
