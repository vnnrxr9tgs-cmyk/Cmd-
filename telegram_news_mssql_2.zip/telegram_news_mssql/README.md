# Telegram News — SQL Server 2008

Один SQL Server, 20–30 клиентов по сети. JSON импортируется на ПК с файлами, UI только читает БД.

```
[ПК]  data/*.json  →  json_to_mssql.py  →  SQL Server 2008 (TelegramNews)
                                                    ↑
                                      mainTLG.py × 20–30 пользователей
```

## Файлы

| Файл | Роль |
|------|------|
| `schema_mssql.sql` | Создание БД, таблиц, индексов |
| `json_to_mssql.py` | Импорт JSON → MSSQL (цикл, без дублей) |
| `mainTLG.py` | Клиент PyQt5 |
| `settings/importer.ini.example` | Пример настроек импортёра |

## 1. Создать БД

В SSMS или:

```bat
sqlcmd -S YOUR_SERVER -E -i schema_mssql.sql
```

`-E` = Windows Auth. Для SQL-логина: `-U sa -P ***`.

## 2. Права

**Импортёр** (запись в news/channels/meta):

```sql
CREATE LOGIN news_importer WITH PASSWORD = '***';
USE TelegramNews;
CREATE USER news_importer FOR LOGIN news_importer;
GRANT SELECT, INSERT, UPDATE ON dbo.channels TO news_importer;
GRANT SELECT, INSERT ON dbo.news TO news_importer;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.meta TO news_importer;
```

**Читатели** (доменная группа или SQL-логин):

```sql
-- пример: доменная группа
CREATE LOGIN [DOMAIN\NewsReaders] FROM WINDOWS;
CREATE USER [DOMAIN\NewsReaders] FOR LOGIN [DOMAIN\NewsReaders];
GRANT SELECT ON dbo.channels TO [DOMAIN\NewsReaders];
GRANT SELECT ON dbo.news TO [DOMAIN\NewsReaders];
GRANT SELECT, INSERT, UPDATE ON dbo.read_state TO [DOMAIN\NewsReaders];
```

## 3. Импортёр

```bat
pip install pyodbc

copy settings\importer.ini.example settings\importer.ini
# отредактировать server, auth, data_dir

python json_to_mssql.py --once
python json_to_mssql.py --interval 30
```

CLI:

```bat
python json_to_mssql.py --server 192.168.1.10 --database TelegramNews --auth windows --data-dir D:\news --once
python json_to_mssql.py --server 192.168.1.10 --auth sql --user news_importer --password *** --once
```

Дубли: `UNIQUE(channel_id, checksum)`. Неизменённые JSON пропускаются по хэшу файла в `meta`.

## 4. Клиент

```bat
pip install PyQt5 pyodbc
python mainTLG.py
```

При первом запуске откроются **Настройки → Подключение**:

| Поле | Пример |
|------|--------|
| Сервер | `192.168.1.10` или `SQLHOST\SQLEXPRESS` |
| База | `TelegramNews` |
| Аутентификация | Windows (домен) **или** SQL Server |
| SQL логин / пароль | только для auth=sql |
| ODBC Driver | `SQL Server` или `SQL Server Native Client 10.0` |
| user_id | ваш логин (для «прочитано» отдельно у каждого) |

Кнопка **Проверить подключение**.

## Поведение UI

- Каналы + badge непрочитанных (**свой** `user_id` в `read_state`)
- В канале 10 новостей, скролл вниз → ещё 10 (`ROW_NUMBER`, SQL 2008)
- Опрос БД каждые N сек → тосты о новых
- Темы dark/light, звук, поиск

## Зависимости

- **На ПК с SQL Server / импортёром:** ODBC Driver, `pyodbc`
- **На клиентах:** то же + `PyQt5`

Проверка драйверов:

```bat
python -c "import pyodbc; print(pyodbc.drivers())"
```

Нужен хотя бы `SQL Server` или `SQL Server Native Client 10.0`.

## Таблицы

- `channels` — метаданные канала  
- `news` — новости (`body NVARCHAR(MAX)`, индекс по channel+date, id)  
- `read_state (user_id, channel_id)` — кто что прочитал  
- `meta` — хэши JSON, версия схемы  
