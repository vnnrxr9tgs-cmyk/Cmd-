-- =============================================================================
-- Telegram News — схема для Microsoft SQL Server 2008+
-- Запуск: sqlcmd -S SERVER -E -i schema_mssql.sql
--      или в SSMS от имени sysadmin / dbcreator
-- =============================================================================

IF DB_ID(N'TelegramNews') IS NULL
    CREATE DATABASE TelegramNews;
GO

USE TelegramNews;
GO

-- ---------------------------------------------------------------------------
-- channels
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.channels', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.channels (
        id            INT IDENTITY(1,1) NOT NULL,
        name          NVARCHAR(256)     NOT NULL,
        last_date     NVARCHAR(64)      NULL,
        last_date_ts  FLOAT             NOT NULL CONSTRAINT DF_channels_last_ts DEFAULT (0),
        last_text     NVARCHAR(500)     NULL,
        news_count    INT               NOT NULL CONSTRAINT DF_channels_cnt DEFAULT (0),
        show_flag     BIT               NOT NULL CONSTRAINT DF_channels_show DEFAULT (1),
        notify_flag   BIT               NOT NULL CONSTRAINT DF_channels_notify DEFAULT (1),
        sound_flag    BIT               NOT NULL CONSTRAINT DF_channels_sound DEFAULT (1),
        CONSTRAINT PK_channels PRIMARY KEY CLUSTERED (id),
        CONSTRAINT UQ_channels_name UNIQUE (name)
    );
END
GO

-- ---------------------------------------------------------------------------
-- news
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.news', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.news (
        id            INT IDENTITY(1,1) NOT NULL,
        channel_id    INT               NOT NULL,
        date_str      NVARCHAR(64)      NOT NULL,
        date_ts       FLOAT             NOT NULL,
        title         NVARCHAR(500)     NULL,
        body          NVARCHAR(MAX)     NOT NULL,
        checksum      CHAR(32)          NOT NULL,
        CONSTRAINT PK_news PRIMARY KEY CLUSTERED (id),
        CONSTRAINT FK_news_channel FOREIGN KEY (channel_id)
            REFERENCES dbo.channels(id) ON DELETE CASCADE,
        CONSTRAINT UQ_news_channel_checksum UNIQUE (channel_id, checksum)
    );
END
GO

-- Индексы для списка канала / сортировки / poll
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_news_channel_date' AND object_id = OBJECT_ID(N'dbo.news'))
    CREATE NONCLUSTERED INDEX IX_news_channel_date
        ON dbo.news (channel_id, date_ts DESC, id DESC)
        INCLUDE (date_str, title, checksum);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_news_date' AND object_id = OBJECT_ID(N'dbo.news'))
    CREATE NONCLUSTERED INDEX IX_news_date
        ON dbo.news (date_ts DESC, id DESC);
GO

-- Быстрый poll: WHERE id > @last
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_news_id' AND object_id = OBJECT_ID(N'dbo.news'))
    CREATE NONCLUSTERED INDEX IX_news_id
        ON dbo.news (id)
        INCLUDE (channel_id, date_str, date_ts, title, checksum);
GO

-- ---------------------------------------------------------------------------
-- read_state — прогресс ПОЛЬЗОВАТЕЛЯ (не общий)
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.read_state', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.read_state (
        user_id         NVARCHAR(128) NOT NULL,
        channel_id      INT           NOT NULL,
        last_read_ts    FLOAT         NOT NULL CONSTRAINT DF_read_ts DEFAULT (0),
        last_read_date  NVARCHAR(64)  NULL,
        CONSTRAINT PK_read_state PRIMARY KEY CLUSTERED (user_id, channel_id),
        CONSTRAINT FK_read_channel FOREIGN KEY (channel_id)
            REFERENCES dbo.channels(id) ON DELETE CASCADE
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_read_state_channel' AND object_id = OBJECT_ID(N'dbo.read_state'))
    CREATE NONCLUSTERED INDEX IX_read_state_channel
        ON dbo.read_state (channel_id, user_id)
        INCLUDE (last_read_ts);
GO

-- ---------------------------------------------------------------------------
-- meta (хэши файлов импорта, версия схемы)
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.meta', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.meta (
        [key]   NVARCHAR(128) NOT NULL,
        value   NVARCHAR(512) NULL,
        CONSTRAINT PK_meta PRIMARY KEY CLUSTERED ([key])
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.meta WHERE [key] = N'schema_version')
    INSERT INTO dbo.meta ([key], value) VALUES (N'schema_version', N'1');
GO

IF NOT EXISTS (SELECT 1 FROM dbo.meta WHERE [key] = N'last_import_ts')
    INSERT INTO dbo.meta ([key], value) VALUES (N'last_import_ts', N'0');
GO

-- ---------------------------------------------------------------------------
-- Роли / пример прав (раскомментируйте и подставьте свои логины)
-- ---------------------------------------------------------------------------
/*
-- Импортёр (запись)
CREATE LOGIN news_importer WITH PASSWORD = N'ChangeMe_Importer!';
USE TelegramNews;
CREATE USER news_importer FOR LOGIN news_importer;
GRANT SELECT, INSERT, UPDATE ON dbo.channels TO news_importer;
GRANT SELECT, INSERT ON dbo.news TO news_importer;  -- дубли режет UNIQUE
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.meta TO news_importer;

-- Читатели (20–30 пользователей): Windows-группа или SQL-логин
-- CREATE LOGIN [DOMAIN\NewsReaders] FROM WINDOWS;
-- CREATE USER [DOMAIN\NewsReaders] FOR LOGIN [DOMAIN\NewsReaders];
-- GRANT SELECT ON dbo.channels TO [DOMAIN\NewsReaders];
-- GRANT SELECT ON dbo.news TO [DOMAIN\NewsReaders];
-- GRANT SELECT, INSERT, UPDATE ON dbo.read_state TO [DOMAIN\NewsReaders];
*/

PRINT N'TelegramNews schema OK';
GO
