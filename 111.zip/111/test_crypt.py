#!/usr/bin/env python3
"""
Шифрование файла HALFLOOP-24 (учебная реализация).

Читает test.txt, шифрует блоками по 3 байта, кладёт рядом test.enc
и печатает hex в консоль.

ВНИМАНИЕ:
  * HALFLOOP-24 взломан и небезопасен для реальных данных.
  * Это УЧЕБНАЯ реализация, не соответствующая официальной спецификации
    MIL-STD-188-141 (публичная версия неполна).
  * Ключ и tweak по умолчанию — из официального тестового вектора.
"""

from pathlib import Path
import argparse
import hashlib
import sys
from collections import Counter

# ============================================================
# 1. AES S-box (HALFLOOP-24 использует AES S-box)
# ============================================================
AES_SBOX = [
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16,
]
RCON = [0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36]

# ============================================================
# 2. GF(2^8)
# ============================================================
def gf_mul(a: int, b: int) -> int:
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        hi = a & 0x80
        a = (a << 1) & 0xff
        if hi:
            a ^= 0x1b
        b >>= 1
    return p

# ============================================================
# 3. Key schedule
# ============================================================
def expand_key(key16: bytes):
    w = [list(key16[i*4:(i+1)*4]) for i in range(4)]
    for i in range(4, 44):
        temp = w[i-1][:]
        if i % 4 == 0:
            temp = temp[1:] + temp[:1]
            temp = [AES_SBOX[b] for b in temp]
            temp[0] ^= RCON[i//4 - 1]
        w.append([w[i-4][j] ^ temp[j] for j in range(4)])
    return [bytes(sum(w[r*4:(r+1)*4], [])) for r in range(11)]

# ============================================================
# 4. Раундовые функции
# ============================================================
def sub_bytes(state):
    return [AES_SBOX[b] for b in state]

def rotate_rows(state):
    b0, b1, b2 = state
    b1 = ((b1 << 1) | (b1 >> 7)) & 0xff
    b2 = ((b2 << 2) | (b2 >> 6)) & 0xff
    return [b0, b1, b2]

def mix_columns(state):
    a = state
    return [
        gf_mul(9, a[0]) ^ gf_mul(2, a[1]) ^ gf_mul(1, a[2]),
        gf_mul(1, a[0]) ^ gf_mul(9, a[1]) ^ gf_mul(2, a[2]),
        gf_mul(2, a[0]) ^ gf_mul(1, a[1]) ^ gf_mul(9, a[2]),
    ]

def add_round_key(state, rk):
    return [state[i] ^ rk[i] for i in range(3)]

# ============================================================
# 5. Шифрование блока 24 бита
# ============================================================
def halfloop24_encrypt(key16: bytes, tweak8: bytes, plaintext3: bytes) -> bytes:
    round_keys = expand_key(key16)

    # --- Tweak injection ---
    # ВАЖНО: в этой учебной реализации tweak XOR-ится с первыми 8 байтами
    # начального раундового ключа. Это упрощение, а не официальная схема.
    tweaked_key = bytearray(round_keys[0])
    for i in range(8):
        tweaked_key[i] ^= tweak8[i]
    round_keys[0] = bytes(tweaked_key)

    state = list(plaintext3)
    for r in range(10):
        state = add_round_key(state, round_keys[r][:3])
        state = sub_bytes(state)
        state = rotate_rows(state)
        if r != 9:
            state = mix_columns(state)
    state = add_round_key(state, round_keys[10][:3])
    return bytes(state)

# ============================================================
# 6. Уникальный tweak для каждого блока
# ============================================================
def make_tweak(base_tweak: bytes, counter: int) -> bytes:
    """
    Генерирует 8-байтный tweak для блока с номером counter.

    Вместо прибавления counter к младшему байту (что давало повторы),
    используем SHA-256 от (base_tweak || counter) и берём первые 8 байт.
    Это гарантирует уникальность tweak для каждого блока и лавинный
    эффект: изменение counter на 1 полностью меняет tweak.
    """
    h = hashlib.sha256(base_tweak + counter.to_bytes(8, "big")).digest()
    return h[:8]

# ============================================================
# 7. Шифрование файла
# ============================================================
def encrypt_file(in_path: Path, out_path: Path, key: bytes, base_tweak: bytes):
    data = in_path.read_bytes()
    print("=" * 60)
    print("ШИФРОВАНИЕ ФАЙЛА HALFLOOP-24 (учебная реализация)")
    print("=" * 60)
    print(f"Входной файл:  {in_path}")
    print(f"Размер:        {len(data)} байт")
    print(f"Ключ:          {key.hex()}")
    print(f"Базовый tweak: {base_tweak.hex()}")
    print()

    out = bytearray()
    n_blocks = (len(data) + 2) // 3
    for i in range(0, len(data), 3):
        block = data[i:i+3].ljust(3, b'\x00')
        idx = i // 3
        tw = make_tweak(base_tweak, idx)
        ct = halfloop24_encrypt(key, tw, block)
        out += ct

    out_path.write_bytes(bytes(out))
    print(f"Выходной файл: {out_path}")
    print(f"Блоков:        {n_blocks}")
    print(f"Размер:        {len(out)} байт")
    print()

    # --- Проверка на повторы ---
    blocks = [bytes(out[i:i+3]) for i in range(0, len(out), 3)]
    cnt = Counter(blocks)
    repeats = {b: n for b, n in cnt.items() if n > 1}
    print(f"Уникальных блоков:   {len(cnt)}")
    print(f"Повторяющихся:       {len(repeats)}")
    if repeats:
        print("Топ-5 повторов:")
        for b, n in sorted(repeats.items(), key=lambda x: -x[1])[:5]:
            print(f"  {b.hex()}: {n} раз")
        print("  (Повторы допустимы только если в открытом тексте")
        print("   тоже были одинаковые 3-байтные блоки — но при")
        print("   уникальном tweak их быть НЕ должно.)")
    else:
        print("Повторов нет — tweak работает корректно.")
    print()

    print("--- Содержимое test.enc (hex, первые 256 байт) ---")
    print(bytes(out[:256]).hex())
    if len(out) > 256:
        print(f"... (всего {len(out)} байт)")
    print()
    print("Готово. Файл test.enc лежит рядом с test.txt")

# ============================================================
# 8. main
# ============================================================
def main():
    p = argparse.ArgumentParser(
        description="Учебное шифрование файла HALFLOOP-24 (блоки по 3 байта)."
    )
    p.add_argument("input", nargs="?", default=None,
                   help="входной файл (по умолчанию test.txt)")
    p.add_argument("-o", "--output", default=None,
                   help="выходной файл (по умолчанию <input>.enc)")
    p.add_argument("--key", default="2b7e151628aed2a6abf7158809cf4f3c",
                   help="16-байтный ключ в hex")
    p.add_argument("--tweak", default="543bd88000017550",
                   help="8-байтный базовый tweak в hex")
    args = p.parse_args()

    # --- Определяем входной файл ---
    here = Path(__file__).resolve().parent
    if args.input is None:
        candidates = [here / "test.txt", Path.cwd() / "test.txt"]
        in_path = next((c for c in candidates if c.exists()), None)
        if in_path is None:
            print("ОШИБКА: test.txt не найден.")
            for c in candidates:
                print(f"  искал: {c}")
            sys.exit(1)
    else:
        in_path = Path(args.input)
        if not in_path.exists():
            print(f"ОШИБКА: файл {in_path} не найден.")
            sys.exit(1)

    out_path = Path(args.output) if args.output else in_path.with_suffix(".enc")

    key = bytes.fromhex(args.key)
    tweak = bytes.fromhex(args.tweak)

    if len(key) != 16:
        print(f"ОШИБКА: ключ должен быть 16 байт, получено {len(key)}.")
        sys.exit(1)
    if len(tweak) != 8:
        print(f"ОШИБКА: tweak должен быть 8 байт, получено {len(tweak)}.")
        sys.exit(1)

    encrypt_file(in_path, out_path, key, tweak)

if __name__ == "__main__":
    main()