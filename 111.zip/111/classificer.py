#!/usr/bin/env python3
"""
Слепой классификатор HALFLOOP-24 / 24-bit block cipher
Ничего заранее не известно (нет ключа, твика, plaintext)
"""

import math
import collections
import sys
from pathlib import Path

def entropy(data: bytes) -> float:
    if not data:
        return 0.0
    c = collections.Counter(data)
    n = len(data)
    return -sum((cnt / n) * math.log2(cnt / n) for cnt in c.values())

def nibble_entropy(data: bytes) -> float:
    nib = [(b >> 4) for b in data] + [(b & 0x0F) for b in data]
    return entropy(bytes(nib))

def chi2_uniformity(data: bytes) -> float:
    """Насколько близко к равномерному распределению (1.0 = идеально)"""
    if len(data) < 64:
        return 0.0
    c = collections.Counter(data)
    expected = len(data) / 256.0
    chi2 = sum((cnt - expected) ** 2 / expected for cnt in c.values())
    # Грубая нормализация
    return max(0.0, 1.0 - chi2 / (len(data) * 3))

def block_stats(data: bytes, bs: int = 3):
    blocks = [data[i:i+bs] for i in range(0, len(data) - bs + 1, bs)]
    if not blocks:
        return 0, 0, 0.0
    cnt = collections.Counter(blocks)
    unique = len(cnt)
    total = len(blocks)
    repeats = sum(1 for v in cnt.values() if v > 1)
    collision_rate = 1.0 - (unique / total)
    return total, unique, collision_rate

def blind_halfloop_score(data: bytes) -> dict:
    res = {
        "length": len(data),
        "entropy": round(entropy(data), 4),
        "nibble_entropy": round(nibble_entropy(data), 4),
        "uniformity": round(chi2_uniformity(data), 4),
        "aligned_24bit": len(data) % 3 == 0,
        "score": 0.0,
        "verdict": ""
    }

    total_blocks, unique_blocks, coll_rate = block_stats(data, 3)
    res["blocks_total"] = total_blocks
    res["blocks_unique"] = unique_blocks
    res["collision_rate"] = round(coll_rate, 5)

    score = 0.0

    # 1. Высокая энтропия (характерно для хорошего блочного шифра)
    if 7.7 <= res["entropy"] <= 8.0:
        score += 30
    elif 7.4 <= res["entropy"] < 7.7:
        score += 18
    elif 7.0 <= res["entropy"] < 7.4:
        score += 8

    # 2. Выравнивание по 24 битам
    if res["aligned_24bit"] and len(data) >= 12:
        score += 25
    elif len(data) % 3 == 0:
        score += 10

    # 3. Равномерность байтов
    score += res["uniformity"] * 20

    # 4. Nibble entropy
    if res["nibble_entropy"] > 3.9:
        score += 15
    elif res["nibble_entropy"] > 3.7:
        score += 8

    # 5. Мало коллизий 3-байтных блоков (при хорошем твике их почти нет)
    if total_blocks > 20:
        if coll_rate < 0.01:
            score += 15
        elif coll_rate < 0.05:
            score += 8
        else:
            score -= 10   # много повторов = подозрительно

    res["score"] = min(100.0, round(score, 1))

    if res["score"] >= 80:
        res["verdict"] = "HIGH — очень похоже на 24-bit block cipher (HALFLOOP-style)"
    elif res["score"] >= 60:
        res["verdict"] = "MEDIUM — возможно 24-bit block cipher"
    elif res["score"] >= 40:
        res["verdict"] = "LOW — слабое сходство"
    else:
        res["verdict"] = "UNLIKELY — больше похоже на random/другой шифр/мусор"

    return res

def analyze_file(path: str):
    data = Path(path).read_bytes()
    print(f"Файл: {path}")
    print(f"Размер: {len(data)} байт\n")
    r = blind_halfloop_score(data)
    for k, v in r.items():
        print(f"{k:18}: {v}")
    return r

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Использование: python3 blind_halfloop.py <файл>")
        print("Или передай hex-строку через stdin")
        sys.exit(1)

    analyze_file(sys.argv[1])