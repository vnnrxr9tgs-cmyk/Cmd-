/**
 * Local AI Chat — frontend v3.25
 * + Идентификация: cookie client_id (ставит backend)
 * + Батчинг DOM через requestAnimationFrame
 * + Безопасный resetModalState перед открытием
 */

// ========== DOM ==========
const messagesContainer = document.getElementById('messages');
const userInput         = document.getElementById('user-input');
const sendBtn           = document.getElementById('send-btn');
const stopBtn           = document.getElementById('stop-generation-btn');
const statusDiv         = document.getElementById('status');
const contextCountSpan  = document.getElementById('context-count');
const modelSelect       = document.getElementById('model-select');
const systemPrompt      = document.getElementById('system-prompt');
const promptPreset      = document.getElementById('prompt-preset');
const temperature       = document.getElementById('temperature');
const topP              = document.getElementById('top-p');
const topK              = document.getElementById('top-k');
const frequencyPenalty  = document.getElementById('frequency-penalty');
const presencePenalty   = document.getElementById('presence-penalty');
const repeatPenalty     = document.getElementById('repeat-penalty');
const maxTokens         = document.getElementById('max-tokens');
const seedInput         = document.getElementById('seed');
const soundToggle       = document.getElementById('sound-toggle');
const notifToggle       = document.getElementById('notif-toggle');
const modelBadge        = document.getElementById('model-badge');
const currentChatTitle  = document.getElementById('currentChatTitle');
const chatsList         = document.getElementById('chatsList');
const visionHint        = document.getElementById('vision-hint');

const pendingAttachments = document.getElementById('pendingAttachments');

const imageInput            = document.getElementById('imageInput');
const uploadImageBtn        = document.getElementById('uploadImageBtn');
const imagePreviewContainer = document.getElementById('imagePreviewContainer');
const imagePreview          = document.getElementById('imagePreview');
const removeImageBtn        = document.getElementById('removeImageBtn');
const imageInfo             = document.getElementById('imageInfo');
const imageUploadArea       = document.getElementById('imageUploadArea');

const appEl            = document.getElementById('app');
const mainArea         = document.getElementById('mainArea');
const dropOverlay      = document.getElementById('dropOverlay');
const openSidebarBtn   = document.getElementById('openSidebarBtn');
const sidebarClose     = document.getElementById('sidebarClose');
const drawerMenu       = document.getElementById('drawerMenu');
const openDrawerBtn    = document.getElementById('openDrawerBtn');
const drawerClose      = document.getElementById('drawerClose');
const drawerOverlay    = document.getElementById('drawerOverlay');
const advancedToggle   = document.getElementById('advancedToggle');
const newChatBtn       = document.getElementById('newChatBtn');
const newTempChatBtn   = document.getElementById('newTempChatBtn');
const newArenaChatBtn  = document.getElementById('newArenaChatBtn');
const exportChatBtn    = document.getElementById('exportChatBtn');
const clearAllChatsBtn = document.getElementById('clearAllChatsBtn');
const clearChatBtn     = document.getElementById('clear-chat-btn');
const resetSettingsBtn = document.getElementById('reset-settings-btn');

const tempBadgeWrap    = document.getElementById('tempBadgeWrap');
const promoteTempBtn   = document.getElementById('promoteTempBtn');
const closeTempBtn     = document.getElementById('closeTempBtn');

const lightboxEl    = document.getElementById('lightbox');
const lightboxImg   = document.getElementById('lightboxImg');
const lightboxClose = document.getElementById('lightboxClose');

const modalOverlay = document.getElementById('modalOverlay');
const modalBox     = document.getElementById('modalBox');
const modalIcon    = document.getElementById('modalIcon');
const modalTitle   = document.getElementById('modalTitle');
const modalMessage = document.getElementById('modalMessage');
const modalActions = document.getElementById('modalActions');

// Arena
const arenaScreen   = document.getElementById('arenaScreen');
const arenaContent  = document.getElementById('arenaContent');
const arenaModelA   = document.getElementById('arenaModelA');
const arenaModelB   = document.getElementById('arenaModelB');
const arenaCfgA     = document.getElementById('arenaCfgA');
const arenaCfgB     = document.getElementById('arenaCfgB');
const arenaQuestion = document.getElementById('arenaQuestion');
const arenaRunBtn   = document.getElementById('arenaRunBtn');
const arenaCloseBtn = document.getElementById('arenaCloseBtn');

// Arena image
const arenaAttachBtn    = document.getElementById('arenaAttachBtn');
const arenaAttachRow    = document.getElementById('arenaAttachRow');
const arenaAttachImg    = document.getElementById('arenaAttachImg');
const arenaAttachName   = document.getElementById('arenaAttachName');
const arenaAttachSize   = document.getElementById('arenaAttachSize');
const arenaAttachRemove = document.getElementById('arenaAttachRemove');
const arenaAttachHint   = document.getElementById('arenaAttachHint');
const arenaImageInput   = document.getElementById('arenaImageInput');

// ========== STATE ==========
let modelsInfo = [];
let currentImageBase64 = null;
let currentImageMimeType = null;
let currentImageFull = null;
let currentImageThumb = null;
let currentImageName = '';
let currentImageSize = 0;
let activeRequest = false;
let currentAbortController = null;
let isAdvancedOpen = localStorage.getItem('advanced_open') === 'true';

const arenaState = {
    active: false,
    modelA: '',
    modelB: '',
    settingsA: null,
    settingsB: null,
    mergeSettings: null,
    mergePrompt: null,
    rounds: [],
};

const DEFAULT_ARENA_SETTINGS = () => ({
    temperature: 0.7,
    top_p: 0.9,
    top_k: 50,
    max_tokens: 2048,
    frequency_penalty: 0.0,
    presence_penalty: 0.0,
    repeat_penalty: 1.0,
    seed: '',
    system_prompt: 'Ты полезный ассистент. Отвечай чётко и по существу.',
});

const DEFAULT_ARENA_PROMPT = `Ты — арбитр. Ниже два ответа на один и тот же вопрос от разных моделей.
Собери из них ОДИН лучший ответ: возьми лучшее из каждого, устрани противоречия, не дублируйся, сохрани структуру (списки, код, таблицы).

Если оба ответа совпадают — просто отдай наиболее полный.
Не упоминай, что это объединение, не ссылайся на "модель A" и "модель B". Просто дай финальный ответ.

Вопрос:
{question}

Ответ A ({model_a}):
{answer_a}

Ответ B ({model_b}):
{answer_b}`;

let audioCtx = null;
let soundEnabled = true;
let notifEnabled = true;
let notificationPermissionGranted = false;

const STORAGE_KEY = 'local_ai_chats_v3';
const OLD_STORAGE_KEY = 'local_ai_chats_v2';
let chats = [];
let currentChatId = null;

let cancelAttempts = [];
let isBlocked = false;
let blockEndTime = null;
const CANCEL_WINDOW_MS = 30000;
const CANCEL_MAX = 3;
const BLOCK_MS = 45000;
const REQUEST_TIMEOUT_MS = 15 * 60 * 1000;

let dragCounter = 0;
const FILE_MAX_BYTES = 5 * 1024 * 1024;
const TEXT_MAX_CHARS = 100000;

// ========== БАТЧИНГ DOM (rAF) ==========
const rafScheduler = (() => {
    const pending = new Map();
    let scheduled = false;

    function flush() {
        scheduled = false;
        const jobs = Array.from(pending.values());
        pending.clear();
        jobs.forEach(fn => { try { fn(); } catch (e) { console.error(e); } });
    }

    return {
        schedule(key, fn) {
            pending.set(key, fn);
            if (!scheduled) {
                scheduled = true;
                requestAnimationFrame(flush);
            }
        },
    };
})();

// ========== МОДАЛЬНОЕ ОКНО ==========
let modalResolve = null;

function resetModalState() {
    if (modalResolve) { try { modalResolve(null); } catch (_) {} modalResolve = null; }
    modalOverlay.classList.remove('open');
    modalActions.innerHTML = '';
    modalMessage.innerHTML = '';
    modalMessage.style.textAlign = '';
    modalMessage.style.whiteSpace = '';
    modalBox.classList.remove('danger', 'purple');
    modalOverlay.onclick = null;
    document.body.style.overflow = '';
}

function openModal(opts = {}) {
    return new Promise((resolve) => {
        resetModalState();
        modalResolve = resolve;
        const {
            title = 'Подтверждение',
            message = '',
            icon = 'fa-exclamation-triangle',
            tone = 'default',
            buttons = [
                { id: 'cancel', text: 'Отмена' },
                { id: 'ok', text: 'OK', autofocus: true },
            ],
        } = opts;

        modalTitle.textContent = title;
        modalMessage.textContent = message;
        modalBox.classList.toggle('danger', tone === 'danger');
        modalBox.classList.toggle('purple', tone === 'purple');
        modalIcon.innerHTML = `<i class="fas ${icon}"></i>`;

        modalActions.innerHTML = '';
        buttons.forEach(btn => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'modal-btn';
            b.dataset.id = btn.id;
            b.textContent = btn.text;
            b.addEventListener('click', () => finish(btn.id));
            modalActions.appendChild(b);
        });

        modalOverlay.classList.add('open');
        document.body.style.overflow = 'hidden';
        const focusBtn = buttons.find(b => b.autofocus);
        if (focusBtn) {
            const el = modalActions.querySelector(`[data-id="${focusBtn.id}"]`);
            if (el) setTimeout(() => el.focus(), 60);
        }

        function finish(value) {
            modalOverlay.classList.remove('open');
            document.body.style.overflow = '';
            modalActions.innerHTML = '';
            modalOverlay.onclick = null;
            document.removeEventListener('keydown', keyHandler);
            modalResolve = null;
            resolve(value);
        }
        function keyHandler(e) {
            if (!modalOverlay.classList.contains('open')) return;
            if (e.key === 'Escape') { e.preventDefault(); finish('cancel'); }
            else if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
                const primary = buttons.find(b => b.autofocus) || buttons[buttons.length - 1];
                if (primary) { e.preventDefault(); finish(primary.id); }
            }
        }
        modalOverlay.onclick = (e) => { if (e.target === modalOverlay) finish('cancel'); };
        document.addEventListener('keydown', keyHandler);
    });
}

function showConfirm(message, options = {}) {
    const { title = 'Подтверждение', okText = 'Да', cancelText = 'Нет',
            danger = true, icon = 'fa-exclamation-triangle', tone } = options;
    const finalTone = tone || (danger ? 'danger' : 'default');
    return openModal({
        title, message, icon, tone: finalTone,
        buttons: [
            { id: 'cancel', text: cancelText },
            { id: 'ok', text: okText, autofocus: true },
        ],
    }).then(id => id === 'ok');
}

// ========== ПРЕСЕТЫ ==========
const PROMPT_PRESETS = {
    translator: `Ты профессиональный переводчик.\n\nПРАВИЛА:\n- Определяй язык исходного текста автоматически.\n- Сохраняй стиль и тон оригинала.\n- Никаких пояснений, только перевод.`,
    programmer: `Ты опытный программист-эксперт.\n\nПРАВИЛА:\n- Рабочие, идиоматичные решения.\n- Сложный код — с короткими комментариями.\n- Если видишь баг — предупреди.`,
    analyst: `Ты профессиональный аналитик.\n\nПРАВИЛА:\n- Отделяй факты от интерпретаций.\n- Структурируй ответы: списки, таблицы.\n- Не выдумывай цифры.`,
    editor: `Ты опытный редактор.\n\nПРАВИЛА:\n- Убирай воду, канцелярит, тавтологии.\n- Показывай готовый результат сразу.`,
    teacher: `Ты терпеливый преподаватель.\n\nПРАВИЛА:\n- Объясняй пошагово.\n- В конце давай 1–2 вопроса для самопроверки.`,
    default: `Ты полезный ассистент. Отвечай чётко и по существу. Используй markdown для структуры, кода и списков.`,
};

// ========== UTILS ==========
function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function showToast(msg, type = 'info') {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.className = 'toast show' + (type === 'error' ? ' error' : type === 'success' ? ' success' : '');
    setTimeout(() => el.classList.remove('show'), 2800);
}

function setStatus(text, isError = false, isBusy = false) {
    const textEl = statusDiv.querySelector('.status-text') || statusDiv;
    if (textEl.classList && textEl.classList.contains('status-text')) {
        textEl.textContent = text;
    } else {
        const spans = statusDiv.querySelectorAll('span');
        if (spans.length > 1) spans[1].textContent = text;
    }
    statusDiv.classList.toggle('error', !!isError);
    statusDiv.classList.toggle('busy', !!isBusy);
}

function escapeHtml(text) {
    if (!text) return '';
    const d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
}

function copyToClipboard(text) {
    const showCopied = () => {
        const n = document.getElementById('copy-notification');
        if (n) {
            n.classList.add('show');
            setTimeout(() => n.classList.remove('show'), 1800);
        }
    };
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(showCopied).catch(() => fallbackCopy(text, showCopied));
        return;
    }
    fallbackCopy(text, showCopied);
}

function fallbackCopy(text, onSuccess) {
    try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.top = '0';
        ta.style.left = '0';
        ta.style.width = '1px';
        ta.style.height = '1px';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        ta.setSelectionRange(0, ta.value.length);
        const ok = document.execCommand('copy');
        document.body.removeChild(ta);
        if (ok && typeof onSuccess === 'function') onSuccess();
        else if (!ok) showToast('Не удалось скопировать', 'error');
    } catch (e) { showToast('Не удалось скопировать', 'error'); }
}

function formatBytes(bytes) {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} Б`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
    return `${(bytes / 1024 / 1024).toFixed(2)} МБ`;
}

// ========== ПРИВЛЕЧЕНИЕ ВНИМАНИЯ ==========
let titleFlashInterval = null;
let originalTitle = document.title;

function flashWindowAttention() {
    try { window.focus(); } catch (_) {}
    if (titleFlashInterval) return;
    let on = false;
    originalTitle = document.title;
    titleFlashInterval = setInterval(() => {
        on = !on;
        document.title = on ? '⬇ Отпустите файл в окне' : originalTitle;
    }, 600);
}
function stopFlashWindowAttention() {
    if (titleFlashInterval) {
        clearInterval(titleFlashInterval);
        titleFlashInterval = null;
    }
    document.title = originalTitle;
}

// ========== ЗВУК ==========
function ensureAudioContext() {
    try {
        if (!audioCtx) {
            const Ctx = window.AudioContext || window.webkitAudioContext;
            if (!Ctx) return null;
            audioCtx = new Ctx();
        }
        if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
        return audioCtx;
    } catch (_) { return null; }
}

function playDoneSound() {
    if (!soundEnabled) return;
    const ctx = ensureAudioContext();
    if (!ctx) return;
    try {
        const now = ctx.currentTime;
        const master = ctx.createGain();
        master.gain.value = 0.18;
        master.connect(ctx.destination);
        [
            { freq: 659.25, start: 0.00, dur: 0.35 },
            { freq: 880.00, start: 0.10, dur: 0.55 },
        ].forEach(t => {
            const osc = ctx.createOscillator();
            osc.type = 'sine';
            osc.frequency.value = t.freq;
            const g = ctx.createGain();
            g.gain.setValueAtTime(0.0001, now + t.start);
            g.gain.linearRampToValueAtTime(1, now + t.start + 0.012);
            g.gain.exponentialRampToValueAtTime(0.0001, now + t.start + t.dur);
            osc.connect(g); g.connect(master);
            osc.start(now + t.start);
            osc.stop(now + t.start + t.dur + 0.05);
        });
    } catch (_) {}
}

async function ensureNotificationPermission() {
    if (!notifEnabled) return false;
    if (!('Notification' in window)) return false;
    if (Notification.permission === 'granted') { notificationPermissionGranted = true; return true; }
    if (Notification.permission === 'denied') { notificationPermissionGranted = false; return false; }
    try {
        const p = await Notification.requestPermission();
        notificationPermissionGranted = (p === 'granted');
        return notificationPermissionGranted;
    } catch (_) { notificationPermissionGranted = false; return false; }
}

function showNativeNotification(title, body) {
    if (!notifEnabled) return;
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;
    try {
        const n = new Notification(title, { body, tag: 'local-ai-done', silent: true });
        n.onclick = () => { window.focus(); n.close(); };
        setTimeout(() => { try { n.close(); } catch (_) {} }, 5000);
    } catch (_) {}
}

function removeTrayNotification() {
    const el = document.getElementById('tray-notification');
    if (!el) return;
    el.classList.remove('show');
    setTimeout(() => { if (el.parentNode) el.remove(); }, 320);
}

function showTrayNotification(title, body) {
    removeTrayNotification();
    const el = document.createElement('div');
    el.id = 'tray-notification';
    el.className = 'tray-notification';
    el.innerHTML = `
        <div class="tray-icon"><i class="fas fa-robot"></i></div>
        <div class="tray-content">
            <div class="tray-title"></div>
            <div class="tray-body"></div>
        </div>
        <button class="tray-close" title="Закрыть"><i class="fas fa-times"></i></button>
    `;
    el.querySelector('.tray-title').textContent = title;
    el.querySelector('.tray-body').textContent = body;
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    let closed = false;
    const close = () => {
        if (closed) return;
        closed = true;
        el.classList.remove('show');
        setTimeout(() => { if (el.parentNode) el.remove(); }, 320);
    };
    el.querySelector('.tray-close').addEventListener('click', (e) => { e.stopPropagation(); close(); });
    el.addEventListener('click', (e) => {
        if (e.target.closest('.tray-close')) return;
        try { window.focus(); } catch (_) {}
        close();
    });
    let autoTimer = setTimeout(close, 5000);
    el.addEventListener('mouseenter', () => clearTimeout(autoTimer));
    el.addEventListener('mouseleave', () => { if (!closed) autoTimer = setTimeout(close, 2000); });
}

function onModelFinished(previewText) {
    playDoneSound();
    if (!notifEnabled) return;
    const title = 'Готово';
    const raw = (previewText || '').replace(/\s+/g, ' ').trim();
    const body = raw ? (raw.slice(0, 120) + (raw.length > 120 ? '…' : '')) : 'Модель закончила отвечать';
    const awayFromPage = document.hidden || !document.hasFocus();
    if (awayFromPage && notificationPermissionGranted) showNativeNotification(title, body);
    else showTrayNotification(title, body);
}

// ========== LIGHTBOX ==========
function openLightbox(src) {
    if (!lightboxEl || !lightboxImg || !src) return;
    lightboxImg.src = src;
    lightboxEl.classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeLightbox() {
    if (!lightboxEl) return;
    lightboxEl.classList.remove('open');
    document.body.style.overflow = '';
    setTimeout(() => {
        if (lightboxImg && !lightboxEl.classList.contains('open')) lightboxImg.src = '';
    }, 220);
}
function initLightbox() {
    if (!lightboxEl) return;
    lightboxEl.addEventListener('click', (e) => {
        if (e.target === lightboxEl || e.target === lightboxImg) closeLightbox();
    });
    if (lightboxClose) {
        lightboxClose.addEventListener('click', (e) => { e.stopPropagation(); closeLightbox(); });
    }
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && lightboxEl.classList.contains('open')) closeLightbox();
    });
}

// ========== MARKDOWN ==========
function formatMessageWithCode(text) {
    if (!text) return '';
    const codeBlocks = [];
    let processed = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
        const id = codeBlocks.length;
        codeBlocks.push({ lang: lang || 'plaintext', code: code.trimEnd() });
        return `\n%%CODEBLOCK_${id}%%\n`;
    });
    processed = processed.replace(/<br\s*\/?>/gi, '%%BR%%');
    processed = escapeHtml(processed);
    processed = processed.replace(/%%BR%%/g, '<br>');
    processed = processed.replace(/`([^`\n]+)`/g, '<code class="inline">$1</code>');
    processed = processed.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    processed = processed.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    processed = processed.replace(/\*(.+?)\*/g, '<em>$1</em>');
    processed = processed.replace(/__(.+?)__/g, '<strong>$1</strong>');
    processed = processed.replace(/_(.+?)_/g, '<em>$1</em>');
    processed = processed.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

    processed = processed.replace(
        /(?:^|\n)(\|.+\|)[ \t]*\n(\|[\s\-:|]+\|)[ \t]*\n((?:\|.+\|[ \t]*(?:\n|$))+)/g,
        (match, headerLine, sepLine, bodyBlock) => {
            const splitRow = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim());
            const sepCells = splitRow(sepLine);
            const isSep = sepCells.every(c => /^:?-{2,}:?$/.test(c));
            if (!isSep) return match;
            const headers = splitRow(headerLine);
            const aligns = sepCells.map(c => {
                const left = c.startsWith(':'), right = c.endsWith(':');
                if (left && right) return 'center';
                if (right) return 'right';
                if (left) return 'left';
                return '';
            });
            const rows = bodyBlock.trim().split('\n').map(splitRow);
            const styleAlign = (a) => a ? ` style="text-align:${a}"` : '';
            let html = '<div class="md-table-wrap"><table class="md-table"><thead><tr>';
            headers.forEach((h, i) => { html += `<th${styleAlign(aligns[i])}>${h}</th>`; });
            html += '</tr></thead><tbody>';
            rows.forEach(r => {
                html += '<tr>';
                for (let i = 0; i < headers.length; i++) {
                    const cell = r[i] != null ? r[i] : '';
                    html += `<td${styleAlign(aligns[i])}>${cell}</td>`;
                }
                html += '</tr>';
            });
            html += '</tbody></table></div>';
            return '\n' + html + '\n';
        }
    );

    processed = processed.replace(/(?:^|\n)([-*] .+(?:\n[-*] .+)*)/g, (block) => {
        const items = block.trim().split(/\n/).map(l => l.replace(/^[-*] /, '').trim());
        return '<ul>' + items.map(i => `<li>${i}</li>`).join('') + '</ul>';
    });
    processed = processed.replace(/(?:^|\n)(\d+\. .+(?:\n\d+\. .+)*)/g, (block) => {
        const items = block.trim().split(/\n/).map(l => l.replace(/^\d+\. /, '').trim());
        return '<ol>' + items.map(i => `<li>${i}</li>`).join('') + '</ol>';
    });

    const parts = processed.split(/\n{2,}/);
    processed = parts.map(p => {
        p = p.trim();
        if (!p) return '';
        if (p.startsWith('<ul>') || p.startsWith('<ol>') || p.startsWith('%%CODEBLOCK_')
            || p.startsWith('<div class="md-table-wrap">')) return p;
        return '<p>' + p.replace(/\n/g, '<br>') + '</p>';
    }).join('');

    codeBlocks.forEach((cb, i) => {
        const html = `
            <div class="code-container">
                <div class="code-header">
                    <div class="code-lang"><i class="fas fa-code"></i> ${escapeHtml(cb.lang.toUpperCase())}</div>
                    <button class="copy-code-btn" type="button"><i class="fas fa-copy"></i> Копировать</button>
                </div>
                <pre class="code-block"><code class="language-${escapeHtml(cb.lang)}">${escapeHtml(cb.code)}</code></pre>
            </div>`;
        processed = processed.replace(`%%CODEBLOCK_${i}%%`, html);
    });
    return processed;
}

function addCopyButtonsToCodeBlocks(container) {
    if (!container) return;
    container.querySelectorAll('.code-container').forEach(box => {
        if (box.querySelector('.copy-code-btn')?.dataset.bound) return;
        const btn = box.querySelector('.copy-code-btn');
        const code = box.querySelector('pre code');
        if (btn && code) {
            btn.dataset.bound = '1';
            btn.onclick = (e) => { e.stopPropagation(); copyToClipboard(code.innerText); };
        }
    });
}

function highlightCode(container) {
    if (!container || !window.hljs) return;
    container.querySelectorAll('pre code').forEach(block => {
        try { hljs.highlightElement(block); } catch (_) {}
    });
}

// ========== МИГРАЦИЯ ==========
function migrateOldStorage() {
    try {
        const old = localStorage.getItem(OLD_STORAGE_KEY);
        if (!old) return;
        if (localStorage.getItem(STORAGE_KEY)) return;
        const data = JSON.parse(old);
        const newChats = (data.chats || []).map(c => ({
            id: c.id, title: c.title, created: c.created, updated: c.updated,
            favorite: false, temporary: false,
            history: (c.history || []).map(m => {
                if (m.role === 'assistant') {
                    return {
                        role: 'assistant',
                        variants: [{ content: m.content || '', reasoning: '', stats: null, createdAt: Date.now() }],
                        activeVariant: 0,
                    };
                }
                return m;
            })
        }));
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ chats: newChats, currentChatId: data.currentChatId }));
    } catch (_) {}
}

function stripImageMarker(content) {
    if (typeof content !== 'string') return content || '';
    return content
        .replace(/\n?🖼️ Изображение прикреплено\s*$/g, '')
        .replace(/^🖼️ Анализ изображения\s*$/g, '')
        .trim();
}

function normalizeHistory(history) {
    return (history || []).map(m => {
        if (m.role === 'divider') return { role: 'divider', type: m.type || 'model', text: m.text || '' };
        if (m.role === 'assistant') {
            if (Array.isArray(m.variants) && m.variants.length) {
                return { ...m, variants: m.variants.map(v => ({ ...v, streaming: false })) };
            }
            return {
                role: 'assistant',
                variants: [{ content: m.content || '', reasoning: '', stats: null, createdAt: Date.now() }],
                activeVariant: 0,
            };
        }
        const img = m.image || null;
        return {
            role: 'user',
            content: stripImageMarker(m.content || ''),
            image: img ? { thumb: img.thumb || null, full: img.full || null } : null,
        };
    });
}

// ========== MULTI-CHAT ==========
function sortChats() {
    chats.sort((a, b) => {
        const af = a.favorite ? 1 : 0;
        const bf = b.favorite ? 1 : 0;
        if (af !== bf) return bf - af;
        return (b.updated || b.created || 0) - (a.updated || a.created || 0);
    });
}

function loadChatsFromStorage() {
    migrateOldStorage();
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
            const data = JSON.parse(raw);
            chats = (data.chats || []).filter(c => !c.temporary).map(c => ({
                ...c, favorite: !!c.favorite, temporary: false,
                history: normalizeHistory(c.history),
            }));
            currentChatId = data.currentChatId || null;
        }
    } catch (_) { chats = []; currentChatId = null; }
    if (!chats.length) {
        const newChat = {
            id: uid(), title: 'Новый чат',
            created: Date.now(), updated: Date.now(),
            favorite: false, temporary: false, history: [],
        };
        chats.unshift(newChat);
        currentChatId = newChat.id;
    } else if (!currentChatId || !chats.find(c => c.id === currentChatId)) {
        currentChatId = chats[0].id;
    }
    sortChats();
    saveChatsToStorage();
}

function chatsForStorage() {
    return chats.filter(c => !c.temporary).map(c => ({
        ...c, favorite: !!c.favorite, temporary: false,
        history: (c.history || []).map(m => {
            if (m.role === 'user' && m.image) return { ...m, image: { thumb: m.image.thumb || null } };
            return m;
        })
    }));
}

function saveChatsToStorage() {
    try {
        const current = chats.find(c => c.id === currentChatId);
        const persistCurrentId = (current && !current.temporary) ? currentChatId : null;
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
            chats: chatsForStorage(), currentChatId: persistCurrentId,
        }));
    } catch (e) { showToast('Не удалось сохранить', 'error'); }
}

function getCurrentChat() { return chats.find(c => c.id === currentChatId) || null; }
function getTemporaryChat() { return chats.find(c => c.temporary) || null; }

function ensureCurrentChat() {
    let chat = getCurrentChat();
    if (chat) return chat;
    if (chats.length) {
        currentChatId = chats[0].id;
        saveChatsToStorage();
        return chats[0];
    }
    return createNewChat(true);
}

function createNewChat(switchTo = true) {
    const chat = {
        id: uid(), title: 'Новый чат',
        created: Date.now(), updated: Date.now(),
        favorite: false, temporary: false, history: [],
    };
    chats.unshift(chat);
    if (switchTo) {
        currentChatId = chat.id;
        renderMessages(); updateChatTitle(); updateTempModeUI();
    }
    sortChats(); saveChatsToStorage(); renderChatsList();
    return chat;
}

function openOrCreateTemporaryChat() {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const existing = getTemporaryChat();
    if (existing) { switchChat(existing.id); showToast('Временный чат открыт', 'info'); return; }
    const chat = {
        id: uid(), title: 'Временный чат',
        created: Date.now(), updated: Date.now(),
        favorite: false, temporary: true, history: [],
    };
    chats.unshift(chat);
    currentChatId = chat.id;
    renderMessages(); updateChatTitle(); updateTempModeUI();
    saveChatsToStorage(); renderChatsList();
    showToast('Временный чат создан', 'success');
}

async function promoteTemporaryChat() {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    if (!chat || !chat.temporary) return;
    const ok = await showConfirm(
        'Сохранить временный чат?\n\nОн появится в списке чатов.',
        { title: 'Сохранить чат', okText: 'Сохранить', cancelText: 'Отмена',
          danger: false, tone: 'purple', icon: 'fa-bookmark' }
    );
    if (!ok) return;
    chat.temporary = false;
    chat.updated = Date.now();
    if (chat.title === 'Временный чат' && chat.history.length) {
        const firstUser = chat.history.find(m => m.role === 'user');
        if (firstUser) {
            let t = (firstUser.content || '').trim();
            if (!t && firstUser.image) t = '🖼️ Изображение';
            t = t.slice(0, 42) + (t.length > 42 ? '…' : '');
            if (t) chat.title = t;
        }
    } else if (!chat.history.length) chat.title = 'Новый чат';
    updateTempModeUI(); updateChatTitle(); sortChats();
    saveChatsToStorage(); renderChatsList();
    showToast('Чат сохранён как обычный', 'success');
}

async function closeTemporaryChat(skipConfirm = false) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    if (!chat || !chat.temporary) return;
    if (!skipConfirm) {
        const ok = await showConfirm(
            'Закрыть временный чат?\n\nДиалог будет удалён.',
            { title: 'Закрыть временный чат', okText: 'Закрыть', cancelText: 'Отмена', danger: true, icon: 'fa-clock' }
        );
        if (!ok) return;
    }
    chats = chats.filter(c => c.id !== chat.id);
    if (chats.length) {
        const target = chats.find(c => !c.temporary) || chats[0];
        currentChatId = target.id;
    } else {
        const newChat = {
            id: uid(), title: 'Новый чат',
            created: Date.now(), updated: Date.now(),
            favorite: false, temporary: false, history: [],
        };
        chats.unshift(newChat);
        currentChatId = newChat.id;
    }
    saveChatsToStorage(); renderMessages(); updateChatTitle(); updateTempModeUI();
    renderChatsList(); updateContextCount();
    showToast('Временный чат закрыт', 'success');
}

function switchChat(id) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    currentChatId = id;
    saveChatsToStorage(); renderMessages(); updateChatTitle(); updateTempModeUI(); renderChatsList();
    if (window.innerWidth <= 900) appEl.classList.add('sidebar-collapsed');
}

function toggleFavorite(id, e) {
    if (e) e.stopPropagation();
    const chat = chats.find(c => c.id === id);
    if (!chat) return;
    chat.favorite = !chat.favorite;
    sortChats(); saveChatsToStorage(); renderChatsList();
    showToast(chat.favorite ? 'Добавлено в избранное' : 'Убрано из избранного', 'success');
}

async function requestDeleteChat(id, e) {
    if (e) e.stopPropagation();
    const chat = chats.find(c => c.id === id);
    if (!chat) return;
    if (chat.favorite) { showToast('Сначала уберите из избранного', 'error'); return; }
    const ok = await showConfirm(`Удалить чат "${chat.title || 'Новый чат'}"?`,
        { title: 'Удаление чата', okText: 'Да', cancelText: 'Нет', danger: true, icon: 'fa-trash-alt' });
    if (!ok) return;
    if (chats.length <= 1) {
        chat.history = []; chat.title = 'Новый чат'; chat.updated = Date.now();
        currentChatId = chat.id;
        saveChatsToStorage(); renderMessages(); updateChatTitle(); renderChatsList();
        return;
    }
    chats = chats.filter(c => c.id !== id);
    if (currentChatId === id) {
        const next = chats.find(c => !c.temporary) || chats[0];
        currentChatId = next.id;
    }
    sortChats(); saveChatsToStorage(); renderMessages();
    updateChatTitle(); updateTempModeUI(); renderChatsList();
}

function startRenameChat(id, e) {
    if (e) e.stopPropagation();
    const chat = chats.find(c => c.id === id);
    if (!chat) return;
    const el = chatsList.querySelector(`.chat-item[data-id="${id}"]`);
    if (!el) return;
    const titleSpan = el.querySelector('.chat-title');
    if (!titleSpan || el.querySelector('.chat-title-input')) return;
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'chat-title-input';
    input.value = chat.title === 'Новый чат' ? '' : chat.title;
    input.maxLength = 80;
    titleSpan.replaceWith(input);
    input.focus(); input.select();
    let finished = false;
    const finish = (save) => {
        if (finished) return;
        finished = true;
        if (save) {
            const val = input.value.trim();
            if (val && val !== chat.title) {
                chat.title = val.slice(0, 80);
                chat.updated = Date.now();
                saveChatsToStorage();
                if (currentChatId === id) updateChatTitle();
                sortChats();
            }
        }
        renderChatsList();
    };
    input.addEventListener('click', (ev) => ev.stopPropagation());
    input.addEventListener('keydown', (ev) => {
        ev.stopPropagation();
        if (ev.key === 'Enter') { ev.preventDefault(); finish(true); }
        else if (ev.key === 'Escape') { ev.preventDefault(); finish(false); }
    });
    input.addEventListener('blur', () => finish(true));
}

function updateChatTitleFromHistory() {
    const chat = getCurrentChat();
    if (!chat || !chat.history.length) return;
    if (chat.title !== 'Новый чат' && chat.title !== 'Временный чат') return;
    const firstUser = chat.history.find(m => m.role === 'user');
    if (firstUser) {
        let t = (firstUser.content || '').trim();
        if (!t && firstUser.image) t = '🖼️ Изображение';
        t = t.slice(0, 42) + (t.length > 42 ? '…' : '');
        chat.title = t || (chat.temporary ? 'Временный чат' : 'Новый чат');
        chat.updated = Date.now();
        sortChats(); saveChatsToStorage(); updateChatTitle(); renderChatsList();
    }
}

function updateChatTitle() {
    const chat = getCurrentChat();
    currentChatTitle.textContent = chat ? (chat.title || '💬 Чат') : '💬 Чат';
}

function updateTempModeUI() {
    const chat = getCurrentChat();
    const isTemp = !!(chat && chat.temporary);
    if (mainArea) mainArea.classList.toggle('temp-mode', isTemp);
    if (tempBadgeWrap) tempBadgeWrap.classList.toggle('visible', isTemp);
}

function renderChatsList() {
    if (!chatsList) return;
    chatsList.innerHTML = '';
    const visibleChats = chats.filter(c => !c.temporary);
    sortChats();
    visibleChats.forEach(chat => {
        const el = document.createElement('div');
        el.className = 'chat-item' + (chat.id === currentChatId ? ' active' : '') + (chat.favorite ? ' favorite' : '');
        el.dataset.id = chat.id;
        el.onclick = () => switchChat(chat.id);
        const date = new Date(chat.updated || chat.created);
        const dateStr = date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
        const favTitle = chat.favorite ? 'Убрать из избранного' : 'В избранное';
        const deleteBtnHtml = chat.favorite
            ? `<button class="chat-lock" title="Чат в избранном"><i class="fas fa-lock"></i></button>`
            : `<button class="chat-delete" title="Удалить"><i class="fas fa-trash-alt"></i></button>`;
        el.innerHTML = `
            <button class="chat-fav-btn" title="${favTitle}"><i class="fas fa-star"></i></button>
            <span class="chat-title">${escapeHtml(chat.title)}</span>
            <span class="chat-date">${dateStr}</span>
            <button class="chat-rename" title="Переименовать"><i class="fas fa-pencil-alt"></i></button>
            ${deleteBtnHtml}
        `;
        el.querySelector('.chat-fav-btn').onclick = (ev) => toggleFavorite(chat.id, ev);
        el.querySelector('.chat-rename').onclick = (ev) => startRenameChat(chat.id, ev);
        const delBtn = el.querySelector('.chat-delete');
        if (delBtn) delBtn.onclick = (ev) => requestDeleteChat(chat.id, ev);
        const lockBtn = el.querySelector('.chat-lock');
        if (lockBtn) lockBtn.onclick = (ev) => { ev.stopPropagation(); showToast('Сначала уберите из избранного', 'info'); };
        chatsList.appendChild(el);
    });
}

function updateContextCount() {
    const chat = getCurrentChat();
    if (!chat) { if (contextCountSpan) contextCountSpan.textContent = 0; return; }
    const n = (chat.history || []).filter(m => m.role === 'user' || m.role === 'assistant').length;
    if (contextCountSpan) contextCountSpan.textContent = n;
}

// ========== ОЧИСТКА РАЗДЕЛИТЕЛЕЙ ==========
function cleanupDividers(chat) {
    if (!chat || !Array.isArray(chat.history)) return false;
    const h = chat.history;
    let startIdx = 0;
    while (startIdx < h.length && h[startIdx].role === 'divider') startIdx++;
    let endIdx = h.length - 1;
    while (endIdx >= 0 && h[endIdx].role === 'divider') endIdx--;
    if (startIdx > 0 || endIdx < h.length - 1) chat.history = h.slice(startIdx, endIdx + 1);
    return chat.history.length !== h.length;
}

function historyForApi(history) {
    const out = [];
    for (const m of history) {
        if (m.role === 'user') out.push({ role: 'user', content: m.content || '' });
        else if (m.role === 'assistant') {
            const v = m.variants?.[m.activeVariant];
            if (v && v.content) out.push({ role: 'assistant', content: v.content });
        }
    }
    return out;
}

function hasAssistantAfter(chat, userIdx) {
    if (!chat) return false;
    for (let i = userIdx + 1; i < chat.history.length; i++) {
        const r = chat.history[i].role;
        if (r === 'assistant') return true;
        if (r === 'user') return false;
    }
    return false;
}

// ========== PENDING ATTACHMENT ==========
function renderPendingAttachment() {
    if (!pendingAttachments) return;
    if (!currentImageBase64) {
        pendingAttachments.style.display = 'none';
        pendingAttachments.innerHTML = '';
        return;
    }
    const name = currentImageName || 'изображение.jpg';
    const sizeStr = currentImageSize ? formatBytes(currentImageSize) : '';
    const thumb = currentImageThumb || currentImageFull || '';
    pendingAttachments.style.display = 'flex';
    pendingAttachments.innerHTML = `
        <div class="pending-attachment">
            <img src="${thumb}" alt="">
            <div class="pending-attachment-info">
                <span class="pending-attachment-name"></span>
                <span class="pending-attachment-size">${escapeHtml(sizeStr)}</span>
            </div>
            <span class="pending-attachment-badge">IMG</span>
            <button class="pending-attachment-remove" title="Убрать"><i class="fas fa-times"></i></button>
        </div>
    `;
    pendingAttachments.querySelector('.pending-attachment-name').textContent = name;
    pendingAttachments.querySelector('img').addEventListener('click', (e) => {
        e.stopPropagation();
        openLightbox(currentImageFull || currentImageThumb);
    });
    pendingAttachments.querySelector('.pending-attachment-remove').addEventListener('click', (e) => {
        e.stopPropagation();
        removeImage();
    });
}

function renderArenaAttachment() {
    if (!arenaAttachRow) return;
    if (!currentImageBase64) {
        arenaAttachRow.style.display = 'none';
        if (arenaAttachHint) arenaAttachHint.textContent = '';
        if (arenaRunBtn) arenaRunBtn.disabled = false;
        return;
    }
    arenaAttachRow.style.display = 'block';
    if (arenaAttachImg) arenaAttachImg.src = currentImageFull || currentImageThumb || '';
    if (arenaAttachName) arenaAttachName.textContent = currentImageName || 'изображение';
    if (arenaAttachSize) arenaAttachSize.textContent = currentImageSize ? formatBytes(currentImageSize) : '';

    const modelAId = arenaModelA?.value || '';
    const modelBId = arenaModelB?.value || '';
    const infoA = modelsInfo.find(m => m.id === modelAId);
    const infoB = modelsInfo.find(m => m.id === modelBId);
    const visionA = infoA ? !!infoA.supports_vision : false;
    const visionB = infoB ? !!infoB.supports_vision : false;

    let hint = '';
    if (!visionA && !visionB) {
        hint = `⚠️ Обе модели (${modelAId}, ${modelBId}) не поддерживают Vision. Изображение не будет обработано. Выберите хотя бы одну модель со значком 🖼️ или уберите файл.`;
    } else if (!visionA) {
        hint = `⚠️ Модель A (${modelAId}) не поддерживает Vision. Изображение увидит только колонка B.`;
    } else if (!visionB) {
        hint = `⚠️ Модель B (${modelBId}) не поддерживает Vision. Изображение увидит только колонка A.`;
    }
    if (arenaAttachHint) arenaAttachHint.textContent = hint;
    if (arenaRunBtn) arenaRunBtn.disabled = (!visionA && !visionB);
}

function clearArenaAttachment() {
    removeImage();
}

// ========== CHAT DIVIDER ==========
function renderDivider(msg, idx) {
    const el = document.createElement('div');
    el.className = 'chat-divider';
    el.dataset.role = 'divider';
    el.dataset.msgIdx = String(idx);
    const textHtml = escapeHtml(msg.text || '').replace(/→/g, '<strong>→</strong>');
    el.innerHTML = `
        <div class="chat-divider-content">
            <i class="fas fa-exchange-alt"></i>
            <span class="divider-text">${textHtml}</span>
            <button class="divider-new-chat" title="Начать новый чат">
                <i class="fas fa-plus"></i> новый чат
            </button>
        </div>
    `;
    el.querySelector('.divider-new-chat').addEventListener('click', (e) => {
        e.stopPropagation();
        promptNewChatFromDivider();
    });
    return el;
}

function addModelDivider(oldModel, newModel) {
    const chat = getCurrentChat();
    if (!chat) return;
    const hasMessages = chat.history.some(m => m.role === 'user' || m.role === 'assistant');
    if (!hasMessages) return;
    chat.history.push({
        role: 'divider', type: 'model',
        text: `Модель изменена: ${oldModel || '—'} → ${newModel || '—'}`,
    });
    chat.updated = Date.now();
    saveChatsToStorage();
    renderMessages();
}

function takeLastAssistantMessage(chat) {
    if (!chat || !Array.isArray(chat.history)) return null;
    for (let i = chat.history.length - 1; i >= 0; i--) {
        if (chat.history[i].role === 'assistant') {
            const cloned = JSON.parse(JSON.stringify(chat.history[i]));
            if (cloned.variants) cloned.variants = cloned.variants.map(v => ({ ...v, streaming: false }));
            return cloned;
        }
    }
    return null;
}

async function promptNewChatFromDivider() {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    const inTemp = !!(chat && chat.temporary);
    if (!inTemp) {
        const carry = takeLastAssistantMessage(chat);
        const newChat = createNewChat(true);
        if (carry) {
            newChat.history.push(carry);
            newChat.updated = Date.now();
            saveChatsToStorage(); renderMessages(); updateContextCount();
            showToast('Новый чат (перенесён ответ)', 'success');
        } else showToast('Новый чат', 'success');
        return;
    }
    const choice = await openModal({
        title: 'Новый чат',
        message: 'Текущий временный чат будет удалён.\nПоследний ответ модели перенесётся.\n\nКуда перенести?',
        icon: 'fa-exchange-alt', tone: 'purple',
        buttons: [
            { id: 'cancel', text: 'Отмена' },
            { id: 'temp', text: 'Временный' },
            { id: 'perm', text: 'Постоянный', autofocus: true },
        ],
    });
    if (choice === 'cancel' || choice === null) return;
    const carry = takeLastAssistantMessage(chat);
    chats = chats.filter(c => !c.temporary);
    if (choice === 'temp') {
        const newChat = {
            id: uid(), title: 'Временный чат',
            created: Date.now(), updated: Date.now(),
            favorite: false, temporary: true, history: [],
        };
        chats.unshift(newChat);
        currentChatId = newChat.id;
        if (carry) newChat.history.push(carry);
        saveChatsToStorage(); renderMessages(); updateChatTitle(); updateTempModeUI();
        renderChatsList(); updateContextCount();
        showToast('Новый временный чат', 'success');
    } else {
        const newChat = {
            id: uid(), title: 'Новый чат',
            created: Date.now(), updated: Date.now(),
            favorite: false, temporary: false, history: [],
        };
        chats.unshift(newChat);
        currentChatId = newChat.id;
        if (carry) newChat.history.push(carry);
        sortChats(); saveChatsToStorage(); renderMessages();
        updateChatTitle(); updateTempModeUI(); renderChatsList(); updateContextCount();
        showToast('Новый постоянный чат', 'success');
    }
}

// ========== РЕНДЕР ==========
function renderWelcome() {
    messagesContainer.innerHTML = `
        <div class="welcome">
            <h2>👋 Локальный AI-чат</h2>
            <p>Работает через LM Studio. История сохраняется в браузере.</p>
            <div class="features">
                <div class="feature">🧠 Несколько чатов</div>
                <div class="feature">⚔️ Арена моделей</div>
                <div class="feature">📊 Таблицы и код</div>
                <div class="feature">⭐ Избранное</div>
            </div>
        </div>
    `;
}

function renderThinkingBlock(variant, isStreaming, blockId) {
    if (!variant.reasoning) return '';
    let status;
    if (!isStreaming) status = `Размышления · ${variant.reasoning.length} симв.`;
    else if (variant.content) status = 'Отвечает…';
    else status = 'Думает…';
    const streamingClass = (isStreaming && !variant.content) ? 'streaming' : '';
    return `
        <details class="thinking-block ${streamingClass}" data-block-id="${blockId}">
            <summary>
                <span class="bulb">💡</span>
                <span class="thinking-status">${escapeHtml(status)}</span>
                <i class="fas fa-chevron-down expand-icon"></i>
            </summary>
            <div class="thinking-text">${escapeHtml(variant.reasoning)}</div>
        </details>
    `;
}

function statsToBadge(stats) {
    if (!stats) return '';
    const parts = [];
    if (stats.tokens_per_sec) parts.push(`${stats.tokens_per_sec} t/s`);
    if (stats.completion_tokens) parts.push(`${stats.completion_tokens} tok`);
    if (stats.ttft_sec != null) parts.push(`TTFT ${stats.ttft_sec}s`);
    if (stats.elapsed_sec) parts.push(`${stats.elapsed_sec}s`);
    return parts.join(' · ');
}

function renderAssistantMessage(msg, idx) {
    const el = document.createElement('div');
    el.className = 'message assistant';
    el.dataset.role = 'assistant';
    el.dataset.msgIdx = String(idx);
    const v = msg.variants[msg.activeVariant];
    const isStreaming = !!v.streaming;
    const blockId = `th-${idx}-${msg.activeVariant}`;
    const thinkingHtml = renderThinkingBlock(v, isStreaming, blockId);
    let contentHtml;
    if (v.content) contentHtml = formatMessageWithCode(v.content);
    else if (isStreaming) contentHtml = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
    else contentHtml = '';
    el.innerHTML = `
        <div class="avatar">🤖</div>
        <div class="message-content">
            ${thinkingHtml}
            <div class="message-text">${contentHtml}</div>
            <div class="message-actions"></div>
        </div>
    `;
    const actions = el.querySelector('.message-actions');
    actions.innerHTML = `
        <button class="msg-btn copy-btn" title="Копировать"><i class="fas fa-copy"></i></button>
        <button class="msg-btn regenerate-btn" title="Перегенерировать" ${isStreaming ? 'disabled' : ''}>
            <i class="fas fa-rotate-right"></i>
        </button>
        <button class="msg-btn delete-msg-btn" title="Удалить" ${isStreaming ? 'disabled' : ''}>
            <i class="fas fa-trash-alt"></i>
        </button>
        <div class="variant-switcher" style="display:${msg.variants.length > 1 ? 'inline-flex' : 'none'};">
            <button class="variant-prev" ${msg.activeVariant === 0 ? 'disabled' : ''}>
                <i class="fas fa-chevron-left"></i>
            </button>
            <span class="variant-counter">${msg.activeVariant + 1} / ${msg.variants.length}</span>
            <button class="variant-next" ${msg.activeVariant >= msg.variants.length - 1 ? 'disabled' : ''}>
                <i class="fas fa-chevron-right"></i>
            </button>
            <button class="variant-delete" title="Удалить вариант" ${isStreaming ? 'disabled' : ''}>
                <i class="fas fa-times"></i>
            </button>
        </div>
        <span class="stats-badge">${statsToBadge(v.stats)}</span>
    `;
    actions.querySelector('.copy-btn').onclick = () => copyToClipboard(v.content || '');
    actions.querySelector('.regenerate-btn').onclick = () => regenerateMessage(idx);
    actions.querySelector('.delete-msg-btn').onclick = () => deleteAssistantMessage(idx);
    const prevBtn = actions.querySelector('.variant-prev');
    const nextBtn = actions.querySelector('.variant-next');
    const delVarBtn = actions.querySelector('.variant-delete');
    if (prevBtn) prevBtn.onclick = () => switchVariant(idx, -1);
    if (nextBtn) nextBtn.onclick = () => switchVariant(idx, +1);
    if (delVarBtn) delVarBtn.onclick = () => deleteVariant(idx, msg.activeVariant);
    if (!isStreaming) { highlightCode(el); addCopyButtonsToCodeBlocks(el); }
    return el;
}

function renderUserMessage(msg, idx) {
    const el = document.createElement('div');
    el.className = 'message user';
    el.dataset.role = 'user';
    el.dataset.msgIdx = String(idx);
    const chat = getCurrentChat();
    const canRetry = chat ? !hasAssistantAfter(chat, idx) : false;
    const textHtml = msg.content
        ? `<div class="message-text">${escapeHtml(msg.content).replace(/\n/g, '<br>')}</div>`
        : '';
    const thumbSrc = msg.image?.thumb || msg.image?.full || null;
    const imgHtml = thumbSrc ? `<img src="${thumbSrc}" class="msg-image-thumb" alt="">` : '';
    el.innerHTML = `
        <div class="avatar">👤</div>
        <div class="message-content">
            ${textHtml}
            ${imgHtml}
            <div class="message-actions">
                <button class="msg-btn copy-btn" title="Копировать"><i class="fas fa-copy"></i></button>
                ${canRetry ? `<button class="msg-btn retry-btn" title="Повторить"><i class="fas fa-redo"></i> Повторить</button>` : ''}
                <button class="msg-btn delete-msg-btn" title="Удалить"><i class="fas fa-trash-alt"></i></button>
            </div>
        </div>
    `;
    el.querySelector('.copy-btn').onclick = () => copyToClipboard(msg.content || '');
    el.querySelector('.delete-msg-btn').onclick = () => deleteUserMessage(idx);
    const retryBtn = el.querySelector('.retry-btn');
    if (retryBtn) retryBtn.onclick = () => executeUserRequest(idx);
    const thumb = el.querySelector('.msg-image-thumb');
    if (thumb) {
        const fullSrc = (msg.image && (msg.image.full || msg.image.thumb)) || thumb.src;
        thumb.addEventListener('click', (e) => { e.stopPropagation(); openLightbox(fullSrc); });
    }
    return el;
}

function renderMessages() {
    let chat = getCurrentChat();
    if (!chat) {
        if (chats.length) { currentChatId = chats[0].id; chat = chats[0]; saveChatsToStorage(); }
        else chat = createNewChat(true);
    }
    messagesContainer.innerHTML = '';
    if (!chat || !chat.history.length) {
        renderWelcome();
        updateContextCount();
        return;
    }
    chat.history.forEach((msg, idx) => {
        if (msg.role === 'user') messagesContainer.appendChild(renderUserMessage(msg, idx));
        else if (msg.role === 'assistant') messagesContainer.appendChild(renderAssistantMessage(msg, idx));
        else if (msg.role === 'divider') messagesContainer.appendChild(renderDivider(msg, idx));
    });
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    updateContextCount();
}

// ========== УДАЛЕНИЕ ==========
function deleteUserMessage(idx) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    if (!chat) return;
    chat.history.splice(idx, 1);
    cleanupDividers(chat);
    chat.updated = Date.now();
    saveChatsToStorage(); renderMessages();
}
function deleteAssistantMessage(idx) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    if (!chat) return;
    chat.history.splice(idx, 1);
    cleanupDividers(chat);
    chat.updated = Date.now();
    saveChatsToStorage(); renderMessages();
}
function deleteVariant(assistantIdx, variantIdx) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    if (!chat) return;
    const msg = chat.history[assistantIdx];
    if (!msg || msg.role !== 'assistant') return;
    if (msg.variants.length <= 1) chat.history.splice(assistantIdx, 1);
    else {
        msg.variants.splice(variantIdx, 1);
        if (variantIdx < msg.activeVariant) msg.activeVariant--;
        else if (msg.activeVariant >= msg.variants.length) msg.activeVariant = msg.variants.length - 1;
    }
    cleanupDividers(chat);
    chat.updated = Date.now();
    saveChatsToStorage(); renderMessages();
}

// ========== STREAMING UPDATE ==========
function updateStreamingAssistantInDom(msgIdx) {
    const chat = getCurrentChat();
    if (!chat) return;
    const msg = chat.history[msgIdx];
    if (!msg || msg.role !== 'assistant') return;
    const el = messagesContainer.querySelector(`[data-msg-idx="${msgIdx}"]`);
    if (!el) return;
    const v = msg.variants[msg.activeVariant];
    const contentBox = el.querySelector('.message-content');
    const blockId = `th-${msgIdx}-${msg.activeVariant}`;
    let tb = contentBox.querySelector('.thinking-block');
    if (v.reasoning && !tb) {
        const tmp = document.createElement('div');
        tmp.innerHTML = renderThinkingBlock(v, v.streaming, blockId);
        tb = tmp.firstElementChild;
        contentBox.insertBefore(tb, contentBox.firstChild);
    }
    if (tb) {
        const textEl = tb.querySelector('.thinking-text');
        if (textEl && textEl.textContent !== v.reasoning) textEl.textContent = v.reasoning;
        const st = tb.querySelector('.thinking-status');
        if (st) {
            let s;
            if (!v.streaming) s = `Размышления · ${v.reasoning.length} симв.`;
            else if (v.content) s = 'Отвечает…';
            else s = 'Думает…';
            if (st.textContent !== s) st.textContent = s;
        }
        if (v.streaming && !v.content) tb.classList.add('streaming');
        else tb.classList.remove('streaming');
    }
    const textDiv = el.querySelector('.message-text');
    if (textDiv) {
        if (v.content) {
            textDiv.innerHTML = formatMessageWithCode(v.content);
            highlightCode(textDiv);
            addCopyButtonsToCodeBlocks(textDiv);
        } else if (v.streaming) {
            if (!textDiv.querySelector('.typing-indicator')) {
                textDiv.innerHTML = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
            }
        } else {
            if (textDiv.querySelector('.typing-indicator')) textDiv.innerHTML = '';
        }
    }
    const badge = el.querySelector('.stats-badge');
    if (badge) badge.textContent = statsToBadge(v.stats);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// ========== IMAGE ==========
function createThumbnail(dataUrl, maxSize = 800, quality = 0.82) {
    return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => {
            let { width, height } = img;
            if (width > height && width > maxSize) {
                height = Math.round(height * maxSize / width); width = maxSize;
            } else if (height >= width && height > maxSize) {
                width = Math.round(width * maxSize / height); height = maxSize;
            }
            const canvas = document.createElement('canvas');
            canvas.width = width; canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);
            try { resolve(canvas.toDataURL('image/jpeg', quality)); }
            catch (_) { resolve(dataUrl); }
        };
        img.onerror = () => resolve(dataUrl);
        img.src = dataUrl;
    });
}

async function handleImageUpload(file) {
    if (!file || !file.type.startsWith('image/')) { showToast('Нужен файл изображения', 'error'); return; }
    if (file.size > 5 * 1024 * 1024) { showToast('Максимум 5 МБ', 'error'); return; }
    const reader = new FileReader();
    reader.onload = async (e) => {
        const dataUrl = e.target.result;
        currentImageBase64 = dataUrl.split(',')[1];
        currentImageMimeType = file.type;
        currentImageFull = dataUrl;
        currentImageName = file.name || 'изображение';
        currentImageSize = file.size || 0;
        try { currentImageThumb = await createThumbnail(dataUrl, 800, 0.82); }
        catch (_) { currentImageThumb = dataUrl; }
        imagePreview.src = dataUrl;
        imagePreviewContainer.style.display = 'block';
        imageInfo.textContent = `${file.name} · ${(file.size / 1024).toFixed(0)} КБ`;
        renderPendingAttachment();
        renderArenaAttachment();
        showToast('Изображение прикреплено', 'success');
    };
    reader.readAsDataURL(file);
}

function removeImage() {
    currentImageBase64 = null;
    currentImageMimeType = null;
    currentImageFull = null;
    currentImageThumb = null;
    currentImageName = '';
    currentImageSize = 0;
    imagePreview.src = '';
    imagePreviewContainer.style.display = 'none';
    imageInfo.textContent = '';
    if (imageInput) imageInput.value = '';
    if (arenaImageInput) arenaImageInput.value = '';
    renderPendingAttachment();
    renderArenaAttachment();
}

function updateImageUploadAccess() {
    const model = modelSelect.value;
    const info = modelsInfo.find(m => m.id === model);
    const canVision = info ? !!info.supports_vision : false;
    if (uploadImageBtn) uploadImageBtn.disabled = !canVision || !model;
    if (imageUploadArea) {
        imageUploadArea.style.opacity = canVision && model ? '1' : '0.5';
        imageUploadArea.style.pointerEvents = canVision && model ? 'auto' : 'none';
    }
    if (visionHint) {
        if (!model) visionHint.textContent = 'Сначала выберите модель';
        else if (canVision) visionHint.textContent = '✓ Модель поддерживает Vision';
        else visionHint.textContent = 'Эта модель без Vision (только текст)';
    }
}

// ========== DROP FILES ==========
function bindDropZone() {
    if (!mainArea) return;
    ['dragover', 'drop'].forEach(evt => {
        window.addEventListener(evt, (e) => {
            if (!mainArea.contains(e.target)) e.preventDefault();
        });
    });
    mainArea.addEventListener('dragenter', (e) => {
        if (!e.dataTransfer) return;
        const hasFiles = Array.from(e.dataTransfer.types || []).includes('Files');
        if (!hasFiles) return;
        e.preventDefault();
        dragCounter++;
        dropOverlay?.classList.add('open');
        flashWindowAttention();
    });
    mainArea.addEventListener('dragover', (e) => {
        if (!e.dataTransfer) return;
        const hasFiles = Array.from(e.dataTransfer.types || []).includes('Files');
        if (!hasFiles) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
        if (dragCounter === 1) { try { window.focus(); } catch (_) {} }
    });
    mainArea.addEventListener('dragleave', () => {
        dragCounter--;
        if (dragCounter <= 0) {
            dragCounter = 0;
            dropOverlay?.classList.remove('open');
            stopFlashWindowAttention();
        }
    });
    mainArea.addEventListener('drop', (e) => {
        e.preventDefault();
        dragCounter = 0;
        dropOverlay?.classList.remove('open');
        stopFlashWindowAttention();
        const files = Array.from(e.dataTransfer?.files || []);
        if (files.length) handleDroppedFiles(files);
    });
}

async function handleDroppedFiles(files) {
    for (const file of files) {
        const name = (file.name || '').toLowerCase();
        const isImage = file.type.startsWith('image/') || /\.(jpe?g|png|webp|gif|bmp)$/.test(name);
        const isTxt = file.type === 'text/plain' || name.endsWith('.txt') || name.endsWith('.md');
        const isDocx = name.endsWith('.docx');
        const isDoc = name.endsWith('.doc') && !name.endsWith('.docx');
        const isPdf = name.endsWith('.pdf');
        if (isImage) await handleDroppedImage(file);
        else if (isTxt) await handleDroppedText(file);
        else if (isDocx) await handleDroppedDocx(file);
        else if (isDoc) showToast('.doc не поддерживается', 'error');
        else if (isPdf) showToast('PDF пока не поддерживается', 'error');
        else showToast(`Формат не поддерживается: ${file.name}`, 'error');
    }
}

async function handleDroppedImage(file) {
    if (file.size > 5 * 1024 * 1024) { showToast(`"${file.name}": больше 5 МБ`, 'error'); return; }
    if (arenaState.active) {
        handleImageUpload(file);
        return;
    }
    const currentModel = modelSelect.value;
    const currentInfo = modelsInfo.find(m => m.id === currentModel);
    const canVision = currentInfo ? !!currentInfo.supports_vision : false;
    if (!canVision) {
        const visionModel = modelsInfo.find(m => m.supports_vision);
        if (!visionModel) { showToast('Нет Vision-моделей', 'error'); return; }
        const oldName = currentModel || '—';
        modelSelect.value = visionModel.id;
        localStorage.setItem('selected_model', visionModel.id);
        updateModelBadge(); updateImageUploadAccess();
        addModelDivider(oldName, visionModel.id);
        showToast(`Модель: ${visionModel.id} (Vision)`, 'success');
    }
    handleImageUpload(file);
}

async function handleDroppedText(file) {
    if (file.size > 2 * 1024 * 1024) { showToast('Больше 2 МБ', 'error'); return; }
    try { insertFileContent(file.name, await file.text()); }
    catch (err) { showToast('Не удалось прочитать файл', 'error'); }
}

async function handleDroppedDocx(file) {
    if (file.size > FILE_MAX_BYTES) { showToast('Больше 5 МБ', 'error'); return; }
    if (!window.mammoth) { showToast('mammoth не загружен', 'error'); return; }
    try {
        const arrayBuffer = await file.arrayBuffer();
        const result = await window.mammoth.extractRawText({ arrayBuffer });
        insertFileContent(file.name, result.value || '');
    } catch (err) { showToast('Не удалось прочитать DOCX', 'error'); }
}

function insertFileContent(filename, text) {
    const cleaned = (text || '').replace(/\r\n/g, '\n').trim();
    if (!cleaned) { showToast('Файл пуст', 'error'); return; }
    const truncated = cleaned.length > TEXT_MAX_CHARS ? cleaned.slice(0, TEXT_MAX_CHARS) + '\n…[обрезано]' : cleaned;
    const block = `📎 ${filename}\n\`\`\`\n${truncated}\n\`\`\`\n\n`;
    const cur = userInput.value || '';
    userInput.value = cur ? (cur + '\n\n' + block) : block;
    userInput.style.height = 'auto';
    userInput.style.height = Math.min(userInput.scrollHeight, 160) + 'px';
    userInput.focus();
    showToast(`Файл "${filename}" добавлен`, 'success');
}

// ========== MODELS & SETTINGS ==========
async function loadModels() {
    try {
        const response = await fetch('/get_models');
        const data = await response.json();
        if (data.models && data.models.length) {
            modelsInfo = data.models;
            modelSelect.innerHTML = '<option value="">— Выберите модель —</option>' +
                modelsInfo.map(m => `<option value="${m.id}">${m.id}${m.supports_vision ? ' 🖼️' : ''}</option>`).join('');
            const saved = localStorage.getItem('selected_model');
            if (saved && modelsInfo.some(m => m.id === saved)) modelSelect.value = saved;
            else if (modelsInfo.length === 1) modelSelect.value = modelsInfo[0].id;
            updateModelBadge();
            updateImageUploadAccess();
            fillArenaModelSelects();
        } else {
            modelSelect.innerHTML = '<option value="">— Модели не найдены —</option>';
            visionHint.textContent = 'Добавьте модели в main21.py (LM_SERVERS)';
        }
    } catch (err) {
        console.error(err);
        modelSelect.innerHTML = '<option value="">— Ошибка загрузки —</option>';
        visionHint.textContent = 'Сервер недоступен';
    }
}

async function warmupModel(modelId, silent = true, signal = null) {
    if (!modelId) return false;
    try {
        const r = await fetch('/warmup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ model: modelId }),
            signal: signal || undefined,
        });
        const data = await r.json().catch(() => ({}));
        if (data && data.warmed) {
            console.log(`[warmup] ${modelId} готов за ${data.elapsed}с`);
            return true;
        }
        if (!silent) showToast('Прогрев: ' + (data?.detail || 'ошибка'), 'error');
        return false;
    } catch (e) {
        if (e.name === 'AbortError') return false;
        return false;
    }
}

function updateModelBadge() {
    const v = modelSelect.value;
    modelBadge.textContent = v || 'Модель не выбрана';
}

function saveSettings() {
    const settings = {
        system_prompt: systemPrompt.value,
        temperature: temperature.value,
        top_p: topP.value,
        top_k: topK.value,
        frequency_penalty: frequencyPenalty.value,
        presence_penalty: presencePenalty.value,
        repeat_penalty: repeatPenalty.value,
        max_tokens: maxTokens.value,
        seed: seedInput.value,
        sound_enabled: soundEnabled,
        notif_enabled: notifEnabled,
    };
    localStorage.setItem('chat_settings', JSON.stringify(settings));
}

function loadSettings() {
    const saved = localStorage.getItem('chat_settings');
    if (!saved) {
        if (soundToggle) soundEnabled = soundToggle.checked;
        if (notifToggle) notifEnabled = notifToggle.checked;
        return;
    }
    try {
        const s = JSON.parse(saved);
        systemPrompt.value = s.system_prompt || '';
        temperature.value = s.temperature ?? 0.7;
        topP.value = s.top_p ?? 0.9;
        topK.value = s.top_k ?? 50;
        frequencyPenalty.value = s.frequency_penalty ?? 0.0;
        presencePenalty.value = s.presence_penalty ?? 0.0;
        repeatPenalty.value = s.repeat_penalty ?? 1.1;
        maxTokens.value = s.max_tokens ?? 2048;
        seedInput.value = s.seed || '';
        soundEnabled = s.sound_enabled !== false;
        notifEnabled = s.notif_enabled !== false;
        if (soundToggle) soundToggle.checked = soundEnabled;
        if (notifToggle) notifToggle.checked = notifEnabled;
        syncRangeLabels();
    } catch (_) {}
}

function syncRangeLabels() {
    document.getElementById('temp-value').textContent = temperature.value;
    document.getElementById('topp-value').textContent = topP.value;
    document.getElementById('topk-value').textContent = topK.value;
    document.getElementById('freq-value').textContent = frequencyPenalty.value;
    document.getElementById('presence-value').textContent = presencePenalty.value;
    document.getElementById('repeat-value').textContent = repeatPenalty.value;
    document.getElementById('max-tokens-value').textContent = maxTokens.value;
}

function applyPreset(key) {
    if (!promptPreset) return;
    if (key === 'empty') {
        systemPrompt.value = '';
        saveSettings();
        promptPreset.value = '';
        showToast('Промпт очищен', 'success');
        return;
    }
    const text = PROMPT_PRESETS[key];
    if (text) {
        systemPrompt.value = text;
        saveSettings();
        showToast('Пресет применён', 'success');
    }
    promptPreset.value = '';
}

function resetSettings() {
    temperature.value = 0.7;
    topP.value = 0.9;
    topK.value = 50;
    frequencyPenalty.value = 0.0;
    presencePenalty.value = 0.0;
    repeatPenalty.value = 1.1;
    maxTokens.value = 2048;
    seedInput.value = '';
    systemPrompt.value = '';
    if (promptPreset) promptPreset.value = '';
    soundEnabled = true; notifEnabled = true;
    if (soundToggle) soundToggle.checked = true;
    if (notifToggle) notifToggle.checked = true;
    syncRangeLabels();
    saveSettings();
    showToast('Настройки сброшены', 'success');
}

// ========== CANCEL / BLOCK ==========
function checkCancelLimit() {
    const now = Date.now();
    cancelAttempts = cancelAttempts.filter(t => now - t < CANCEL_WINDOW_MS);
    if (cancelAttempts.length >= CANCEL_MAX) {
        isBlocked = true;
        blockEndTime = now + BLOCK_MS;
        return false;
    }
    cancelAttempts.push(now);
    return true;
}
function isSendBlocked() {
    if (!isBlocked) return false;
    if (Date.now() >= blockEndTime) { isBlocked = false; cancelAttempts = []; return false; }
    return true;
}
async function stopGeneration() {
    if (!activeRequest) return;
    if (!checkCancelLimit()) { showToast('Слишком много отмен', 'error'); return; }
    if (currentAbortController) {
        try { currentAbortController.abort(); } catch (_) {}
        currentAbortController = null;
    }
    try { await fetch('/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); } catch (_) {}
}

// ========== ОБЫЧНЫЙ СТРИМ ==========
async function streamIntoVariant({ message, history, variant, msgIdx, imageBase64, imageMimeType, onFinish }) {
    const chat = getCurrentChat();
    if (!chat) return;
    variant.content = '';
    variant.reasoning = '';
    variant.stats = null;
    variant.createdAt = Date.now();
    variant.streaming = true;
    updateStreamingAssistantInDom(msgIdx);
    const payload = {
        message, history,
        model: modelSelect.value,
        system_prompt: systemPrompt.value || 'Ты полезный ассистент.',
        temperature: parseFloat(temperature.value),
        top_p: parseFloat(topP.value),
        top_k: parseInt(topK.value, 10),
        frequency_penalty: parseFloat(frequencyPenalty.value),
        presence_penalty: parseFloat(presencePenalty.value),
        repeat_penalty: parseFloat(repeatPenalty.value),
        max_tokens: parseInt(maxTokens.value, 10),
    };
    if (imageBase64) { payload.image = imageBase64; payload.image_mime_type = imageMimeType; }
    if (seedInput.value !== '') payload.seed = parseInt(seedInput.value, 10);
    currentAbortController = new AbortController();
    const timeoutId = setTimeout(() => { if (currentAbortController) currentAbortController.abort(); }, REQUEST_TIMEOUT_MS);
    let cancelled = false;
    let errored = false;
    let phase = 'idle';
    try {
        const response = await fetch('/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            signal: currentAbortController.signal,
        });
        clearTimeout(timeoutId);
        if (!response.ok) {
            let errMsg = `HTTP ${response.status}`;
            try { const j = await response.json(); errMsg = j.error || errMsg; } catch (_) {}
            throw new Error(errMsg);
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        const scheduleDom = () => rafScheduler.schedule(`asst-${msgIdx}`, () => updateStreamingAssistantInDom(msgIdx));
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';
            for (const line of lines) {
                if (!line.startsWith('data: ')) continue;
                let data;
                try { data = JSON.parse(line.slice(6)); } catch (_) { continue; }
                if (data.error) throw new Error(data.error);
                if (data.cancelled) {
                    cancelled = true;
                    if (data.partial) variant.content = data.partial;
                    if (data.reasoning_partial) variant.reasoning = data.reasoning_partial;
                    if (data.stats) variant.stats = data.stats;
                    break;
                }
                if (data.reasoning) {
                    variant.reasoning += data.reasoning;
                    if (phase !== 'thinking') { phase = 'thinking'; setStatus('Думает…', false, true); }
                    scheduleDom();
                }
                if (data.content != null) {
                    if (data.full != null) variant.content = data.full;
                    else variant.content += data.content;
                    if (phase !== 'answering') { phase = 'answering'; setStatus('Отвечает…', false, true); }
                    scheduleDom();
                }
                if (data.stats) variant.stats = data.stats;
                if (data.done) {
                    if (data.full != null) variant.content = data.full;
                    if (data.reasoning != null) variant.reasoning = data.reasoning;
                    if (data.stats) variant.stats = data.stats;
                }
            }
            if (cancelled) break;
        }
    } catch (error) {
        if (error.name === 'AbortError') cancelled = true;
        else if (error instanceof TypeError && /failed to fetch|networkerror|load failed/i.test(error.message || '')) {
            errored = true;
            variant.content += `\n\n❌ Соединение с сервером прервалось. Попробуйте «Повторить».`;
        } else {
            errored = true;
            variant.content += `\n\n❌ ${error.message || 'Ошибка'}`;
        }
    } finally {
        clearTimeout(timeoutId);
        variant.streaming = false;
        activeRequest = false;
        currentAbortController = null;
        sendBtn.disabled = false;
        if (stopBtn) stopBtn.style.display = 'none';
        setStatus(errored ? 'Ошибка' : (cancelled ? 'Отменено' : 'Готов'), errored);
        const oldEl = messagesContainer.querySelector(`[data-msg-idx="${msgIdx}"]`);
        const newEl = renderAssistantMessage(chat.history[msgIdx], msgIdx);
        if (oldEl) oldEl.replaceWith(newEl);
        saveChatsToStorage();
        if (typeof onFinish === 'function') onFinish(cancelled);
    }
}

// ========== SEND (обычный чат) ==========
function isModelSelected() {
    if (!modelSelect.value) {
        showToast('Выберите модель в настройках', 'error');
        openDrawer();
        return false;
    }
    return true;
}

async function sendMessage() {
    if (!isModelSelected()) return;
    if (isSendBlocked()) {
        const rem = Math.ceil((blockEndTime - Date.now()) / 1000);
        showToast(`Блокировка ещё ${rem} с`, 'error');
        return;
    }
    if (activeRequest) { setStatus('Идёт генерация…', false, true); return; }
    const chat = ensureCurrentChat();
    if (!chat) { showToast('Не удалось создать чат', 'error'); return; }
    const message = userInput.value.trim();
    if (!message && !currentImageBase64) { showToast('Введите сообщение', 'error'); return; }
    ensureAudioContext();
    if (notifEnabled && 'Notification' in window && Notification.permission === 'default') ensureNotificationPermission();

    activeRequest = true;
    setStatus('Загружаю модель…', false, true);
    sendBtn.disabled = true;
    if (stopBtn) stopBtn.style.display = 'flex';

    const hadImage = !!currentImageBase64;
    const imageB64 = currentImageBase64;
    const imageMime = currentImageMimeType;
    const imageFull = currentImageFull;
    const imageThumb = currentImageThumb;

    chat.history.push({
        role: 'user', content: message,
        image: (imageThumb || imageFull) ? { thumb: imageThumb || imageFull, full: imageFull || null } : null,
    });
    const userMsgIdx = chat.history.length - 1;
    chat.history.push({
        role: 'assistant',
        variants: [{ content: '', reasoning: '', stats: null, createdAt: Date.now(), streaming: true }],
        activeVariant: 0,
    });
    const assistantIdx = chat.history.length - 1;

    if (messagesContainer.querySelector('.welcome')) messagesContainer.innerHTML = '';
    renderMessages();
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    userInput.value = '';
    userInput.style.height = 'auto';
    updateChatTitleFromHistory();
    if (hadImage) removeImage();

    currentAbortController = new AbortController();
    const warmupOk = await warmupModel(modelSelect.value, true, currentAbortController.signal);
    const wasCancelled = (currentAbortController === null);
    currentAbortController = null;

    if (wasCancelled) {
        chat.history.splice(assistantIdx, 1);
        activeRequest = false;
        sendBtn.disabled = false;
        if (stopBtn) stopBtn.style.display = 'none';
        setStatus('Отменено', false);
        renderMessages();
        return;
    }

    if (!warmupOk) {
        const asstMsg = chat.history[assistantIdx];
        if (asstMsg) {
            asstMsg.variants[0].streaming = false;
            asstMsg.variants[0].content = '❌ Не удалось загрузить модель. Проверьте LM Studio.';
        }
        activeRequest = false;
        sendBtn.disabled = false;
        if (stopBtn) stopBtn.style.display = 'none';
        setStatus('Ошибка', true);
        renderMessages();
        return;
    }

    setStatus('Генерация…', false, true);
    const history = historyForApi(chat.history.slice(0, userMsgIdx));

    await streamIntoVariant({
        message: message || '',
        history,
        variant: chat.history[assistantIdx].variants[0],
        msgIdx: assistantIdx,
        imageBase64: imageB64,
        imageMimeType: imageMime,
        onFinish: (cancelled) => {
            updateContextCount();
            if (!cancelled) {
                const asstMsg = chat.history[assistantIdx];
                const v = asstMsg?.variants?.[asstMsg.activeVariant];
                onModelFinished(v?.content || '');
            }
        }
    });
}

async function executeUserRequest(userIdx) {
    if (activeRequest) { showToast('Дождитесь окончания', 'error'); return; }
    if (!isModelSelected()) return;
    const chat = getCurrentChat();
    if (!chat) return;
    const userMsg = chat.history[userIdx];
    if (!userMsg || userMsg.role !== 'user') return;
    const userText = (userMsg.content || '').trim();
    if (!userText && userMsg.image) { showToast('Только изображение', 'error'); return; }
    if (!userText) { showToast('Пустой запрос', 'error'); return; }

    activeRequest = true;
    setStatus('Загружаю модель…', false, true);
    sendBtn.disabled = true;
    if (stopBtn) stopBtn.style.display = 'flex';

    const newAsstMsg = {
        role: 'assistant',
        variants: [{ content: '', reasoning: '', stats: null, createdAt: Date.now(), streaming: true }],
        activeVariant: 0,
    };
    chat.history.splice(userIdx + 1, 0, newAsstMsg);
    const assistantIdx = userIdx + 1;
    renderMessages();
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    currentAbortController = new AbortController();
    const warmupOk = await warmupModel(modelSelect.value, true, currentAbortController.signal);
    const wasCancelled = (currentAbortController === null);
    currentAbortController = null;

    if (wasCancelled) {
        chat.history.splice(assistantIdx, 1);
        activeRequest = false;
        sendBtn.disabled = false;
        if (stopBtn) stopBtn.style.display = 'none';
        setStatus('Отменено', false);
        renderMessages();
        return;
    }

    if (!warmupOk) {
        newAsstMsg.variants[0].streaming = false;
        newAsstMsg.variants[0].content = '❌ Не удалось загрузить модель.';
        activeRequest = false;
        sendBtn.disabled = false;
        if (stopBtn) stopBtn.style.display = 'none';
        setStatus('Ошибка', true);
        renderMessages();
        return;
    }

    setStatus('Генерация…', false, true);
    const history = historyForApi(chat.history.slice(0, userIdx));

    await streamIntoVariant({
        message: userText, history,
        variant: newAsstMsg.variants[0], msgIdx: assistantIdx,
        imageBase64: null, imageMimeType: null,
        onFinish: (cancelled) => {
            updateContextCount();
            if (!cancelled) {
                const v = newAsstMsg.variants[newAsstMsg.activeVariant];
                onModelFinished(v?.content || '');
            }
        },
    });
}

async function regenerateMessage(assistantIdx) {
    if (activeRequest) { showToast('Дождитесь окончания', 'error'); return; }
    if (!isModelSelected()) return;
    const chat = getCurrentChat();
    if (!chat) return;
    const asstMsg = chat.history[assistantIdx];
    if (!asstMsg || asstMsg.role !== 'assistant') return;
    let userIdx = -1;
    for (let i = assistantIdx - 1; i >= 0; i--) {
        if (chat.history[i].role === 'user') { userIdx = i; break; }
    }
    if (userIdx < 0) { showToast('Не найден вопрос', 'error'); return; }
    const userMsg = chat.history[userIdx];
    const userText = (userMsg.content || '').trim();
    if (!userText && userMsg.image) { showToast('Только изображение', 'error'); return; }
    if (!userText) { showToast('Пустой запрос', 'error'); return; }

    activeRequest = true;
    setStatus('Загружаю модель…', false, true);
    sendBtn.disabled = true;
    if (stopBtn) stopBtn.style.display = 'flex';

    const newVariant = { content: '', reasoning: '', stats: null, createdAt: Date.now(), streaming: true };
    asstMsg.variants.push(newVariant);
    asstMsg.activeVariant = asstMsg.variants.length - 1;

    const oldEl = messagesContainer.querySelector(`[data-msg-idx="${assistantIdx}"]`);
    if (oldEl) oldEl.replaceWith(renderAssistantMessage(asstMsg, assistantIdx));

    currentAbortController = new AbortController();
    const warmupOk = await warmupModel(modelSelect.value, true, currentAbortController.signal);
    const wasCancelled = (currentAbortController === null);
    currentAbortController = null;

    if (wasCancelled) {
        if (asstMsg.variants.length > 1) {
            asstMsg.variants.pop();
            asstMsg.activeVariant = asstMsg.variants.length - 1;
        }
        activeRequest = false;
        sendBtn.disabled = false;
        if (stopBtn) stopBtn.style.display = 'none';
        setStatus('Отменено', false);
        const el = messagesContainer.querySelector(`[data-msg-idx="${assistantIdx}"]`);
        if (el) el.replaceWith(renderAssistantMessage(asstMsg, assistantIdx));
        return;
    }

    if (!warmupOk) {
        newVariant.streaming = false;
        newVariant.content = '❌ Не удалось загрузить модель.';
        activeRequest = false;
        sendBtn.disabled = false;
        if (stopBtn) stopBtn.style.display = 'none';
        setStatus('Ошибка', true);
        const el = messagesContainer.querySelector(`[data-msg-idx="${assistantIdx}"]`);
        if (el) el.replaceWith(renderAssistantMessage(asstMsg, assistantIdx));
        return;
    }

    setStatus('Регенерация…', false, true);
    const history = historyForApi(chat.history.slice(0, userIdx));

    await streamIntoVariant({
        message: userText, history,
        variant: newVariant, msgIdx: assistantIdx,
        imageBase64: null, imageMimeType: null,
        onFinish: (cancelled) => {
            updateContextCount();
            if (!cancelled) {
                const v = asstMsg.variants[asstMsg.activeVariant];
                onModelFinished(v?.content || '');
            }
        },
    });
}

function switchVariant(assistantIdx, direction) {
    const chat = getCurrentChat();
    if (!chat) return;
    const msg = chat.history[assistantIdx];
    if (!msg || msg.role !== 'assistant') return;
    const newIdx = msg.activeVariant + direction;
    if (newIdx < 0 || newIdx >= msg.variants.length) return;
    msg.activeVariant = newIdx;
    const oldEl = messagesContainer.querySelector(`[data-msg-idx="${assistantIdx}"]`);
    if (oldEl) oldEl.replaceWith(renderAssistantMessage(msg, assistantIdx));
    saveChatsToStorage();
}

// ========== EXPORT ==========
function exportCurrentChat() {
    const chat = getCurrentChat();
    if (!chat || !chat.history.length) { showToast('Нечего экспортировать', 'error'); return; }
    let md = `# ${chat.title}\n\n`;
    if (chat.temporary) md += `_Временный чат._\n\n`;
    chat.history.forEach(m => {
        if (m.role === 'user') {
            md += `**Вы:**\n${m.content || ''}\n\n`;
            if (m.image?.thumb) md += `_(приложено изображение)_\n\n`;
        } else if (m.role === 'assistant') {
            const v = m.variants[m.activeVariant];
            if (v?.reasoning) md += `<details><summary>Размышления</summary>\n\n${v.reasoning}\n\n</details>\n\n`;
            md += `**Ассистент:**\n${v?.content || ''}\n\n`;
            if (m.variants.length > 1) md += `_Вариант ${m.activeVariant + 1} из ${m.variants.length}_\n\n`;
        } else if (m.role === 'divider') {
            md += `---\n*${m.text}*\n\n`;
        }
    });
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${(chat.title || 'chat').replace(/[^\wа-яё\-]+/gi, '_').slice(0, 40)}.md`;
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('Экспортировано', 'success');
}

function openDrawer() { drawerMenu.classList.add('open'); drawerOverlay.classList.add('open'); }
function closeDrawer() { drawerMenu.classList.remove('open'); drawerOverlay.classList.remove('open'); }

// ============================================================
// ==================== ARENA =================================
// ============================================================

function arenaHasActive() {
    return arenaState.rounds.some(r =>
        (r.answerA && r.answerA.streaming) ||
        (r.answerB && r.answerB.streaming) ||
        (r.merged && r.merged.streaming) ||
        !!r._warmupA ||
        !!r._warmupB ||
        !!r._warmupMerge ||
        !!r._abortA ||
        !!r._abortB ||
        !!r._abortMerge
    );
}

function fillArenaModelSelects() {
    if (!arenaModelA || !arenaModelB) return;
    const buildOptions = (excludeId) => modelsInfo
        .filter(m => m.id !== excludeId)
        .map(m => `<option value="${m.id}">${m.id}${m.supports_vision ? ' 🖼️' : ''}</option>`)
        .join('');

    const prevA = arenaModelA.value || arenaState.modelA || '';
    const prevB = arenaModelB.value || arenaState.modelB || '';

    arenaModelA.innerHTML = buildOptions(prevB);
    if (prevA && modelsInfo.some(m => m.id === prevA) && prevA !== prevB) arenaModelA.value = prevA;
    else {
        const first = Array.from(arenaModelA.options).find(o => o.value !== prevB);
        if (first) arenaModelA.value = first.value;
    }

    arenaModelB.innerHTML = buildOptions(arenaModelA.value);
    if (prevB && modelsInfo.some(m => m.id === prevB) && prevB !== arenaModelA.value) arenaModelB.value = prevB;
    else {
        const first = Array.from(arenaModelB.options).find(o => o.value !== arenaModelA.value);
        if (first) arenaModelB.value = first.value;
    }
    arenaState.modelA = arenaModelA.value;
    arenaState.modelB = arenaModelB.value;
}

function openArena() {
    if (!modelsInfo.length) { showToast('Модели не загружены', 'error'); return; }
    if (modelsInfo.length < 2) { showToast('Нужно минимум 2 модели', 'error'); return; }
    arenaState.active = true;
    arenaScreen.classList.add('open');
    if (!arenaState.settingsA) arenaState.settingsA = DEFAULT_ARENA_SETTINGS();
    if (!arenaState.settingsB) arenaState.settingsB = DEFAULT_ARENA_SETTINGS();
    if (!arenaState.mergeSettings) arenaState.mergeSettings = { ...DEFAULT_ARENA_SETTINGS(), temperature: 0.5, max_tokens: 4096 };
    if (arenaState.mergePrompt === null) arenaState.mergePrompt = DEFAULT_ARENA_PROMPT;
    fillArenaModelSelects();
    renderArenaContent();
    renderArenaAttachment();
    if (!activeRequest && !arenaHasActive()) {
        setStatus('Готов', false, false);
    }
    arenaQuestion.focus();
}

function closeArena() {
    arenaState.active = false;
    arenaScreen.classList.remove('open');
    if (!activeRequest && !arenaHasActive()) {
        setStatus('Готов', false, false);
    }
}

function openArenaSettingsModal(which) {
    resetModalState();
    const isMerge = which === 'merge';
    const currentSettings = isMerge ? arenaState.mergeSettings
                          : (which === 'A' ? arenaState.settingsA : arenaState.settingsB);
    const title = isMerge ? 'Настройки модели-арбитра' : `Настройки модели ${which}`;

    modalTitle.textContent = title;
    modalMessage.style.textAlign = 'left';
    modalMessage.style.whiteSpace = 'normal';
    modalIcon.innerHTML = `<i class="fas fa-sliders-h"></i>`;

    const wrap = document.createElement('div');
    wrap.className = 'arena-config-modal-body';

    const mkRange = (label, key, min, max, step) => {
        const row = document.createElement('div');
        const top = document.createElement('div');
        top.className = 'cfg-row';
        const lbl = document.createElement('label');
        lbl.textContent = label;
        const val = document.createElement('span');
        val.className = 'cfg-val';
        val.textContent = String(currentSettings[key]);
        top.appendChild(lbl);
        top.appendChild(val);
        const inp = document.createElement('input');
        inp.type = 'range';
        inp.min = min; inp.max = max; inp.step = step;
        inp.value = currentSettings[key];
        inp.addEventListener('input', () => { val.textContent = inp.value; });
        row.appendChild(top);
        row.appendChild(inp);
        wrap.appendChild(row);
        return inp;
    };

    const rTemp = mkRange('Temperature', 'temperature', 0, 2, 0.01);
    const rTopP = mkRange('Top P', 'top_p', 0, 1, 0.01);
    const rTopK = mkRange('Top K', 'top_k', 1, 200, 1);
    const rMax = mkRange('Max tokens', 'max_tokens', 100, 16000, 64);
    const rFreq = mkRange('Frequency penalty', 'frequency_penalty', -2, 2, 0.05);
    const rPres = mkRange('Presence penalty', 'presence_penalty', -2, 2, 0.05);
    const rRep = mkRange('Repeat penalty', 'repeat_penalty', 0.8, 1.5, 0.01);

    const seedRow = document.createElement('div');
    const seedLabel = document.createElement('label');
    seedLabel.textContent = 'Seed (пусто = случайный)';
    const seedInp = document.createElement('input');
    seedInp.type = 'number';
    seedInp.value = currentSettings.seed || '';
    seedInp.placeholder = 'Пусто';
    seedRow.appendChild(seedLabel);
    seedRow.appendChild(seedInp);
    wrap.appendChild(seedRow);

    const sysLabel = document.createElement('label');
    sysLabel.textContent = 'Системный промпт';
    const sysInp = document.createElement('textarea');
    sysInp.value = currentSettings.system_prompt || '';
    wrap.appendChild(sysLabel);
    wrap.appendChild(sysInp);

    let mergePromptInp = null;
    if (isMerge) {
        const mpLabel = document.createElement('label');
        mpLabel.textContent = 'Промпт арбитра';
        mergePromptInp = document.createElement('textarea');
        mergePromptInp.value = arenaState.mergePrompt || DEFAULT_ARENA_PROMPT;
        mergePromptInp.style.minHeight = '180px';
        const mpHint = document.createElement('small');
        mpHint.textContent = 'Плейсхолдеры: {question}, {model_a}, {answer_a}, {model_b}, {answer_b}';
        mpHint.style.display = 'block';
        mpHint.style.opacity = '0.6';
        mpHint.style.fontSize = '11px';
        mpHint.style.marginTop = '4px';
        wrap.appendChild(mpLabel);
        wrap.appendChild(mergePromptInp);
        wrap.appendChild(mpHint);
    }

    modalMessage.appendChild(wrap);

    modalActions.innerHTML = '';
    const btnReset = document.createElement('button');
    btnReset.className = 'modal-btn';
    btnReset.textContent = 'Сбросить';
    const btnCancel = document.createElement('button');
    btnCancel.className = 'modal-btn';
    btnCancel.textContent = 'Отмена';
    const btnSave = document.createElement('button');
    btnSave.className = 'modal-btn';
    btnSave.textContent = 'Сохранить';
    modalActions.appendChild(btnReset);
    modalActions.appendChild(btnCancel);
    modalActions.appendChild(btnSave);
    modalOverlay.classList.add('open');
    document.body.style.overflow = 'hidden';

    const cleanup = () => {
        modalOverlay.classList.remove('open');
        document.body.style.overflow = '';
        modalMessage.style.textAlign = '';
        modalMessage.style.whiteSpace = '';
        modalMessage.innerHTML = '';
        modalActions.innerHTML = '';
        modalOverlay.onclick = null;
    };

    btnReset.onclick = () => {
        const def = isMerge ? { ...DEFAULT_ARENA_SETTINGS(), temperature: 0.5, max_tokens: 4096 } : DEFAULT_ARENA_SETTINGS();
        rTemp.value = def.temperature;
        rTopP.value = def.top_p;
        rTopK.value = def.top_k;
        rMax.value = def.max_tokens;
        rFreq.value = def.frequency_penalty;
        rPres.value = def.presence_penalty;
        rRep.value = def.repeat_penalty;
        seedInp.value = '';
        sysInp.value = def.system_prompt || '';
        wrap.querySelectorAll('.cfg-row').forEach((row, idx) => {
            const val = row.querySelector('.cfg-val');
            const ranges = [rTemp, rTopP, rTopK, rMax, rFreq, rPres, rRep];
            if (val && ranges[idx]) val.textContent = ranges[idx].value;
        });
        if (isMerge && mergePromptInp) mergePromptInp.value = DEFAULT_ARENA_PROMPT;
    };

    btnCancel.onclick = cleanup;
    btnSave.onclick = () => {
        const newSettings = {
            temperature: parseFloat(rTemp.value),
            top_p: parseFloat(rTopP.value),
            top_k: parseInt(rTopK.value, 10),
            max_tokens: parseInt(rMax.value, 10),
            frequency_penalty: parseFloat(rFreq.value),
            presence_penalty: parseFloat(rPres.value),
            repeat_penalty: parseFloat(rRep.value),
            seed: seedInp.value,
            system_prompt: sysInp.value || 'Ты полезный ассистент.',
        };
        if (isMerge) {
            arenaState.mergeSettings = newSettings;
            if (mergePromptInp) arenaState.mergePrompt = mergePromptInp.value || DEFAULT_ARENA_PROMPT;
        } else if (which === 'A') arenaState.settingsA = newSettings;
        else arenaState.settingsB = newSettings;
        cleanup();
        showToast('Настройки сохранены', 'success');
    };

    modalOverlay.onclick = (e) => { if (e.target === modalOverlay) cleanup(); };
}

function renderArenaContent() {
    if (!arenaContent) return;
    arenaContent.innerHTML = '';
    if (!arenaState.rounds.length) return;
    arenaState.rounds.forEach((round, ridx) => {
        arenaContent.appendChild(renderArenaRound(round, ridx));
    });
    arenaContent.scrollTop = arenaContent.scrollHeight;
}

function updateArenaRoundInDom(ridx) {
    const round = arenaState.rounds[ridx];
    if (!round) return;
    const oldEl = arenaContent.querySelector(`[data-round-idx="${ridx}"]`);
    const newEl = renderArenaRound(round, ridx);
    if (oldEl) oldEl.replaceWith(newEl);
    arenaContent.scrollTop = arenaContent.scrollHeight;
}

function renderArenaRound(round, ridx) {
    const el = document.createElement('div');
    el.className = 'arena-round';
    el.dataset.roundIdx = String(ridx);

    const q = escapeHtml(round.question || '').slice(0, 240);
    const a = round.answerA || {};
    const b = round.answerB || {};
    const merged = round.merged;

    const statusA = a.streaming
        ? (a.reasoning && !a.content ? '💡 думает' : '✍️ пишет')
        : (a.content ? '✓ готов' : (a.error ? '✕ ошибка' : '—'));
    const statusB = b.streaming
        ? (b.reasoning && !b.content ? '💡 думает' : '✍️ пишет')
        : (b.content ? '✓ готов' : (b.error ? '✕ ошибка' : '—'));

    const bothDone = !a.streaming && !b.streaming && a.content && b.content;
    const canMerge = bothDone && !merged;

    const mergeOptions = modelsInfo.map(m =>
        `<option value="${m.id}" ${round.mergeModel === m.id ? 'selected' : ''}>${escapeHtml(m.id)}</option>`
    ).join('');

    const contentA = a.content
        ? `<div class="arena-content-live">${formatMessageWithCode(a.content)}</div>`
        : (a.streaming ? '<div class="arena-content-live"><div class="typing-indicator"><span></span><span></span><span></span></div></div>'
                       : '<div class="arena-col-empty">Ответ пуст</div>');
    const contentB = b.content
        ? `<div class="arena-content-live">${formatMessageWithCode(b.content)}</div>`
        : (b.streaming ? '<div class="arena-content-live"><div class="typing-indicator"><span></span><span></span><span></span></div></div>'
                       : '<div class="arena-col-empty">Ответ пуст</div>');

    const thinkA = a.reasoning ? renderThinkingBlock(a, a.streaming, `ar-${ridx}-A`) : '';
    const thinkB = b.reasoning ? renderThinkingBlock(b, b.streaming, `ar-${ridx}-B`) : '';

    const roundImageHtml = (round.image && round.image.thumb)
        ? `<img src="${round.image.thumb}" class="arena-round-image" alt="">`
        : '';

    let mergedHtml = '';
    if (merged) {
        const mStreaming = !!merged.streaming;
        const mergedBody = merged.content
            ? `<div class="arena-merged-body">${formatMessageWithCode(merged.content)}</div>`
            : (mStreaming ? '<div class="arena-merged-body"><div class="typing-indicator"><span></span><span></span><span></span></div></div>'
                          : '<div class="arena-merged-body"><div class="arena-col-empty">—</div></div>');
        const mergedThink = merged.reasoning
            ? renderThinkingBlock(merged, mStreaming, `ar-${ridx}-M`)
            : '';
        const mergedWarning = (!merged.content && !mStreaming && merged.reasoning)
            ? `<div style="margin-top:8px;padding:8px 10px;background:rgba(255,180,80,0.08);border:1px solid rgba(255,180,80,0.25);border-radius:8px;font-size:12.5px;color:#ffd0b8;">
                  ⚠️ Модель-арбитр ушла в размышления и не выдала финальный ответ. Разверните «Размышления» выше или попробуйте другую модель.
               </div>`
            : '';
        mergedHtml = `
            <div class="arena-merged-box">
                <div class="arena-merged-head">
                    <i class="fas fa-wand-magic-sparkles"></i>
                    Объединено моделью <span class="arena-merged-model">${escapeHtml(round.mergeModel || '—')}</span>
                    ${mStreaming ? '<span class="merge-status-badge" style="margin-left:auto;">💡 думает</span>' : ''}
                </div>
                ${mergedThink}
                ${mergedBody}
                ${mergedWarning}
                <div class="arena-merged-actions">
                    <button class="msg-btn arena-merged-copy" ${merged.content ? '' : 'disabled'}>
                        <i class="fas fa-copy"></i> Копировать
                    </button>
                    <button class="msg-btn arena-merge-stop-btn" ${mStreaming ? '' : 'style="display:none;"'}>
                        <i class="fas fa-stop"></i> Стоп
                    </button>
                    <button class="arena-promote-btn arena-merged-promote"
                            ${(merged.content && !mStreaming) ? '' : 'disabled'}>
                        <i class="fas fa-arrow-right"></i> В обычный чат
                    </button>
                </div>
            </div>
        `;
    }

    el.innerHTML = `
        <div class="arena-round-header">
            ${roundImageHtml}
            <i class="fas fa-question-circle" style="color:#ff9a5a;"></i>
            <span class="arena-round-q">${q || '(пусто)'}</span>
            <button class="arena-remove-btn" title="Удалить раунд">
                <i class="fas fa-trash-alt"></i> Удалить
            </button>
        </div>
        <div class="arena-round-grid">
            <div class="arena-round-col col-a">
                <div class="arena-round-col-head">
                    <span style="font-family:'Consolas',monospace;opacity:.7;">A</span>
                    <span class="arena-model-name">${escapeHtml(round.modelA || '—')}</span>
                    <span class="arena-col-status">${statusA}</span>
                </div>
                <div class="arena-round-col-body">
                    ${thinkA}
                    ${contentA}
                </div>
                <div class="arena-round-col-foot">
                    <button class="msg-btn arena-copy-a" ${a.content ? '' : 'disabled'}>
                        <i class="fas fa-copy"></i> Копировать
                    </button>
                    <button class="msg-btn arena-regen-a" ${a.streaming ? 'disabled' : ''}>
                        <i class="fas fa-rotate-right"></i> Ещё раз
                    </button>
                    <button class="msg-btn arena-stop-a" ${a.streaming ? '' : 'disabled'}>
                        <i class="fas fa-stop"></i> Стоп
                    </button>
                </div>
            </div>
            <div class="arena-round-col col-b">
                <div class="arena-round-col-head">
                    <span style="font-family:'Consolas',monospace;opacity:.7;">B</span>
                    <span class="arena-model-name">${escapeHtml(round.modelB || '—')}</span>
                    <span class="arena-col-status">${statusB}</span>
                </div>
                <div class="arena-round-col-body">
                    ${thinkB}
                    ${contentB}
                </div>
                <div class="arena-round-col-foot">
                    <button class="msg-btn arena-copy-b" ${b.content ? '' : 'disabled'}>
                        <i class="fas fa-copy"></i> Копировать
                    </button>
                    <button class="msg-btn arena-regen-b" ${b.streaming ? 'disabled' : ''}>
                        <i class="fas fa-rotate-right"></i> Ещё раз
                    </button>
                    <button class="msg-btn arena-stop-b" ${b.streaming ? '' : 'disabled'}>
                        <i class="fas fa-stop"></i> Стоп
                    </button>
                </div>
            </div>
        </div>
        ${!merged ? `
            <div class="arena-round-merge-bar">
                <span class="arena-merge-label">Объединить через:</span>
                <select class="arena-merge-select">
                    <option value="">— Модель —</option>
                    ${mergeOptions}
                </select>
                <button type="button" class="arena-merge-config-btn" data-ridx="${ridx}" title="Настройки модели-арбитра">
                    <i class="fas fa-cog"></i> Настройки
                </button>
                <button class="arena-merge-btn" ${canMerge ? '' : 'disabled'}>
                    <i class="fas fa-wand-magic-sparkles"></i> Объединить
                </button>
            </div>
        ` : mergedHtml}
    `;

    const copyA = el.querySelector('.arena-copy-a');
    const copyB = el.querySelector('.arena-copy-b');
    if (copyA) copyA.onclick = () => copyToClipboard(a.content || '');
    if (copyB) copyB.onclick = () => copyToClipboard(b.content || '');

    const regenA = el.querySelector('.arena-regen-a');
    const regenB = el.querySelector('.arena-regen-b');
    if (regenA) regenA.onclick = () => regenArenaSide(ridx, 'A');
    if (regenB) regenB.onclick = () => regenArenaSide(ridx, 'B');

    const stopA = el.querySelector('.arena-stop-a');
    const stopB = el.querySelector('.arena-stop-b');
    if (stopA) stopA.onclick = () => abortArenaSide(round.id, 'A');
    if (stopB) stopB.onclick = () => abortArenaSide(round.id, 'B');

    const delBtn = el.querySelector('.arena-remove-btn');
    if (delBtn) delBtn.onclick = () => removeArenaRound(ridx);

    const mergeSelect = el.querySelector('.arena-merge-select');
    const mergeBtn = el.querySelector('.arena-merge-btn');
    if (mergeBtn) {
        mergeBtn.onclick = () => {
            const m = mergeSelect?.value;
            if (!m) { showToast('Выберите модель для объединения', 'error'); return; }
            round.mergeModel = m;
            startArenaMerge(ridx);
        };
    }

    const mergedCopy = el.querySelector('.arena-merged-copy');
    if (mergedCopy) mergedCopy.onclick = () => copyToClipboard(round.merged?.content || '');
    const mergedPromote = el.querySelector('.arena-merged-promote');
    if (mergedPromote) mergedPromote.onclick = () => promoteArenaMergedToChat(ridx);
    const mergedStop = el.querySelector('.arena-merge-stop-btn');
    if (mergedStop) mergedStop.onclick = () => abortArenaMerge(round.id);

    const rImg = el.querySelector('.arena-round-image');
    if (rImg) {
        rImg.addEventListener('click', () => {
            if (round.image && round.image.full) openLightbox(round.image.full);
        });
    }

    if (a.content && !a.streaming) { highlightCode(el.querySelector('.col-a')); addCopyButtonsToCodeBlocks(el.querySelector('.col-a')); }
    if (b.content && !b.streaming) { highlightCode(el.querySelector('.col-b')); addCopyButtonsToCodeBlocks(el.querySelector('.col-b')); }
    if (merged && merged.content && !merged.streaming) {
        highlightCode(el.querySelector('.arena-merged-box'));
        addCopyButtonsToCodeBlocks(el.querySelector('.arena-merged-box'));
    }

    return el;
}

function refreshArenaColumn(ridx, side) {
    const round = arenaState.rounds[ridx];
    if (!round) return;
    const roundEl = arenaContent.querySelector(`[data-round-idx="${ridx}"]`);
    if (!roundEl) return;

    const colEl = roundEl.querySelector(side === 'A' ? '.col-a' : '.col-b');
    if (!colEl) return;

    const data = side === 'A' ? (round.answerA || {}) : (round.answerB || {});
    const sideLow = side.toLowerCase();

    const statusEl = colEl.querySelector('.arena-col-status');
    if (statusEl) {
        let s;
        if (data.streaming) s = (data.reasoning && !data.content) ? '💡 думает' : '✍️ пишет';
        else if (data.content) s = '✓ готов';
        else if (data.error) s = '✕ ошибка';
        else s = '—';
        if (statusEl.textContent !== s) statusEl.textContent = s;
    }

    const bodyEl = colEl.querySelector('.arena-round-col-body');
    if (!bodyEl) return;

    let tb = bodyEl.querySelector('.thinking-block');
    if (data.reasoning && !tb) {
        const tmp = document.createElement('div');
        tmp.innerHTML = renderThinkingBlock(data, data.streaming, `ar-${ridx}-${side}`);
        tb = tmp.firstElementChild;
        bodyEl.insertBefore(tb, bodyEl.firstChild);
    }
    if (tb) {
        const txt = tb.querySelector('.thinking-text');
        if (txt && txt.textContent !== data.reasoning) txt.textContent = data.reasoning;
        const st = tb.querySelector('.thinking-status');
        if (st) {
            let s;
            if (!data.streaming) s = `Размышления · ${data.reasoning.length} симв.`;
            else if (data.content) s = 'Отвечает…';
            else s = 'Думает…';
            if (st.textContent !== s) st.textContent = s;
        }
        const shouldStream = !!(data.streaming && !data.content);
        if (tb.classList.contains('streaming') !== shouldStream) {
            tb.classList.toggle('streaming', shouldStream);
        }
    }

    let contentDiv = bodyEl.querySelector('.arena-content-live');
    if (!contentDiv) {
        contentDiv = document.createElement('div');
        contentDiv.className = 'arena-content-live';
        bodyEl.appendChild(contentDiv);
    }
    const empty = bodyEl.querySelector('.arena-col-empty');
    if (empty && data.content) empty.remove();

    if (data.content) {
        if (contentDiv.dataset.raw !== data.content) {
            contentDiv.dataset.raw = data.content;
            contentDiv.innerHTML = formatMessageWithCode(data.content);
            highlightCode(contentDiv);
            addCopyButtonsToCodeBlocks(contentDiv);
        }
    } else if (data.streaming) {
        if (!contentDiv.querySelector('.typing-indicator')) {
            contentDiv.innerHTML = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
        }
    } else {
        if (contentDiv.querySelector('.typing-indicator')) contentDiv.innerHTML = '';
        if (!data.content && !data.error && !bodyEl.querySelector('.arena-col-empty')) {
            const e = document.createElement('div');
            e.className = 'arena-col-empty';
            e.textContent = 'Ответ пуст';
            bodyEl.appendChild(e);
        }
    }

    const regenBtn = colEl.querySelector(`.arena-regen-${sideLow}`);
    const stopBtn = colEl.querySelector(`.arena-stop-${sideLow}`);
    const copyBtn = colEl.querySelector(`.arena-copy-${sideLow}`);
    if (regenBtn) regenBtn.disabled = !!data.streaming;
    if (copyBtn) copyBtn.disabled = !data.content;
    if (stopBtn) {
        stopBtn.style.display = '';
        stopBtn.disabled = !data.streaming;
    }

    const headEl = colEl.querySelector('.arena-round-col-head');
    if (headEl && data.stats) {
        let badge = headEl.querySelector('.arena-stats');
        if (!badge) {
            badge = document.createElement('span');
            badge.className = 'arena-stats stats-badge';
            badge.style.marginLeft = 'auto';
            headEl.appendChild(badge);
        }
        badge.textContent = statsToBadge(data.stats);
    }

    if (!round.merged) {
        const a = round.answerA || {};
        const b = round.answerB || {};
        const bothDone = !a.streaming && !b.streaming && a.content && b.content;
        const mb = roundEl.querySelector('.arena-merge-btn');
        if (mb) mb.disabled = !bothDone;
    }

    arenaContent.scrollTop = arenaContent.scrollHeight;
}

async function arenaRun() {
    if (isSendBlocked()) { showToast('Блокировка', 'error'); return; }
    if (activeRequest) { showToast('Дождитесь окончания', 'error'); return; }

    const modelA = arenaModelA.value;
    const modelB = arenaModelB.value;
    if (!modelA || !modelB) { showToast('Выберите обе модели', 'error'); return; }
    if (modelA === modelB) { showToast('Модели должны различаться', 'error'); return; }

    const imgB64 = currentImageBase64;
    const imgMime = currentImageMimeType;
    const imgThumb = currentImageThumb || currentImageFull;

    const question = arenaQuestion.value.trim();
    if (!question && !imgB64) { showToast('Введите вопрос или прикрепите изображение', 'error'); return; }

    if (imgB64) {
        const infoA = modelsInfo.find(m => m.id === modelA);
        const infoB = modelsInfo.find(m => m.id === modelB);
        const visionA = infoA ? !!infoA.supports_vision : false;
        const visionB = infoB ? !!infoB.supports_vision : false;
        if (!visionA && !visionB) {
            showToast('Обе модели не поддерживают Vision. Выберите хотя бы одну с 🖼️ или уберите файл.', 'error');
            return;
        }
    }

    if (!arenaState.settingsA) arenaState.settingsA = DEFAULT_ARENA_SETTINGS();
    if (!arenaState.settingsB) arenaState.settingsB = DEFAULT_ARENA_SETTINGS();

    ensureAudioContext();
    if (notifEnabled && 'Notification' in window && Notification.permission === 'default') ensureNotificationPermission();

    const round = {
        id: uid(),
        question,
        modelA, modelB,
        answerA: { content: '', reasoning: '', stats: null, streaming: true, createdAt: Date.now(), error: null },
        answerB: { content: '', reasoning: '', stats: null, streaming: true, createdAt: Date.now(), error: null },
        merged: null,
        mergeModel: null,
        createdAt: Date.now(),
        image: imgB64 ? { base64: imgB64, mime: imgMime, thumb: imgThumb || null, full: currentImageFull || null } : null,
    };
    arenaState.rounds.push(round);
    const ridx = arenaState.rounds.length - 1;

    arenaQuestion.value = '';
    arenaQuestion.style.height = 'auto';
    renderArenaContent();
    arenaContent.scrollTop = arenaContent.scrollHeight;

    if (imgB64) removeImage();

    const warmupCtrlA = new AbortController();
    const warmupCtrlB = new AbortController();
    round._warmupA = warmupCtrlA;
    round._warmupB = warmupCtrlB;

    setStatus('Загружаю модели…', false, true);

    const warmA = await warmupModel(modelA, true, warmupCtrlA.signal);
    const cancelledA = warmupCtrlA.signal.aborted;
    delete round._warmupA;

    if (cancelledA) {
        round.answerA.streaming = false;
        round.answerA.content = '⏹️ Отменено';
        refreshArenaColumn(ridx, 'A');
    }

    const warmB = await warmupModel(modelB, true, warmupCtrlB.signal);
    const cancelledB = warmupCtrlB.signal.aborted;
    delete round._warmupB;

    if (cancelledB) {
        round.answerB.streaming = false;
        round.answerB.content = '⏹️ Отменено';
        refreshArenaColumn(ridx, 'B');
    }

    const tasks = [];

    if (warmA) {
        tasks.push(streamArenaSide(round, ridx, 'A', modelA, question, imgB64, imgMime));
    } else if (!cancelledA) {
        round.answerA.streaming = false;
        round.answerA.content = '❌ Не удалось загрузить модель A.';
        refreshArenaColumn(ridx, 'A');
    }

    if (warmB) {
        tasks.push(streamArenaSide(round, ridx, 'B', modelB, question, imgB64, imgMime));
    } else if (!cancelledB) {
        round.answerB.streaming = false;
        round.answerB.content = '❌ Не удалось загрузить модель B.';
        refreshArenaColumn(ridx, 'B');
    }

    if (tasks.length) setStatus('Генерация…', false, true);

    Promise.all(tasks).then(() => {
        updateArenaRoundInDom(ridx);
        onModelFinished('Арена завершена');
        if (!arenaHasActive()) setStatus('Готов', false, false);
    });
}

async function streamArenaSide(round, ridx, side, modelId, question, imageB64, imageMime) {
    if (!round) return;
    const settings = side === 'A' ? arenaState.settingsA : arenaState.settingsB;
    const sideData = side === 'A' ? round.answerA : round.answerB;

    const payload = {
        message: question || (imageB64 ? 'Опиши изображение подробно.' : ''),
        history: [],
        model: modelId,
        system_prompt: settings.system_prompt || 'Ты полезный ассистент.',
        temperature: settings.temperature,
        top_p: settings.top_p,
        top_k: settings.top_k,
        frequency_penalty: settings.frequency_penalty,
        presence_penalty: settings.presence_penalty,
        repeat_penalty: settings.repeat_penalty,
        max_tokens: settings.max_tokens,
    };
    if (imageB64 && imageMime) {
        const info = modelsInfo.find(m => m.id === modelId);
        if (info && info.supports_vision) {
            payload.image = imageB64;
            payload.image_mime_type = imageMime;
        }
    }
    if (settings.seed !== '' && settings.seed != null) {
        try { payload.seed = parseInt(settings.seed, 10); } catch (_) {}
    }

    const controller = new AbortController();
    round['_abort' + side] = controller;

    const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    const scheduleDom = () => rafScheduler.schedule(`arena-${ridx}-${side}`, () => refreshArenaColumn(ridx, side));

    try {
        const response = await fetch('/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            signal: controller.signal,
        });
        clearTimeout(timeoutId);
        if (!response.ok) {
            let errMsg = `HTTP ${response.status}`;
            try { const j = await response.json(); errMsg = j.error || errMsg; } catch (_) {}
            throw new Error(errMsg);
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';
            for (const line of lines) {
                if (!line.startsWith('data: ')) continue;
                let data;
                try { data = JSON.parse(line.slice(6)); } catch (_) { continue; }
                if (data.error) throw new Error(data.error);
                if (data.cancelled) {
                    if (data.partial) sideData.content = data.partial;
                    if (data.reasoning_partial) sideData.reasoning = data.reasoning_partial;
                    break;
                }
                if (data.reasoning) {
                    sideData.reasoning += data.reasoning;
                    scheduleDom();
                }
                if (data.content != null) {
                    if (data.full != null) sideData.content = data.full;
                    else sideData.content += data.content;
                    scheduleDom();
                }
                if (data.stats) { sideData.stats = data.stats; scheduleDom(); }
                if (data.done) {
                    if (data.full != null) sideData.content = data.full;
                    if (data.reasoning != null) sideData.reasoning = data.reasoning;
                    if (data.stats) sideData.stats = data.stats;
                }
            }
        }
    } catch (error) {
        if (error.name === 'AbortError') {
            sideData.content += '\n\n⏹️ Отменено';
        } else {
            sideData.content += `\n\n❌ ${error.message || 'Ошибка'}`;
            sideData.error = error.message;
        }
    } finally {
        clearTimeout(timeoutId);
        sideData.streaming = false;
        delete round['_abort' + side];
        refreshArenaColumn(ridx, side);
        if (!arenaHasActive()) setStatus('Готов', false, false);
    }
}

async function regenArenaSide(ridx, side) {
    const round = arenaState.rounds[ridx];
    if (!round) return;
    const modelId = side === 'A' ? round.modelA : round.modelB;
    if (!modelId) return;

    const newData = { content: '', reasoning: '', stats: null, streaming: true, createdAt: Date.now(), error: null };
    if (side === 'A') round.answerA = newData;
    else round.answerB = newData;
    round.merged = null;

    updateArenaRoundInDom(ridx);

    const imgB64 = round.image ? round.image.base64 : null;
    const imgMime = round.image ? round.image.mime : null;

    const warmupCtrl = new AbortController();
    round['_warmup' + side] = warmupCtrl;

    setStatus('Загружаю модель…', false, true);
    const warmupOk = await warmupModel(modelId, true, warmupCtrl.signal);
    const cancelled = warmupCtrl.signal.aborted;
    delete round['_warmup' + side];

    if (cancelled) {
        newData.streaming = false;
        newData.content = '⏹️ Отменено';
        refreshArenaColumn(ridx, side);
        if (!arenaHasActive()) setStatus('Готов', false, false);
        return;
    }

    if (!warmupOk) {
        newData.streaming = false;
        newData.content = '❌ Не удалось загрузить модель.';
        refreshArenaColumn(ridx, side);
        if (!arenaHasActive()) setStatus('Готов', false, false);
        return;
    }

    setStatus('Генерация…', false, true);
    await streamArenaSide(round, ridx, side, modelId, round.question, imgB64, imgMime);
}

function abortArenaSide(roundId, side) {
    const round = arenaState.rounds.find(r => r.id === roundId);
    if (!round) return;
    const streamCtrl = round['_abort' + side];
    if (streamCtrl) {
        try { streamCtrl.abort(); } catch (_) {}
    }
    const warmupCtrl = round['_warmup' + side];
    if (warmupCtrl) {
        try { warmupCtrl.abort(); } catch (_) {}
    }
    setTimeout(() => {
        if (!activeRequest && !arenaHasActive()) {
            setStatus('Готов', false, false);
        }
    }, 120);
}

async function startArenaMerge(ridx) {
    const round = arenaState.rounds[ridx];
    if (!round || !round.mergeModel) return;
    const a = round.answerA || {};
    const b = round.answerB || {};
    if (!a.content && !b.content) { showToast('Нечего объединять', 'error'); return; }
    if (!arenaState.mergeSettings) arenaState.mergeSettings = { ...DEFAULT_ARENA_SETTINGS(), temperature: 0.5, max_tokens: 4096 };

    round.merged = { content: '', reasoning: '', stats: null, streaming: true, createdAt: Date.now() };
    updateArenaRoundInDom(ridx);

    setStatus('Загружаю модель-арбитра…', false, true);
    const warmupCtrl = new AbortController();
    round._warmupMerge = warmupCtrl;
    const warmOk = await warmupModel(round.mergeModel, true, warmupCtrl.signal);
    const cancelled = warmupCtrl.signal.aborted;
    delete round._warmupMerge;

    if (cancelled) {
        round.merged.streaming = false;
        round.merged.content = '⏹️ Отменено';
        updateArenaRoundInDom(ridx);
        setStatus('Отменено', false);
        if (!arenaHasActive()) setStatus('Готов', false, false);
        return;
    }

    if (!warmOk) {
        round.merged.streaming = false;
        round.merged.content = '❌ Не удалось загрузить модель-арбитра.';
        updateArenaRoundInDom(ridx);
        setStatus('Ошибка', true);
        if (!arenaHasActive()) setStatus('Готов', false, false);
        return;
    }

    const controller = new AbortController();
    round._abortMerge = controller;

    const settings = arenaState.mergeSettings;
    const payload = {
        question: round.question || '',
        answer_a: a.content || '',
        answer_b: b.content || '',
        model_a: round.modelA || '',
        model_b: round.modelB || '',
        merge_model: round.mergeModel,
        temperature: settings.temperature,
        max_tokens: settings.max_tokens,
        custom_prompt: arenaState.mergePrompt || null,
    };

    if (round.image && round.image.base64) {
        const infoMerge = modelsInfo.find(m => m.id === round.mergeModel);
        if (infoMerge && infoMerge.supports_vision) {
            payload.image = round.image.base64;
            payload.image_mime_type = round.image.mime;
        }
    }

    const scheduleDom = () => rafScheduler.schedule(`arena-merge-${ridx}`, () => {
        const roundEl = arenaContent.querySelector(`[data-round-idx="${ridx}"]`);
        if (!roundEl) return;

        let box = roundEl.querySelector('.arena-merged-box');
        if (!box) {
            const newEl = renderArenaRound(round, ridx);
            roundEl.replaceWith(newEl);
            return;
        }

        let think = box.querySelector('.thinking-block');
        if (round.merged.reasoning && !think) {
            const tmp = document.createElement('div');
            tmp.innerHTML = renderThinkingBlock(round.merged, round.merged.streaming, `ar-${ridx}-M`);
            box.insertBefore(tmp.firstElementChild, box.querySelector('.arena-merged-body'));
        } else if (think) {
            const txt = think.querySelector('.thinking-text');
            if (txt && txt.textContent !== round.merged.reasoning) txt.textContent = round.merged.reasoning;
            const st = think.querySelector('.thinking-status');
            if (st) {
                let s;
                if (!round.merged.streaming) s = `Размышления · ${round.merged.reasoning.length} симв.`;
                else if (round.merged.content) s = 'Отвечает…';
                else s = 'Думает…';
                if (st.textContent !== s) st.textContent = s;
            }
            const shouldStream = !!(round.merged.streaming && !round.merged.content);
            if (think.classList.contains('streaming') !== shouldStream) {
                think.classList.toggle('streaming', shouldStream);
            }
        }

        const body = box.querySelector('.arena-merged-body');
        if (body && round.merged.content) {
            if (body.dataset.raw !== round.merged.content) {
                body.dataset.raw = round.merged.content;
                body.innerHTML = formatMessageWithCode(round.merged.content);
                highlightCode(body);
                addCopyButtonsToCodeBlocks(body);
            }
        } else if (body && round.merged.streaming) {
            if (!body.querySelector('.typing-indicator')) {
                body.innerHTML = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
            }
        }

        const stopBtn = box.querySelector('.arena-merge-stop-btn');
        if (stopBtn) {
            stopBtn.style.display = round.merged.streaming ? '' : 'none';
        }

        const head = box.querySelector('.arena-merged-head');
        if (head) {
            const mStream = !!round.merged.streaming;
            let badge = head.querySelector('.merge-status-badge');
            if (mStream && !badge) {
                const s = document.createElement('span');
                s.className = 'merge-status-badge';
                s.style.marginLeft = 'auto';
                s.textContent = '💡 думает';
                head.appendChild(s);
            } else if (!mStream && badge) {
                badge.remove();
            }
        }

        arenaContent.scrollTop = arenaContent.scrollHeight;
    });

    try {
        const response = await fetch('/chat_arena_merge', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            signal: controller.signal,
        });
        if (!response.ok) {
            let errMsg = `HTTP ${response.status}`;
            try { const j = await response.json(); errMsg = j.error || errMsg; } catch (_) {}
            throw new Error(errMsg);
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';
            for (const line of lines) {
                if (!line.startsWith('data: ')) continue;
                let data;
                try { data = JSON.parse(line.slice(6)); } catch (_) { continue; }
                if (data.error) throw new Error(data.error);
                if (data.cancelled) {
                    if (data.partial) round.merged.content = data.partial;
                    if (data.reasoning_partial) round.merged.reasoning = data.reasoning_partial;
                    break;
                }
                if (data.reasoning) { round.merged.reasoning += data.reasoning; scheduleDom(); }
                if (data.content != null) {
                    if (data.full != null) round.merged.content = data.full;
                    else round.merged.content += data.content;
                    scheduleDom();
                }
                if (data.stats) round.merged.stats = data.stats;
                if (data.done) {
                    if (data.full != null) round.merged.content = data.full;
                    if (data.reasoning != null) round.merged.reasoning = data.reasoning;
                    if (data.stats) round.merged.stats = data.stats;
                }
            }
        }
    } catch (e) {
        if (e.name === 'AbortError') round.merged.content += '\n\n⏹️ Отменено';
        else round.merged.content += `\n\n❌ ${e.message || 'Ошибка merge'}`;
    } finally {
        round.merged.streaming = false;
        delete round._abortMerge;
        updateArenaRoundInDom(ridx);
        onModelFinished(round.merged.content);
        if (!arenaHasActive()) setStatus('Готов', false, false);
    }
}

function abortArenaMerge(roundId) {
    const round = arenaState.rounds.find(r => r.id === roundId);
    if (!round) return;
    if (round._abortMerge) {
        try { round._abortMerge.abort(); } catch (_) {}
    }
    if (round._warmupMerge) {
        try { round._warmupMerge.abort(); } catch (_) {}
    }
    setTimeout(() => {
        if (!activeRequest && !arenaHasActive()) setStatus('Готов', false, false);
    }, 120);
}

function removeArenaRound(ridx) {
    if (!arenaState.rounds[ridx]) return;
    arenaState.rounds.splice(ridx, 1);
    renderArenaContent();
    showToast('Раунд удалён', 'success');
}

async function promoteArenaMergedToChat(ridx) {
    const round = arenaState.rounds[ridx];
    if (!round || !round.merged || !round.merged.content) {
        showToast('Нет объединённого ответа', 'error');
        return;
    }
    const chat = ensureCurrentChat();
    if (!chat) return;

    const asstMsg = {
        role: 'assistant',
        variants: [{
            content: round.merged.content,
            reasoning: round.merged.reasoning || '',
            stats: round.merged.stats || null,
            createdAt: Date.now(),
            streaming: false,
        }],
        activeVariant: 0,
        fromArena: true,
    };
    chat.history.push({
        role: 'user',
        content: `⚔️ Арена — ${round.question || '(вопрос)'}`,
        image: round.image && round.image.thumb
            ? { thumb: round.image.thumb, full: round.image.full || null }
            : null,
    });
    chat.history.push(asstMsg);
    chat.updated = Date.now();
    saveChatsToStorage();

    closeArena();
    renderMessages();
    updateChatTitle();
    updateContextCount();
    showToast('Объединённый ответ перенесён в обычный чат', 'success');
}

function bindArenaEvents() {
    if (arenaModelA) {
        arenaModelA.addEventListener('change', () => {
            arenaState.modelA = arenaModelA.value;
            const prevB = arenaModelB.value;
            arenaModelB.innerHTML = modelsInfo
                .filter(m => m.id !== arenaModelA.value)
                .map(m => `<option value="${m.id}">${m.id}${m.supports_vision ? ' 🖼️' : ''}</option>`)
                .join('');
            if (modelsInfo.some(m => m.id === prevB) && prevB !== arenaModelA.value) {
                arenaModelB.value = prevB;
            } else if (arenaModelB.options.length) {
                arenaModelB.value = arenaModelB.options[0].value;
            }
            arenaState.modelB = arenaModelB.value;
            renderArenaAttachment();
        });
    }
    if (arenaModelB) {
        arenaModelB.addEventListener('change', () => {
            arenaState.modelB = arenaModelB.value;
            renderArenaAttachment();
        });
    }
    if (arenaCfgA) arenaCfgA.addEventListener('click', () => openArenaSettingsModal('A'));
    if (arenaCfgB) arenaCfgB.addEventListener('click', () => openArenaSettingsModal('B'));
    if (arenaRunBtn) arenaRunBtn.addEventListener('click', arenaRun);

    if (arenaContent) {
        arenaContent.addEventListener('click', (e) => {
            const cfgBtn = e.target.closest('.arena-merge-config-btn');
            if (cfgBtn) {
                e.preventDefault();
                e.stopPropagation();
                openArenaSettingsModal('merge');
            }
        });
    }

    if (arenaCloseBtn) {
        arenaCloseBtn.addEventListener('click', () => {
            const hasActive = arenaHasActive();
            if (hasActive) {
                showConfirm('Есть активные запросы. Прервать и закрыть?', {
                    title: 'Закрыть арену', okText: 'Закрыть', cancelText: 'Отмена',
                    danger: true, icon: 'fa-times',
                }).then(ok => {
                    if (ok) {
                        arenaState.rounds.forEach(r => {
                            if (r._abortA) try { r._abortA.abort(); } catch (_) {}
                            if (r._abortB) try { r._abortB.abort(); } catch (_) {}
                            if (r._abortMerge) try { r._abortMerge.abort(); } catch (_) {}
                            if (r._warmupA) try { r._warmupA.abort(); } catch (_) {}
                            if (r._warmupB) try { r._warmupB.abort(); } catch (_) {}
                            if (r._warmupMerge) try { r._warmupMerge.abort(); } catch (_) {}
                        });
                        closeArena();
                    }
                });
            } else {
                closeArena();
            }
        });
    }

    if (arenaQuestion) {
        arenaQuestion.addEventListener('input', function () {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 200) + 'px';
        });
        arenaQuestion.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                arenaRun();
            }
        });
    }

    if (arenaAttachBtn) {
        arenaAttachBtn.addEventListener('click', () => arenaImageInput?.click());
    }
    if (arenaImageInput) {
        arenaImageInput.addEventListener('change', (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            if (!file.type.startsWith('image/')) {
                showToast('Только изображения', 'error');
                return;
            }
            handleImageUpload(file);
        });
    }
    if (arenaAttachRemove) {
        arenaAttachRemove.addEventListener('click', () => clearArenaAttachment());
    }
    if (arenaAttachImg) {
        arenaAttachImg.addEventListener('click', () => {
            openLightbox(currentImageFull || currentImageThumb);
        });
    }
}

function bindEvents() {
    [temperature, topP, topK, frequencyPenalty, presencePenalty, repeatPenalty, maxTokens].forEach(el => {
        if (el) el.addEventListener('input', () => { syncRangeLabels(); saveSettings(); });
    });
    systemPrompt?.addEventListener('change', saveSettings);
    seedInput?.addEventListener('change', saveSettings);

    promptPreset?.addEventListener('change', () => {
        if (promptPreset.value) applyPreset(promptPreset.value);
    });

    soundToggle?.addEventListener('change', () => {
        soundEnabled = soundToggle.checked;
        if (soundEnabled) { ensureAudioContext(); playDoneSound(); }
        saveSettings();
    });

    notifToggle?.addEventListener('change', () => {
        notifEnabled = notifToggle.checked;
        saveSettings();
        if (notifEnabled && 'Notification' in window && Notification.permission === 'default') {
            ensureNotificationPermission();
        }
        if (!notifEnabled) removeTrayNotification();
    });

    let previousModel = modelSelect.value;
    modelSelect?.addEventListener('change', () => {
        const newModel = modelSelect.value;
        const oldModel = previousModel;
        previousModel = newModel;
        localStorage.setItem('selected_model', newModel);
        updateModelBadge();
        updateImageUploadAccess();
        if (currentImageBase64) {
            const info = modelsInfo.find(m => m.id === newModel);
            const canVision = info ? !!info.supports_vision : false;
            if (!canVision) { removeImage(); showToast('Модель без vision — файл удалён', 'error'); }
        }
        if (oldModel !== newModel) {
            addModelDivider(oldModel, newModel);
        }
        showToast(`Модель: ${newModel}`, 'success');
    });

    if (isAdvancedOpen) advancedToggle?.parentElement?.classList.add('open');
    advancedToggle?.addEventListener('click', () => {
        const sec = advancedToggle.parentElement;
        sec.classList.toggle('open');
        localStorage.setItem('advanced_open', sec.classList.contains('open'));
    });

    openDrawerBtn?.addEventListener('click', openDrawer);
    drawerClose?.addEventListener('click', closeDrawer);
    drawerOverlay?.addEventListener('click', closeDrawer);

    openSidebarBtn?.addEventListener('click', () => appEl.classList.toggle('sidebar-collapsed'));
    sidebarClose?.addEventListener('click', () => appEl.classList.add('sidebar-collapsed'));

    newChatBtn?.addEventListener('click', () => {
        if (activeRequest) return showToast('Дождитесь генерации', 'error');
        createNewChat(true);
        showToast('Новый чат', 'success');
    });

    newTempChatBtn?.addEventListener('click', () => openOrCreateTemporaryChat());
    newArenaChatBtn?.addEventListener('click', () => openArena());

    promoteTempBtn?.addEventListener('click', () => promoteTemporaryChat());
    closeTempBtn?.addEventListener('click', () => closeTemporaryChat());

    exportChatBtn?.addEventListener('click', exportCurrentChat);

    clearAllChatsBtn?.addEventListener('click', async () => {
        const favorites = chats.filter(c => c.favorite && !c.temporary);
        const msg = favorites.length
            ? `Удалить все чаты?\n\nИзбранные (${favorites.length}) останутся.`
            : 'Удалить все чаты?';
        const ok = await showConfirm(msg, {
            title: 'Очистить всё', okText: 'Да', cancelText: 'Нет',
            danger: true, icon: 'fa-trash-alt',
        });
        if (!ok) return;
        chats = favorites.slice();
        if (!chats.length) {
            const newChat = {
                id: uid(), title: 'Новый чат',
                created: Date.now(), updated: Date.now(),
                favorite: false, temporary: false, history: [],
            };
            chats.unshift(newChat);
            currentChatId = newChat.id;
        } else {
            if (!chats.find(c => c.id === currentChatId)) currentChatId = chats[0].id;
            sortChats();
        }
        saveChatsToStorage(); renderChatsList(); renderMessages();
        updateChatTitle(); updateTempModeUI(); updateContextCount();
        showToast('Чаты очищены', 'success');
    });

    clearChatBtn?.addEventListener('click', async () => {
        const chat = getCurrentChat();
        if (!chat) return;
        const ok = await showConfirm('Очистить текущий диалог?',
            { title: 'Очистить', okText: 'Да', cancelText: 'Нет', danger: true, icon: 'fa-eraser' });
        if (!ok) return;
        chat.history = [];
        chat.title = chat.temporary ? 'Временный чат' : 'Новый чат';
        chat.updated = Date.now();
        saveChatsToStorage(); renderMessages(); updateChatTitle(); renderChatsList();
        closeDrawer();
        showToast('Диалог очищен', 'success');
    });

    resetSettingsBtn?.addEventListener('click', resetSettings);

    uploadImageBtn?.addEventListener('click', () => imageInput?.click());
    imageInput?.addEventListener('change', (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) { showToast('Только изображения', 'error'); return; }
        const cur = modelSelect.value;
        const curInfo = modelsInfo.find(m => m.id === cur);
        const canVision = curInfo ? !!curInfo.supports_vision : false;
        if (!canVision) {
            const visionModel = modelsInfo.find(m => m.supports_vision);
            if (!visionModel) { showToast('Нет Vision-моделей', 'error'); return; }
            const oldName = cur || '—';
            modelSelect.value = visionModel.id;
            localStorage.setItem('selected_model', visionModel.id);
            updateModelBadge(); updateImageUploadAccess();
            addModelDivider(oldName, visionModel.id);
            showToast(`Модель: ${visionModel.id}`, 'success');
        }
        handleImageUpload(file);
    });
    removeImageBtn?.addEventListener('click', removeImage);

    imageUploadArea?.addEventListener('dragover', (e) => { e.preventDefault(); imageUploadArea.classList.add('drag-over'); });
    imageUploadArea?.addEventListener('dragleave', () => imageUploadArea.classList.remove('drag-over'));
    imageUploadArea?.addEventListener('drop', (e) => {
        e.preventDefault();
        imageUploadArea.classList.remove('drag-over');
        if (e.dataTransfer.files?.[0]) handleDroppedFiles(Array.from(e.dataTransfer.files));
    });

    userInput?.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 160) + 'px';
    });
    userInput?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
    });
    sendBtn?.addEventListener('click', sendMessage);
    stopBtn?.addEventListener('click', stopGeneration);

    bindDropZone();
    bindArenaEvents();

    window.addEventListener('dragend', stopFlashWindowAttention);
    window.addEventListener('blur', () => { setTimeout(stopFlashWindowAttention, 200); });

    setInterval(() => {
        fetch('/heartbeat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ session_id: currentChatId || '' })
        }).catch(() => {});
    }, 45000);
}

function init() {
    loadChatsFromStorage();
    loadSettings();
    loadModels();
    renderChatsList();
    renderMessages();
    updateChatTitle();
    updateTempModeUI();
    updateContextCount();
    bindEvents();
    updateImageUploadAccess();
    initLightbox();

    if ('Notification' in window && Notification.permission === 'granted') notificationPermissionGranted = true;
    if (window.innerWidth <= 900) appEl.classList.add('sidebar-collapsed');
    if (window.hljs) hljs.highlightAll();
    console.log('Local AI Chat v3.25 ready (cookie-based identity, rAF batching)');
}

init();