from flask import Flask, render_template, request, jsonify, Response, stream_with_context
import requests
import time
import json
import uuid
import threading
from functools import wraps
from datetime import datetime, timedelta
import base64
import imghdr
import io
from PIL import Image
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)
app.config['SESSION_PERMANENT'] = False
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10MB

# ========== КОНФИГУРАЦИЯ LM STUDIO ==========
LM_SERVERS = {
    "qwen3-8b": "http://127.0.0.1:1234/v1",
    "gemma-4-e2b-it-ud": "http://127.0.0.1:1234/v1",
    "qwen3vl-2b-instruct": "http://127.0.0.1:1234/v1",
    "k2-horizon-7b": "http://127.0.0.1:1234/v1",
}

VISION_SUPPORT = {
    "qwen3-8b": False,
    "gemma-4-e2b-it-ud": False,
    "qwen3vl-2b-instruct": True,
    "k2-horizon-7b": False,
}
# ===========================================

RATE_LIMIT_SECONDS = 2.5
MAX_TOKENS_LIMIT = 8192
MAX_HISTORY_MESSAGES = 24

REQUEST_TIMEOUT_CONNECT = 120
REQUEST_TIMEOUT_READ = 600

CANCEL_LIMIT_WINDOW = 30
CANCEL_MAX_ATTEMPTS = 3
CANCEL_BLOCK_DURATION = 45

MAX_IMAGE_SIZE_MB = 5
MAX_IMAGE_SIZE_BYTES = MAX_IMAGE_SIZE_MB * 1024 * 1024
MAX_IMAGE_WIDTH = 4096
MAX_IMAGE_HEIGHT = 4096
ALLOWED_IMAGE_FORMATS = ['jpeg', 'jpg', 'png', 'webp']

# ========== ИДЕНТИФИКАЦИЯ ПОЛЬЗОВАТЕЛЯ (COOKIE + IP) ==========
COOKIE_NAME = 'client_id'
COOKIE_MAX_AGE = 60 * 60 * 24 * 365   # 1 год
USER_TTL_SECONDS = 60 * 30            # 30 минут неактивности → удаляем
CLEANUP_INTERVAL = 60                 # проверка раз в минуту
MAX_TRACKED_USERS = 1000              # жёсткий лимит одновременных пользователей

user_last_seen = {}
user_last_seen_lock = threading.Lock()


def get_client_id():
    """
    Стабильный идентификатор клиента.
    Приоритет: cookie client_id → remote_addr.
    Cookie ставится в after_request, если её нет.
    """
    cid = request.cookies.get(COOKIE_NAME)
    if cid and len(cid) == 32 and all(c in '0123456789abcdef' for c in cid):
        return f"c:{cid}"
    return f"ip:{request.remote_addr or 'unknown'}"


def touch_user(user_id):
    """Отмечает активность пользователя для TTL-очистки."""
    with user_last_seen_lock:
        user_last_seen[user_id] = time.time()


@app.after_request
def ensure_client_cookie(response):
    """Ставит cookie client_id, если её ещё нет."""
    if not request.cookies.get(COOKIE_NAME):
        new_id = uuid.uuid4().hex
        response.set_cookie(
            COOKIE_NAME, new_id,
            max_age=COOKIE_MAX_AGE,
            httponly=True,
            samesite='Lax',
            secure=False,  # True за HTTPS
        )
    return response


# ========== СОСТОЯНИЕ ЗАПРОСОВ ==========
# active_requests[user_id] — set(request_id) — допускает параллельные запросы (арена)
# active_requests_started[user_id] — dict(request_id -> ts)
cancel_attempts = {}
cancel_blocked_until = {}
last_request_time = {}
active_requests = {}
active_requests_started = {}
user_sessions = {}

STALE_REQUEST_SECONDS = 300   # для арены долгие reasoning-модели
MAX_PARALLEL_PER_USER = 4

# Теги размышлений Qwen3
THINK_OPEN = ' thinking'
THINK_CLOSE = ''

# ========== ДЕФОЛТНЫЙ ПРОМПТ АРБИТРА ==========
DEFAULT_ARENA_MERGE_PROMPT = (
    "Ты — арбитр. Ниже два ответа на один и тот же вопрос от разных моделей.\n"
    "Собери из них ОДИН лучший ответ: возьми лучшее из каждого, устрани противоречия, "
    "не дублируйся, сохрани структуру (списки, код, таблицы).\n\n"
    "Если оба ответа совпадают — просто отдай наиболее полный.\n"
    "Не упоминай, что это объединение, не ссылайся на \"модель A\" и \"модель B\". "
    "Просто дай финальный ответ.\n\n"
    "Вопрос:\n{question}\n\n"
    "Ответ A ({model_a}):\n{answer_a}\n\n"
    "Ответ B ({model_b}):\n{answer_b}"
)


# ========== ХЕЛПЕРЫ ==========
def sse(obj):
    return f"data: {json.dumps(obj, ensure_ascii=False)}\n\n"


def _active_set(user_id):
    s = active_requests.get(user_id)
    if not isinstance(s, set):
        s = set()
        active_requests[user_id] = s
    return s


def _started_dict(user_id):
    d = active_requests_started.get(user_id)
    if not isinstance(d, dict):
        d = {}
        active_requests_started[user_id] = d
    return d


def _register_request(user_id, request_id):
    _active_set(user_id).add(request_id)
    _started_dict(user_id)[request_id] = time.time()


def _unregister_request(user_id, request_id):
    _active_set(user_id).discard(request_id)
    _started_dict(user_id).pop(request_id, None)


def _cleanup_stale(user_id):
    now = time.time()
    s = _active_set(user_id)
    d = _started_dict(user_id)
    for rid in list(s):
        started = d.get(rid, 0)
        if now - started > STALE_REQUEST_SECONDS:
            print(f"⚠️ Сброс зависшего запроса {rid} (>{STALE_REQUEST_SECONDS}с)")
            s.discard(rid)
            d.pop(rid, None)


def validate_image_safe(base64_string, client_mime_type):
    base64_size = len(base64_string)
    estimated_bytes = int(base64_size * 0.75)
    if estimated_bytes > MAX_IMAGE_SIZE_BYTES:
        return False, f"Изображение слишком большое. Максимум {MAX_IMAGE_SIZE_MB}MB", None
    try:
        image_bytes = base64.b64decode(base64_string)
    except Exception as e:
        return False, f"Некорректные данные изображения: {str(e)}", None
    if len(image_bytes) > MAX_IMAGE_SIZE_BYTES:
        return False, f"Изображение слишком большое после декодирования. Максимум {MAX_IMAGE_SIZE_MB}MB", None
    if len(image_bytes) < 100:
        return False, "Файл изображения слишком маленький или пустой", None

    detected_format = imghdr.what(None, h=image_bytes)
    if not detected_format:
        if len(image_bytes) > 4:
            if image_bytes[0:3] == b'\xff\xd8\xff':
                detected_format = 'jpeg'
            elif image_bytes[0:8] == b'\x89PNG\r\n\x1a\n':
                detected_format = 'png'
            elif len(image_bytes) > 12 and image_bytes[0:4] == b'RIFF' and image_bytes[8:12] == b'WEBP':
                detected_format = 'webp'
    if not detected_format:
        return False, "Файл не является изображением или формат не поддерживается", None
    if detected_format not in ALLOWED_IMAGE_FORMATS:
        return False, f"Формат '{detected_format}' не поддерживается. Разрешены: {', '.join(ALLOWED_IMAGE_FORMATS)}", None

    if detected_format in ('jpg', 'jpeg'):
        validated_mime = 'image/jpeg'
    elif detected_format == 'png':
        validated_mime = 'image/png'
    elif detected_format == 'webp':
        validated_mime = 'image/webp'
    else:
        validated_mime = f'image/{detected_format}'

    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            if img.width > MAX_IMAGE_WIDTH or img.height > MAX_IMAGE_HEIGHT:
                return False, f"Изображение слишком большое: {img.width}x{img.height}. Максимум {MAX_IMAGE_WIDTH}x{MAX_IMAGE_HEIGHT}", None
            img.verify()
    except Exception as e:
        return False, f"Ошибка обработки изображения: {str(e)}", None
    return True, None, validated_mime


def extract_text_from_content(content):
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        texts = []
        for item in content:
            if isinstance(item, dict) and item.get('type') == 'text':
                texts.append(item.get('text', ''))
        return ' '.join(texts)
    return str(content) if content else ''


def count_tokens(text):
    if not text:
        return 0
    return max(1, len(text) // 3 + text.count('\n') // 2)


def check_token_limit(messages, system_prompt, user_message):
    total_text = system_prompt or ''
    if isinstance(user_message, list):
        user_text = extract_text_from_content(user_message)
    else:
        user_text = user_message or ''
    total_text += user_text
    for msg in messages:
        content = msg.get('content', '')
        total_text += extract_text_from_content(content)
    token_count = count_tokens(total_text)
    if token_count > MAX_TOKENS_LIMIT:
        return False, f"Превышен лимит токенов: ~{token_count}/{MAX_TOKENS_LIMIT}. Очистите историю или уменьшите max_tokens."
    return True, token_count


def truncate_history(messages, max_messages=MAX_HISTORY_MESSAGES):
    if len(messages) <= max_messages + 1:
        return messages
    system = [m for m in messages if m.get('role') == 'system']
    rest = [m for m in messages if m.get('role') != 'system']
    return system + rest[-(max_messages):]


def build_stats(full_response, full_reasoning, start_ts, first_token_ts, usage, chunks):
    now = time.time()
    elapsed = now - start_ts
    ttft = (first_token_ts - start_ts) if first_token_ts else None
    gen_time = (now - first_token_ts) if first_token_ts else 0.0

    if usage:
        completion_tokens = usage.get('completion_tokens') or 0
        prompt_tokens = usage.get('prompt_tokens') or 0
        total_tokens = usage.get('total_tokens') or (completion_tokens + prompt_tokens)
    else:
        completion_tokens = count_tokens(full_response + full_reasoning)
        prompt_tokens = 0
        total_tokens = completion_tokens

    tps = (completion_tokens / gen_time) if gen_time > 0.05 else 0.0

    return {
        'prompt_tokens': prompt_tokens,
        'completion_tokens': completion_tokens,
        'total_tokens': total_tokens,
        'elapsed_sec': round(elapsed, 2),
        'ttft_sec': round(ttft, 2) if ttft is not None else None,
        'tokens_per_sec': round(tps, 1),
        'chunks': chunks,
        'reasoning_chars': len(full_reasoning),
        'answer_chars': len(full_response),
    }


def check_cancel_limit(user_id):
    now = datetime.now()
    if user_id in cancel_blocked_until:
        if now < cancel_blocked_until[user_id]:
            remaining = int((cancel_blocked_until[user_id] - now).total_seconds())
            return False, f"Слишком много отмен. Блокировка ещё {remaining} с."
        else:
            del cancel_blocked_until[user_id]
            cancel_attempts[user_id] = []
    if user_id not in cancel_attempts:
        cancel_attempts[user_id] = []
    cutoff = now - timedelta(seconds=CANCEL_LIMIT_WINDOW)
    cancel_attempts[user_id] = [ts for ts in cancel_attempts[user_id] if ts > cutoff]
    # Защита от роста списка при спаме отмен
    if len(cancel_attempts[user_id]) > 100:
        cancel_attempts[user_id] = cancel_attempts[user_id][-20:]
    if len(cancel_attempts[user_id]) >= CANCEL_MAX_ATTEMPTS:
        cancel_blocked_until[user_id] = now + timedelta(seconds=CANCEL_BLOCK_DURATION)
        return False, f"Слишком много отмен ({CANCEL_MAX_ATTEMPTS} за {CANCEL_LIMIT_WINDOW} с). Подождите {CANCEL_BLOCK_DURATION} с."
    cancel_attempts[user_id].append(now)
    return True, None


def rate_limit(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = get_client_id()
        touch_user(user_id)
        now = time.time()
        _cleanup_stale(user_id)
        s = _active_set(user_id)
        if len(s) >= MAX_PARALLEL_PER_USER:
            return jsonify({'error': 'Слишком много одновременных запросов. Дождитесь завершения.'}), 429
        if user_id in last_request_time:
            elapsed = now - last_request_time[user_id]
            if elapsed < RATE_LIMIT_SECONDS and not s:
                wait_time = round(RATE_LIMIT_SECONDS - elapsed, 1)
                return jsonify({'error': f'Слишком много запросов. Подождите {wait_time} с.', 'wait_time': wait_time}), 429
        last_request_time[user_id] = now
        return f(*args, **kwargs)
    return decorated_function


# ========== ФОНОВАЯ ОЧИСТКА НЕАКТИВНЫХ ПОЛЬЗОВАТЕЛЕЙ ==========
def _drop_user(user_id):
    """Полное удаление данных пользователя из всех структур."""
    active_requests.pop(user_id, None)
    active_requests_started.pop(user_id, None)
    cancel_attempts.pop(user_id, None)
    cancel_blocked_until.pop(user_id, None)
    last_request_time.pop(user_id, None)
    user_sessions.pop(user_id, None)


def cleanup_all_users():
    """
    Удаляет данные неактивных пользователей (TTL) и принудительно
    ограничивает общее число отслеживаемых пользователей.
    """
    now = time.time()
    cutoff = now - USER_TTL_SECONDS
    stale = []

    with user_last_seen_lock:
        # 1. TTL-очистка
        for uid, ts in list(user_last_seen.items()):
            if ts < cutoff:
                stale.append(uid)
                user_last_seen.pop(uid, None)

        # 2. Жёсткий лимит по количеству
        if len(user_last_seen) > MAX_TRACKED_USERS:
            extra = sorted(user_last_seen.items(), key=lambda x: x[1])[
                :len(user_last_seen) - MAX_TRACKED_USERS
            ]
            for uid, _ in extra:
                stale.append(uid)
                user_last_seen.pop(uid, None)

    # 3. Удаляем данные тех, кто не имеет активных запросов
    for uid in set(stale):
        s = active_requests.get(uid)
        if s:
            d = active_requests_started.get(uid, {})
            # Оставляем только «живые» запросы
            for rid in list(s):
                if now - d.get(rid, 0) > STALE_REQUEST_SECONDS:
                    s.discard(rid)
                    d.pop(rid, None)
            if s:
                continue  # ещё есть активные — не трогаем
        _drop_user(uid)

    if stale:
        print(f"🧹 Очистка: удалено {len(set(stale))} неактивных. "
              f"Активных отслеживается: {len(user_last_seen)}")


def start_cleanup_thread():
    def loop():
        while True:
            try:
                cleanup_all_users()
            except Exception as e:
                print(f"⚠️ cleanup error: {e}")
            time.sleep(CLEANUP_INTERVAL)

    t = threading.Thread(target=loop, daemon=True, name='cleanup')
    t.start()
    print(f"🧹 Фоновый cleanup запущен (TTL={USER_TTL_SECONDS}s, "
          f"интервал={CLEANUP_INTERVAL}s, лимит={MAX_TRACKED_USERS})")


# ========== ПАРСЕР  thinking ==========
class ThinkTagParser:
    def __init__(self):
        self.in_think = False
        self.tag_buffer = ''

    def feed(self, piece):
        out = []
        text = self.tag_buffer + piece
        self.tag_buffer = ''

        while text:
            if not self.in_think:
                idx = text.find(THINK_OPEN)
                if idx == -1:
                    saved = ''
                    for k in range(1, min(len(THINK_OPEN), len(text)) + 1):
                        if text.endswith(THINK_OPEN[:k]):
                            saved = THINK_OPEN[:k]
                    if saved:
                        main = text[:-len(saved)]
                        if main:
                            out.append(('content', main))
                        self.tag_buffer = saved
                        return out
                    out.append(('content', text))
                    return out
                if idx > 0:
                    out.append(('content', text[:idx]))
                text = text[idx + len(THINK_OPEN):]
                self.in_think = True
                continue
            else:
                idx = text.find(THINK_CLOSE)
                if idx == -1:
                    saved = ''
                    for k in range(1, min(len(THINK_CLOSE), len(text)) + 1):
                        if text.endswith(THINK_CLOSE[:k]):
                            saved = THINK_CLOSE[:k]
                    if saved:
                        main = text[:-len(saved)]
                        if main:
                            out.append(('reasoning', main))
                        self.tag_buffer = saved
                        return out
                    out.append(('reasoning', text))
                    return out
                if idx > 0:
                    out.append(('reasoning', text[:idx]))
                text = text[idx + len(THINK_CLOSE):]
                self.in_think = False
                continue
        return out

    def flush(self):
        if not self.tag_buffer:
            return []
        piece = self.tag_buffer
        self.tag_buffer = ''
        return [('reasoning' if self.in_think else 'content', piece)]


# ========== ОБЩИЙ СТРИМ ==========
def _stream_chat_response(user_id, request_id, lm_studio_url, payload,
                          model_name, base_url, validated_image_data):
    def generate():
        full_response = ""
        full_reasoning = ""
        usage = None
        start_ts = time.time()
        first_token_ts = None
        chunks = 0
        tag_parser = ThinkTagParser()
        response = None

        def emit(kind, text):
            nonlocal full_response, full_reasoning, first_token_ts, chunks
            if not text:
                return None
            if first_token_ts is None:
                first_token_ts = time.time()
            chunks += 1
            if kind == 'reasoning':
                full_reasoning += text
                return sse({'reasoning': text, 'request_id': request_id})
            else:
                full_response += text
                return sse({'content': text, 'full': full_response, 'request_id': request_id})

        try:
            last_err = None
            for attempt in range(2):
                if request_id not in _active_set(user_id):
                    return
                try:
                    response = requests.post(
                        lm_studio_url,
                        json=payload,
                        stream=True,
                        timeout=(REQUEST_TIMEOUT_CONNECT, REQUEST_TIMEOUT_READ)
                    )
                    if response.status_code == 200:
                        break
                    last_err = f'HTTP {response.status_code}: {(response.text or "")[:200]}'
                    try: response.close()
                    except Exception: pass
                    response = None
                    if attempt == 0:
                        print(f"⚠️ LM Studio {last_err} — повтор через 2 с")
                        time.sleep(2)
                        continue
                except (requests.exceptions.Timeout,
                        requests.exceptions.ConnectionError) as e:
                    last_err = str(e)[:200]
                    response = None
                    if attempt == 0:
                        print(f"⚠️ LM Studio {last_err} — повтор через 2 с")
                        time.sleep(2)
                        continue
                    raise

            if response is None or response.status_code != 200:
                yield sse({'error': f'Ошибка LM Studio: {last_err or "не удалось получить ответ"}', 'request_id': request_id})
                return

            if validated_image_data:
                yield sse({'content': '🖼️ **Обработка изображения...**', 'request_id': request_id})

            for line in response.iter_lines():
                if request_id not in _active_set(user_id):
                    response.close()
                    for k, t in tag_parser.flush():
                        piece = emit(k, t)
                        if piece: yield piece
                    yield sse({
                        'cancelled': True,
                        'partial': full_response,
                        'reasoning_partial': full_reasoning,
                        'stats': build_stats(full_response, full_reasoning,
                                             start_ts, first_token_ts, usage, chunks),
                        'request_id': request_id,
                    })
                    return

                if user_id in user_sessions and not user_sessions[user_id].get('active', True):
                    response.close()
                    yield sse({
                        'cancelled': True,
                        'partial': full_response,
                        'reasoning_partial': full_reasoning,
                        'reason': 'session_closed',
                        'request_id': request_id,
                    })
                    return

                if not line:
                    continue
                line = line.decode('utf-8', errors='replace')
                if not line.startswith('data: '):
                    continue
                data_str = line[6:].strip()
                if data_str == '[DONE]':
                    break
                try:
                    chunk = json.loads(data_str)
                except json.JSONDecodeError:
                    continue
                if chunk.get('usage'):
                    usage = chunk['usage']
                choices = chunk.get('choices') or []
                if not choices:
                    continue
                delta = choices[0].get('delta') or {}
                reasoning_piece = delta.get('reasoning_content') or delta.get('reasoning') or ''
                if reasoning_piece:
                    if first_token_ts is None:
                        first_token_ts = time.time()
                    chunks += 1
                    full_reasoning += reasoning_piece
                    yield sse({'reasoning': reasoning_piece, 'request_id': request_id})
                    continue
                content = delta.get('content') or ''
                if not content:
                    continue
                for kind, text in tag_parser.feed(content):
                    piece = emit(kind, text)
                    if piece:
                        yield piece

            for kind, text in tag_parser.flush():
                piece = emit(kind, text)
                if piece:
                    yield piece

            stats = build_stats(full_response, full_reasoning,
                                start_ts, first_token_ts, usage, chunks)
            yield sse({
                'done': True,
                'full': full_response,
                'reasoning': full_reasoning,
                'stats': stats,
                'request_id': request_id,
            })

        except GeneratorExit:
            try: response.close()
            except Exception: pass
        except requests.exceptions.Timeout:
            try:
                yield sse({'error': f'Таймаут ответа от {model_name} ({REQUEST_TIMEOUT_READ} с).', 'request_id': request_id})
            except Exception:
                pass
        except requests.exceptions.ConnectionError:
            try:
                yield sse({'error': f'Не удалось подключиться к {base_url}.', 'request_id': request_id})
            except Exception:
                pass
        except Exception as e:
            try:
                yield sse({'error': str(e), 'request_id': request_id})
            except Exception:
                pass
        finally:
            _unregister_request(user_id, request_id)

    return generate()


def _build_lm_url(model_name):
    base_url = LM_SERVERS[model_name].rstrip('/')
    if base_url.endswith('/v1') or base_url.endswith('/api'):
        return base_url + "/chat/completions", base_url
    return base_url + "/v1/chat/completions", base_url


# ========== ROUTES ==========
@app.route('/health', methods=['GET'])
def health():
    servers_status = {}
    for model, base in LM_SERVERS.items():
        try:
            r = requests.get(base.rstrip('/') + '/models', timeout=3)
            servers_status[model] = {'ok': r.status_code == 200, 'status': r.status_code}
        except Exception as e:
            servers_status[model] = {'ok': False, 'error': str(e)[:80]}
    return jsonify({
        'status': 'ok',
        'models': list(LM_SERVERS.keys()),
        'servers': servers_status,
        'time': datetime.now().isoformat()
    })


@app.route('/warmup', methods=['POST'])
def warmup():
    data = request.json or {}
    model_name = data.get('model') or ''
    if not model_name or model_name not in LM_SERVERS:
        return jsonify({'status': 'error', 'detail': 'Модель не найдена'}), 400

    url, _ = _build_lm_url(model_name)
    payload = {
        "model": model_name,
        "messages": [{"role": "user", "content": "ok"}],
        "max_tokens": 1,
        "stream": False,
        "temperature": 0,
    }

    started = time.time()
    try:
        r = requests.post(url, json=payload, timeout=(120, 180))
        elapsed = round(time.time() - started, 2)
        if r.status_code == 200:
            print(f"✅ Warmup OK: {model_name} за {elapsed} с")
            return jsonify({'status': 'ok', 'warmed': True, 'elapsed': elapsed})
        return jsonify({'status': 'error', 'http': r.status_code, 'detail': (r.text or '')[:200], 'elapsed': elapsed})
    except requests.exceptions.Timeout:
        return jsonify({'status': 'error', 'detail': 'timeout'})
    except requests.exceptions.ConnectionError:
        return jsonify({'status': 'error', 'detail': 'connection refused'})
    except Exception as e:
        return jsonify({'status': 'error', 'detail': str(e)[:200]})


@app.route('/cancel', methods=['POST'])
def cancel_request():
    user_id = get_client_id()
    touch_user(user_id)
    data = request.json or {}
    target_request_id = data.get('request_id')

    is_allowed, error_message = check_cancel_limit(user_id)
    if not is_allowed:
        return jsonify({'error': error_message, 'blocked': True, 'block_duration': CANCEL_BLOCK_DURATION}), 429

    s = _active_set(user_id)
    d = _started_dict(user_id)

    if target_request_id:
        if target_request_id in s:
            s.discard(target_request_id)
            d.pop(target_request_id, None)
            return jsonify({'status': 'cancelled', 'request_id': target_request_id})
        return jsonify({'status': 'no_active_request'})

    if s:
        count = len(s)
        active_requests[user_id] = set()
        active_requests_started[user_id] = {}
        return jsonify({'status': 'cancelled_all', 'count': count})
    return jsonify({'status': 'no_active_request'})


@app.route('/heartbeat', methods=['POST'])
def heartbeat():
    user_id = get_client_id()
    touch_user(user_id)
    data = request.json or {}
    session_id = data.get('session_id', '')
    user_sessions[user_id] = {
        'session_id': session_id,
        'last_heartbeat': time.time(),
        'active': True
    }
    return jsonify({'status': 'ok'})


@app.route('/cleanup_session', methods=['POST'])
def cleanup_session():
    user_id = get_client_id()
    touch_user(user_id)
    active_requests[user_id] = set()
    active_requests_started[user_id] = {}
    if user_id in user_sessions:
        user_sessions[user_id]['active'] = False
    return jsonify({'status': 'cleaned'})


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/get_models', methods=['GET'])
def get_models():
    models_list = []
    for model_id in LM_SERVERS.keys():
        models_list.append({
            "id": model_id,
            "supports_vision": VISION_SUPPORT.get(model_id, False)
        })
    return jsonify({'models': models_list, 'server_busy': False})


# ========== ОБЫЧНЫЙ ЧАТ ==========
@app.route('/chat', methods=['POST'])
@rate_limit
def chat():
    user_id = get_client_id()
    touch_user(user_id)
    request_id = str(uuid.uuid4())
    _register_request(user_id, request_id)

    try:
        data = request.json or {}
        user_message = (data.get('message') or '').strip()
        conversation_history = data.get('history') or []
        model_name = data.get('model') or ''

        if not model_name or model_name not in LM_SERVERS:
            _unregister_request(user_id, request_id)
            return jsonify({'error': f'Модель "{model_name}" не найдена.'}), 400

        lm_studio_url, base_url = _build_lm_url(model_name)

        image_data = data.get('image')
        image_mime_type = data.get('image_mime_type', 'image/jpeg')
        validated_image_data = None
        validated_mime_type = None

        if image_data:
            is_valid, error_msg, validated_mime = validate_image_safe(image_data, image_mime_type)
            if not is_valid:
                _unregister_request(user_id, request_id)
                return jsonify({'error': f'Ошибка изображения: {error_msg}'}), 400
            validated_image_data = image_data
            validated_mime_type = validated_mime or image_mime_type

        temperature = float(data.get('temperature', 0.7))
        top_p = float(data.get('top_p', 0.9))
        top_k = int(data.get('top_k', 50))
        presence_penalty = float(data.get('presence_penalty', 0.0))
        frequency_penalty = float(data.get('frequency_penalty', 0.0))
        repeat_penalty = float(data.get('repeat_penalty', 1.0))
        system_prompt = data.get('system_prompt') or 'Ты полезный ассистент.'
        max_tokens = int(data.get('max_tokens', 2048))
        stop_sequences = data.get('stop_sequences') or []
        seed = data.get('seed')

        messages = [{"role": "system", "content": system_prompt}]
        for msg in conversation_history:
            role = msg.get('role')
            content = msg.get('content')
            if role in ('user', 'assistant') and content is not None:
                messages.append({"role": role, "content": content})

        if validated_image_data:
            user_content = []
            if user_message:
                user_content.append({"type": "text", "text": user_message})
            else:
                user_content.append({"type": "text", "text": "Что на этом изображении?"})
            user_content.append({
                "type": "image_url",
                "image_url": {"url": f"data:{validated_mime_type};base64,{validated_image_data}"}
            })
            messages.append({"role": "user", "content": user_content})
        else:
            if not user_message:
                _unregister_request(user_id, request_id)
                return jsonify({'error': 'Введите сообщение'}), 400
            messages.append({"role": "user", "content": user_message})

        messages = truncate_history(messages)

        is_valid, token_result = check_token_limit(messages, system_prompt, user_message)
        if not is_valid:
            _unregister_request(user_id, request_id)
            return jsonify({'error': token_result}), 400

        payload = {
            "model": model_name,
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "top_k": top_k,
            "max_tokens": max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
            "chat_template_kwargs": {"enable_thinking": True},
        }
        if presence_penalty != 0.0: payload["presence_penalty"] = presence_penalty
        if frequency_penalty != 0.0: payload["frequency_penalty"] = frequency_penalty
        if repeat_penalty != 1.0: payload["repeat_penalty"] = repeat_penalty
        if stop_sequences: payload["stop"] = stop_sequences
        if seed is not None and seed != '':
            try: payload["seed"] = int(seed)
            except (ValueError, TypeError): pass

        generator = _stream_chat_response(
            user_id, request_id, lm_studio_url, payload,
            model_name, base_url, validated_image_data
        )

        return Response(
            stream_with_context(generator),
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache, no-transform',
                'X-Accel-Buffering': 'no',
                'Connection': 'keep-alive',
                'Content-Type': 'text/event-stream; charset=utf-8',
                'Transfer-Encoding': 'chunked',
            }
        )
    except Exception as e:
        _unregister_request(user_id, request_id)
        return jsonify({'error': f'Внутренняя ошибка: {str(e)}'}), 500


# ========== АРЕНА ==========
def _substitute_prompt(template, question, model_a, answer_a, model_b, answer_b):
    s = template or ''
    s = s.replace('{question}', question or '(пусто)')
    s = s.replace('{model_a}', model_a or 'Model A')
    s = s.replace('{answer_a}', answer_a or '(пустой ответ)')
    s = s.replace('{model_b}', model_b or 'Model B')
    s = s.replace('{answer_b}', answer_b or '(пустой ответ)')
    return s


@app.route('/chat_arena_merge', methods=['POST'])
@rate_limit
def chat_arena_merge():
    user_id = get_client_id()
    touch_user(user_id)
    request_id = str(uuid.uuid4())
    _register_request(user_id, request_id)

    try:
        data = request.json or {}
        question = (data.get('question') or '').strip()
        answer_a = (data.get('answer_a') or '').strip()
        answer_b = (data.get('answer_b') or '').strip()
        model_a = (data.get('model_a') or '').strip()
        model_b = (data.get('model_b') or '').strip()
        merge_model = (data.get('merge_model') or '').strip()
        custom_prompt = (data.get('custom_prompt') or '').strip()

        print(f"🎭 Arena merge: model={merge_model!r}, "
              f"answer_a={len(answer_a)} симв., answer_b={len(answer_b)} симв., "
              f"question={len(question)} симв., custom_prompt={len(custom_prompt)} симв.")
        if answer_a:
            print(f"   A preview: {answer_a[:80]!r}")
        if answer_b:
            print(f"   B preview: {answer_b[:80]!r}")

        if not merge_model or merge_model not in LM_SERVERS:
            _unregister_request(user_id, request_id)
            return jsonify({'error': f'Модель "{merge_model}" не найдена'}), 400

        if not answer_a and not answer_b:
            _unregister_request(user_id, request_id)
            return jsonify({'error': 'Оба ответа пусты — нечего объединять'}), 400

        lm_studio_url, base_url = _build_lm_url(merge_model)

        template = custom_prompt if custom_prompt else DEFAULT_ARENA_MERGE_PROMPT
        user_prompt = _substitute_prompt(
            template,
            question=question,
            model_a=model_a,
            answer_a=answer_a,
            model_b=model_b,
            answer_b=answer_b,
        )

        system_prompt = (
            "Ты — эксперт-редактор. Твоя задача — объединить два ответа на один вопрос "
            "в один наиболее полный и качественный ответ. Сохраняй markdown, код и таблицы. "
            "Не упоминай источники, не пиши 'модель A' или 'модель B'."
        )

        print(f"   → user_prompt итог: {len(user_prompt)} симв. "
              f"(custom={'да' if custom_prompt else 'нет'})")

        image_data = data.get('image')
        image_mime_type = data.get('image_mime_type', 'image/jpeg')
        validated_image_data = None
        validated_mime_type = None

        if image_data and VISION_SUPPORT.get(merge_model, False):
            is_valid, error_msg, validated_mime = validate_image_safe(image_data, image_mime_type)
            if is_valid:
                validated_image_data = image_data
                validated_mime_type = validated_mime or image_mime_type
                print(f"   + передаём картинку арбитру ({len(validated_image_data)} base64 симв.)")
            else:
                print(f"⚠️ Arena merge image invalid: {error_msg}")

        if validated_image_data:
            user_content = [
                {"type": "text", "text": user_prompt},
                {"type": "image_url", "image_url": {
                    "url": f"data:{validated_mime_type};base64,{validated_image_data}"
                }},
            ]
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
            ]
        else:
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]

        temperature = float(data.get('temperature', 0.5))
        max_tokens = int(data.get('max_tokens', 4096))

        payload = {
            "model": merge_model,
            "messages": messages,
            "temperature": temperature,
            "top_p": 0.9,
            "max_tokens": max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
            "chat_template_kwargs": {"enable_thinking": True},
        }

        generator = _stream_chat_response(
            user_id, request_id, lm_studio_url, payload,
            merge_model, base_url, None
        )

        return Response(
            stream_with_context(generator),
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache, no-transform',
                'X-Accel-Buffering': 'no',
                'Connection': 'keep-alive',
                'Content-Type': 'text/event-stream; charset=utf-8',
                'Transfer-Encoding': 'chunked',
            }
        )
    except Exception as e:
        _unregister_request(user_id, request_id)
        print(f"❌ Arena merge error: {e}")
        return jsonify({'error': f'Внутренняя ошибка: {str(e)}'}), 500


if __name__ == '__main__':
    start_cleanup_thread()
    print("🚀 AI Chat запущен: http://0.0.0.0:5000")
    print("   Модели:", list(LM_SERVERS.keys()))
    print("   Режим: параллельные запросы разрешены (до 4 на пользователя)")
    print("   Идентификация: cookie client_id + fallback на IP")
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)