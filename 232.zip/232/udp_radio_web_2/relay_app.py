#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UDP Radio Relay — ретранслятор аудиопотока GNU Radio.

Принимает UDP-пакеты от GNU Radio (SDR) и раздаёт их клиентам,
которые зарегистрировались через keep-alive "HELLO".

Протокол:
    клиент -> relay : b"HELLO"  (каждые ~3 сек)
    relay  -> клиент: аудиопакеты (raw bytes, без изменений)
    SDR    -> relay : аудиопакеты (любые данные, кроме b"HELLO")

Особенности:
    * Windows: отключение WSAECONNRESET делается через ctypes.WSAIoctl
      (Python socket.ioctl принимает только SIO_RCVALL / SIO_KEEPALIVE_VALS,
      а SIO_UDP_CONNRESET у него вызывает ValueError).
    * Если WSAIoctl не сработал — _recv_loop всё равно глотает
      ошибки 10054/10052/10038/10040 и продолжает цикл.
    * Клиенты НЕ удаляются по IP при новом HELLO. Старые умирают
      только по таймауту. Это устраняет race «Стоп→Плей».
    * При ошибке sendto клиент сразу выкидывается из списка.

Только для локальной сети. Не выставляйте порт в интернет.
"""

from __future__ import annotations

import argparse
import json
import os
import socket
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox


APP_TITLE = "UDP Radio Relay"
CONFIG_PATH = Path.home() / ".udp_radio_relay.json"

KEEPALIVE_PAYLOAD = b"HELLO"

# Windows errno, которые прилетают от ICMP и которые не должны убивать recv_loop
_WIN_ICMP_ERRNOS = {10052, 10053, 10054, 10038, 10040}

DEFAULT_CONFIG = {
    "listen": "0.0.0.0",
    "port": 7355,
    "sdr_host": "",
    "timeout": 5.0,
    "max_clients": 50,
    "reuse_addr": True,
}


# ---------------------------------------------------------------------------
# Windows: WSAIoctl(SIO_UDP_CONNRESET, FALSE) через ctypes
# ---------------------------------------------------------------------------

def _disable_udp_connreset(sock: socket.socket) -> None:
    """
    Best-effort отключение WSAECONNRESET на UDP-сокете.

    При получении ICMP port unreachable (клиент закрыл сокет) Windows
    по умолчанию заставляет recvfrom возвращать WSAECONNRESET (10054).
    Отключаем это поведение через WSAIoctl(SIO_UDP_CONNRESET, FALSE).

    Если что-то пойдёт не так — не страшно, _recv_loop уже глотает
    errno 10054 и продолжает работу.
    """
    if not sys.platform.startswith("win"):
        return

    try:
        import ctypes
        from ctypes import wintypes

        ws2_32 = ctypes.WinDLL("ws2_32", use_last_error=True)

        # Прототип WSAIoctl
        ws2_32.WSAIoctl.argtypes = [
            wintypes.SOCKET,                     # SOCKET s
            wintypes.DWORD,                      # DWORD dwIoControlCode
            wintypes.LPVOID,                     # LPVOID lpvInBuffer
            wintypes.DWORD,                      # DWORD cbInBuffer
            wintypes.LPVOID,                     # LPVOID lpvOutBuffer
            wintypes.DWORD,                      # DWORD cbOutBuffer
            ctypes.POINTER(wintypes.DWORD),      # LPDWORD lpcbBytesReturned
            wintypes.LPVOID,                     # LPWSAOVERLAPPED
            wintypes.LPVOID,                     # LPWSAOVERLAPPED_COMPLETION_ROUTINE
        ]
        ws2_32.WSAIoctl.restype = ctypes.c_int

        SIO_UDP_CONNRESET = 0x9800000C  # _WSAIOW(IOC_VENDOR, 12)

        in_buf = wintypes.BOOL(False)          # BOOL FALSE = 4 байта
        bytes_returned = wintypes.DWORD(0)

        ret = ws2_32.WSAIoctl(
            sock.fileno(),
            SIO_UDP_CONNRESET,
            ctypes.byref(in_buf), ctypes.sizeof(in_buf),
            None, 0,
            ctypes.byref(bytes_returned),
            None, None,
        )
        if ret != 0:
            err = ctypes.get_last_error()
            print(f"[relay] WSAIoctl(SIO_UDP_CONNRESET) failed: err={err} "
                  f"(не критично, recv_loop защищён)")
    except Exception as e:
        print(f"[relay] WSAIoctl setup skipped: {e} "
              f"(не критично, recv_loop защищён)")


# ---------------------------------------------------------------------------
# Конфиг
# ---------------------------------------------------------------------------

def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    try:
        if CONFIG_PATH.exists():
            with CONFIG_PATH.open("r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    if k in cfg:
                        cfg[k] = v
    except (OSError, ValueError):
        pass
    return cfg


def save_config(cfg: dict) -> None:
    """Атомарная запись — не побьётся при сбое."""
    tmp = CONFIG_PATH.with_suffix(".json.tmp")
    try:
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CONFIG_PATH)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Ядро ретранслятора
# ---------------------------------------------------------------------------

class RelayCore:
    """Логика ретранслятора, независимая от GUI."""

    def __init__(
        self,
        listen: str,
        port: int,
        sdr_host: str,
        timeout: float = 5.0,
        max_clients: int = 50,
        reuse_addr: bool = True,
    ):
        self.listen = listen
        self.port = port
        self.sdr_host = self._normalize_host(sdr_host)
        self.timeout = timeout
        self.max_clients = max_clients
        self.reuse_addr = reuse_addr

        self.sock: socket.socket | None = None
        # addr -> {"ts": float, "keepalives": int}
        self.clients: dict[tuple[str, int], dict] = {}
        self.lock = threading.Lock()

        self.stats = {
            "audio_packets": 0,
            "audio_bytes": 0,
            "forwarded": 0,
            "send_errors": 0,
            "hello_packets": 0,
            "ignored_packets": 0,
            "recv_errors": 0,
        }

        self._stop_event = threading.Event()
        self._recv_thread: threading.Thread | None = None
        self._cleaner_thread: threading.Thread | None = None
        self.running = False
        self.error: str | None = None

    @staticmethod
    def _normalize_host(host: str) -> str:
        host = (host or "").strip()
        if not host:
            return ""
        try:
            return socket.gethostbyname(host)
        except OSError:
            return host

    # ------------------------------------------------------------------
    # Start / Stop
    # ------------------------------------------------------------------
    def start(self) -> bool:
        if self.running:
            return True
        self.error = None
        self._stop_event.clear()

        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            if self.reuse_addr:
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            if sys.platform.startswith("win"):
                _disable_udp_connreset(self.sock)

            self.sock.bind((self.listen, self.port))
            self.sock.settimeout(0.3)
        except OSError as e:
            self.error = str(e)
            if self.sock:
                try:
                    self.sock.close()
                except OSError:
                    pass
                self.sock = None
            return False

        with self.lock:
            self.clients.clear()
        for k in self.stats:
            self.stats[k] = 0

        self.running = True
        self._recv_thread = threading.Thread(
            target=self._recv_loop, name="RelayRecv", daemon=True
        )
        self._cleaner_thread = threading.Thread(
            target=self._cleanup_loop, name="RelayCleaner", daemon=True
        )
        self._recv_thread.start()
        self._cleaner_thread.start()
        return True

    def stop(self) -> None:
        """Идемпотентный, безопасный стоп."""
        self._stop_event.set()
        self.running = False

        s = self.sock
        self.sock = None
        if s is not None:
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                s.close()
            except OSError:
                pass

        for th in (self._recv_thread, self._cleaner_thread):
            if th is not None and th.is_alive():
                th.join(timeout=2.0)

        self._recv_thread = None
        self._cleaner_thread = None

        with self.lock:
            self.clients.clear()

    # ------------------------------------------------------------------
    # Фоновые циклы
    # ------------------------------------------------------------------
    def _cleanup_loop(self) -> None:
        while not self._stop_event.wait(1.0):
            now = time.time()
            with self.lock:
                dead = [
                    a for a, info in self.clients.items()
                    if now - info["ts"] > self.timeout
                ]
                for a in dead:
                    del self.clients[a]

    def _recv_loop(self) -> None:
        sock = self.sock
        if sock is None:
            return

        while not self._stop_event.is_set():
            try:
                data, addr = sock.recvfrom(65536)
            except socket.timeout:
                continue
            except OSError as e:
                if self._stop_event.is_set():
                    break
                err = getattr(e, "errno", None) or getattr(e, "winerror", None)
                if err in _WIN_ICMP_ERRNOS:
                    self.stats["recv_errors"] += 1
                    continue
                self.stats["recv_errors"] += 1
                time.sleep(0.01)
                continue

            if not data:
                continue

            # --- 1) HELLO ---
            if data == KEEPALIVE_PAYLOAD:
                self.stats["hello_packets"] += 1
                with self.lock:
                    info = self.clients.get(addr)
                    if info is None:
                        # ВАЖНО: не удаляем старые по IP — иначе
                        # умирающий старый клиент «перетирает» нового.
                        if len(self.clients) >= self.max_clients:
                            self.stats["ignored_packets"] += 1
                            continue
                        self.clients[addr] = {
                            "ts": time.time(),
                            "keepalives": 1,
                        }
                    else:
                        info["ts"] = time.time()
                        info["keepalives"] += 1
                continue

            # --- 2) Аудио ---
            if self.sdr_host and addr[0] != self.sdr_host:
                self.stats["ignored_packets"] += 1
                continue

            self.stats["audio_packets"] += 1
            self.stats["audio_bytes"] += len(data)

            with self.lock:
                targets = list(self.clients.keys())

            sent = 0
            errs = 0
            dead: list[tuple[str, int]] = []
            for c in targets:
                try:
                    sock.sendto(data, c)
                    sent += 1
                except OSError:
                    errs += 1
                    dead.append(c)

            if dead:
                with self.lock:
                    for c in dead:
                        self.clients.pop(c, None)

            self.stats["forwarded"] += sent
            self.stats["send_errors"] += errs

    # ------------------------------------------------------------------
    # Снимок для GUI
    # ------------------------------------------------------------------
    def snapshot(self) -> tuple[list[dict], dict, int]:
        now = time.time()
        with self.lock:
            rows = []
            for (ip, port), info in sorted(self.clients.items()):
                ago = max(0.0, now - info["ts"])
                rows.append({
                    "ip": ip,
                    "port": port,
                    "ago": ago,
                    "keepalives": info["keepalives"],
                })
            n = len(self.clients)
            stats = dict(self.stats)
        return rows, stats, n

    def drop_all_clients(self) -> int:
        with self.lock:
            n = len(self.clients)
            self.clients.clear()
        return n


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------

class RelayApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.configure(bg="#1e1e2e")

        self.cfg = load_config()
        self.core: RelayCore | None = None
        self._tick_id: str | None = None
        self._row_iids: dict[tuple[str, int], str] = {}

        self._setup_style()
        self._build_ui()
        self._apply_config(self.cfg)
        self._connect_autosave()

        self._tick_id = self.after(500, self._tick)

    # ------------------------------------------------------------------
    # Стиль
    # ------------------------------------------------------------------
    def _setup_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        bg = "#1e1e2e"
        fg = "#cdd6f4"
        accent = "#89b4fa"
        surface = "#313244"
        muted = "#a6adc8"
        green = "#a6e3a1"
        red = "#f38ba8"

        style.configure(".", background=bg, foreground=fg,
                        fieldbackground=surface)
        style.configure("TFrame", background=bg)
        style.configure("TLabel", background=bg, foreground=fg,
                        font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"),
                        foreground=accent)
        style.configure("Hint.TLabel", foreground=muted,
                        font=("Segoe UI", 8))
        style.configure("Status.TLabel", font=("Segoe UI", 10))
        style.configure("TCheckbutton", background=bg, foreground=fg,
                        font=("Segoe UI", 10))
        style.configure("TEntry", fieldbackground=surface, foreground=fg,
                        insertcolor=fg)
        style.configure("TButton", font=("Segoe UI", 10, "bold"), padding=8)
        style.configure("Start.TButton", background=accent, foreground=bg)
        style.map("Start.TButton",
                  background=[("active", "#b4befe"), ("disabled", "#45475a")])
        style.configure("Stop.TButton", background=red, foreground=bg)
        style.map("Stop.TButton",
                  background=[("active", "#eba0ac"), ("disabled", "#45475a")])
        style.configure("Ghost.TButton", background=surface, foreground=fg)
        style.map("Ghost.TButton",
                  background=[("active", "#585b70"), ("disabled", "#45475a")])
        style.configure("Treeview",
                        background=surface, fieldbackground=surface,
                        foreground=fg, rowheight=22)
        style.configure("Treeview.Heading",
                        background=bg, foreground=accent,
                        font=("Segoe UI", 9, "bold"))
        style.map("Treeview",
                  background=[("selected", accent)],
                  foreground=[("selected", bg)])
        style.configure("TLabelframe", background=bg, foreground=fg)
        style.configure("TLabelframe.Label", background=bg, foreground=accent,
                        font=("Segoe UI", 10, "bold"))

        self._colors = {
            "bg": bg, "fg": fg, "accent": accent, "surface": surface,
            "muted": muted, "green": green, "red": red,
        }

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        pad = {"padx": 10, "pady": 5}
        root = ttk.Frame(self, padding=18)
        root.grid(row=0, column=0, sticky="nsew")

        ttk.Label(root, text="UDP Radio Relay", style="Title.TLabel").grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 4)
        )
        ttk.Label(
            root,
            text="Принимает поток от GNU Radio и раздаёт клиентам в локальной сети",
            style="Hint.TLabel",
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 14))

        # --- параметры ---
        frm = ttk.LabelFrame(root, text="Параметры", padding=12)
        frm.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(0, 10))

        ttk.Label(frm, text="Слушать на IP:").grid(row=0, column=0,
                                                   sticky="w", **pad)
        self.var_listen = tk.StringVar(value="0.0.0.0")
        self.ent_listen = ttk.Entry(frm, textvariable=self.var_listen, width=18)
        self.ent_listen.grid(row=0, column=1, sticky="w", **pad)

        ttk.Label(frm, text="Порт:").grid(row=1, column=0, sticky="w", **pad)
        self.var_port = tk.StringVar(value="7355")
        self.ent_port = ttk.Entry(frm, textvariable=self.var_port, width=18)
        self.ent_port.grid(row=1, column=1, sticky="w", **pad)

        ttk.Label(frm, text="IP GNU Radio (SDR):").grid(
            row=2, column=0, sticky="w", **pad)
        self.var_sdr = tk.StringVar(value="")
        self.ent_sdr = ttk.Entry(frm, textvariable=self.var_sdr, width=18)
        self.ent_sdr.grid(row=2, column=1, sticky="w", **pad)
        ttk.Label(
            frm,
            text="IP или имя. Пусто = принимать от всех",
            style="Hint.TLabel",
        ).grid(row=2, column=2, sticky="w", padx=6)

        ttk.Label(frm, text="Таймаут клиента (сек):").grid(
            row=3, column=0, sticky="w", **pad)
        self.var_timeout = tk.StringVar(value="5")
        self.ent_timeout = ttk.Entry(frm, textvariable=self.var_timeout, width=18)
        self.ent_timeout.grid(row=3, column=1, sticky="w", **pad)

        ttk.Label(frm, text="Макс. клиентов:").grid(
            row=4, column=0, sticky="w", **pad)
        self.var_max = tk.StringVar(value="50")
        self.ent_max = ttk.Entry(frm, textvariable=self.var_max, width=18)
        self.ent_max.grid(row=4, column=1, sticky="w", **pad)

        self.var_reuse = tk.BooleanVar(value=True)
        self.chk_reuse = ttk.Checkbutton(
            frm, text="SO_REUSEADDR (разрешает двойной bind)",
            variable=self.var_reuse,
        )
        self.chk_reuse.grid(row=5, column=0, columnspan=3, sticky="w",
                            padx=10, pady=(6, 0))

        # --- кнопки ---
        btn_frm = ttk.Frame(root)
        btn_frm.grid(row=3, column=0, columnspan=3, pady=(4, 12))

        self.btn_start = ttk.Button(
            btn_frm, text="▶   Старт", style="Start.TButton",
            command=self._start, width=14,
        )
        self.btn_start.pack(side="left", padx=(0, 8))

        self.btn_stop = ttk.Button(
            btn_frm, text="■   Стоп", style="Stop.TButton",
            command=self._stop, width=14, state="disabled",
        )
        self.btn_stop.pack(side="left", padx=(0, 8))

        self.btn_drop = ttk.Button(
            btn_frm, text="✕  Сбросить клиентов", style="Ghost.TButton",
            command=self._drop_clients, width=20, state="disabled",
        )
        self.btn_drop.pack(side="left")

        # --- статус ---
        self.lbl_status = ttk.Label(
            root, text="Статус: остановлено", style="Status.TLabel",
            foreground=self._colors["muted"],
        )
        self.lbl_status.grid(row=4, column=0, columnspan=3, sticky="w",
                             pady=(0, 8))

        # --- таблица клиентов ---
        tbl_frm = ttk.LabelFrame(root, text="Активные клиенты", padding=8)
        tbl_frm.grid(row=5, column=0, columnspan=3, sticky="nsew",
                     pady=(0, 10))

        cols = ("ip", "port", "ago", "keepalives")
        self.tree = ttk.Treeview(
            tbl_frm, columns=cols, show="headings", height=8,
            selectmode="browse",
        )
        self.tree.heading("ip", text="IP")
        self.tree.heading("port", text="Порт")
        self.tree.heading("ago", text="Последний keep-alive")
        self.tree.heading("keepalives", text="Keep-alive'ов")
        self.tree.column("ip", width=140, anchor="w")
        self.tree.column("port", width=80, anchor="center")
        self.tree.column("ago", width=160, anchor="center")
        self.tree.column("keepalives", width=110, anchor="center")

        scroll = ttk.Scrollbar(tbl_frm, orient="vertical",
                               command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        tbl_frm.columnconfigure(0, weight=1)

        # --- статистика ---
        self.lbl_stats = ttk.Label(
            root,
            text="Аудио-пакетов: 0  ·  Байт: 0  ·  Переслано: 0  ·  Клиентов: 0",
            style="Status.TLabel",
        )
        self.lbl_stats.grid(row=6, column=0, columnspan=3, sticky="w")

        self.lbl_stats2 = ttk.Label(
            root,
            text="HELLO: 0  ·  Проигнорировано: 0  ·  "
                 "Ошибок sendto: 0  ·  Ошибок recv: 0",
            style="Hint.TLabel",
        )
        self.lbl_stats2.grid(row=7, column=0, columnspan=3, sticky="w",
                             pady=(4, 0))

        ttk.Label(
            root,
            text="Только для локальной сети. Не открывайте порт в интернет.",
            style="Hint.TLabel",
        ).grid(row=8, column=0, columnspan=3, sticky="w", pady=(10, 0))

    # ------------------------------------------------------------------
    # Настройки
    # ------------------------------------------------------------------
    def _apply_config(self, cfg: dict) -> None:
        self.var_listen.set(str(cfg["listen"]))
        self.var_port.set(str(cfg["port"]))
        self.var_sdr.set(str(cfg["sdr_host"]))
        self.var_timeout.set(str(cfg["timeout"]))
        self.var_max.set(str(cfg["max_clients"]))
        self.var_reuse.set(bool(cfg["reuse_addr"]))

    def _collect_config(self) -> dict:
        try:
            port = int(self.var_port.get().strip())
        except ValueError:
            port = DEFAULT_CONFIG["port"]
        try:
            timeout = float(self.var_timeout.get().strip())
        except ValueError:
            timeout = DEFAULT_CONFIG["timeout"]
        try:
            max_clients = int(self.var_max.get().strip())
        except ValueError:
            max_clients = DEFAULT_CONFIG["max_clients"]
        return {
            "listen": self.var_listen.get().strip() or "0.0.0.0",
            "port": port,
            "sdr_host": self.var_sdr.get().strip(),
            "timeout": timeout,
            "max_clients": max_clients,
            "reuse_addr": bool(self.var_reuse.get()),
        }

    def _connect_autosave(self) -> None:
        for var in (self.var_listen, self.var_port, self.var_sdr,
                    self.var_timeout, self.var_max):
            var.trace_add("write", self._autosave)
        self.var_reuse.trace_add("write", self._autosave)

    def _autosave(self, *_) -> None:
        self.cfg = self._collect_config()
        save_config(self.cfg)

    # ------------------------------------------------------------------
    # Start / Stop / Drop
    # ------------------------------------------------------------------
    def _set_inputs_state(self, state: str) -> None:
        for w in (self.ent_listen, self.ent_port, self.ent_sdr,
                  self.ent_timeout, self.ent_max, self.chk_reuse):
            w.configure(state=state)

    def _start(self) -> None:
        if self.core and self.core.running:
            return

        try:
            listen = self.var_listen.get().strip() or "0.0.0.0"
            port = int(self.var_port.get().strip())
            sdr = self.var_sdr.get().strip()
            timeout = float(self.var_timeout.get().strip() or "5")
            max_clients = int(self.var_max.get().strip() or "50")
        except ValueError:
            messagebox.showerror(APP_TITLE,
                                 "Проверьте порт, таймаут и макс. клиентов (числа).")
            return

        if not (1 <= port <= 65535):
            messagebox.showerror(APP_TITLE,
                                 "Порт должен быть в диапазоне 1–65535.")
            return
        if timeout <= 0:
            messagebox.showerror(APP_TITLE, "Таймаут должен быть > 0.")
            return
        if max_clients < 1:
            messagebox.showerror(APP_TITLE, "Макс. клиентов должен быть >= 1.")
            return

        self._autosave()

        core = RelayCore(
            listen, port, sdr,
            timeout=timeout, max_clients=max_clients,
            reuse_addr=bool(self.var_reuse.get()),
        )
        if not core.start():
            messagebox.showerror(
                APP_TITLE,
                f"Не удалось занять {listen}:{port}\n{core.error or ''}",
            )
            return

        self.core = core
        self._row_iids.clear()
        for item in self.tree.get_children():
            self.tree.delete(item)

        self._set_inputs_state("disabled")
        self.btn_start.configure(state="disabled")
        self.btn_stop.configure(state="normal")
        self.btn_drop.configure(state="normal")

        sdr_txt = self.core.sdr_host or "любой источник"
        self.lbl_status.configure(
            text=f"Статус: слушаю {listen}:{port}  ·  источник: {sdr_txt}",
            foreground=self._colors["green"],
        )

    def _stop(self) -> None:
        core = self.core
        self.core = None
        if core is not None:
            try:
                core.stop()
            except Exception:
                pass

        self._set_inputs_state("normal")
        self.btn_start.configure(state="normal")
        self.btn_stop.configure(state="disabled")
        self.btn_drop.configure(state="disabled")
        self.lbl_status.configure(
            text="Статус: остановлено",
            foreground=self._colors["muted"],
        )

        self._row_iids.clear()
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.lbl_stats.configure(
            text="Аудио-пакетов: 0  ·  Байт: 0  ·  Переслано: 0  ·  Клиентов: 0"
        )
        self.lbl_stats2.configure(
            text="HELLO: 0  ·  Проигнорировано: 0  ·  "
                 "Ошибок sendto: 0  ·  Ошибок recv: 0"
        )

    def _drop_clients(self) -> None:
        core = self.core
        if core is None or not core.running:
            return
        n = core.drop_all_clients()
        if n:
            self.lbl_status.configure(
                text=f"Статус: сброшено клиентов: {n}. Ждём переподключения…",
                foreground=self._colors["accent"],
            )

    # ------------------------------------------------------------------
    # Тик
    # ------------------------------------------------------------------
    def _tick(self) -> None:
        try:
            self._update_from_core()
        finally:
            if self.winfo_exists():
                self._tick_id = self.after(500, self._tick)
            else:
                self._tick_id = None

    def _update_from_core(self) -> None:
        core = self.core
        if core is None or not core.running:
            return

        rows, stats, n = core.snapshot()

        seen: set[tuple[str, int]] = set()
        for r in rows:
            key = (r["ip"], r["port"])
            seen.add(key)
            ago = r["ago"]
            if ago < 2:
                ago_s = "сейчас"
            elif ago < 60:
                ago_s = f"{ago:.0f} сек назад"
            else:
                ago_s = f"{ago / 60:.1f} мин назад"
            vals = (r["ip"], r["port"], ago_s, r["keepalives"])
            iid = self._row_iids.get(key)
            if iid is not None and self.tree.exists(iid):
                self.tree.item(iid, values=vals)
            else:
                iid = self.tree.insert("", "end", values=vals)
                self._row_iids[key] = iid

        for key in list(self._row_iids.keys()):
            if key not in seen:
                iid = self._row_iids.pop(key, None)
                if iid is not None and self.tree.exists(iid):
                    self.tree.delete(iid)

        b = stats["audio_bytes"]
        if b >= 1_000_000:
            b_s = f"{b / 1_000_000:.1f} МБ"
        elif b >= 1000:
            b_s = f"{b / 1000:.1f} КБ"
        else:
            b_s = f"{b} Б"

        self.lbl_stats.configure(
            text=(
                f"Аудио-пакетов: {stats['audio_packets']}  ·  "
                f"Байт: {b_s}  ·  "
                f"Переслано: {stats['forwarded']}  ·  "
                f"Клиентов: {n}"
            )
        )
        self.lbl_stats2.configure(
            text=(
                f"HELLO: {stats['hello_packets']}  ·  "
                f"Проигнорировано: {stats['ignored_packets']}  ·  "
                f"Ошибок sendto: {stats['send_errors']}  ·  "
                f"Ошибок recv: {stats['recv_errors']}"
            )
        )

    # ------------------------------------------------------------------
    # Закрытие
    # ------------------------------------------------------------------
    def _on_close(self) -> None:
        if self._tick_id is not None:
            try:
                self.after_cancel(self._tick_id)
            except tk.TclError:
                pass
            self._tick_id = None
        try:
            self._autosave()
        except Exception:
            pass
        try:
            self._stop()
        finally:
            self.destroy()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(
        prog="relay_app.py",
        description="UDP Radio Relay — ретранслятор аудиопотока GNU Radio.",
    )
    parser.add_argument("--sdr-host", default="",
                        help="IP или имя машины с GNU Radio (пусто — любой)")
    parser.add_argument("--port", type=int, default=0,
                        help="UDP-порт (по умолчанию из конфига/7355)")
    parser.add_argument("--listen", default="",
                        help="IP для прослушивания (по умолчанию 0.0.0.0)")
    parser.add_argument("--timeout", type=float, default=0.0,
                        help="Таймаут клиента в секундах (по умолчанию 5)")
    parser.add_argument("--max-clients", type=int, default=0,
                        help="Максимум клиентов (по умолчанию 50)")
    parser.add_argument("--no-reuse", action="store_true",
                        help="Не ставить SO_REUSEADDR (жёсткий bind)")
    args = parser.parse_args()

    app = RelayApp()
    if args.sdr_host:
        app.var_sdr.set(args.sdr_host)
    if args.port:
        app.var_port.set(str(args.port))
    if args.listen:
        app.var_listen.set(args.listen)
    if args.timeout > 0:
        app.var_timeout.set(str(args.timeout))
    if args.max_clients > 0:
        app.var_max.set(str(args.max_clients))
    if args.no_reuse:
        app.var_reuse.set(False)

    app.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())