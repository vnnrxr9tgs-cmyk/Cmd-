# UDP Radio Web Player

Веб-плеер для аудиопотока GNU Radio через `relay_app.py`.

Бэкенд (Flask + SocketIO) подключается к relay как обычный клиент (шлёт `HELLO`),
принимает UDP-пакеты и раздаёт PCM в браузеры по WebSocket.
Воспроизведение — **Web Audio API** (без плагинов).

## Схема

```
GNU Radio (UDP sink)
        │
        ▼
  relay_app.py  ←──── HELLO (каждые ~3 с)
        │
        ▼  audio packets
  app.py (Flask)
        │
        ▼  WebSocket (float32 PCM)
   Браузер (Chrome / Firefox)
```

## Установка

```bash
cd udp_radio_web
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Запуск

1. Запустите **relay** (на машине с доступом к GNU Radio):

   ```bash
   python relay_app.py
   # или с параметрами: --port 7355 --sdr-host 192.168.1.5
   ```

2. Запустите веб-плеер:

   ```bash
   python app.py
   # или:
   # python app.py --host 192.168.1.10 --port 7355 --web-port 5000
   ```

3. Откройте в браузере:

   ```
   http://<IP-машины-с-app.py>:5000
   ```

4. Укажите IP relay (если не localhost), нажмите **▶**.

## Параметры CLI

| Аргумент       | Описание                          | По умолчанию   |
|----------------|-----------------------------------|----------------|
| `--host`       | IP relay-сервера                  | из конфига     |
| `--port`       | UDP-порт relay                    | 7355           |
| `--web-port`   | HTTP-порт веб-UI                  | 5000           |
| `--listen`     | Адрес привязки Flask              | 0.0.0.0        |
| `--rate`       | Sample rate (Гц)                  | 48000          |
| `--channels`   | 1 или 2                           | 1              |
| `--format`     | float32 / int16 / int8            | float32        |

Настройки сохраняются в `~/.udp_radio_web.json`.

## Формат аудио (должен совпадать с GNU Radio)

| GNU Radio type | Значение в UI |
|----------------|---------------|
| Float          | float32       |
| Short          | int16         |
| Byte           | int8          |

Частота дискретизации и число каналов — как в Audio Sink / UDP Sink в GRC.

## Важно

- Только **локальная сеть**. Не пробрасывайте порты в интернет.
- Один экземпляр `app.py` = один UDP-клиент к relay. Несколько браузеров слушают один и тот же поток.
- Для низкой задержки держите `buffer` в relay/player небольшим; в вебе есть джиттер ~80 мс.
- Chrome/Firefox лучше Edge/Safari для Web Audio + WebSocket.

## Зависимости

- Python 3.9+
- flask, flask-socketio, numpy, eventlet
