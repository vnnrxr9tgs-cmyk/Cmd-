#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тестовый UDP-источник для relay: умеет «прям звук».

Режимы (--source):
    tone   : синус
    melody : мелодия с ADSR и гармониками
    voice  : формантный «псевдо-голос»
    wav    : проигрывает WAV (--wav path.wav), циклично
    mic    : живой микрофон (нужен sounddevice)

Формат выхода: raw PCM float32 / int16 / int8.
"""

from __future__ import annotations

import argparse
import math
import socket
import sys
import time
import wave

import numpy as np


# ----------------------------- Утилиты -----------------------------

def to_pcm(wave: np.ndarray, fmt: str) -> bytes:
    """wave: float32 [-1, 1], shape (frames, channels) → bytes."""
    if fmt == "int16":
        return (np.clip(wave, -1.0, 1.0) * 32767.0).astype("<i2").tobytes()
    if fmt == "int8":
        return (np.clip(wave, -1.0, 1.0) * 127.0).astype("<i1").tobytes()
    return wave.astype("<f4").tobytes()


def resample_linear(x: np.ndarray, src_rate: int, dst_rate: int) -> np.ndarray:
    """Простой линейный ресемплер. x: (frames, ch) или (frames,)."""
    if src_rate == dst_rate:
        return x
    x = np.asarray(x)
    n_src = x.shape[0]
    n_dst = int(round(n_src * dst_rate / src_rate))
    if n_dst <= 0:
        return x[:0]
    src_idx = np.linspace(0, n_src - 1, n_dst, dtype=np.float64)
    i0 = np.floor(src_idx).astype(np.int64)
    i1 = np.minimum(i0 + 1, n_src - 1)
    frac = (src_idx - i0).astype(x.dtype)
    return x[i0] * (1 - frac) + x[i1] * frac


# ----------------------------- Источники -----------------------------

class Source:
    channels: int

    def read(self, frames: int) -> np.ndarray:  # pragma: no cover
        raise NotImplementedError

    def close(self) -> None:
        pass


class ToneSource(Source):
    def __init__(self, rate: int, freq: float, channels: int, amp: float):
        self.rate = rate
        self.freq = freq
        self.channels = channels
        self.amp = amp
        self.phase = 0.0

    def read(self, frames: int) -> np.ndarray:
        t = (np.arange(frames, dtype=np.float64) + self.phase) / self.rate
        w = self.amp * np.sin(2 * np.pi * self.freq * t)
        self.phase += frames
        if self.channels == 2:
            return np.column_stack([
                w,
                self.amp * np.sin(2 * np.pi * self.freq * t + 0.3),
            ]).astype(np.float32)
        return w.reshape(-1, 1).astype(np.float32)


MELODY = [
    (440.0, 0.35), (494.0, 0.35), (523.0, 0.35), (587.0, 0.35),
    (659.0, 0.50), (587.0, 0.35), (523.0, 0.35), (494.0, 0.35),
    (440.0, 0.70), (0.0, 0.25),
]


class MelodySource(Source):
    def __init__(self, rate: int, channels: int, amp: float):
        self.rate = rate
        self.channels = channels
        self.amp = amp
        self.t = 0.0
        self.note_idx = 0
        self.note_t = 0.0
        self.note_dur = MELODY[0][1]
        self.freq = MELODY[0][0]
        self._advance_note()

    def _advance_note(self):
        self.freq, self.note_dur = MELODY[self.note_idx % len(MELODY)]
        self.note_idx += 1
        self.note_t = 0.0

    def _adsr(self, x: np.ndarray) -> np.ndarray:
        a, d, s, r = 0.02, 0.08, 0.7, 0.10
        env = np.ones_like(x)
        env = np.where(x < a, x / a, env)
        env = np.where((x >= a) & (x < a + d), 1 - (1 - s) * (x - a) / d, env)
        env = np.where(x >= a + d, s, env)
        tail = self.note_dur - x
        env = np.where(tail < r, np.maximum(env * tail / r, 0.0), env)
        return env

    def read(self, frames: int) -> np.ndarray:
        out = np.zeros(frames, dtype=np.float64)
        written = 0
        while written < frames:
            take = min(
                frames - written,
                int(math.ceil((self.note_dur - self.note_t) * self.rate)),
            )
            take = max(1, take)
            t = (np.arange(take, dtype=np.float64) + self.note_t * self.rate) / self.rate
            if self.freq > 0:
                vib = 1 + 0.005 * np.sin(2 * np.pi * 5.0 * t)
                w = np.sin(2 * np.pi * self.freq * t * vib)
                w += 0.3 * np.sin(2 * np.pi * 2 * self.freq * t * vib)
                w += 0.15 * np.sin(2 * np.pi * 3 * self.freq * t * vib)
                w *= self._adsr(t)
            else:
                w = np.zeros(take)
            out[written:written + take] = w
            written += take
            self.note_t += take / self.rate
            self.t += take / self.rate
            if self.note_t >= self.note_dur:
                self._advance_note()

        w = (self.amp * out).astype(np.float32)
        if self.channels == 2:
            return np.column_stack([w, np.roll(w, 1) * 0.95]).astype(np.float32)
        return w.reshape(-1, 1)


class VoiceSource(Source):
    FORMANTS = [(700, 80), (1200, 90), (2600, 120)]

    def __init__(self, rate: int, channels: int, amp: float, seed: int = 1):
        self.rate = rate
        self.channels = channels
        self.amp = amp
        self.rng = np.random.default_rng(seed)
        self.t = 0.0
        self.filters = [self._resonator(f, bw) for f, bw in self.FORMANTS]

    def _resonator(self, f0: float, bw: float):
        r = math.exp(-math.pi * bw / self.rate)
        theta = 2 * math.pi * f0 / self.rate
        a1 = -2 * r * math.cos(theta)
        a2 = r * r
        b0 = (1 - r) * math.sqrt(1 - 2 * r * math.cos(2 * theta) + r * r)
        return (b0, a1, a2)

    def read(self, frames: int) -> np.ndarray:
        noise = self.rng.standard_normal(frames).astype(np.float64)
        f0 = 110 + 20 * math.sin(2 * math.pi * 0.7 * self.t)
        t = (np.arange(frames, dtype=np.float64) + self.t * self.rate) / self.rate
        glottal = 0.5 * np.sign(np.sin(2 * np.pi * f0 * t))
        x = 0.15 * noise + 0.85 * glottal

        y = x.copy()
        for (b0, a1, a2) in self.filters:
            y = self._biquad(y, b0, a1, a2)

        syll = 0.5 + 0.5 * np.sin(2 * np.pi * 4.0 * t)
        y *= syll ** 1.5

        rms = math.sqrt(float(np.mean(y * y)) + 1e-12)
        y = y / rms * 0.3

        self.t += frames / self.rate
        w = (self.amp * y).astype(np.float32)
        if self.channels == 2:
            return np.column_stack([w, np.roll(w, 5)]).astype(np.float32)
        return w.reshape(-1, 1)

    def _biquad(self, x, b0, a1, a2):
        y = np.empty_like(x)
        y1 = y2 = 0.0
        for i in range(len(x)):
            y0 = b0 * x[i] - a1 * y1 - a2 * y2
            y[i] = y0
            y2, y1 = y1, y0
        return y


class WavSource(Source):
    def __init__(self, path: str, rate: int, channels: int, amp: float):
        with wave.open(path, "rb") as wf:
            src_ch = wf.getnchannels()
            src_rate = wf.getframerate()
            sampwidth = wf.getsampwidth()
            n = wf.getnframes()
            raw = wf.readframes(n)
        if sampwidth == 2:
            data = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
        elif sampwidth == 4:
            data = np.frombuffer(raw, dtype="<i4").astype(np.float32) / 2147483648.0
        elif sampwidth == 1:
            data = (np.frombuffer(raw, dtype="<u1").astype(np.float32) - 128) / 128.0
        else:
            raise ValueError(f"unsupported sampwidth={sampwidth}")
        data = data.reshape(-1, src_ch)
        data = resample_linear(data, src_rate, rate).astype(np.float32)

        if channels == 1 and data.shape[1] > 1:
            data = data.mean(axis=1, keepdims=True)
        elif channels == 2 and data.shape[1] == 1:
            data = np.repeat(data, 2, axis=1)

        self.data = (data * amp).astype(np.float32)
        self.channels = channels
        self.pos = 0

    def read(self, frames: int) -> np.ndarray:
        out = np.empty((frames, self.channels), dtype=np.float32)
        written = 0
        n = len(self.data)
        while written < frames:
            take = min(frames - written, n - self.pos)
            out[written:written + take] = self.data[self.pos:self.pos + take]
            written += take
            self.pos += take
            if self.pos >= n:
                self.pos = 0
        return out


class MicSource(Source):
    def __init__(self, rate: int, channels: int, amp: float, device=None):
        import sounddevice as sd
        self.channels = channels
        self.amp = amp
        self.buf = np.zeros((0, channels), dtype=np.float32)
        self.stream = sd.InputStream(
            samplerate=rate, channels=channels, dtype="float32",
            blocksize=0, device=device, callback=self._cb,
        )
        self.stream.start()

    def _cb(self, indata, frames, time_info, status):
        if status:
            print(f"[mic] {status}", file=sys.stderr)
        self.buf = np.concatenate([self.buf, indata.copy()], axis=0)

    def read(self, frames: int) -> np.ndarray:
        deadline = time.perf_counter() + 0.05
        while len(self.buf) < frames and time.perf_counter() < deadline:
            time.sleep(0.002)
        if len(self.buf) < frames:
            pad = np.zeros((frames - len(self.buf), self.channels), dtype=np.float32)
            out = np.concatenate([self.buf, pad], axis=0)
            self.buf = np.zeros((0, self.channels), dtype=np.float32)
            return out * self.amp
        out = self.buf[:frames]
        self.buf = self.buf[frames:]
        return out * self.amp

    def close(self):
        try:
            self.stream.stop()
            self.stream.close()
        except Exception:
            pass


# ----------------------------- Сборка -----------------------------

def build_source(args) -> Source:
    if args.source == "tone":
        return ToneSource(args.rate, args.freq, args.channels, args.amp)
    if args.source == "melody":
        return MelodySource(args.rate, args.channels, args.amp)
    if args.source == "voice":
        return VoiceSource(args.rate, args.channels, args.amp, seed=args.seed)
    if args.source == "wav":
        if not args.wav:
            raise SystemExit("--source wav требует --wav path.wav")
        return WavSource(args.wav, args.rate, args.channels, args.amp)
    if args.source == "mic":
        return MicSource(args.rate, args.channels, args.amp, device=args.device)
    raise SystemExit(f"unknown source: {args.source}")


def main() -> int:
    p = argparse.ArgumentParser(description="Тестовый UDP-источник для relay")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=7355)
    p.add_argument("--rate", type=int, default=24000)
    p.add_argument("--channels", type=int, default=1, choices=(1, 2))
    p.add_argument("--format", default="float32", choices=("float32", "int16", "int8"))
    p.add_argument("--source", default="tone",
                   choices=("tone", "melody", "voice", "wav", "mic"))
    p.add_argument("--freq", type=float, default=440.0)
    p.add_argument("--packet-ms", type=float, default=20.0)
    p.add_argument("--amp", type=float, default=0.25)
    p.add_argument("--wav", default=None)
    p.add_argument("--device", default=None)
    p.add_argument("--seed", type=int, default=1)
    args = p.parse_args()

    frames = max(1, int(args.rate * args.packet_ms / 1000.0))
    packet_sec = frames / float(args.rate)

    src = build_source(args)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    dest = (args.host, args.port)

    print(f"Тестовый SDR → {args.host}:{args.port}")
    print(f"  source={args.source}, {args.rate} Hz, {args.channels} ch, "
          f"{args.format}, пакет {args.packet_ms} мс, amp={args.amp}")
    print("  Ctrl+C — стоп\n")

    next_t = time.perf_counter()
    packets = 0
    try:
        while True:
            wave = src.read(frames)
            data = to_pcm(wave, args.format)
            sock.sendto(data, dest)
            packets += 1
            if packets % 50 == 0:
                print(f"  отправлено пакетов: {packets}", end="\r")

            next_t += packet_sec
            delay = next_t - time.perf_counter()
            if delay > 0:
                time.sleep(delay)
            else:
                next_t = time.perf_counter()
    except KeyboardInterrupt:
        print(f"\nСтоп. Всего пакетов: {packets}")
    finally:
        src.close()
        sock.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())