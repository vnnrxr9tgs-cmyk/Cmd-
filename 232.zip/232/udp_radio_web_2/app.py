#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UDP Radio Web Player — Flask-сервер для relay_app.

Принимает UDP-поток от relay (keep-alive HELLO), конвертирует в float32 PCM
и раздаёт браузерам через HTTP-стрим /api/audio.

Формат фрейма в /api/audio (little-endian):
    [len:uint32][seq:uint32][samplerate:uint32][channels:uint8][pcm:len байт]
    pcm = float32 LE, чередование каналов (interleaved)

Управление:
    POST /api/start  → запустить приёмник
    POST /api/stop   → остановить
    GET  /api/status → JSON со статусом
    GET  /api/audio  → стрим бинарных фреймов

Socket.IO оставлен только для статуса (совместимость с прошлым UI).
Запуск:
    pip install flask flask-socketio numpy
    python app.py
Только для локальной сети.
"""

from __future__ import annotations

import argparse
import json
import os
import queue
import socket
import struct
import sys
import threading
import time
from pathlib import Path

import numpy as np
from flask import (
    Flask, Response, render_template, request, jsonify, stream_with_context
)
from flask_socketio import SocketIO, emit

# ---------------------------------------------------------------------------
# Константы
# ---------------------------------------------------------------------------

APP_TITLE = "UDP Radio Web"
CONFIG_PATH = Path.home() / ".udp_radio_web.json"
KEEPALIVE_PAYLOAD = b"HELLO"
KEEPALIVE_INTERVAL = 3.0

FORMAT_MAP = {
    "float32": np.float32,
    "int16": np.int16,
    "int8": np.int8,
}

DEFAULT_CONFIG = {
    "relay_host": "127.0.0.1",
    "relay_port": 7355,
    "samplerate": 24000,
    "channels": 1,
    "format": "float32",
    "listen_host": "0.0.0.0",
    "web_port": 5000,
}

# Служебный «пустой» фрейм: len=0, seq=0, sr=0, ch=0 — используется как keepalive
# в стриме, чтобы прокси/браузер не рвали соединение.
EMPTY_FRAME = struct.pack("<IIIB", 0, 0, 0, 0)
FRAME_HEADER = struct.Struct("<IIIB")  # len, seq, sr, ch


# ---------------------------------------------------------------------------
# Конфиг
# ---------------------------------------------------------------------------

def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    try:
        if CONFIG_PATH.exists():
            with CONFIG_PATH.open("r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    if k in cfg:
                        cfg[k] = v
    except (OSError, ValueError):
        pass
    return cfg


def save_config(cfg: dict) -> None:
    tmp = CONFIG_PATH.with_suffix(".json.tmp")
    try:
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CONFIG_PATH)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# UDP-приёмник
# ---------------------------------------------------------------------------

class UdpReceiver(threading.Thread):
    """
    Принимает аудио от relay, конвертирует в float32 PCM и раскладывает
    готовые фреймы в очереди подписчиков (queue.Queue).

    НЕ трогает socketio — это ответственность HTTP-стрима.
    """

    def __init__(
        self,
        host: str,
        port: int,
        dtype,
        channels: int,
        samplerate: int,
        stats: dict,
        stats_lock: threading.Lock,
        subscribers: set,
        subscribers_lock: threading.Lock,
    ):
        super().__init__(daemon=True, name="UdpReceiver")
        self.host = host
        self.port = port
        self.dtype = dtype
        self.channels = channels
        self.samplerate = samplerate
        self.stats = stats
        self.stats_lock = stats_lock
        self.subscribers = subscribers
        self.subscribers_lock = subscribers_lock

        self._stop_event = threading.Event()
        self.sock: socket.socket | None = None
        self.running = False
        self.error: str | None = None
        self._seq = 0

    def bind(self) -> bool:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("", 0))
            s.settimeout(0.2)
        except OSError as e:
            self.error = f"Не удалось открыть UDP-сокет: {e}"
            with self.stats_lock:
                self.stats["error"] = self.error
            try:
                s.close()
            except Exception:
                pass
            return False
        self.sock = s
        return True

    def stop(self) -> None:
        self._stop_event.set()
        self.running = False
        s = self.sock
        self.sock = None
        if s is not None:
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                s.close()
            except OSError:
                pass

    def _broadcast_frame(self, frame: bytes) -> None:
        """Кладёт готовый фрейм всем подписчикам. Медленных — дропает."""
        with self.subscribers_lock:
            subs = list(self.subscribers)
        for q in subs:
            try:
                q.put_nowait(frame)
            except queue.Full:
                # Медленный клиент — дропаем кадр, не блокируем приём.
                with self.stats_lock:
                    self.stats["dropped_frames"] = \
                        self.stats.get("dropped_frames", 0) + 1

    def run(self) -> None:
        if self.sock is None:
            if not self.bind():
                print(f"[rx] bind failed: {self.error}")
                return

        print(f"[rx] thread started, bound to {self.sock.getsockname()}, "
              f"relay={self.host}:{self.port}")

        self.running = True
        with self.stats_lock:
            self.stats["error"] = None

        relay_addr = (self.host, self.port)
        last_keepalive = 0.0
        got_any = False

        while not self._stop_event.is_set():
            now = time.time()
            if now - last_keepalive >= KEEPALIVE_INTERVAL:
                try:
                    self.sock.sendto(KEEPALIVE_PAYLOAD, relay_addr)
                except OSError as e:
                    print(f"[rx] HELLO sendto failed: {e}")
                last_keepalive = now

            try:
                data, addr = self.sock.recvfrom(65536)
            except socket.timeout:
                continue
            except OSError as e:
                if self._stop_event.is_set():
                    break
                print(f"[rx] recvfrom OSError: {e}")
                break

            if not data or data == KEEPALIVE_PAYLOAD:
                continue

            if not got_any:
                got_any = True
                print(f"[rx] first packet from {addr}, {len(data)} bytes")

            try:
                arr = np.frombuffer(data, dtype=self.dtype)
            except ValueError:
                continue

            n_frames = len(arr) // self.channels
            if n_frames == 0:
                continue

            arr = arr[: n_frames * self.channels].reshape(-1, self.channels)

            if self.dtype == np.int16:
                arr = arr.astype(np.float32) / 32768.0
            elif self.dtype == np.int8:
                arr = arr.astype(np.float32) / 128.0
            else:
                arr = arr.astype(np.float32)

            np.clip(arr, -1.0, 1.0, out=arr)

            pcm = arr.ravel().astype("<f4").tobytes()
            self._seq += 1

            with self.stats_lock:
                self.stats["packets"] += 1
                self.stats["bytes"] += len(data)
                self.stats["last_packet"] = time.time()

            header = FRAME_HEADER.pack(len(pcm), self._seq,
                                       self.samplerate, self.channels)
            self._broadcast_frame(header + pcm)

        print("[rx] thread exiting")
        self.running = False
        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass
        self.sock = None


# ---------------------------------------------------------------------------
# Flask + SocketIO
# ---------------------------------------------------------------------------

app = Flask(__name__)
app.config["SECRET_KEY"] = os.urandom(24).hex()
app.config["TEMPLATES_AUTO_RELOAD"] = True
socketio = SocketIO(
    app,
    cors_allowed_origins="*",
    async_mode="threading",
    ping_timeout=20,
    ping_interval=10,
    logger=False,
    engineio_logger=False,
)


_state = {
    "receiver": None,
    "config": load_config(),
    "stats": {
        "packets": 0,
        "bytes": 0,
        "clients": 0,          # socketio-клиентов (для старого UI)
        "subscribers": 0,      # HTTP-стримов
        "dropped_frames": 0,
        "error": None,
        "last_packet": 0.0,
        "started_at": None,
    },
    "lock": threading.Lock(),      # общий lock для receiver + config
    "stats_lock": threading.Lock(),  # отдельный для stats
    "subscribers": set(),           # set[queue.Queue]
    "subscribers_lock": threading.Lock(),
    "stop_broadcast": threading.Event(),
}


def _get_status() -> dict:
    cfg = _state["config"]
    with _state["lock"]:
        rx = _state["receiver"]
        running = bool(rx and rx.running)
    with _state["stats_lock"]:
        stats = dict(_state["stats"])
    with _state["subscribers_lock"]:
        n_subs = len(_state["subscribers"])

    return {
        "running": running,
        "relay_host": cfg["relay_host"],
        "relay_port": cfg["relay_port"],
        "samplerate": cfg["samplerate"],
        "channels": cfg["channels"],
        "format": cfg["format"],
        "packets": stats["packets"],
        "bytes": stats["bytes"],
        "clients": stats["clients"],
        "subscribers": n_subs,
        "dropped_frames": stats.get("dropped_frames", 0),
        "error": stats.get("error"),
        "last_packet_ago": (
            round(time.time() - stats["last_packet"], 1)
            if stats["last_packet"] else None
        ),
    }


# ---------------------------------------------------------------------------
# HTTP: страница и API
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html", title=APP_TITLE)


@app.route("/api/status")
def api_status():
    return jsonify(_get_status())


@app.route("/api/config", methods=["GET", "POST"])
def api_config():
    if request.method == "GET":
        return jsonify(_state["config"])

    data = request.get_json(silent=True) or {}
    cfg = _state["config"]
    for key in ("relay_host", "relay_port", "samplerate", "channels", "format"):
        if key in data:
            cfg[key] = data[key]
    try:
        cfg["relay_port"] = int(cfg["relay_port"])
        cfg["samplerate"] = int(cfg["samplerate"])
        cfg["channels"] = int(cfg["channels"])
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Некорректные числа"}), 400
    if cfg["format"] not in FORMAT_MAP:
        return jsonify({"ok": False, "error": "Неизвестный формат"}), 400
    if not (1 <= cfg["relay_port"] <= 65535):
        return jsonify({"ok": False, "error": "Порт 1–65535"}), 400
    if cfg["channels"] not in (1, 2):
        return jsonify({"ok": False, "error": "Каналы: 1 или 2"}), 400
    if cfg["samplerate"] < 8000:
        return jsonify({"ok": False, "error": "Частота слишком низкая"}), 400

    save_config(cfg)
    return jsonify({"ok": True, "config": cfg})


# ---------------------------------------------------------------------------
# Логика start/stop (используется HTTP-ручками)
# ---------------------------------------------------------------------------

def _do_start() -> dict:
    """Возвращает dict результата: {"ok": bool, "error": str | None}."""
    # 1) Останавливаем старый, если есть
    with _state["lock"]:
        old = _state["receiver"]
        _state["receiver"] = None
    if old is not None:
        print("[start] stopping old receiver...")
        try:
            old.stop()
            old.join(timeout=3.0)
            if old.is_alive():
                print("[start] WARN: old receiver still alive")
                old.join(timeout=2.0)
        except Exception as e:
            print(f"[start] old.stop() error: {e}")

    # 2) Сбрасываем статистику
    cfg = _state["config"]
    dtype = FORMAT_MAP.get(cfg["format"], np.float32)
    with _state["stats_lock"]:
        _state["stats"]["packets"] = 0
        _state["stats"]["bytes"] = 0
        _state["stats"]["dropped_frames"] = 0
        _state["stats"]["error"] = None
        _state["stats"]["last_packet"] = 0.0
        _state["stats"]["started_at"] = time.time()

    # 3) Новый приёмник
    receiver = UdpReceiver(
        host=str(cfg["relay_host"]).strip() or "127.0.0.1",
        port=int(cfg["relay_port"]),
        dtype=dtype,
        channels=int(cfg["channels"]),
        samplerate=int(cfg["samplerate"]),
        stats=_state["stats"],
        stats_lock=_state["stats_lock"],
        subscribers=_state["subscribers"],
        subscribers_lock=_state["subscribers_lock"],
    )

    if not receiver.bind():
        print(f"[start] bind failed: {receiver.error}")
        return {"ok": False, "error": receiver.error or "bind failed"}

    with _state["lock"]:
        _state["receiver"] = receiver
    receiver.start()
    print("[start] new receiver started")
    return {"ok": True, "error": None}


def _do_stop() -> None:
    with _state["lock"]:
        rx = _state["receiver"]
        _state["receiver"] = None
    if rx is not None:
        print("[stop] stopping receiver...")
        try:
            rx.stop()
            rx.join(timeout=3.0)
            if rx.is_alive():
                print("[stop] WARN: receiver still alive after 3s")
        except Exception as e:
            print(f"[stop] error: {e}")
    print("[stop] done")


@app.route("/api/start", methods=["POST"])
def api_start():
    result = _do_start()
    socketio.emit("status", _get_status())
    if not result["ok"]:
        return jsonify({"ok": False, "error": result["error"]}), 500
    return jsonify({"ok": True})


@app.route("/api/stop", methods=["POST"])
def api_stop():
    _do_stop()
    socketio.emit("status", _get_status())
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# HTTP-стрим аудио
# ---------------------------------------------------------------------------

@app.route("/api/audio")
def api_audio():
    """
    Отдаёт бинарный поток фреймов [len:u32][seq:u32][sr:u32][ch:u8][pcm].
    Каждый браузер получает свою очередь (queue.Queue). Если очередь
    переполнена — кадр дропается, чтобы не тормозить общий приём.
    """
    q: queue.Queue = queue.Queue(maxsize=200)

    with _state["subscribers_lock"]:
        _state["subscribers"].add(q)
    with _state["stats_lock"]:
        _state["stats"]["subscribers"] = len(_state["subscribers"])

    def gen():
        try:
            # Заголовки "no buffer" уже стоят в Response; отдаём поток.
            # Первым делом отправим пустой фрейм — браузер сразу видит,
            # что канал открыт.
            yield EMPTY_FRAME

            while True:
                try:
                    frame = q.get(timeout=5.0)
                except queue.Empty:
                    # Keepalive, чтобы nginx/браузер не закрыли соединение.
                    yield EMPTY_FRAME
                    continue
                yield frame
        except GeneratorExit:
            pass
        finally:
            with _state["subscribers_lock"]:
                _state["subscribers"].discard(q)
            with _state["stats_lock"]:
                _state["stats"]["subscribers"] = len(_state["subscribers"])

    headers = {
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "X-Accel-Buffering": "no",  # если вдруг будет nginx
        "Connection": "keep-alive",
    }
    return Response(
        stream_with_context(gen()),
        mimetype="application/octet-stream",
        headers=headers,
        direct_passthrough=True,
    )


# ---------------------------------------------------------------------------
# Socket.IO: только статус (для совместимости)
# ---------------------------------------------------------------------------

@socketio.on("connect")
def on_connect():
    with _state["stats_lock"]:
        _state["stats"]["clients"] += 1
    emit("status", _get_status())
    socketio.emit("status", _get_status())


@socketio.on("disconnect")
def on_disconnect():
    with _state["stats_lock"]:
        _state["stats"]["clients"] = max(0, _state["stats"]["clients"] - 1)
    socketio.emit("status", _get_status())


@socketio.on("get_status")
def on_get_status():
    emit("status", _get_status())


# ---------------------------------------------------------------------------
# Периодическая рассылка статуса
# ---------------------------------------------------------------------------

def _status_broadcast_loop():
    while not _state["stop_broadcast"].wait(1.0):
        try:
            socketio.emit("status", _get_status())
        except Exception:
            pass


# ---------------------------------------------------------------------------
# CLI / main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description=APP_TITLE)
    parser.add_argument("--host", default="", help="IP relay")
    parser.add_argument("--port", type=int, default=0, help="UDP-порт relay")
    parser.add_argument("--web-port", type=int, default=0,
                        help="HTTP-порт (по умолчанию 5000)")
    parser.add_argument("--listen", default="", help="Адрес Flask (0.0.0.0)")
    parser.add_argument("--rate", type=int, default=0, help="Sample rate")
    parser.add_argument("--channels", type=int, default=0, help="1 или 2")
    parser.add_argument("--format", default="",
                        choices=["", "float32", "int16", "int8"])
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    cfg = _state["config"]
    if args.host:
        cfg["relay_host"] = args.host
    if args.port:
        cfg["relay_port"] = args.port
    if args.rate:
        cfg["samplerate"] = args.rate
    if args.channels in (1, 2):
        cfg["channels"] = args.channels
    if args.format:
        cfg["format"] = args.format
    if args.listen:
        cfg["listen_host"] = args.listen
    if args.web_port:
        cfg["web_port"] = args.web_port

    save_config(cfg)

    listen = cfg.get("listen_host") or "0.0.0.0"
    web_port = int(cfg.get("web_port") or 5000)

    print(f"{APP_TITLE}")
    print(f"  Web UI  →  http://{'127.0.0.1' if listen == '0.0.0.0' else listen}:{web_port}")
    print(f"  Relay   →  {cfg['relay_host']}:{cfg['relay_port']}")
    print(f"  Audio   →  {cfg['samplerate']} Hz, {cfg['channels']} ch, {cfg['format']}")
    print("  Ctrl+C для выхода.\n")

    threading.Thread(target=_status_broadcast_loop, daemon=True).start()

    try:
        socketio.run(
            app,
            host=listen,
            port=web_port,
            debug=args.debug,
            use_reloader=False,
            allow_unsafe_werkzeug=True,
        )
    finally:
        _state["stop_broadcast"].set()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nОстановлено.")
        sys.exit(0)