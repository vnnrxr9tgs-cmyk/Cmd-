#!/usr/bin/env python3
"""
Telegram News — клиент Microsoft SQL Server 2008+.

Источник новостей: SQL Server (не JSON).
Импорт JSON → БД: json_to_mssql.py на сервере/ПК с файлами.
"""

from __future__ import annotations

import ctypes
import hashlib
import http.client
import json
import math
import os
import sys
import threading
import time
import traceback
from urllib.parse import urlparse
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtMultimedia import QMediaContent, QMediaPlayer
from PyQt5.QtNetwork import QLocalServer, QLocalSocket
from PyQt5.QtWidgets import *

try:
    import pyodbc
except ImportError:
    pyodbc = None  # проверка при старте

# ---------------------------------------------------------------------------
# Paths / constants
# ---------------------------------------------------------------------------


def excepthook(exc_type, exc_value, exc_tb):
    traceback.print_exception(exc_type, exc_value, exc_tb)
    sys.__excepthook__(exc_type, exc_value, exc_tb)


sys.excepthook = excepthook

if getattr(sys, "frozen", False):
    BASE_DIR = Path(sys.executable).resolve().parent
    BUNDLE_DIR = Path(getattr(sys, "_MEIPASS", BASE_DIR))
else:
    BASE_DIR = Path(__file__).resolve().parent
    BUNDLE_DIR = BASE_DIR

SETTINGS_DIR = BASE_DIR / "settings"
_EXTERNAL_SOUNDS_DIR = BASE_DIR / "sounds"
SOUNDS_DIR = _EXTERNAL_SOUNDS_DIR if _EXTERNAL_SOUNDS_DIR.exists() else (BUNDLE_DIR / "sounds")
SETTINGS_FILE = SETTINGS_DIR / "settings.xml"
SOUND_FILE = SOUNDS_DIR / "1.mp3"
II_CONFIG_FILE = SETTINGS_DIR / "ii.json"
PROMPTS_FILE = SETTINGS_DIR / "prompts.json"
FAVORITES_FILE = SETTINGS_DIR / "favorites.json"

APP_FONT_FAMILIES: List[str] = []


def load_bundled_fonts():
    """Регистрирует локальные TTF/OTF из sounds (важно для emoji на старых Windows)."""
    APP_FONT_FAMILIES.clear()
    if not SOUNDS_DIR.exists():
        return
    for fp in list(SOUNDS_DIR.glob("*.ttf")) + list(SOUNDS_DIR.glob("*.otf")):
        try:
            fid = QFontDatabase.addApplicationFont(str(fp))
            if fid >= 0:
                APP_FONT_FAMILIES.extend(QFontDatabase.applicationFontFamilies(fid))
        except Exception:
            pass


def emoji_font(size=12, bold=False):
    preferred = next((f for f in APP_FONT_FAMILIES if "emoji" in f.lower()), None)
    f = QFont(preferred or "Segoe UI Emoji", size)
    f.setBold(bold)
    return f


def dwm_composition_enabled() -> bool:
    """
    True — DWM-композиция включена (Win7 с Aero, Win8/10/11, не-Windows).
    False — старый Win7 без Aero: полупрозрачность и opacity-анимации не работают,
    и если их всё-таки включить, окно может остаться полностью прозрачным.
    """
    if sys.platform != "win32":
        return True
    try:
        enabled = ctypes.c_int()
        ctypes.windll.dwmapi.DwmIsCompositionEnabled(ctypes.byref(enabled))
        return bool(enabled.value)
    except Exception:
        # Не смогли определить — считаем, что композиция есть (Win8/10/11).
        return True


SIDEBAR_WIDTH = 500
CARD_RADIUS = 12
FONT_SIZE_TITLE = 13
FONT_SIZE_CHANNEL = 11
FONT_SIZE_SMALL = 9
CHANNEL_HEIGHT = 120
PAGE_SIZE = 10
NEWS_PREVIEW_LIMIT = 700
# Русский текст читается заметно медленнее английского;
# 200 wpm давало «1 минута» практически для всех новостей.
READING_WPM = 150

# ---------------------------------------------------------------------------
# Themes
# ---------------------------------------------------------------------------


class DarkTheme:
    name = "dark"
    WINDOW = "#111925"
    SIDEBAR = "#131c2a"
    HEADER = "#141d2b"
    CARD = "#192436"
    CARD_HOVER = "#213149"
    CARD_ACTIVE = "#2a3e5c"
    CARD_UNREAD = "#182842"
    NEWS_CARD = "#1b2739"
    NEWS_CARD_HOVER = "#243550"
    NEWS_CARD_GRAD_TOP = "#243349"
    NEWS_CARD_GRAD_BOTTOM = "#1a2538"
    BORDER = "#0a111b"
    TEXT = "#e9eef6"
    SUBTEXT = "#8fa1b8"
    BLUE = "#6a9cf0"
    BLUE_LIGHT = "#8db8ff"
    BLUE_DARK = "#4a72d2"
    RED = "#ee5d5d"
    STAR = "#f7c65a"
    UNREAD_BADGE = "#6a9cf0"
    SHADOW_RGB = "0,0,0"
    GLOW_RGB = "106,156,240"
    AVATAR_COLORS = [
        "#e8767c", "#77c98f", "#68aef0", "#a999ee", "#ef83b5",
        "#5fcad0", "#f4a874", "#a3b06e", "#d6a06f", "#bd8fa6",
    ]
    TOAST_GRAD_TOP = "#2a3a54"
    TOAST_GRAD_BOTTOM = "#152033"
    SCROLL_HANDLE = "#4d5b73"
    SCROLL_HANDLE_HOVER = "#6b7d98"
    BG_GRAD_TOP = "#172233"
    BG_GRAD_BOTTOM = "#0f1824"


class LightTheme:
    name = "light"
    WINDOW = "#eaeff7"
    SIDEBAR = "#f7f9fd"
    HEADER = "#fbfcff"
    CARD = "#ffffff"
    CARD_HOVER = "#e9f0fc"
    CARD_ACTIVE = "#d6e5fb"
    CARD_UNREAD = "#eff5ff"
    NEWS_CARD = "#ffffff"
    NEWS_CARD_HOVER = "#f3f7fe"
    NEWS_CARD_GRAD_TOP = "#ffffff"
    NEWS_CARD_GRAD_BOTTOM = "#f3f6fc"
    BORDER = "#d5deec"
    TEXT = "#172134"
    SUBTEXT = "#64768e"
    BLUE = "#3a7bdc"
    BLUE_LIGHT = "#629aee"
    BLUE_DARK = "#2a5db6"
    RED = "#dc4444"
    STAR = "#eba30c"
    UNREAD_BADGE = "#3a7bdc"
    SHADOW_RGB = "40,60,95"
    GLOW_RGB = "58,123,220"
    AVATAR_COLORS = [
        "#e8767c", "#77c98f", "#68aef0", "#a999ee", "#ef83b5",
        "#5fcad0", "#f4a874", "#a3b06e", "#d6a06f", "#bd8fa6",
    ]
    TOAST_GRAD_TOP = "#ffffff"
    TOAST_GRAD_BOTTOM = "#ecf1f9"
    SCROLL_HANDLE = "#b3bdcd"
    SCROLL_HANDLE_HOVER = "#8d9bb0"
    BG_GRAD_TOP = "#f2f6fc"
    BG_GRAD_BOTTOM = "#e8eef7"


Theme = DarkTheme


def apply_theme(cls):
    global Theme
    Theme = cls


def font_s(size=10, bold=False):
    f = QFont("Segoe UI", size)
    f.setBold(bold)
    f.setLetterSpacing(QFont.AbsoluteSpacing, 0.2)
    return f


def draw_card_shadow(painter: QPainter, rect: QRect, radius: int = CARD_RADIUS, strength: float = 1.0):
    painter.save()
    painter.setPen(Qt.NoPen)
    r, g, b = (int(x) for x in Theme.SHADOW_RGB.split(","))
    for grow, alpha in ((0, 28), (2, 18), (5, 11), (8, 6)):
        shadow_rect = rect.adjusted(-grow, -grow + 4, grow, grow + 6)
        painter.setBrush(QColor(r, g, b, max(0, min(255, int(alpha * strength)))))
        painter.drawRoundedRect(shadow_rect, radius + grow, radius + grow)
    painter.restore()


def draw_hover_glow(painter: QPainter, rect: QRect, radius: int = CARD_RADIUS, alpha: int = 140):
    if alpha <= 0:
        return
    painter.save()
    painter.setBrush(Qt.NoBrush)
    r, g, b = (int(x) for x in Theme.GLOW_RGB.split(","))
    painter.setPen(QPen(QColor(r, g, b, max(0, min(255, alpha))), 1.4))
    painter.drawRoundedRect(rect.adjusted(0, 0, -1, -1), radius, radius)
    painter.restore()


def mix_color(a, b, t: float) -> QColor:
    """Линейное смешивание двух цветов (t=0 → a, t=1 → b)."""
    ca, cb = QColor(a), QColor(b)
    t = max(0.0, min(1.0, float(t)))
    return QColor(
        int(ca.red() + (cb.red() - ca.red()) * t),
        int(ca.green() + (cb.green() - ca.green()) * t),
        int(ca.blue() + (cb.blue() - ca.blue()) * t),
    )


def fade_in(widget: QWidget, duration: int = 200) -> None:
    """Мягкое появление окна. Без DWM ничего не делаем, иначе окно зависнет прозрачным."""
    if not dwm_composition_enabled():
        return
    try:
        widget.setWindowOpacity(0.0)
        anim = QPropertyAnimation(widget, b"windowOpacity", widget)
        anim.setDuration(duration)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.finished.connect(lambda: widget.setWindowOpacity(1.0))
        anim.start(QAbstractAnimation.DeleteWhenStopped)
    except Exception:
        try:
            widget.setWindowOpacity(1.0)
        except Exception:
            pass


def hex_to_rgb(h: str) -> Tuple[int, int, int]:
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def primary_btn_qss(radius: int = 12, padding: str = "8px 20px") -> str:
    return f"""
        QPushButton {{
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 {Theme.BLUE_LIGHT}, stop:1 {Theme.BLUE_DARK});
            color: white; border: none; border-radius: {radius}px; padding: {padding};
        }}
        QPushButton:hover {{
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 {Theme.BLUE}, stop:1 {Theme.BLUE_DARK});
        }}
        QPushButton:pressed {{ background: {Theme.BLUE_DARK}; }}
        QPushButton:disabled {{ background: {Theme.CARD_HOVER}; color: {Theme.SUBTEXT}; }}
    """


def secondary_btn_qss(radius: int = 12, padding: str = "8px 20px") -> str:
    return f"""
        QPushButton {{
            background: {Theme.CARD}; color: {Theme.TEXT};
            border: 1px solid {Theme.BORDER}; border-radius: {radius}px; padding: {padding};
        }}
        QPushButton:hover {{ background: {Theme.CARD_HOVER}; border-color: {Theme.BLUE}; }}
        QPushButton:pressed {{ background: {Theme.CARD_ACTIVE}; }}
        QPushButton:disabled {{ color: {Theme.SUBTEXT}; border-color: {Theme.BORDER}; }}
    """


def danger_btn_qss(radius: int = 12, padding: str = "8px 20px") -> str:
    r, g, b = hex_to_rgb(Theme.RED)
    return f"""
        QPushButton {{
            background: transparent; color: {Theme.RED};
            border: 1px solid {Theme.RED}; border-radius: {radius}px; padding: {padding};
        }}
        QPushButton:hover {{ background: rgba({r}, {g}, {b}, 0.14); }}
        QPushButton:pressed {{ background: rgba({r}, {g}, {b}, 0.24); }}
    """


def favorite_btn_qss(active: bool, radius: int = 10, padding: str = "8px 18px") -> str:
    if not active:
        return secondary_btn_qss(radius=radius, padding=padding)
    r, g, b = hex_to_rgb(Theme.STAR)
    return f"""
        QPushButton {{
            background: rgba({r}, {g}, {b}, 0.12); color: {Theme.STAR};
            border: 1px solid {Theme.STAR}; border-radius: {radius}px; padding: {padding};
        }}
        QPushButton:hover {{ background: rgba({r}, {g}, {b}, 0.22); }}
        QPushButton:pressed {{ background: rgba({r}, {g}, {b}, 0.32); }}
    """


def glass_field_qss(radius: int = 18) -> str:
    if Theme.name == "dark":
        bg, bd = "rgba(255, 255, 255, 0.10)", "rgba(255, 255, 255, 0.14)"
        focus_bd = "rgba(255, 255, 255, 0.38)"
    else:
        bg, bd = "rgba(255, 255, 255, 0.92)", "rgba(0, 0, 0, 0.08)"
        focus_bd = Theme.BLUE
    return f"""
        QLineEdit {{
            background: {bg};
            color: {Theme.TEXT};
            border: 1px solid {bd};
            border-radius: {radius}px;
            padding: 0 16px;
        }}
        QLineEdit:focus {{ border: 1px solid {focus_bd}; }}
    """


def glass_icon_btn_qss(radius: int = 16) -> str:
    if Theme.name == "dark":
        hover = "rgba(255, 255, 255, 0.16)"
        pressed = "rgba(255, 255, 255, 0.06)"
    else:
        hover = "rgba(0, 0, 0, 0.06)"
        pressed = "rgba(0, 0, 0, 0.10)"
    return f"""
        QPushButton {{
            background: transparent;
            color: {Theme.TEXT};
            border: none;
            border-radius: {radius}px;
            padding: 0px;
        }}
        QPushButton:hover {{ background: {hover}; }}
        QPushButton:pressed {{ background: {pressed}; }}
        QPushButton:disabled {{ color: {Theme.SUBTEXT}; }}
    """


class GlassBar(QFrame):
    """Одна большая вытянутая «стеклянная» капсула с иконками-кнопками внутри."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, False)
        self.setFixedHeight(46)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        rect = self.rect().adjusted(0, 0, -1, -1)
        r = rect.height() / 2.0

        if Theme.name == "dark":
            g_top = QColor(255, 255, 255, 44)
            g_bot = QColor(255, 255, 255, 12)
            bd = QColor(255, 255, 255, 58)
        else:
            g_top = QColor(255, 255, 255, 245)
            g_bot = QColor(255, 255, 255, 150)
            bd = QColor(0, 0, 0, 22)

        grad = QLinearGradient(rect.left(), rect.top(), rect.left(), rect.bottom())
        grad.setColorAt(0.0, g_top)
        grad.setColorAt(1.0, g_bot)
        p.setBrush(QBrush(grad))
        p.setPen(QPen(bd, 1))
        p.drawRoundedRect(rect, r, r)


class BusyBar(QWidget):
    """Тонкая индикаторная полоска: пока идёт запрос — по ней плавно скользит светлый отрезок."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(4)
        self._phase = 0.0
        self._active = False
        self._anim = QVariantAnimation(self)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.setDuration(1400)
        self._anim.setLoopCount(-1)
        self._anim.setEasingCurve(QEasingCurve.InOutSine)
        self._anim.valueChanged.connect(self._on_value)

    def _on_value(self, v):
        self._phase = float(v)
        self.update()

    def set_active(self, on: bool):
        on = bool(on)
        if on == self._active:
            return
        self._active = on
        if on:
            self._anim.start()
        else:
            self._anim.stop()
        self.update()

    def paintEvent(self, e):
        if not self._active:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        track = QPainterPath()
        track.addRoundedRect(QRectF(0, 0, w, h), h / 2.0, h / 2.0)
        r, g, b = (int(x) for x in Theme.GLOW_RGB.split(","))
        p.fillPath(track, QColor(r, g, b, 34))
        seg = max(40.0, w * 0.3)
        x = -seg + (w + seg) * self._phase
        p.setClipPath(track)
        grad = QLinearGradient(x, 0, x + seg, 0)
        grad.setColorAt(0.0, QColor(r, g, b, 0))
        grad.setColorAt(0.5, QColor(Theme.BLUE_LIGHT))
        grad.setColorAt(1.0, QColor(r, g, b, 0))
        p.fillRect(QRectF(x, 0, seg, h), QBrush(grad))


def human_time(text: str) -> str:
    if not text:
        return ""
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%d.%m.%Y %H:%M", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(text, fmt).strftime("%H:%M")
        except ValueError:
            continue
    return text[:5] if len(text) >= 5 else text


def truncate(text, max_len=80):
    return text[:max_len] + "…" if len(text) > max_len else text


def reading_minutes(text: str) -> int:
    words = len((text or "").split())
    return max(1, (words + READING_WPM - 1) // READING_WPM)


def preview_text(text: str, limit: int = NEWS_PREVIEW_LIMIT) -> Tuple[str, bool]:
    text = text or ""
    if len(text) <= limit:
        return text, False
    cut = text[:limit]
    sp = cut.rfind(" ")
    if sp > limit * 0.6:
        cut = cut[:sp]
    return cut.rstrip() + "…", True


def draw_avatar(painter: QPainter, rect: QRect, text: str):
    painter.save()
    painter.setRenderHint(QPainter.Antialiasing, True)
    idx = int(hashlib.md5(text.encode()).hexdigest(), 16) % len(Theme.AVATAR_COLORS)
    painter.setBrush(QColor(Theme.AVATAR_COLORS[idx]))
    painter.setPen(Qt.NoPen)
    painter.drawEllipse(rect)
    words = text.split()
    letters = words[0][:2].upper() if len(words) == 1 else (words[0][0] + words[1][0]).upper()
    painter.setPen(Qt.white)
    painter.setFont(font_s(int(rect.height() * 0.30), True))
    painter.drawText(rect, Qt.AlignCenter, letters)
    painter.restore()


def default_user_id() -> str:
    try:
        return os.getlogin()
    except Exception:
        return os.environ.get("USERNAME") or os.environ.get("USER") or "user"


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------


class Settings:
    def __init__(self, filename: Path = SETTINGS_FILE):
        self.filename = Path(filename)
        self.enabled_channels: Dict[str, dict] = {}
        self.font_size = 14
        self.sound_enabled = True
        self.notifications_enabled = True
        self.notification_detail = "full"  # full | minimal
        self.initialized = False
        self.theme = "dark"
        self.poll_interval_sec = 5
        self.mssql_server = ""
        self.mssql_database = "TelegramNews"
        self.mssql_auth = "windows"
        self.mssql_user = ""
        self.mssql_password = ""
        self.mssql_driver = "SQL Server"
        self.user_id = ""
        self.load()

    def load(self):
        if not self.filename.exists():
            return
        try:
            root = ET.parse(str(self.filename)).getroot()
            self.enabled_channels = {}
            for ch in root.findall("channel"):
                name = ch.get("name")
                self.enabled_channels[name] = {
                    "show": (ch.findtext("show") or "true").lower() == "true",
                    "notify": (ch.findtext("notify") or "true").lower() == "true",
                    "sound": (ch.findtext("sound") or "true").lower() == "true",
                }
            self.font_size = int(root.findtext("font_size") or 14)
            self.sound_enabled = (root.findtext("sound_enabled") or "true").lower() == "true"
            self.notifications_enabled = (root.findtext("notifications_enabled") or "true").lower() == "true"
            self.notification_detail = (root.findtext("notification_detail") or "full").strip().lower()
            if self.notification_detail not in ("full", "minimal"):
                self.notification_detail = "full"
            self.initialized = (root.findtext("initialized") or "false").lower() == "true"
            self.theme = (root.findtext("theme") or "dark").strip().lower()
            if self.theme not in ("dark", "light"):
                self.theme = "dark"
            try:
                self.poll_interval_sec = int(root.findtext("poll_interval_sec") or 5)
            except ValueError:
                self.poll_interval_sec = 5
            self.mssql_server = root.findtext("mssql_server") or ""
            self.mssql_database = root.findtext("mssql_database") or "TelegramNews"
            self.mssql_auth = (root.findtext("mssql_auth") or "windows").lower()
            self.mssql_user = root.findtext("mssql_user") or ""
            self.mssql_password = root.findtext("mssql_password") or ""
            self.mssql_driver = root.findtext("mssql_driver") or "SQL Server"
            self.user_id = (root.findtext("user_id") or "").strip()
        except Exception:
            pass

    def save(self):
        root = ET.Element("settings")
        for name, data in self.enabled_channels.items():
            ch = ET.SubElement(root, "channel", name=name)
            ET.SubElement(ch, "show").text = str(data.get("show", True)).lower()
            ET.SubElement(ch, "notify").text = str(data.get("notify", True)).lower()
            ET.SubElement(ch, "sound").text = str(data.get("sound", True)).lower()
        ET.SubElement(root, "font_size").text = str(self.font_size)
        ET.SubElement(root, "sound_enabled").text = str(self.sound_enabled).lower()
        ET.SubElement(root, "notifications_enabled").text = str(self.notifications_enabled).lower()
        ET.SubElement(root, "notification_detail").text = self.notification_detail
        ET.SubElement(root, "initialized").text = str(self.initialized).lower()
        ET.SubElement(root, "theme").text = self.theme
        ET.SubElement(root, "poll_interval_sec").text = str(self.poll_interval_sec)
        ET.SubElement(root, "mssql_server").text = self.mssql_server
        ET.SubElement(root, "mssql_database").text = self.mssql_database
        ET.SubElement(root, "mssql_auth").text = self.mssql_auth
        ET.SubElement(root, "mssql_user").text = self.mssql_user
        ET.SubElement(root, "mssql_password").text = self.mssql_password
        ET.SubElement(root, "mssql_driver").text = self.mssql_driver
        ET.SubElement(root, "user_id").text = self.user_id
        self.filename.parent.mkdir(parents=True, exist_ok=True)
        ET.ElementTree(root).write(str(self.filename), encoding="utf-8", xml_declaration=True)

    def conn_str(self, driver: Optional[str] = None) -> str:
        d = driver or self.mssql_driver or "SQL Server"
        drv = d if d.startswith("{") else f"{{{d}}}"
        parts = [
            f"DRIVER={drv}",
            f"SERVER={self.mssql_server}",
            f"DATABASE={self.mssql_database}",
            "Connection Timeout=8",
            "Login Timeout=8",
            "TrustServerCertificate=yes",
        ]
        if self.mssql_auth in ("windows", "trusted", "sspi", "domain"):
            parts.append("Trusted_Connection=yes")
        else:
            parts.append(f"UID={self.mssql_user}")
            parts.append(f"PWD={self.mssql_password}")
        return ";".join(parts)

    def candidate_drivers(self) -> List[str]:
        preferred = (self.mssql_driver or "SQL Server").strip()
        order = [
            preferred,
            "SQL Server",
            "SQL Server Native Client 10.0",
            "SQL Server Native Client 11.0",
            "ODBC Driver 11 for SQL Server",
            "ODBC Driver 13 for SQL Server",
            "ODBC Driver 17 for SQL Server",
            "ODBC Driver 18 for SQL Server",
        ]
        seen = set()
        out = []
        for d in order:
            if d and d not in seen:
                seen.add(d)
                out.append(d)
        return out

    def is_show(self, name: str) -> bool:
        return self.enabled_channels.get(name, {}).get("show", True)

    def is_notify(self, name: str) -> bool:
        return self.is_show(name) and self.enabled_channels.get(name, {}).get("notify", True)

    def is_sound(self, name: str) -> bool:
        return self.enabled_channels.get(name, {}).get("sound", True)

    def set_channel(self, name, show, notify, sound=True):
        self.enabled_channels[name] = {
            "show": bool(show),
            "notify": bool(notify) if show else False,
            "sound": bool(sound),
        }


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------


@dataclass
class News:
    id: int
    date: str
    channel: str
    text: str
    title: str = ""
    date_ts: float = 0.0
    checksum: str = ""

    def cs(self) -> str:
        return self.checksum or hashlib.md5(
            f"{self.date}{self.channel}{self.title}{self.text}".encode()
        ).hexdigest()


@dataclass
class Channel:
    id: int
    name: str
    last_news: str
    last_date: str
    count: int
    unread_count: int = 0
    notify_enabled: bool = True
    sound_enabled: bool = True


# ---------------------------------------------------------------------------
# Избранное — локальный JSON, отдельно от БД
# ---------------------------------------------------------------------------


class FavoritesStore:
    def __init__(self, filename: Path = FAVORITES_FILE):
        self.filename = Path(filename)
        self.items: List[dict] = []
        self.load()

    def load(self):
        self.items = []
        if not self.filename.exists():
            return
        try:
            raw = json.loads(self.filename.read_text(encoding="utf-8"))
            if isinstance(raw, list):
                self.items = [it for it in raw if isinstance(it, dict) and it.get("checksum")]
        except Exception:
            self.items = []

    def save(self):
        try:
            self.filename.parent.mkdir(parents=True, exist_ok=True)
            self.filename.write_text(
                json.dumps(self.items, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except Exception:
            pass

    def contains(self, checksum: str) -> bool:
        return bool(checksum) and any(it.get("checksum") == checksum for it in self.items)

    def checksum_set(self) -> set:
        return {it.get("checksum") for it in self.items if it.get("checksum")}

    def add(self, news: "News") -> bool:
        cs = news.checksum or news.cs()
        if self.contains(cs):
            return False
        self.items.insert(0, {
            "channel": news.channel,
            "title": news.title,
            "text": news.text,
            "date": news.date,
            "date_ts": news.date_ts,
            "checksum": cs,
            "added_at": datetime.now().isoformat(timespec="seconds"),
        })
        self.save()
        return True

    def remove(self, checksum: str) -> bool:
        before = len(self.items)
        self.items = [it for it in self.items if it.get("checksum") != checksum]
        if len(self.items) != before:
            self.save()
            return True
        return False

    def clear(self):
        self.items = []
        self.save()

    def to_news_list(self) -> List["News"]:
        out = []
        for i, it in enumerate(self.items):
            out.append(News(
                id=-(i + 1),
                date=it.get("date", ""),
                channel=it.get("channel", ""),
                text=it.get("text", ""),
                title=it.get("title", ""),
                date_ts=it.get("date_ts", 0.0) or 0.0,
                checksum=it.get("checksum", ""),
            ))
        return out

    def search(self, query: str) -> List["News"]:
        q = (query or "").strip().lower()
        if not q:
            return self.to_news_list()
        return [
            n for n in self.to_news_list()
            if q in (n.title or "").lower() or q in (n.text or "").lower() or q in (n.channel or "").lower()
        ]


# ---------------------------------------------------------------------------
# MSSQL Storage
# ---------------------------------------------------------------------------


class NewsStorage:
    """Синхронный доступ к MSSQL. Не шарить один connection между потоками."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.channels: List[Channel] = []
        self._working_driver: Optional[str] = None
        self.favorites = FavoritesStore()

    def connect(self):
        if pyodbc is None:
            raise RuntimeError("pyodbc не установлен. pip install pyodbc")
        if not self.settings.mssql_server:
            raise RuntimeError("Не указан SQL Server (Настройки → Подключение)")

        errors = []
        drivers = []
        if self._working_driver:
            drivers.append(self._working_driver)
        drivers.extend(self.settings.candidate_drivers())

        seen = set()
        for drv in drivers:
            if drv in seen:
                continue
            seen.add(drv)
            try:
                conn = pyodbc.connect(
                    self.settings.conn_str(drv),
                    timeout=8,
                    autocommit=True,
                )
                try:
                    conn.timeout = 8
                except Exception:
                    pass
                self._working_driver = drv
                if self.settings.mssql_driver != drv:
                    self.settings.mssql_driver = drv
                return conn
            except Exception as e:
                errors.append(f"{drv}: {e}")
                continue
        raise RuntimeError(
            "Не удалось подключиться к SQL Server.\n" + "\n".join(errors[-5:])
        )

    def close(self):
        pass

    def test_connection(self) -> Tuple[bool, str, Optional[str]]:
        try:
            conn = self.connect()
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM dbo.channels")
            ch_cnt = int(cur.fetchone()[0])
            cur.execute("SELECT COUNT(*), ISNULL(MAX(id),0) FROM dbo.news")
            n, max_id = cur.fetchone()
            n, max_id = int(n or 0), int(max_id or 0)
            conn.close()
            drv = self._working_driver or self.settings.mssql_driver
            return (
                True,
                f"OK · driver={drv} · каналов={ch_cnt} · новостей={n} · max_id={max_id}",
                drv,
            )
        except Exception as e:
            return False, str(e), None

    def get_all_channel_names(self) -> List[str]:
        conn = self.connect()
        try:
            cur = conn.cursor()
            cur.execute("SELECT name FROM dbo.channels ORDER BY name")
            return [r[0] for r in cur.fetchall()]
        finally:
            conn.close()

    def load_channels(self) -> List[Channel]:
        conn = self.connect()
        try:
            cur = conn.cursor()
            user = self.settings.user_id
            cur.execute(
                """
                SELECT
                    c.id,
                    c.name,
                    c.last_date,
                    c.last_text,
                    c.news_count,
                    (
                        SELECT COUNT(*)
                        FROM dbo.news n
                        WHERE n.channel_id = c.id
                          AND n.date_ts > ISNULL(r.last_read_ts, 0)
                    ) AS unread_count
                FROM dbo.channels c
                LEFT JOIN dbo.read_state r
                       ON r.channel_id = c.id AND r.user_id = ?
                ORDER BY c.last_date_ts DESC, c.name
                """,
                (user,),
            )
            channels: List[Channel] = []
            for row in cur.fetchall():
                cid, name, last_date, last_text, news_count, unread = row
                if not self.settings.is_show(name):
                    continue
                channels.append(
                    Channel(
                        id=int(cid),
                        name=name,
                        last_news=last_text or "",
                        last_date=last_date or "",
                        count=int(news_count or 0),
                        unread_count=int(unread or 0),
                        notify_enabled=self.settings.is_notify(name),
                        sound_enabled=self.settings.is_sound(name),
                    )
                )
            self.channels = channels
            return channels
        finally:
            conn.close()

    def news_page(
        self,
        channel_name: Optional[str],
        offset: int = 0,
        limit: int = PAGE_SIZE,
        search: Optional[str] = None,
    ) -> Tuple[List[News], int]:
        conn = self.connect()
        try:
            cur = conn.cursor()
            where = ["1=1"]
            params: list = []

            if channel_name:
                where.append("c.name = ?")
                params.append(channel_name)
            else:
                hidden = [
                    n
                    for n, d in self.settings.enabled_channels.items()
                    if not d.get("show", True)
                ]
                if hidden:
                    ph = ",".join("?" * len(hidden))
                    where.append(f"c.name NOT IN ({ph})")
                    params.extend(hidden)

            if search:
                where.append("(n.body LIKE ? OR ISNULL(n.title, N'') LIKE ?)")
                q = f"%{search}%"
                params.extend([q, q])

            where_sql = " AND ".join(where)

            cur.execute(
                f"""
                SELECT COUNT(*)
                FROM dbo.news n
                INNER JOIN dbo.channels c ON c.id = n.channel_id
                WHERE {where_sql}
                """,
                params,
            )
            total = int(cur.fetchone()[0])

            sql = f"""
                SELECT id, date_str, date_ts, title, body, checksum, channel
                FROM (
                    SELECT n.id, n.date_str, n.date_ts, n.title, n.body, n.checksum,
                           c.name AS channel,
                           ROW_NUMBER() OVER (ORDER BY n.date_ts DESC, n.id DESC) AS rn
                    FROM dbo.news n
                    INNER JOIN dbo.channels c ON c.id = n.channel_id
                    WHERE {where_sql}
                ) t
                WHERE rn BETWEEN ? AND ?
                ORDER BY rn
            """
            cur.execute(sql, params + [offset + 1, offset + limit])
            news = [
                News(
                    id=int(r[0]),
                    date=r[1] or "",
                    channel=r[6],
                    text=r[4] or "",
                    title=r[3] or "",
                    date_ts=float(r[2] or 0),
                    checksum=r[5] or "",
                )
                for r in cur.fetchall()
            ]
            return news, total
        finally:
            conn.close()

    def mark_channel_read(self, channel_name: str) -> None:
        conn = self.connect()
        try:
            cur = conn.cursor()
            user = self.settings.user_id
            cur.execute("SELECT id FROM dbo.channels WHERE name = ?", (channel_name,))
            row = cur.fetchone()
            if not row:
                return
            cid = int(row[0])
            cur.execute(
                """
                SELECT TOP 1 date_str, date_ts FROM dbo.news
                WHERE channel_id = ?
                ORDER BY date_ts DESC, id DESC
                """,
                (cid,),
            )
            last = cur.fetchone()
            if not last:
                return
            date_str, date_ts = last[0], float(last[1] or 0)
            cur.execute(
                """
                IF EXISTS (SELECT 1 FROM dbo.read_state WHERE user_id = ? AND channel_id = ?)
                    UPDATE dbo.read_state
                    SET last_read_ts = ?, last_read_date = ?
                    WHERE user_id = ? AND channel_id = ?
                ELSE
                    INSERT INTO dbo.read_state (user_id, channel_id, last_read_ts, last_read_date)
                    VALUES (?, ?, ?, ?)
                """,
                (user, cid, date_ts, date_str, user, cid, user, cid, date_ts, date_str),
            )
        finally:
            conn.close()

    def mark_all_read(self) -> None:
        conn = self.connect()
        try:
            cur = conn.cursor()
            user = self.settings.user_id
            cur.execute(
                """
                ;WITH latest AS (
                    SELECT n.channel_id, n.date_ts, n.date_str,
                           ROW_NUMBER() OVER (PARTITION BY n.channel_id ORDER BY n.date_ts DESC, n.id DESC) AS rn
                    FROM dbo.news n
                )
                UPDATE r
                   SET r.last_read_ts = l.date_ts,
                       r.last_read_date = l.date_str
                FROM dbo.read_state r
                INNER JOIN latest l ON l.channel_id = r.channel_id AND l.rn = 1
                WHERE r.user_id = ?;

                ;WITH latest AS (
                    SELECT n.channel_id, n.date_ts, n.date_str,
                           ROW_NUMBER() OVER (PARTITION BY n.channel_id ORDER BY n.date_ts DESC, n.id DESC) AS rn
                    FROM dbo.news n
                )
                INSERT INTO dbo.read_state (user_id, channel_id, last_read_ts, last_read_date)
                SELECT ?, l.channel_id, l.date_ts, l.date_str
                FROM latest l
                WHERE l.rn = 1
                  AND NOT EXISTS (
                      SELECT 1 FROM dbo.read_state r
                      WHERE r.user_id = ? AND r.channel_id = l.channel_id
                  );
                """,
                (user, user, user),
            )
        finally:
            conn.close()

    def max_news_id(self) -> int:
        conn = self.connect()
        try:
            cur = conn.cursor()
            cur.execute("SELECT ISNULL(MAX(id), 0) FROM dbo.news")
            return int(cur.fetchone()[0])
        finally:
            conn.close()

    def news_since_id(self, after_id: int) -> List[News]:
        conn = self.connect()
        try:
            cur = conn.cursor()
            cur.execute(
                """
                SELECT n.id, n.date_str, n.date_ts, n.title, n.body, n.checksum, c.name
                FROM dbo.news n
                INNER JOIN dbo.channels c ON c.id = n.channel_id
                WHERE n.id > ?
                ORDER BY n.date_ts DESC, n.id DESC
                """,
                (after_id,),
            )
            return [
                News(
                    id=int(r[0]),
                    date=r[1] or "",
                    channel=r[6],
                    text=r[4] or "",
                    title=r[3] or "",
                    date_ts=float(r[2] or 0),
                    checksum=r[5] or "",
                )
                for r in cur.fetchall()
            ]
        finally:
            conn.close()

    def news_for_ai(self, channel_names: List[str], since_ts: float, until_ts: float, limit: int = 500) -> List[News]:
        if not channel_names:
            return []
        names = [n for n in channel_names if self.settings.is_show(n)]
        if not names:
            return []
        conn = self.connect()
        try:
            cur = conn.cursor()
            ph = ",".join("?" * len(names))
            sql = f"""
                SELECT TOP {max(1, min(int(limit), 2000))}
                       n.id, n.date_str, n.date_ts, n.title, n.body, n.checksum, c.name
                FROM dbo.news n
                INNER JOIN dbo.channels c ON c.id = n.channel_id
                WHERE c.name IN ({ph})
                  AND n.date_ts >= ? AND n.date_ts <= ?
                ORDER BY n.date_ts ASC, n.id ASC
            """
            cur.execute(sql, names + [float(since_ts), float(until_ts)])
            return [
                News(
                    id=int(r[0]), date=r[1] or "", date_ts=float(r[2] or 0),
                    title=r[3] or "", text=r[4] or "", checksum=r[5] or "", channel=r[6]
                )
                for r in cur.fetchall()
            ]
        finally:
            conn.close()

    def poll_bundle(self, after_id: int, load_new: bool = True, batch_size: int = 500) -> Tuple[int, List[News], List[Channel]]:
        conn = self.connect()
        try:
            cur = conn.cursor()
            cur.execute("SELECT ISNULL(MAX(id), 0) FROM dbo.news")
            max_id = int(cur.fetchone()[0])
            new_items: List[News] = []
            checkpoint_id = max_id
            if load_new and max_id > after_id:
                safe_batch = max(1, min(int(batch_size), 2000))
                cur.execute(
                    f"""
                    SELECT TOP {safe_batch} n.id, n.date_str, n.date_ts, n.title, n.body, n.checksum, c.name
                    FROM dbo.news n
                    INNER JOIN dbo.channels c ON c.id = n.channel_id
                    WHERE n.id > ?
                    ORDER BY n.id ASC
                    """,
                    (after_id,),
                )
                new_items = [
                    News(
                        id=int(r[0]),
                        date=r[1] or "",
                        channel=r[6],
                        text=r[4] or "",
                        title=r[3] or "",
                        date_ts=float(r[2] or 0),
                        checksum=r[5] or "",
                    )
                    for r in cur.fetchall()
                ]
                if new_items:
                    checkpoint_id = new_items[-1].id
            user = self.settings.user_id
            cur.execute(
                """
                SELECT
                    c.id, c.name, c.last_date, c.last_text, c.news_count,
                    (
                        SELECT COUNT(*) FROM dbo.news n
                        WHERE n.channel_id = c.id
                          AND n.date_ts > ISNULL(r.last_read_ts, 0)
                    ) AS unread_count
                FROM dbo.channels c
                LEFT JOIN dbo.read_state r
                       ON r.channel_id = c.id AND r.user_id = ?
                ORDER BY c.last_date_ts DESC, c.name
                """,
                (user,),
            )
            channels: List[Channel] = []
            for row in cur.fetchall():
                cid, name, last_date, last_text, news_count, unread = row
                if not self.settings.is_show(name):
                    continue
                channels.append(
                    Channel(
                        id=int(cid),
                        name=name,
                        last_news=last_text or "",
                        last_date=last_date or "",
                        count=int(news_count or 0),
                        unread_count=int(unread or 0),
                        notify_enabled=self.settings.is_notify(name),
                        sound_enabled=self.settings.is_sound(name),
                    )
                )
            self.channels = channels
            return checkpoint_id, new_items, channels
        finally:
            conn.close()


# ---------------------------------------------------------------------------
# Фоновые задачи БД (QThread)
# ---------------------------------------------------------------------------


class DbTask(QThread):
    finished_ok = pyqtSignal(str, object)
    failed = pyqtSignal(str, str)

    def __init__(self, settings: Settings, op: str, params: Optional[dict] = None, parent=None):
        super().__init__(parent)
        self._settings = settings
        self.op = op
        self.params = params or {}

    def run(self):
        storage = NewsStorage(self._settings)
        try:
            p = self.params
            if self.op == "load_channels":
                result = storage.load_channels()
            elif self.op == "news_page":
                result = storage.news_page(
                    p.get("channel_name"),
                    int(p.get("offset", 0)),
                    int(p.get("limit", PAGE_SIZE)),
                    p.get("search"),
                )
            elif self.op == "mark_read_and_page":
                storage.mark_channel_read(p["channel_name"])
                channels = storage.load_channels()
                news, total = storage.news_page(
                    p["channel_name"], 0, int(p.get("limit", PAGE_SIZE)), None
                )
                result = (channels, news, total)
            elif self.op == "poll":
                result = storage.poll_bundle(
                    int(p.get("after_id", 0)), bool(p.get("load_new", True)), int(p.get("batch_size", 500))
                )
            elif self.op == "ai_news":
                result = storage.news_for_ai(
                    list(p.get("channels") or []), float(p.get("since_ts", 0)),
                    float(p.get("until_ts", time.time())), int(p.get("limit", 500))
                )
            elif self.op == "test":
                result = storage.test_connection()
            elif self.op == "channel_names":
                result = storage.get_all_channel_names()
            elif self.op == "mark_all_read":
                storage.mark_all_read()
                result = True
            else:
                raise ValueError(f"Unknown op: {self.op}")
            self.finished_ok.emit(self.op, result)
        except Exception as e:
            self.failed.emit(self.op, str(e))


# ---------------------------------------------------------------------------
# Глобальный трекер живых QThread
# ---------------------------------------------------------------------------
_LIVE_THREADS: list = []


def _track_thread(task) -> None:
    _LIVE_THREADS.append(task)

    def _drop(*_args):
        try:
            _LIVE_THREADS.remove(task)
        except ValueError:
            pass
        try:
            task.deleteLater()
        except RuntimeError:
            pass

    task.finished.connect(_drop)


# ---------------------------------------------------------------------------
# Models / delegates
# ---------------------------------------------------------------------------


class ChannelListModel(QAbstractListModel):
    def __init__(self):
        super().__init__()
        self._all_channels: List[Channel] = []
        self._channels: List[Channel] = []
        self._selected = -1
        self._filter = ""

    def rowCount(self, parent=QModelIndex()):
        return len(self._channels)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self._channels)):
            return None
        ch = self._channels[index.row()]
        if role == Qt.DisplayRole:
            return ch.name
        if role == Qt.UserRole:
            return ch
        if role == Qt.UserRole + 1:
            return index.row() == self._selected
        return None

    def setChannels(self, channels: List[Channel]):
        prev_name = (
            self._channels[self._selected].name
            if 0 <= self._selected < len(self._channels) else None
        )
        self.beginResetModel()
        self._all_channels = list(channels)
        self._apply_filter_locked()
        self._selected = next(
            (i for i, c in enumerate(self._channels) if prev_name and c.name == prev_name), -1
        )
        self.endResetModel()

    def setFilter(self, text: str):
        text = (text or "").strip().lower()
        if text == self._filter:
            return
        prev_name = (
            self._channels[self._selected].name
            if 0 <= self._selected < len(self._channels) else None
        )
        self.beginResetModel()
        self._filter = text
        self._apply_filter_locked()
        self._selected = next(
            (i for i, c in enumerate(self._channels) if prev_name and c.name == prev_name), -1
        )
        self.endResetModel()

    def _apply_filter_locked(self):
        if not self._filter:
            self._channels = list(self._all_channels)
        else:
            f = self._filter
            self._channels = [c for c in self._all_channels if f in c.name.lower()]

    def setSelected(self, row: int):
        old = self._selected
        self._selected = row
        if 0 <= old < len(self._channels):
            self.dataChanged.emit(self.index(old), self.index(old), [Qt.UserRole + 1])
        if 0 <= row < len(self._channels):
            self.dataChanged.emit(self.index(row), self.index(row), [Qt.UserRole + 1])

    def selectByName(self, name: str):
        idx = next((i for i, c in enumerate(self._channels) if c.name == name), -1)
        self.setSelected(idx)


class NewsListModel(QAbstractListModel):
    def __init__(self):
        super().__init__()
        self._news: List[News] = []
        self._total = 0

    def rowCount(self, parent=QModelIndex()):
        return len(self._news)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self._news)):
            return None
        n = self._news[index.row()]
        if role == Qt.DisplayRole:
            return n.title or n.text
        if role == Qt.UserRole:
            return n
        return None

    def reset_page(self, news: List[News], total: int):
        self.beginResetModel()
        self._news = news
        self._total = total
        self.endResetModel()

    def append_page(self, more: List[News]) -> bool:
        if not more:
            return False
        s = len(self._news)
        self.beginInsertRows(QModelIndex(), s, s + len(more) - 1)
        self._news.extend(more)
        self.endInsertRows()
        return len(self._news) < self._total

    def hasMore(self) -> bool:
        return len(self._news) < self._total

    def clear(self):
        self.beginResetModel()
        self._news = []
        self._total = 0
        self.endResetModel()


class AnimatedListView(QListView):
    """QListView с плавным наведением и поочерёдным появлением первых карточек."""

    HOVER_STEP = 0.14
    REVEAL_ROWS = 8
    REVEAL_DELAY = 0.04
    REVEAL_DURATION = 0.30

    def __init__(self, parent=None):
        super().__init__(parent)
        self._hover_row = -1
        self._hover_prog: Dict[int, float] = {}
        self._reveal_t0 = 0.0
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(20)
        self._anim_timer.timeout.connect(self._tick)
        self.setMouseTracking(True)
        self.viewport().setAttribute(Qt.WA_Hover, True)
        self.viewport().installEventFilter(self)
        self.verticalScrollBar().valueChanged.connect(self._refresh_hover)

    def eventFilter(self, obj, ev):
        if obj is self.viewport() and ev.type() == QEvent.Leave:
            self._set_hover(-1)
        return super().eventFilter(obj, ev)

    def setModel(self, model):
        super().setModel(model)
        if model is not None:
            model.modelReset.connect(self._on_model_reset)

    def hover_progress(self, row: int) -> float:
        return self._hover_prog.get(row, 0.0)

    def reveal_progress(self, row: int) -> float:
        if not self._reveal_t0 or row >= self.REVEAL_ROWS:
            return 1.0
        t = (time.monotonic() - self._reveal_t0 - row * self.REVEAL_DELAY) / self.REVEAL_DURATION
        t = max(0.0, min(1.0, t))
        return 1.0 - (1.0 - t) ** 3

    def start_reveal(self):
        self._reveal_t0 = time.monotonic()
        self._start_timer()
        self.viewport().update()

    def mouseMoveEvent(self, e):
        super().mouseMoveEvent(e)
        self._set_hover(self.indexAt(e.pos()).row())

    def leaveEvent(self, e):
        self._set_hover(-1)
        super().leaveEvent(e)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._refresh_hover()

    def _on_model_reset(self):
        self._hover_prog.clear()
        self._hover_row = -1
        QTimer.singleShot(0, self._refresh_hover)

    def _refresh_hover(self, *_):
        try:
            if not self.viewport().underMouse():
                return
            pos = self.viewport().mapFromGlobal(QCursor.pos())
            self._set_hover(self.indexAt(pos).row())
        except RuntimeError:
            pass

    def _set_hover(self, row: int):
        if row == self._hover_row:
            return
        self._hover_row = row
        if row >= 0:
            self._hover_prog.setdefault(row, 0.0)
        self._start_timer()

    def _start_timer(self):
        if not self._anim_timer.isActive():
            self._anim_timer.start()

    def _tick(self):
        busy = False
        changed = False
        for r in list(self._hover_prog.keys()):
            v = self._hover_prog[r]
            target = 1.0 if r == self._hover_row else 0.0
            if v != target:
                nv = v + max(-self.HOVER_STEP, min(self.HOVER_STEP, target - v))
                if abs(nv - target) < 0.001:
                    nv = target
                self._hover_prog[r] = nv
                changed = True
                if nv != target:
                    busy = True
                v = nv
            if v == 0.0 and target == 0.0:
                del self._hover_prog[r]
        if self._reveal_t0:
            total = self.REVEAL_ROWS * self.REVEAL_DELAY + self.REVEAL_DURATION
            if time.monotonic() - self._reveal_t0 >= total:
                self._reveal_t0 = 0.0
            else:
                busy = True
            changed = True
        if changed:
            self.viewport().update()
        if not busy:
            self._anim_timer.stop()


class ChannelDelegate(QStyledItemDelegate):
    hover_progress = None

    def paint(self, painter, option, index):
        channel = index.data(Qt.UserRole)
        if not channel:
            return
        selected = index.data(Qt.UserRole + 1)
        if callable(self.hover_progress):
            hp = self.hover_progress(index.row())
        else:
            hp = 1.0 if (option.state & QStyle.State_MouseOver) else 0.0
        unread = channel.unread_count
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)
        rect = option.rect.adjusted(4, 4, -4, -4)
        if selected:
            bg = QColor(Theme.CARD_ACTIVE)
        else:
            base = Theme.CARD_UNREAD if unread > 0 else Theme.CARD
            bg = mix_color(base, Theme.CARD_HOVER, hp)
        draw_card_shadow(painter, rect, CARD_RADIUS, 1.0 + 0.5 * hp)
        painter.setBrush(bg)
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(rect, CARD_RADIUS, CARD_RADIUS)

        if Theme.name == "dark":
            hl = QLinearGradient(rect.left(), rect.top(), rect.left(), rect.top() + 16)
            hl.setColorAt(0, QColor(255, 255, 255, 14))
            hl.setColorAt(1, QColor(255, 255, 255, 0))
        else:
            hl = QLinearGradient(rect.left(), rect.top(), rect.left(), rect.top() + 12)
            hl.setColorAt(0, QColor(0, 0, 0, 10))
            hl.setColorAt(1, QColor(0, 0, 0, 0))
        painter.setBrush(QBrush(hl))
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(rect, CARD_RADIUS, CARD_RADIUS)

        draw_hover_glow(painter, rect, CARD_RADIUS, 140 if selected else int(140 * hp))
        painter.restore()

        av = QRect(rect.left() + 56, rect.top() + (rect.height() - 42) // 2, 42, 42)
        draw_avatar(painter, av, channel.name)
        painter.setFont(font_s(10))
        painter.setPen(QColor(Theme.TEXT if channel.notify_enabled else Theme.SUBTEXT))
        painter.drawText(QRect(rect.left() + 14, rect.top() + 16, 24, 24), Qt.AlignCenter,
                         "🔔" if channel.notify_enabled else "🔕")
        painter.setPen(QColor(Theme.TEXT if channel.sound_enabled else Theme.SUBTEXT))
        painter.drawText(QRect(rect.left() + 14, rect.bottom() - 36, 24, 24), Qt.AlignCenter,
                         "🔊" if channel.sound_enabled else "🔇")

        time_r = QRect(rect.right() - 70, rect.top() + 8, 60, 16)
        name_r = QRect(av.right() + 12, rect.top() + 8, time_r.left() - av.right() - 20, 20)
        painter.setPen(QColor(Theme.TEXT))
        painter.setFont(font_s(FONT_SIZE_CHANNEL, True))
        painter.drawText(name_r, Qt.AlignLeft | Qt.AlignVCenter,
                         painter.fontMetrics().elidedText(channel.name, Qt.ElideRight, name_r.width()))
        painter.setPen(QColor(Theme.SUBTEXT))
        painter.setFont(font_s(FONT_SIZE_SMALL))
        prev = QRect(name_r.left(), name_r.bottom() + 4, rect.right() - name_r.left() - 12, 50)
        fm = painter.fontMetrics()
        lines = [fm.elidedText(l, Qt.ElideRight, prev.width()) for l in (channel.last_news or "").split("\n")]
        max_l = max(1, prev.height() // fm.height())
        if len(lines) > max_l:
            lines = lines[: max_l - 1]
            if lines:
                lines[-1] = fm.elidedText(lines[-1], Qt.ElideRight, prev.width() - fm.width("…")) + "…"
        painter.drawText(prev, Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap, "\n".join(lines))
        painter.setFont(font_s(8))
        painter.drawText(time_r, Qt.AlignRight | Qt.AlignVCenter, human_time(channel.last_date))
        if unread > 0:
            accent = QLinearGradient(rect.left(), rect.top() + 15, rect.left(), rect.bottom() - 15)
            accent.setColorAt(0, QColor(Theme.BLUE_LIGHT))
            accent.setColorAt(1, QColor(Theme.BLUE_DARK))
            painter.setBrush(QBrush(accent))
            painter.setPen(Qt.NoPen)
            painter.drawRoundedRect(QRect(rect.left() + 4, rect.top() + 15, 4, rect.height() - 30), 2, 2)
            b = QRect(rect.right() - 24, rect.bottom() - 24, 20, 20)
            badge = QRadialGradient(QPointF(b.center()), b.width() / 2)
            badge.setColorAt(0, QColor(Theme.BLUE_LIGHT))
            badge.setColorAt(1, QColor(Theme.BLUE_DARK))
            painter.setBrush(QBrush(badge))
            painter.drawEllipse(b)
            painter.setPen(Qt.white)
            painter.setFont(font_s(9, True))
            painter.drawText(b, Qt.AlignCenter, str(unread))

    def sizeHint(self, option, index):
        return QSize(SIDEBAR_WIDTH - 28, CHANNEL_HEIGHT)


class NewsDelegate(QStyledItemDelegate):
    def __init__(self, font_size=14):
        super().__init__()
        self.font_size = font_size
        self._cache: Dict[str, int] = {}
        self.favorite_checksums: set = set()
        self.hover_progress = None
        self.reveal_progress = None
        self.star_pulse: Dict[str, float] = {}

    def set_favorites(self, checksums: set):
        self.favorite_checksums = checksums or set()

    def star_rect_for(self, item_rect: QRect) -> QRect:
        rect = item_rect.adjusted(6, 6, -6, -6)
        return QRect(rect.right() - 34, rect.top() + 8, 26, 26)

    def star_hit_rect_for(self, item_rect: QRect) -> QRect:
        return self.star_rect_for(item_rect).adjusted(-6, -6, 6, 6)

    def paint(self, painter, option, index):
        news = index.data(Qt.UserRole)
        if not news:
            return
        row = index.row()
        if callable(self.hover_progress):
            hp = self.hover_progress(row)
        else:
            hp = 1.0 if (option.state & QStyle.State_MouseOver) else 0.0
        rv = self.reveal_progress(row) if callable(self.reveal_progress) else 1.0

        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.TextAntialiasing, True)
        if rv < 1.0:
            painter.setOpacity(max(0.0, rv))
            painter.translate(0, (1.0 - rv) * 12)
        painter.translate(0, -1.0 * hp)

        rect = option.rect.adjusted(6, 6, -6, -6)
        g = QLinearGradient(rect.topLeft(), rect.bottomRight())
        g.setColorAt(0, mix_color(Theme.NEWS_CARD_GRAD_TOP, Theme.NEWS_CARD_HOVER, hp))
        g.setColorAt(1, mix_color(Theme.NEWS_CARD_GRAD_BOTTOM, Theme.NEWS_CARD, hp))
        draw_card_shadow(painter, rect, CARD_RADIUS, 1.0 + 0.7 * hp)
        painter.setBrush(QBrush(g))
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(rect, CARD_RADIUS, CARD_RADIUS)
        edge = QColor(255, 255, 255, 16) if Theme.name == "dark" else QColor(255, 255, 255, 200)
        painter.setBrush(Qt.NoBrush)
        painter.setPen(QPen(edge, 1))
        painter.drawRoundedRect(rect.adjusted(0, 0, -1, -1), CARD_RADIUS, CARD_RADIUS)
        draw_hover_glow(painter, rect, CARD_RADIUS, int(140 * hp))

        top = QRect(rect.left() + 16, rect.top() + 12, rect.width() - 32, 34)
        av = QRect(top.left(), top.top(), 34, 34)
        draw_avatar(painter, av, news.channel)
        painter.setPen(QColor(Theme.TEXT))
        painter.setFont(font_s(FONT_SIZE_CHANNEL, True))
        painter.drawText(QRect(av.right() + 10, top.top() + 8, 160, 20), Qt.AlignLeft | Qt.AlignVCenter, news.channel)
        painter.setPen(QColor(Theme.SUBTEXT))
        painter.setFont(font_s(FONT_SIZE_SMALL))
        painter.drawText(QRect(top.right() - 132, top.top() + 8, 90, 20), Qt.AlignRight | Qt.AlignVCenter, human_time(news.date))

        cs = news.checksum or news.cs()
        is_fav = bool(cs) and cs in self.favorite_checksums
        self._draw_star(painter, self.star_rect_for(option.rect), is_fav, hp, self.star_pulse.get(cs))

        if news.title:
            tr = QRect(rect.left() + 16, top.bottom() + 18, rect.width() - 32, 30)
            painter.setPen(QColor(Theme.TEXT))
            painter.setFont(font_s(self.font_size + 2, True))
            painter.drawText(tr, Qt.AlignLeft | Qt.AlignTop,
                             painter.fontMetrics().elidedText(news.title, Qt.ElideRight, tr.width()))
            body_top = tr.bottom() + 26
        else:
            body_top = top.bottom() + 8
        date_y = rect.bottom() - 10 - 18
        preview, truncated = preview_text(news.text)
        hint_h = 20 if truncated else 0
        body = QRect(rect.left() + 16, body_top, rect.width() - 32, max(0, date_y - 2 - hint_h - body_top))
        painter.setPen(QColor(Theme.TEXT))
        painter.setFont(font_s(self.font_size))
        painter.drawText(body, Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap, preview)
        if truncated:
            hint_r = QRect(rect.left() + 16, body.bottom() + 2, rect.width() - 32, hint_h)
            painter.setPen(mix_color(Theme.BLUE, Theme.BLUE_LIGHT, hp))
            painter.setFont(font_s(FONT_SIZE_SMALL, True))
            painter.drawText(hint_r.translated(int(3 * hp), 0), Qt.AlignLeft | Qt.AlignVCenter, "Показать полностью →")
        painter.setPen(QColor(Theme.SUBTEXT))
        painter.setFont(font_s(FONT_SIZE_SMALL - 1))
        meta = f"{news.date} · ~{reading_minutes(news.text)} мин чтения"
        painter.drawText(QRect(rect.left() + 16, date_y, rect.width() - 32, 18), Qt.AlignLeft | Qt.AlignVCenter, meta)
        painter.restore()

    def _draw_star(self, painter, star_rect: QRect, is_fav: bool, hp: float, pulse: Optional[float]):
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)
        c = QPointF(star_rect.center())
        painter.translate(c)
        if pulse is not None:
            k = 1.0 + 0.35 * math.sin(math.pi * pulse)
            painter.scale(k, k)
            if is_fav:
                painter.rotate(18.0 * math.sin(2.0 * math.pi * pulse) * (1.0 - pulse))
            if is_fav:
                r, g, b = hex_to_rgb(Theme.STAR)
                halo = QRadialGradient(QPointF(0, 0), star_rect.width() * 0.9)
                halo.setColorAt(0, QColor(r, g, b, int(90 * (1.0 - pulse))))
                halo.setColorAt(1, QColor(r, g, b, 0))
                painter.setPen(Qt.NoPen)
                painter.setBrush(QBrush(halo))
                painter.drawEllipse(QPointF(0, 0), star_rect.width() * 0.9, star_rect.width() * 0.9)
        painter.translate(-c)
        painter.setFont(font_s(15))
        painter.setPen(QColor(Theme.STAR) if is_fav else mix_color(Theme.SUBTEXT, Theme.TEXT, hp * 0.8))
        painter.drawText(star_rect, Qt.AlignCenter, "★" if is_fav else "☆")
        painter.restore()

    def sizeHint(self, option, index):
        news = index.data(Qt.UserRole)
        if not news:
            return QSize(option.rect.width(), 120)
        w = max(100, option.rect.width())
        if not news.checksum:
            news.checksum = news.cs()
        key = f"{news.checksum}:{w}:{self.font_size}"
        if key in self._cache:
            return QSize(w, self._cache[key])
        preview, truncated = preview_text(news.text)
        fm = QFontMetrics(font_s(self.font_size))
        bh = fm.boundingRect(QRect(0, 0, w - 32, 10000), Qt.TextWordWrap | Qt.AlignLeft, preview).height()
        th = 0
        if news.title:
            th = QFontMetrics(font_s(self.font_size + 2, True)).boundingRect(
                QRect(0, 0, w - 32, 100), Qt.TextWrapAnywhere | Qt.AlignLeft, news.title
            ).height()
        hint_h = 20 if truncated else 0
        h = max(100, 12 + 34 + 18 + th + (26 if news.title else 0) + bh + hint_h + 28 + 20 + 10 + 8)
        self._cache[key] = h
        if len(self._cache) > 600:
            self._cache.clear()
        return QSize(w, h)

    def clear_cache(self):
        self._cache.clear()


# ---------------------------------------------------------------------------
# UI pieces
# ---------------------------------------------------------------------------


class FavoritesRow(QWidget):
    """Закреплённая строка «⭐ Избранное» над списком каналов."""

    clicked = pyqtSignal()
    menuRequested = pyqtSignal(QPoint)

    def __init__(self):
        super().__init__()
        self.setFixedHeight(64)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)
        self._hover = False
        self._hp = 0.0
        self._bump = -1.0
        self._selected = False
        self._count = 0
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.menuRequested)
        self._hover_anim = QVariantAnimation(self)
        self._hover_anim.setDuration(170)
        self._hover_anim.setEasingCurve(QEasingCurve.OutCubic)
        self._hover_anim.valueChanged.connect(self._on_hover_value)
        self._bump_anim = QVariantAnimation(self)
        self._bump_anim.setDuration(420)
        self._bump_anim.setStartValue(0.0)
        self._bump_anim.setEndValue(1.0)
        self._bump_anim.setEasingCurve(QEasingCurve.OutCubic)
        self._bump_anim.valueChanged.connect(self._on_bump_value)
        self._bump_anim.finished.connect(self._on_bump_done)

    def _on_hover_value(self, v):
        self._hp = float(v)
        self.update()

    def _on_bump_value(self, v):
        self._bump = float(v)
        self.update()

    def _on_bump_done(self):
        self._bump = -1.0
        self.update()

    def _animate_hover(self, target: float):
        self._hover_anim.stop()
        self._hover_anim.setStartValue(self._hp)
        self._hover_anim.setEndValue(target)
        self._hover_anim.start()

    def set_count(self, n: int):
        changed = (n != self._count)
        self._count = n
        if changed:
            self._bump_anim.stop()
            self._bump_anim.start()
        self.update()

    def set_selected(self, sel: bool):
        if self._selected != sel:
            self._selected = sel
            self.update()

    def enterEvent(self, e):
        self._hover = True
        self._animate_hover(1.0)

    def leaveEvent(self, e):
        self._hover = False
        self._animate_hover(0.0)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.clicked.emit()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        rect = self.rect().adjusted(4, 4, -4, -4)
        if self._selected:
            bg = QColor(Theme.CARD_ACTIVE)
        else:
            bg = mix_color(Theme.CARD, Theme.CARD_HOVER, self._hp)
        draw_card_shadow(p, rect, CARD_RADIUS, 1.0 + 0.5 * self._hp)
        p.setBrush(bg)
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(rect, CARD_RADIUS, CARD_RADIUS)
        draw_hover_glow(p, rect, CARD_RADIUS, 140 if self._selected else int(140 * self._hp))

        star_rect = QRect(rect.left() + 8, rect.top() + (rect.height() - 34) // 2, 34, 34)
        p.save()
        if self._bump >= 0.0:
            k = 1.0 + 0.22 * math.sin(math.pi * self._bump)
            c = QPointF(star_rect.center())
            p.translate(c)
            p.scale(k, k)
            p.translate(-c)
        grad = QRadialGradient(QPointF(star_rect.center()), star_rect.width() / 2)
        grad.setColorAt(0, QColor(Theme.STAR).lighter(112))
        grad.setColorAt(1, QColor(Theme.STAR).darker(135))
        p.setBrush(QBrush(grad))
        p.setPen(Qt.NoPen)
        p.drawEllipse(star_rect)
        p.setPen(Qt.white)
        p.setFont(font_s(15, True))
        p.drawText(star_rect, Qt.AlignCenter, "★")
        p.restore()

        text_rect = QRect(star_rect.right() + 10, rect.top() + 10, rect.width() - star_rect.width() - 30, 20)
        p.setPen(QColor(Theme.TEXT))
        p.setFont(font_s(FONT_SIZE_CHANNEL, True))
        p.drawText(text_rect, Qt.AlignLeft | Qt.AlignVCenter, "Избранное")

        sub_rect = QRect(text_rect.left(), text_rect.bottom() + 2, text_rect.width(), 18)
        p.setPen(QColor(Theme.SUBTEXT))
        p.setFont(font_s(FONT_SIZE_SMALL))
        sub_text = f"{self._count} сохранено" if self._count else "Пока пусто"
        p.drawText(sub_rect, Qt.AlignLeft | Qt.AlignVCenter, sub_text)
        p.end()


class Sidebar(QFrame):
    channelSelected = pyqtSignal(object)
    settingsChanged = pyqtSignal()
    favoritesSelected = pyqtSignal()
    favoritesClearRequested = pyqtSignal()

    def __init__(self, storage: NewsStorage):
        super().__init__()
        self.storage = storage
        self.setFixedWidth(SIDEBAR_WIDTH)
        self.setObjectName("sidebarFrame")
        self._style()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 16, 14, 14)
        self.title = QLabel("КАНАЛЫ")
        self.title.setFont(font_s(12, True))
        self.title.setStyleSheet(f"color: {Theme.BLUE}; background: transparent;")
        lay.addWidget(self.title)

        self.fav_row = FavoritesRow()
        self.fav_row.clicked.connect(self._fav_clicked)
        self.fav_row.menuRequested.connect(self._fav_menu)
        lay.addWidget(self.fav_row)

        self.channel_search = QLineEdit()
        self.channel_search.setPlaceholderText("🔍  Поиск каналов")
        self.channel_search.setClearButtonEnabled(True)
        self.channel_search.setFixedHeight(36)
        self._channel_search_style()
        lay.addWidget(self.channel_search)

        self.list = AnimatedListView()
        self.list.setFrameShape(QFrame.NoFrame)
        self.list.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.list.setMouseTracking(True)
        self.list.viewport().setAttribute(Qt.WA_Hover, True)
        self.list.setSelectionMode(QAbstractItemView.NoSelection)
        self.list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._menu)
        self._list_style()
        self.model = ChannelListModel()
        self.list.setModel(self.model)
        self.channel_delegate = ChannelDelegate()
        self.channel_delegate.hover_progress = self.list.hover_progress
        self.list.setItemDelegate(self.channel_delegate)
        self.list.clicked.connect(self._click)
        lay.addWidget(self.list)

        self.channel_search.textChanged.connect(self.model.setFilter)

    def _fav_clicked(self):
        self.model.setSelected(-1)
        self.fav_row.set_selected(True)
        self.favoritesSelected.emit()

    def _fav_menu(self, pos):
        menu = QMenu()
        menu.setStyleSheet(
            f"QMenu {{ background: {Theme.CARD}; color: {Theme.TEXT}; border: 1px solid {Theme.BORDER}; "
            f"border-radius: 10px; padding: 6px; }} QMenu::item:selected {{ background: {Theme.CARD_ACTIVE}; }}"
        )
        a = QAction("Очистить избранное", self)
        a.triggered.connect(self.favoritesClearRequested.emit)
        menu.addAction(a)
        menu.exec_(self.fav_row.mapToGlobal(pos))

    def set_favorites_count(self, n: int):
        self.fav_row.set_count(n)

    def set_favorites_active(self, active: bool):
        self.fav_row.set_selected(active)
        if active:
            self.model.setSelected(-1)

    def _style(self):
        self.setStyleSheet(f"""
            QFrame#sidebarFrame {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
                stop:0 {Theme.SIDEBAR}, stop:1 {Theme.WINDOW});
                border: none; border-right: 1px solid {Theme.BORDER}; border-radius: 16px; }}
        """)

    def _list_style(self):
        self.list.setStyleSheet(f"""
            QListView {{ background: transparent; border: none; }}
            QScrollBar:vertical {{ width: 12px; background: transparent; margin: 2px; }}
            QScrollBar::handle:vertical {{
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 {Theme.SCROLL_HANDLE}, stop:1 {Theme.SCROLL_HANDLE_HOVER});
                border-radius: 6px; min-height: 30px;
            }}
            QScrollBar::handle:vertical:hover {{ background: {Theme.SCROLL_HANDLE_HOVER}; }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
        """)

    def _channel_search_style(self):
        if Theme.name == "dark":
            bg, bd = "rgba(255, 255, 255, 0.08)", "rgba(255, 255, 255, 0.14)"
            focus_bd = "rgba(255, 255, 255, 0.34)"
        else:
            bg, bd = "rgba(0, 0, 0, 0.04)", "rgba(0, 0, 0, 0.08)"
            focus_bd = Theme.BLUE
        self.channel_search.setStyleSheet(f"""
            QLineEdit {{
                background: {bg};
                color: {Theme.TEXT};
                border: 1px solid {bd};
                border-radius: 12px;
                padding: 0 12px;
            }}
            QLineEdit:focus {{ border: 1px solid {focus_bd}; }}
        """)

    def apply_theme(self):
        self._style()
        self._list_style()
        self._channel_search_style()
        self.title.setStyleSheet(f"color: {Theme.BLUE}; background: transparent;")
        self.list.viewport().update()
        self.fav_row.update()

    def setChannels(self, channels):
        self.model.setChannels(channels)

    def selectNoChannel(self):
        self.model.setSelected(-1)
        self.fav_row.set_selected(False)

    def select_channel_by_name(self, name: str):
        self.model.selectByName(name)

    def _click(self, index):
        ch = index.data(Qt.UserRole)
        if ch:
            self.fav_row.set_selected(False)
            self.model.setSelected(index.row())
            self.channelSelected.emit(ch)

    def _menu(self, pos):
        index = self.list.indexAt(pos)
        if not index.isValid():
            return
        ch = index.data(Qt.UserRole)
        if not ch:
            return
        menu = QMenu()
        menu.setStyleSheet(
            f"QMenu {{ background: {Theme.CARD}; color: {Theme.TEXT}; border: 1px solid {Theme.BORDER}; "
            f"border-radius: 10px; padding: 6px; }} QMenu::item:selected {{ background: {Theme.CARD_ACTIVE}; }}"
        )
        for label, field, val in (
            ("Показывать", "show", self.storage.settings.is_show(ch.name)),
            ("Трей уведомление", "notify", ch.notify_enabled),
            ("Звук", "sound", ch.sound_enabled),
        ):
            a = QAction(label, self)
            a.setCheckable(True)
            a.setChecked(val)
            a.triggered.connect(lambda c, ch=ch, f=field: self._tog(ch, f, c))
            menu.addAction(a)
        menu.exec_(self.list.viewport().mapToGlobal(pos))

    def _tog(self, ch, field, checked):
        s = self.storage.settings
        show, notify, sound = s.is_show(ch.name), s.is_notify(ch.name), s.is_sound(ch.name)
        if field == "show":
            show = checked
            if not show:
                notify = False
        elif field == "notify":
            notify = checked
        else:
            sound = checked
        s.set_channel(ch.name, show, notify, sound)
        s.save()
        self.settingsChanged.emit()


class NewsListView(AnimatedListView):
    """Список новостей. Клик по звезде «в избранное» перехватывается до QListView."""

    starToggled = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._star_press: Optional[QPersistentModelIndex] = None
        self.star_pulse: Dict[str, float] = {}
        self._pulse_anims: Dict[str, QVariantAnimation] = {}

    def _star_index_at(self, pos) -> Optional[QModelIndex]:
        index = self.indexAt(pos)
        if not index.isValid():
            return None
        delegate = self.itemDelegate(index)
        hit_rect = getattr(delegate, "star_hit_rect_for", None)
        if hit_rect is None:
            return None
        if hit_rect(self.visualRect(index)).contains(pos):
            return index
        return None

    def _begin_star_press(self, e) -> bool:
        if e.button() != Qt.LeftButton:
            return False
        index = self._star_index_at(e.pos())
        if index is None:
            self._star_press = None
            return False
        self._star_press = QPersistentModelIndex(index)
        e.accept()
        return True

    def mousePressEvent(self, e):
        if not self._begin_star_press(e):
            super().mousePressEvent(e)

    def mouseDoubleClickEvent(self, e):
        if not self._begin_star_press(e):
            super().mouseDoubleClickEvent(e)

    def mouseReleaseEvent(self, e):
        pressed, self._star_press = self._star_press, None
        over = self._star_index_at(e.pos())
        if e.button() == Qt.LeftButton and (pressed is not None or over is not None):
            if (pressed is not None and pressed.isValid() and over is not None
                    and over.row() == pressed.row()):
                news = over.data(Qt.UserRole)
                if news:
                    self.starToggled.emit(news)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def pulse_star(self, checksum: str):
        if not checksum:
            return
        old = self._pulse_anims.pop(checksum, None)
        if old is not None:
            old.stop()
            old.deleteLater()
        anim = QVariantAnimation(self)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setDuration(520)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.valueChanged.connect(lambda v, cs=checksum: self._on_pulse(cs, float(v)))
        anim.finished.connect(lambda cs=checksum, a=anim: self._pulse_done(cs, a))
        self._pulse_anims[checksum] = anim
        self.star_pulse[checksum] = 0.0
        anim.start()

    def _on_pulse(self, checksum: str, value: float):
        if checksum in self._pulse_anims:
            self.star_pulse[checksum] = value
            self.viewport().update()

    def _pulse_done(self, checksum: str, anim):
        if self._pulse_anims.get(checksum) is anim:
            del self._pulse_anims[checksum]
            self.star_pulse.pop(checksum, None)
            self.viewport().update()
        anim.deleteLater()


class MainContent(QWidget):
    refreshRequested = pyqtSignal()
    searchRequested = pyqtSignal(str)
    settingsRequested = pyqtSignal()
    soundToggleRequested = pyqtSignal()
    themeToggleRequested = pyqtSignal()
    loadMoreRequested = pyqtSignal()
    aiRequested = pyqtSignal()
    markAllReadRequested = pyqtSignal()
    newsActivated = pyqtSignal(object)
    favoriteToggled = pyqtSignal(object)

    def __init__(self, font_size=14, sound_enabled=True):
        super().__init__()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)

        # Верхняя панель: имя канала + счётчик + поиск + стеклянная капсула с иконками.
        self.header = QFrame()
        self.header.setFixedHeight(64)
        hl = QHBoxLayout(self.header)
        hl.setContentsMargins(24, 12, 24, 12)

        self.channel_title = QLabel("Каналы")
        self.channel_title.setFont(font_s(FONT_SIZE_TITLE, True))
        self.channel_title.setStyleSheet(f"color: {Theme.TEXT}; background: transparent;")
        hl.addWidget(self.channel_title)

        self.count_label = QLabel("0")
        self.count_label.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")
        hl.addWidget(self.count_label)

        hl.addStretch()

        self.search = QLineEdit()
        self.search.setPlaceholderText("Поиск...")
        self.search.setFixedWidth(240)
        self.search.setMinimumHeight(36)
        self._search_style()
        self.search.textChanged.connect(self.searchRequested)
        hl.addWidget(self.search)

        self.header_bar = GlassBar()
        bar_lay = QHBoxLayout(self.header_bar)
        bar_lay.setContentsMargins(7, 7, 7, 7)
        bar_lay.setSpacing(4)

        self.ai_btn = self._icon_btn("ИИ")
        self.ai_btn.setToolTip("Режим ИИ")
        self.ai_btn.clicked.connect(self.aiRequested.emit)
        bar_lay.addWidget(self.ai_btn)

        self.refresh_btn = self._icon_btn("⟳")
        self.refresh_btn.setToolTip("Обновить")
        self.refresh_btn.clicked.connect(self.refreshRequested)
        bar_lay.addWidget(self.refresh_btn)

        self.mark_all_btn = self._icon_btn("✓✓")
        self.mark_all_btn.setToolTip("Отметить все новости прочитанными")
        self.mark_all_btn.setFont(font_s(10, True))
        self.mark_all_btn.clicked.connect(self.markAllReadRequested.emit)
        bar_lay.addWidget(self.mark_all_btn)

        self.sound_btn = self._icon_btn("")
        self.sound_btn.clicked.connect(self.soundToggleRequested.emit)
        bar_lay.addWidget(self.sound_btn)
        self.set_sound_icon(sound_enabled)

        self.theme_btn = self._icon_btn("☀" if Theme.name == "dark" else "🌙")
        self.theme_btn.clicked.connect(self.themeToggleRequested.emit)
        bar_lay.addWidget(self.theme_btn)

        self.settings_btn = self._icon_btn("⚙")
        self.settings_btn.clicked.connect(self.settingsRequested)
        bar_lay.addWidget(self.settings_btn)

        hl.addWidget(self.header_bar)
        lay.addWidget(self.header)

        # Список новостей.
        self.news_list = NewsListView()
        self.news_list.setFrameShape(QFrame.NoFrame)
        self.news_list.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.news_list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.news_list.setMouseTracking(True)
        self.news_list.viewport().setAttribute(Qt.WA_Hover, True)
        self.news_list.setSelectionMode(QAbstractItemView.NoSelection)
        self.news_list.setCursor(Qt.PointingHandCursor)
        self._list_style()
        self.news_model = NewsListModel()
        self.news_delegate = NewsDelegate(font_size)
        self.news_list.setModel(self.news_model)
        self.news_delegate.hover_progress = self.news_list.hover_progress
        self.news_delegate.reveal_progress = self.news_list.reveal_progress
        self.news_delegate.star_pulse = self.news_list.star_pulse
        self.news_list.setItemDelegate(self.news_delegate)
        self.news_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.news_list.customContextMenuRequested.connect(self._news_menu)
        self.news_list.clicked.connect(self._news_clicked)
        self.news_list.starToggled.connect(self.favoriteToggled.emit)
        self.news_list.verticalScrollBar().valueChanged.connect(self._scroll)
        lay.addWidget(self.news_list)

        self.placeholder = QLabel("Выберите канал или настройте подключение к SQL Server")
        self.placeholder.setAlignment(Qt.AlignCenter)
        self.placeholder.setFont(font_s(14, True))
        self.placeholder.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")
        self.placeholder.hide()
        lay.addWidget(self.placeholder)

        # Красим шапку в самом конце, когда дерево виджетов полностью собрано.
        # Иначе Qt успевает отрисовать QFrame с системным фоном до применения QSS.
        self._hdr()
        self._loading = False

    def _icon_btn(self, t):
        b = QPushButton(t)
        b.setFixedSize(40, 32)
        b.setCursor(Qt.PointingHandCursor)
        b.setFont(font_s(12 if t == "ИИ" else 14, t == "ИИ"))
        b.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self._icon_btn_style(b)
        return b

    def _icon_btn_style(self, b):
        b.setStyleSheet(glass_icon_btn_qss(radius=16))

    def _hdr(self):
        """
        Панель управления над лентой.

        Ключевые моменты:
        1) objectName + селектор `QFrame#newsHeader` — стилизуем только саму шапку.
        2) WA_StyledBackground=True обязателен: в этом режиме Qt реально рисует
           фон QFrame через QSS-правило `background`. Если выставить False, фон
           начинает браться из системной палитры и появляется серо-тёмная плашка
           под «Каналы N» слева от строки поиска.
        3) autoFillBackground(False) — чтобы палитра не подмешивалась поверх градиента.
        4) QLabel и QLineEdit внутри шапки — прозрачные, чтобы не наследовали фон окна.
        """
        self.header.setObjectName("newsHeader")
        self.header.setAttribute(Qt.WA_StyledBackground, True)
        self.header.setAutoFillBackground(False)

        top = Theme.BG_GRAD_TOP
        end = mix_color(Theme.BG_GRAD_TOP, Theme.BG_GRAD_BOTTOM, 0.25).name()
        self.header.setStyleSheet(f"""
            QFrame#newsHeader {{
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 {top}, stop:1 {end});
                border: none;
                border-bottom: 1px solid {Theme.BORDER};
            }}
            QFrame#newsHeader > QLabel {{ background: transparent; }}
            QFrame#newsHeader > QLineEdit {{ background: transparent; }}
        """)

    def _search_style(self):
        self.search.setStyleSheet(glass_field_qss(radius=18))

    def _list_style(self):
        self.news_list.setStyleSheet(f"""
            QListView {{ background: transparent; border: none; }}
            QScrollBar:vertical {{ width: 12px; background: transparent; margin: 2px; }}
            QScrollBar::handle:vertical {{
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 {Theme.SCROLL_HANDLE}, stop:1 {Theme.SCROLL_HANDLE_HOVER});
                border-radius: 6px; min-height: 40px;
            }}
            QScrollBar::handle:vertical:hover {{ background: {Theme.SCROLL_HANDLE_HOVER}; }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
        """)

    def apply_theme(self):
        self._hdr()
        self._search_style()
        self._list_style()
        self.channel_title.setStyleSheet(f"color: {Theme.TEXT}; background: transparent;")
        self.count_label.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")
        self.placeholder.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")
        for b in (self.ai_btn, self.refresh_btn, self.mark_all_btn, self.sound_btn, self.theme_btn, self.settings_btn):
            self._icon_btn_style(b)
        self.theme_btn.setFont(emoji_font(14))
        self.theme_btn.setText("☀" if Theme.name == "dark" else "🌙")
        self.ai_btn.setFont(font_s(12, True))
        self.mark_all_btn.setFont(font_s(10, True))
        self.header_bar.update()
        self.news_delegate.clear_cache()
        self.news_list.viewport().update()
        # Qt иногда не перерисовывает QFrame по objectName-селектору после смены темы —
        # сбрасываем стиль явно.
        try:
            self.header.style().unpolish(self.header)
            self.header.style().polish(self.header)
            self.header.update()
        except Exception:
            pass
        self.update()

    def _scroll(self, v):
        if self._loading:
            return
        bar = self.news_list.verticalScrollBar()
        if bar.maximum() > 0 and v >= bar.maximum() * 0.85 and self.news_model.hasMore():
            self._loading = True
            self.loadMoreRequested.emit()
            QTimer.singleShot(150, lambda: setattr(self, "_loading", False))

    def _news_menu(self, pos):
        idx = self.news_list.indexAt(pos)
        if not idx.isValid():
            return
        news = idx.data(Qt.UserRole)
        if not news:
            return
        m = QMenu()
        m.setStyleSheet(
            f"QMenu {{ background: {Theme.CARD}; color: {Theme.TEXT}; border: 1px solid {Theme.BORDER}; "
            f"border-radius: 10px; padding: 6px; }} QMenu::item:selected {{ background: {Theme.CARD_ACTIVE}; }}"
        )
        a = QAction("Скопировать", self)
        a.triggered.connect(lambda: QApplication.clipboard().setText(f"{news.channel}\n{news.title}\n{news.text}"))
        m.addAction(a)
        cs = news.checksum or news.cs()
        is_fav = cs in self.news_delegate.favorite_checksums
        fav_a = QAction("★ Убрать из избранного" if is_fav else "☆ В избранное", self)
        fav_a.triggered.connect(lambda: self.favoriteToggled.emit(news))
        m.addAction(fav_a)
        m.exec_(self.news_list.viewport().mapToGlobal(pos))

    def _news_clicked(self, index):
        news = index.data(Qt.UserRole)
        if news:
            self.newsActivated.emit(news)

    def set_favorites(self, checksums: set):
        checksums = set(checksums or ())
        changed = checksums ^ set(self.news_delegate.favorite_checksums or ())
        self.news_delegate.set_favorites(checksums)
        if 0 < len(changed) <= 3:
            for cs in changed:
                self.news_list.pulse_star(cs)
        self.news_list.viewport().update()

    def set_sound_icon(self, en):
        self.sound_btn.setFont(emoji_font(14))
        self.sound_btn.setText("🔊" if en else "🔇")

    def paintEvent(self, e):
        p = QPainter(self)
        g = QLinearGradient(0, 0, self.width(), self.height())
        g.setColorAt(0, QColor(Theme.BG_GRAD_TOP))
        g.setColorAt(1, QColor(Theme.BG_GRAD_BOTTOM))
        p.fillRect(self.rect(), g)

    def showNewsPage(self, news, total, scroll_top=True, reveal=None):
        if reveal is None:
            reveal = scroll_top
        self.news_list.show()
        self.placeholder.hide()
        self.news_delegate.clear_cache()
        self.news_model.reset_page(news, total)
        if scroll_top:
            QTimer.singleShot(0, self.news_list.scrollToTop)
        if reveal:
            self.news_list.start_reveal()

    def appendNewsPage(self, more):
        self.news_model.append_page(more)

    def showPlaceholder(self):
        self.news_list.hide()
        self.placeholder.show()
        self.news_model.clear()

    def setChannelInfo(self, name, count):
        self.channel_title.setText(name)
        self.count_label.setText(str(count))

    def set_font_size(self, size):
        self.news_delegate.font_size = size
        self.news_delegate.clear_cache()
        self.news_list.scheduleDelayedItemsLayout()


# ---------------------------------------------------------------------------
# Reader — полноэкранное чтение одной новости
# ---------------------------------------------------------------------------


class ReaderDialog(QDialog):
    favoriteToggled = pyqtSignal(object)

    def __init__(self, news: News, font_size: int, favorites: "FavoritesStore", parent=None):
        super().__init__(parent)
        self.news = news
        self.favorites = favorites
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setUpdatesEnabled(False)
        self.setWindowTitle(news.channel)
        self.resize(760, 660)
        self.setMinimumSize(480, 380)
        self.setStyleSheet(f"""
            QDialog {{ background: {Theme.WINDOW}; }}
            QLabel {{ color: {Theme.TEXT}; background: transparent; }}
            QTextBrowser {{ background: {Theme.CARD}; color: {Theme.TEXT};
                border: 1px solid {Theme.BORDER}; border-radius: {CARD_RADIUS}px; padding: 16px; }}
        """)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 20, 20, 20)
        lay.setSpacing(12)

        head = QHBoxLayout()
        head.setSpacing(12)
        av_label = QLabel()
        av_pix = QPixmap(44, 44)
        av_pix.fill(Qt.transparent)
        p = QPainter(av_pix)
        draw_avatar(p, QRect(0, 0, 44, 44), news.channel)
        p.end()
        av_label.setPixmap(av_pix)
        head.addWidget(av_label)

        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        ch_lab = QLabel(news.channel)
        ch_lab.setFont(font_s(FONT_SIZE_CHANNEL + 1, True))
        title_box.addWidget(ch_lab)
        meta_lab = QLabel(f"{news.date} · ~{reading_minutes(news.text)} мин чтения")
        meta_lab.setFont(font_s(FONT_SIZE_SMALL))
        meta_lab.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")
        title_box.addWidget(meta_lab)
        head.addLayout(title_box)
        head.addStretch()
        lay.addLayout(head)

        if news.title:
            t = QLabel(news.title)
            t.setWordWrap(True)
            t.setFont(font_s(font_size + 4, True))
            lay.addWidget(t)

        body = QTextBrowser()
        body.setOpenExternalLinks(True)
        body.setFont(font_s(font_size))
        body.setPlainText(news.text)
        lay.addWidget(body, 1)

        btns = QHBoxLayout()
        self.fav_btn = QPushButton()
        self.fav_btn.setCursor(Qt.PointingHandCursor)
        self._refresh_fav_btn()
        self.fav_btn.clicked.connect(self._on_fav_clicked)
        btns.addWidget(self.fav_btn)
        btns.addStretch()
        copy_b = QPushButton("Скопировать")
        copy_b.setCursor(Qt.PointingHandCursor)
        copy_b.setStyleSheet(secondary_btn_qss(radius=10, padding="8px 20px"))
        copy_b.clicked.connect(
            lambda: QApplication.clipboard().setText(f"{news.channel}\n{news.title}\n{news.text}")
        )
        close_b = QPushButton("Закрыть")
        close_b.setCursor(Qt.PointingHandCursor)
        close_b.setStyleSheet(primary_btn_qss(radius=10, padding="8px 20px"))
        close_b.clicked.connect(self.accept)
        btns.addWidget(copy_b)
        btns.addWidget(close_b)
        lay.addLayout(btns)

        try:
            self.style().unpolish(self)
            self.style().polish(self)
            self.ensurePolished()
        except Exception:
            pass
        self.setUpdatesEnabled(True)

    def showEvent(self, e):
        super().showEvent(e)
        if not getattr(self, "_shown_once", False):
            self._shown_once = True
            fade_in(self, 180)

    def _refresh_fav_btn(self):
        is_fav = self.favorites.contains(self.news.checksum or self.news.cs())
        self.fav_btn.setText("★ Убрать из избранного" if is_fav else "☆ В избранное")
        self.fav_btn.setStyleSheet(favorite_btn_qss(is_fav, radius=10, padding="8px 18px"))

    def _on_fav_clicked(self):
        self.favoriteToggled.emit(self.news)
        self._refresh_fav_btn()


# ---------------------------------------------------------------------------
# Settings dialog (connection + channels)
# ---------------------------------------------------------------------------


class SettingsDialog(QDialog):
    def __init__(self, channels: List[str], settings: Settings, storage: NewsStorage, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.storage = storage
        self._test_task: Optional[DbTask] = None
        self.setUpdatesEnabled(False)
        self.setWindowTitle("Настройки")
        self.setMinimumSize(640, 560)
        self.setStyleSheet(f"""
            QDialog {{ background: {Theme.WINDOW}; color: {Theme.TEXT}; }}
            QWidget {{ color: {Theme.TEXT}; background: transparent; }}
            QLabel {{ color: {Theme.TEXT}; background: transparent; }}
            QCheckBox {{ color: {Theme.TEXT}; background: transparent; spacing: 8px; }}
            QCheckBox::indicator {{
                width: 16px; height: 16px;
                border: 1px solid {Theme.BORDER};
                border-radius: 3px;
                background: {Theme.CARD};
            }}
            QCheckBox::indicator:checked {{
                background: {Theme.BLUE};
                border: 1px solid {Theme.BLUE};
            }}
            QRadioButton {{ color: {Theme.TEXT}; background: transparent; spacing: 8px; }}
            QGroupBox {{
                color: {Theme.TEXT}; background: transparent;
                border: 1px solid {Theme.BORDER}; border-radius: 8px;
                margin-top: 10px; padding-top: 6px;
            }}
            QGroupBox::title {{
                color: {Theme.TEXT}; background: {Theme.WINDOW};
                subcontrol-origin: margin; left: 10px; padding: 0 5px;
            }}
            QLineEdit, QSpinBox, QComboBox {{
                background: {Theme.CARD};
                color: {Theme.TEXT};
                border: 1px solid {Theme.BORDER};
                border-radius: 6px;
                padding: 6px;
                min-height: 22px;
            }}
            QLineEdit:disabled, QSpinBox:disabled, QComboBox:disabled {{
                color: {Theme.SUBTEXT};
                background: {Theme.WINDOW};
            }}
            QComboBox QAbstractItemView {{
                background: {Theme.CARD};
                color: {Theme.TEXT};
                selection-background-color: {Theme.CARD_ACTIVE};
                border: 1px solid {Theme.BORDER};
            }}
            QSpinBox::up-button, QSpinBox::down-button {{
                background: {Theme.CARD_HOVER};
                border: none;
                width: 18px;
            }}
            QTabWidget::pane {{
                border: 1px solid {Theme.BORDER};
                background: {Theme.WINDOW};
                top: -1px;
            }}
            QTabBar::tab {{
                background: {Theme.CARD};
                color: {Theme.TEXT};
                padding: 8px 16px;
                border: 1px solid {Theme.BORDER};
                border-bottom: none;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-right: 2px;
            }}
            QTabBar::tab:selected {{
                background: {Theme.CARD_ACTIVE};
                color: {Theme.TEXT};
            }}
            QTabBar::tab:!selected {{
                margin-top: 2px;
                color: {Theme.SUBTEXT};
            }}
            QTableWidget {{
                background: {Theme.CARD};
                color: {Theme.TEXT};
                border: 1px solid {Theme.BORDER};
                gridline-color: {Theme.BORDER};
                outline: none;
            }}
            QTableWidget::item {{ color: {Theme.TEXT}; padding: 4px; }}
            QHeaderView::section {{
                background: {Theme.CARD_HOVER};
                color: {Theme.SUBTEXT};
                border: none;
                border-bottom: 1px solid {Theme.BORDER};
                padding: 6px;
            }}
            QPushButton {{
                background: {Theme.CARD};
                color: {Theme.TEXT};
                border: 1px solid {Theme.BORDER};
                border-radius: 10px;
                padding: 8px 16px;
            }}
            QPushButton:hover {{ background: {Theme.CARD_HOVER}; }}
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)

        tabs = QTabWidget()
        layout.addWidget(tabs)

        # --- Connection tab ---
        conn_w = QWidget()
        cf = QFormLayout(conn_w)
        cf.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        cf.setSpacing(10)
        self.server_edit = QLineEdit(settings.mssql_server)
        self.db_edit = QLineEdit(settings.mssql_database)
        self.auth_combo = QComboBox()
        self.auth_combo.addItems(["Windows (домен / Trusted)", "SQL Server (логин/пароль)"])
        self.auth_combo.setCurrentIndex(0 if settings.mssql_auth == "windows" else 1)
        self.user_edit = QLineEdit(settings.mssql_user)
        self.pass_edit = QLineEdit(settings.mssql_password)
        self.pass_edit.setEchoMode(QLineEdit.Password)
        self.driver_edit = QLineEdit(settings.mssql_driver)
        self.userid_edit = QLineEdit(settings.user_id)
        self.auth_combo.currentIndexChanged.connect(self._auth_changed)

        def _form_label(text: str) -> QLabel:
            lab = QLabel(text)
            lab.setStyleSheet(f"color: {Theme.TEXT}; background: transparent;")
            return lab

        cf.addRow(_form_label("Сервер (IP\\имя):"), self.server_edit)
        cf.addRow(_form_label("База данных:"), self.db_edit)
        cf.addRow(_form_label("Аутентификация:"), self.auth_combo)
        cf.addRow(_form_label("SQL логин:"), self.user_edit)
        cf.addRow(_form_label("Пароль:"), self.pass_edit)
        cf.addRow(_form_label("ODBC Driver:"), self.driver_edit)
        cf.addRow(_form_label("Ваш user_id (прочитано):"), self.userid_edit)
        hint = QLabel(
            "Windows: Trusted_Connection, логин SQL не нужен.\n"
            "SQL: укажите UID/PWD.\n"
            "Driver: «SQL Server» или «SQL Server Native Client 10.0»."
        )
        hint.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")
        hint.setWordWrap(True)
        cf.addRow(hint)
        test_btn = QPushButton("Проверить подключение")
        test_btn.setStyleSheet(primary_btn_qss(radius=8, padding="8px 16px"))
        test_btn.clicked.connect(self._test)
        self.test_label = QLabel("")
        self.test_label.setWordWrap(True)
        self.test_label.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")
        cf.addRow(test_btn)
        cf.addRow(self.test_label)
        self._auth_changed(self.auth_combo.currentIndex())
        tabs.addTab(conn_w, "Подключение")

        # --- Channels tab ---
        ch_w = QWidget()
        chl = QVBoxLayout(ch_w)
        self.ch_search = QLineEdit()
        self.ch_search.setPlaceholderText("Поиск каналов...")
        self.ch_search.textChanged.connect(self._filter_ch)
        chl.addWidget(self.ch_search)
        self.table = QTableWidget(len(channels), 3)
        self.table.setHorizontalHeaderLabels(["Канал", "Показ", "Трей"])
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.cb_show, self.cb_notify = {}, {}
        for row, name in enumerate(channels):
            item = QTableWidgetItem(name)
            item.setForeground(QColor(Theme.TEXT))
            self.table.setItem(row, 0, item)
            for col, checked, store in (
                (1, settings.is_show(name), self.cb_show),
                (2, settings.is_notify(name), self.cb_notify),
            ):
                cb = QCheckBox()
                cb.setChecked(checked)
                w = QWidget()
                w.setStyleSheet("background: transparent;")
                l = QHBoxLayout(w)
                l.addWidget(cb)
                l.setAlignment(Qt.AlignCenter)
                l.setContentsMargins(0, 0, 0, 0)
                self.table.setCellWidget(row, col, w)
                store[name] = cb
            self.cb_notify[name].setEnabled(self.cb_show[name].isChecked())
            self.cb_show[name].toggled.connect(
                lambda checked, n=name: self._channel_show_toggled(n, checked)
            )
        chl.addWidget(self.table)
        tabs.addTab(ch_w, "Каналы")

        # --- General ---
        gen = QWidget()
        gl = QVBoxLayout(gen)
        gl.setSpacing(12)
        self.notify_cb = QCheckBox("Трей-уведомления")
        self.notify_cb.setChecked(settings.notifications_enabled)
        self.sound_cb = QCheckBox("Звук")
        self.sound_cb.setChecked(settings.sound_enabled)
        gl.addWidget(self.notify_cb)
        gl.addWidget(self.sound_cb)

        detail_box = QGroupBox("Вид всплывающего уведомления")
        detail_l = QVBoxLayout(detail_box)
        self.detail_full_rb = QRadioButton("Полное — текст новости, как сейчас")
        self.detail_minimal_rb = QRadioButton(
            "Минимальное — только «Уведомление Telegram», без текста"
        )
        self._detail_group = QButtonGroup(self)
        self._detail_group.addButton(self.detail_full_rb)
        self._detail_group.addButton(self.detail_minimal_rb)
        if settings.notification_detail == "minimal":
            self.detail_minimal_rb.setChecked(True)
        else:
            self.detail_full_rb.setChecked(True)
        detail_l.addWidget(self.detail_full_rb)
        detail_l.addWidget(self.detail_minimal_rb)
        gl.addWidget(detail_box)

        def _sync_detail_enabled(checked):
            detail_box.setEnabled(checked)

        _sync_detail_enabled(self.notify_cb.isChecked())
        self.notify_cb.toggled.connect(_sync_detail_enabled)

        row = QHBoxLayout()
        row.addWidget(_form_label("Тема"))
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Тёмная", "Светлая"])
        self.theme_combo.setCurrentIndex(0 if settings.theme == "dark" else 1)
        row.addWidget(self.theme_combo)
        row.addStretch()
        gl.addLayout(row)
        row2 = QHBoxLayout()
        row2.addWidget(_form_label("Шрифт"))
        self.font_spin = QSpinBox()
        self.font_spin.setRange(10, 30)
        self.font_spin.setValue(settings.font_size)
        row2.addWidget(self.font_spin)
        row2.addStretch()
        gl.addLayout(row2)
        row3 = QHBoxLayout()
        row3.addWidget(_form_label("Опрос БД (сек)"))
        self.poll_spin = QSpinBox()
        self.poll_spin.setRange(1, 120)
        self.poll_spin.setValue(settings.poll_interval_sec)
        row3.addWidget(self.poll_spin)
        row3.addStretch()
        gl.addLayout(row3)
        gl.addStretch()
        tabs.addTab(gen, "Основные")

        btns = QHBoxLayout()
        btns.addStretch()
        save = QPushButton("Сохранить")
        save.setStyleSheet(primary_btn_qss(radius=12, padding="8px 20px"))
        save.clicked.connect(self._save)
        cancel = QPushButton("Отмена")
        cancel.setCursor(Qt.PointingHandCursor)
        cancel.setStyleSheet(secondary_btn_qss(radius=12, padding="8px 20px"))
        cancel.clicked.connect(self.reject)
        btns.addWidget(save)
        btns.addWidget(cancel)
        layout.addLayout(btns)

        try:
            self.style().unpolish(self)
            self.style().polish(self)
            self.ensurePolished()
        except Exception:
            pass
        self.setUpdatesEnabled(True)

    def _auth_changed(self, idx):
        sql_mode = idx == 1
        self.user_edit.setEnabled(sql_mode)
        self.pass_edit.setEnabled(sql_mode)

    def _filter_ch(self, text):
        t = text.strip().lower()
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            self.table.setRowHidden(row, t not in (item.text().lower() if item else ""))

    def _test(self):
        self._apply_conn_fields()
        self.storage._working_driver = None
        self.test_label.setText("Подключение…")
        self.test_label.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")

        task = DbTask(self.settings, "test", parent=QApplication.instance())

        def on_ok(_op, result):
            try:
                ok, msg, drv = result
                self.test_label.setText(("✓ " if ok else "✗ ") + msg)
                self.test_label.setStyleSheet(
                    f"color: {'#4eae5c' if ok else Theme.RED}; background: transparent;"
                )
                if ok and drv:
                    self.driver_edit.setText(drv)
                    self.settings.mssql_driver = drv
                    self.storage._working_driver = drv
            except RuntimeError:
                pass
            finally:
                self._test_task = None

        def on_err(_op, msg):
            try:
                self.test_label.setText("✗ " + msg)
                self.test_label.setStyleSheet(f"color: {Theme.RED}; background: transparent;")
            except RuntimeError:
                pass
            finally:
                self._test_task = None

        task.finished_ok.connect(on_ok)
        task.failed.connect(on_err)
        _track_thread(task)
        self._test_task = task
        task.start()

    def _channel_show_toggled(self, name: str, checked: bool):
        notify = self.cb_notify.get(name)
        if notify is not None:
            notify.setEnabled(checked)
            if not checked:
                notify.setChecked(False)

    def _apply_conn_fields(self):
        self.settings.mssql_server = self.server_edit.text().strip()
        self.settings.mssql_database = self.db_edit.text().strip() or "TelegramNews"
        self.settings.mssql_auth = "windows" if self.auth_combo.currentIndex() == 0 else "sql"
        self.settings.mssql_user = self.user_edit.text().strip()
        self.settings.mssql_password = self.pass_edit.text()
        self.settings.mssql_driver = self.driver_edit.text().strip() or "SQL Server"
        self.settings.user_id = self.userid_edit.text().strip()

    def _save(self):
        self._apply_conn_fields()
        if not self.settings.user_id:
            QMessageBox.warning(self, "Имя пользователя", "Укажите свой ник для индивидуальной настройки.")
            self.userid_edit.setFocus()
            return
        for name, cb in self.cb_show.items():
            show = cb.isChecked()
            notify = self.cb_notify[name].isChecked() if show else False
            self.settings.set_channel(name, show, notify, True)
        self.settings.notifications_enabled = self.notify_cb.isChecked()
        self.settings.sound_enabled = self.sound_cb.isChecked()
        self.settings.notification_detail = (
            "minimal" if self.detail_minimal_rb.isChecked() else "full"
        )
        self.settings.theme = "dark" if self.theme_combo.currentIndex() == 0 else "light"
        self.settings.font_size = self.font_spin.value()
        self.settings.poll_interval_sec = self.poll_spin.value()
        self.settings.save()
        self.storage.close()
        self.accept()


# ---------------------------------------------------------------------------
# AI mode
# ---------------------------------------------------------------------------


class AIConfig:
    DEFAULTS = {
        "base_url": "http://127.0.0.1:3000",
        "api_path": "/api/chat/completions",
        "token": "",
        "model": "",
        "username": "",
        "timeout_sec": 120,
        "max_news": 500,
        "max_chars": 120000,
        "answer_font_size": 13,
    }

    def __init__(self, filename: Path = II_CONFIG_FILE):
        self.filename = Path(filename)
        self.data = dict(self.DEFAULTS)
        self.load()

    def load(self):
        if not self.filename.exists():
            return
        try:
            raw = json.loads(self.filename.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                for k in self.DEFAULTS:
                    if k in raw:
                        self.data[k] = raw[k]
        except Exception:
            pass

    def save(self):
        self.filename.parent.mkdir(parents=True, exist_ok=True)
        self.filename.write_text(
            json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8"
        )


class PromptStore:
    BUILTIN = {
        "Краткая сводка": (
            "Сделай краткую, структурированную сводку новостей. Объедини дубли, "
            "выдели главное, укажи каналы и не придумывай факты, которых нет в исходных сообщениях."
        ),
        "Важное и риски": (
            "Проанализируй новости, выдели наиболее важные события, потенциальные риски, "
            "что требует внимания в первую очередь. Для каждого вывода укажи, на каких сообщениях он основан."
        ),
    }

    def __init__(self, filename: Path = PROMPTS_FILE):
        self.filename = Path(filename)
        self.custom: Dict[str, str] = {}
        self.load()

    def load(self):
        if not self.filename.exists():
            return
        try:
            raw = json.loads(self.filename.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                self.custom = {str(k): str(v) for k, v in raw.items() if str(k).strip()}
        except Exception:
            self.custom = {}

    def save(self):
        self.filename.parent.mkdir(parents=True, exist_ok=True)
        self.filename.write_text(
            json.dumps(self.custom, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def all(self) -> Dict[str, str]:
        out = dict(self.BUILTIN)
        out.update(self.custom)
        return out


class AIRequestTask(QThread):
    finished_ok = pyqtSignal(str)
    failed = pyqtSignal(str)
    cancelled = pyqtSignal()

    def __init__(self, config: dict, system_prompt: str, user_text: str, parent=None):
        super().__init__(parent)
        self.config = dict(config)
        self.system_prompt = system_prompt
        self.user_text = user_text
        self._cancel_event = threading.Event()
        self._conn = None

    def cancel(self):
        self._cancel_event.set()
        conn = self._conn
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    def run(self):
        if self._cancel_event.is_set():
            self.cancelled.emit()
            return
        try:
            base = str(self.config.get("base_url", "")).strip().rstrip("/")
            path = str(self.config.get("api_path", "/api/chat/completions")).strip()
            if not path.startswith("/"):
                path = "/" + path
            if "://" not in base:
                base = "http://" + base
                parsed = urlparse(base)
            else:
                parsed = urlparse(base)
            if parsed.scheme not in ("http", "https") or not parsed.hostname:
                raise RuntimeError("Некорректный адрес ИИ-сервера. Пример: http://12345.88:3000")
            prefix = parsed.path.rstrip("/")
            full_path = prefix + path
            timeout = max(5, int(self.config.get("timeout_sec", 120) or 120))
            conn_cls = http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
            self._conn = conn_cls(parsed.hostname, parsed.port, timeout=timeout)

            payload = {
                "model": str(self.config.get("model", "")).strip(),
                "messages": [
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": self.user_text},
                ],
                "stream": False,
            }
            if not payload["model"]:
                raise RuntimeError("Не указано имя модели")
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            headers = {"Content-Type": "application/json", "Accept": "application/json"}
            token = str(self.config.get("token", "")).strip()
            if token:
                headers["Authorization"] = "Bearer " + token
            username = str(self.config.get("username", "")).strip()
            if username:
                headers["X-User-Name"] = username

            self._conn.request("POST", full_path, body=body, headers=headers)
            if self._cancel_event.is_set():
                self.cancelled.emit()
                return
            response = self._conn.getresponse()
            raw = response.read()
            if self._cancel_event.is_set():
                self.cancelled.emit()
                return
            text = raw.decode("utf-8", errors="replace")
            if response.status < 200 or response.status >= 300:
                raise RuntimeError(f"HTTP {response.status}: {text[:1200]}")
            data = json.loads(text)
            answer = ""
            try:
                answer = data["choices"][0]["message"]["content"]
            except Exception:
                answer = data.get("response") or data.get("message") or data.get("content") or ""
                if isinstance(answer, dict):
                    answer = answer.get("content") or answer.get("text") or ""
            if not str(answer).strip():
                raise RuntimeError("Сервер вернул ответ без текста")
            self.finished_ok.emit(str(answer))
        except Exception as e:
            if self._cancel_event.is_set():
                self.cancelled.emit()
            else:
                self.failed.emit(str(e))
        finally:
            if self._conn is not None:
                try:
                    self._conn.close()
                except Exception:
                    pass
            self._conn = None


class AIModeDialog(QDialog):
    def __init__(self, storage: NewsStorage, parent=None):
        super().__init__(parent)
        self.storage = storage
        self.config = AIConfig()
        self.prompts = PromptStore()
        self._db_task: Optional[DbTask] = None
        self._ai_task: Optional[AIRequestTask] = None
        self._channel_selection_initialized = False
        self._answer_raw_text = ""
        self._answer_font_size = max(10, min(22, int(self.config.data.get("answer_font_size", 13) or 13)))
        self._run_id = 0
        self._busy_base = ""
        self._busy_started = 0.0
        self._status_timer = QTimer(self)
        self._status_timer.setInterval(400)
        self._status_timer.timeout.connect(self._tick_status)
        self.setWindowTitle("Режим ИИ")
        self.resize(1100, 760)
        self.setMinimumSize(900, 620)
        self.setAttribute(Qt.WA_DeleteOnClose, False)
        self.setUpdatesEnabled(False)
        self._build_ui()
        self.apply_theme()
        self._load_config_ui()
        self._reload_prompts()
        self._load_channels()
        try:
            self.style().unpolish(self)
            self.style().polish(self)
            self.ensurePolished()
        except Exception:
            pass
        self.setUpdatesEnabled(True)
        self.update()
        self.repaint()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(10)

        splitter = QSplitter(Qt.Horizontal)

        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 8, 0)
        ll.setSpacing(10)

        cfg = QGroupBox("Подключение ИИ")
        form = QFormLayout(cfg)
        self.url_edit = QLineEdit()
        self.path_edit = QLineEdit()
        self.model_edit = QLineEdit()
        self.user_edit = QLineEdit()
        self.token_edit = QLineEdit()
        self.token_edit.setEchoMode(QLineEdit.Password)
        form.addRow("Адрес:", self.url_edit)
        form.addRow("API path:", self.path_edit)
        form.addRow("Модель:", self.model_edit)
        form.addRow("Пользователь:", self.user_edit)
        form.addRow("Токен:", self.token_edit)
        self.save_cfg_btn = QPushButton("Сохранить подключение")
        self.save_cfg_btn.setCursor(Qt.PointingHandCursor)
        self.save_cfg_btn.setStyleSheet(secondary_btn_qss(radius=10, padding="7px 16px"))
        self.save_cfg_btn.clicked.connect(self._save_config_ui)
        form.addRow(self.save_cfg_btn)
        ll.addWidget(cfg)

        interval_box = QGroupBox("Интервал анализа")
        il = QHBoxLayout(interval_box)
        il.setContentsMargins(10, 8, 10, 8)
        il.setSpacing(8)
        il.addWidget(QLabel("Брать новости за последние:"))
        self.interval_spin = QSpinBox()
        self.interval_spin.setRange(1, 720)
        self.interval_spin.setValue(1)
        self.interval_spin.setMinimumWidth(80)
        self.interval_unit = QComboBox()
        self.interval_unit.addItems(["минут", "часов", "дней"])
        self.interval_unit.setCurrentIndex(1)
        self.interval_unit.setMinimumWidth(95)
        il.addWidget(self.interval_spin)
        il.addWidget(self.interval_unit)
        il.addStretch(1)
        ll.addWidget(interval_box)

        source = QGroupBox("Новости")
        sl = QVBoxLayout(source)
        self.channel_search = QLineEdit()
        self.channel_search.setPlaceholderText("Поиск канала…")
        self.channel_search.setClearButtonEnabled(True)
        self.channel_search.textChanged.connect(self._filter_channels)
        sl.addWidget(self.channel_search)
        self.channels_list = QListWidget()
        self.channels_list.setMinimumHeight(130)
        self.channels_list.itemChanged.connect(self._channel_selection_changed)
        limit_row = QHBoxLayout()
        limit_note = QLabel("Каналов за один запрос: от 1 до 3")
        limit_note.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")
        self.channel_count_label = QLabel("0/3")
        self.channel_count_label.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")
        limit_row.addWidget(limit_note)
        limit_row.addStretch()
        limit_row.addWidget(self.channel_count_label)
        sl.addLayout(limit_row)
        sl.addWidget(self.channels_list)
        ll.addWidget(source, 1)

        prompt_box = QGroupBox("Промт")
        pl = QVBoxLayout(prompt_box)
        pr = QHBoxLayout()
        self.prompt_combo = QComboBox()
        self.prompt_combo.currentTextChanged.connect(self._prompt_selected)
        self.save_prompt_btn = QPushButton("Сохранить как…")
        self.delete_prompt_btn = QPushButton("Удалить свой")
        self.save_prompt_btn.setCursor(Qt.PointingHandCursor)
        self.delete_prompt_btn.setCursor(Qt.PointingHandCursor)
        self.save_prompt_btn.setStyleSheet(secondary_btn_qss(radius=10, padding="7px 14px"))
        self.delete_prompt_btn.setStyleSheet(danger_btn_qss(radius=10, padding="7px 14px"))
        self.save_prompt_btn.clicked.connect(self._save_prompt)
        self.delete_prompt_btn.clicked.connect(self._delete_prompt)
        pr.addWidget(self.prompt_combo, 1)
        pr.addWidget(self.save_prompt_btn)
        pr.addWidget(self.delete_prompt_btn)
        pl.addLayout(pr)
        self.prompt_edit = QPlainTextEdit()
        self.prompt_edit.setMinimumHeight(150)
        pl.addWidget(self.prompt_edit)
        ll.addWidget(prompt_box, 1)

        actions = QHBoxLayout()
        self.run_btn = QPushButton("Запустить")
        self.cancel_btn = QPushButton("Отмена")
        self.run_btn.setCursor(Qt.PointingHandCursor)
        self.cancel_btn.setCursor(Qt.PointingHandCursor)
        self.run_btn.setStyleSheet(primary_btn_qss(radius=10, padding="8px 18px"))
        self.cancel_btn.setStyleSheet(secondary_btn_qss(radius=10, padding="8px 18px"))
        self.cancel_btn.setEnabled(False)
        self.run_btn.clicked.connect(self._run)
        self.cancel_btn.clicked.connect(self._cancel)
        actions.addWidget(self.run_btn)
        actions.addWidget(self.cancel_btn)
        actions.addStretch()
        ll.addLayout(actions)

        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(8, 0, 0, 0)
        top = QHBoxLayout()
        top.addWidget(QLabel("Ответ ИИ"))
        top.addStretch()
        self.font_minus_btn = QPushButton("A−")
        self.font_plus_btn = QPushButton("A+")
        self.font_minus_btn.setToolTip("Уменьшить шрифт ответа")
        self.font_plus_btn.setToolTip("Увеличить шрифт ответа")
        self.font_minus_btn.clicked.connect(lambda: self._change_answer_font(-1))
        self.font_plus_btn.clicked.connect(lambda: self._change_answer_font(1))
        self.copy_btn = QPushButton("Копировать")
        self.reset_btn = QPushButton("Сброс")
        self.copy_btn.setCursor(Qt.PointingHandCursor)
        self.reset_btn.setCursor(Qt.PointingHandCursor)
        self.copy_btn.setStyleSheet(secondary_btn_qss(radius=10, padding="6px 14px"))
        self.reset_btn.setStyleSheet(secondary_btn_qss(radius=10, padding="6px 14px"))
        self.copy_btn.clicked.connect(lambda: QApplication.clipboard().setText(self._answer_raw_text or self.answer.toPlainText()))
        self.reset_btn.clicked.connect(self._reset)
        top.addWidget(self.font_minus_btn)
        top.addWidget(self.font_plus_btn)
        top.addWidget(self.copy_btn)
        top.addWidget(self.reset_btn)
        rl.addLayout(top)
        self.answer = QTextBrowser()
        self.answer.setOpenExternalLinks(False)
        self.answer.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        self.answer.setWordWrapMode(QTextOption.WrapAtWordBoundaryOrAnywhere)
        rl.addWidget(self.answer, 1)
        self.busy_bar = BusyBar()
        rl.addWidget(self.busy_bar)
        self.status = QLabel("Готово")
        self.status.setWordWrap(True)
        rl.addWidget(self.status)

        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.NoFrame)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        left_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        left_scroll.setWidget(left)

        splitter.addWidget(left_scroll)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([430, 670])
        root.addWidget(splitter, 1)

    def _set_ai_palette(self, widget: QWidget, text: Optional[str] = None):
        pal = widget.palette()
        pal.setColor(QPalette.Window, QColor(Theme.WINDOW))
        pal.setColor(QPalette.Base, QColor(Theme.CARD))
        pal.setColor(QPalette.AlternateBase, QColor(Theme.CARD_HOVER))
        pal.setColor(QPalette.Button, QColor(Theme.CARD))
        pal.setColor(QPalette.Text, QColor(text or Theme.TEXT))
        pal.setColor(QPalette.WindowText, QColor(text or Theme.TEXT))
        pal.setColor(QPalette.ButtonText, QColor(text or Theme.TEXT))
        pal.setColor(QPalette.Highlight, QColor(Theme.CARD_ACTIVE))
        pal.setColor(QPalette.HighlightedText, QColor(Theme.TEXT))
        pal.setColor(QPalette.PlaceholderText, QColor(Theme.SUBTEXT))
        pal.setColor(QPalette.Disabled, QPalette.Text, QColor(Theme.SUBTEXT))
        pal.setColor(QPalette.Disabled, QPalette.WindowText, QColor(Theme.SUBTEXT))
        pal.setColor(QPalette.Disabled, QPalette.ButtonText, QColor(Theme.SUBTEXT))
        widget.setPalette(pal)

    def apply_theme(self):
        text = Theme.TEXT
        subtext = Theme.SUBTEXT
        self.setStyleSheet(f"""
            QDialog, QWidget {{ background: {Theme.WINDOW}; color: {text}; }}
            QDialog * {{ color: {text}; }}
            QLabel {{ color: {text}; background: transparent; }}
            QGroupBox {{
                color: {text}; background: transparent;
                border: 1px solid {Theme.BORDER}; border-radius: 12px;
                margin-top: 12px; padding-top: 6px;
            }}
            QGroupBox::title {{
                color: {Theme.BLUE_LIGHT if Theme.name == "dark" else Theme.BLUE};
                background: {Theme.WINDOW};
                subcontrol-origin: margin; left: 12px; padding: 0 6px;
            }}
            QFormLayout QLabel {{ color: {text}; }}
            QLineEdit, QPlainTextEdit, QTextEdit, QTextBrowser {{
                background: {Theme.CARD}; color: {text};
                selection-background-color: {Theme.BLUE};
                selection-color: #ffffff;
                border: 1px solid {Theme.BORDER}; border-radius: 10px; padding: 6px;
            }}
            QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QTextBrowser:focus,
            QComboBox:focus, QSpinBox:focus {{ border: 1px solid {Theme.BLUE}; }}
            QComboBox, QSpinBox {{
                background: {Theme.CARD}; color: {text};
                selection-background-color: {Theme.CARD_ACTIVE};
                selection-color: {text};
                border: 1px solid {Theme.BORDER}; border-radius: 8px; padding: 5px 7px;
            }}
            QComboBox QAbstractItemView {{
                background: {Theme.CARD}; color: {text};
                selection-background-color: {Theme.CARD_ACTIVE};
                selection-color: {text};
                border: 1px solid {Theme.BORDER};
            }}
            QAbstractItemView::item {{ color: {text}; background: {Theme.CARD}; }}
            QAbstractItemView::item:selected {{ color: {text}; background: {Theme.CARD_ACTIVE}; }}
            QMenu {{ background: {Theme.CARD}; color: {text}; border: 1px solid {Theme.BORDER}; }}
            QMenu::item:selected {{ background: {Theme.CARD_ACTIVE}; color: {text}; }}
            QListWidget {{ background: {Theme.CARD}; color: {text}; border: 1px solid {Theme.BORDER}; }}
            QListWidget::item:selected {{ background: {Theme.CARD_ACTIVE}; color: {text}; }}
            QPushButton {{
                background: {Theme.CARD}; color: {text};
                border: 1px solid {Theme.BORDER}; border-radius: 8px; padding: 6px 10px;
            }}
            QPushButton:hover {{ background: {Theme.CARD_HOVER}; color: {text}; }}
            QPushButton:pressed {{ background: {Theme.CARD_ACTIVE}; color: {text}; }}
            QPushButton:disabled {{ color: {subtext}; }}
            QScrollBar:vertical {{ width: 10px; background: transparent; margin: 2px; }}
            QScrollBar::handle:vertical {{ background: {Theme.SCROLL_HANDLE}; border-radius: 5px; min-height: 30px; }}
            QScrollBar::handle:vertical:hover {{ background: {Theme.SCROLL_HANDLE_HOVER}; }}
            QScrollBar:horizontal {{ height: 10px; background: transparent; margin: 2px; }}
            QScrollBar::handle:horizontal {{ background: {Theme.SCROLL_HANDLE}; border-radius: 5px; min-width: 30px; }}
            QScrollBar::handle:horizontal:hover {{ background: {Theme.SCROLL_HANDLE_HOVER}; }}
            QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
            QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}
            QSplitter::handle {{ background: transparent; }}
            QSplitter::handle:hover {{ background: {Theme.CARD_ACTIVE}; }}
        """)
        self._style_buttons()

        for child in self.findChildren(QWidget):
            self._set_ai_palette(child)
        for group in self.findChildren(QGroupBox):
            self._set_ai_palette(group)
        for child in self.findChildren(QLabel):
            child.setStyleSheet(f"color: {text}; background: transparent;")
            self._set_ai_palette(child)
        for child in (
            self.url_edit, self.path_edit, self.model_edit, self.user_edit,
            self.token_edit, self.prompt_edit, self.answer, self.channels_list,
            self.channel_search, self.channel_count_label, self.prompt_combo,
            self.interval_spin, self.interval_unit, self.save_cfg_btn,
            self.save_prompt_btn, self.delete_prompt_btn, self.run_btn,
            self.cancel_btn, self.font_minus_btn, self.font_plus_btn,
            self.copy_btn, self.reset_btn,
        ):
            self._set_ai_palette(child)
        self.status.setStyleSheet(f"color: {subtext}; background: transparent;")
        self._set_ai_palette(self.status, subtext)

    def _style_buttons(self):
        self.save_cfg_btn.setStyleSheet(secondary_btn_qss(radius=10, padding="7px 16px"))
        self.save_prompt_btn.setStyleSheet(secondary_btn_qss(radius=10, padding="7px 14px"))
        self.delete_prompt_btn.setStyleSheet(danger_btn_qss(radius=10, padding="7px 14px"))
        self.run_btn.setStyleSheet(primary_btn_qss(radius=10, padding="8px 18px"))
        self.cancel_btn.setStyleSheet(secondary_btn_qss(radius=10, padding="8px 18px"))
        self.copy_btn.setStyleSheet(secondary_btn_qss(radius=10, padding="6px 14px"))
        self.reset_btn.setStyleSheet(secondary_btn_qss(radius=10, padding="6px 14px"))
        self.busy_bar.update()

    def _load_config_ui(self):
        d = self.config.data
        self.url_edit.setText(str(d.get("base_url", "")))
        self.path_edit.setText(str(d.get("api_path", "/api/chat/completions")))
        self.model_edit.setText(str(d.get("model", "")))
        self.user_edit.setText(str(d.get("username", "")))
        self.token_edit.setText(str(d.get("token", "")))

    def _save_config_ui(self):
        self.config.data.update({
            "base_url": self.url_edit.text().strip(),
            "api_path": self.path_edit.text().strip() or "/api/chat/completions",
            "model": self.model_edit.text().strip(),
            "username": self.user_edit.text().strip(),
            "token": self.token_edit.text().strip(),
            "answer_font_size": self._answer_font_size,
        })
        self.config.save()
        self.status.setText(f"Настройки сохранены: {II_CONFIG_FILE}")

    def _load_channels(self):
        selected_before = set(self._selected_channels()) if self._channel_selection_initialized else set()
        self.channels_list.blockSignals(True)
        self.channels_list.clear()
        visible_names = [
            ch.name for ch in self.storage.channels
            if self.storage.settings.is_show(ch.name)
        ]
        for idx, name in enumerate(visible_names):
            item = QListWidgetItem(name)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            if self._channel_selection_initialized:
                checked = name in selected_before
            else:
                checked = idx < 3
            item.setCheckState(Qt.Checked if checked else Qt.Unchecked)
            self.channels_list.addItem(item)
        self.channels_list.blockSignals(False)
        self._channel_selection_initialized = True
        self._filter_channels(self.channel_search.text() if hasattr(self, "channel_search") else "")
        self._update_channel_count()

    def _filter_channels(self, text: str):
        needle = (text or "").strip().casefold()
        for i in range(self.channels_list.count()):
            item = self.channels_list.item(i)
            item.setHidden(bool(needle) and needle not in item.text().casefold())

    def _update_channel_count(self):
        count = len(self._selected_channels())
        self.channel_count_label.setText(f"{count}/3")

    def _reload_prompts(self, select_name: Optional[str] = None):
        self.prompt_combo.blockSignals(True)
        self.prompt_combo.clear()
        for name in self.prompts.all().keys():
            self.prompt_combo.addItem(name)
        if select_name:
            i = self.prompt_combo.findText(select_name)
            if i >= 0:
                self.prompt_combo.setCurrentIndex(i)
        self.prompt_combo.blockSignals(False)
        self._prompt_selected(self.prompt_combo.currentText())

    def _prompt_selected(self, name: str):
        text = self.prompts.all().get(name, "")
        self.prompt_edit.setPlainText(text)
        self.delete_prompt_btn.setEnabled(name in self.prompts.custom)

    def _save_prompt(self):
        text = self.prompt_edit.toPlainText().strip()
        if not text:
            QMessageBox.warning(self, "Промт", "Промт пустой.")
            return
        name, ok = QInputDialog.getText(self, "Сохранить промт", "Название:")
        name = name.strip()
        if not ok or not name:
            return
        if name in PromptStore.BUILTIN:
            QMessageBox.warning(self, "Промт", "Это имя занято стандартным промтом.")
            return
        self.prompts.custom[name] = text
        self.prompts.save()
        self._reload_prompts(name)

    def _delete_prompt(self):
        name = self.prompt_combo.currentText()
        if name not in self.prompts.custom:
            return
        del self.prompts.custom[name]
        self.prompts.save()
        self._reload_prompts()

    def _channel_selection_changed(self, changed_item):
        if changed_item.checkState() == Qt.Checked:
            checked = [
                self.channels_list.item(i)
                for i in range(self.channels_list.count())
                if self.channels_list.item(i).checkState() == Qt.Checked
            ]
            if len(checked) > 3:
                self.channels_list.blockSignals(True)
                changed_item.setCheckState(Qt.Unchecked)
                self.channels_list.blockSignals(False)
                self.status.setText("Можно выбрать не более 3 каналов.")
        self._update_channel_count()

    def _selected_channels(self) -> List[str]:
        out = []
        for i in range(self.channels_list.count()):
            item = self.channels_list.item(i)
            if item.checkState() == Qt.Checked:
                out.append(item.text())
        return out

    def _interval_seconds(self) -> int:
        mult = (60, 3600, 86400)[self.interval_unit.currentIndex()]
        return self.interval_spin.value() * mult

    def _set_busy(self, busy: bool, status: str = ""):
        self.run_btn.setEnabled(not busy)
        self.cancel_btn.setEnabled(busy)
        self.busy_bar.set_active(busy)
        if busy:
            if status:
                self._busy_base = status.rstrip("….")
            if not self._busy_started:
                self._busy_started = time.monotonic()
            if not self._status_timer.isActive():
                self._status_timer.start()
            self._tick_status()
        else:
            self._status_timer.stop()
            self._busy_started = 0.0
            if status:
                self.status.setText(status)

    def _tick_status(self):
        if not self._busy_started:
            return
        now = time.monotonic()
        dots = "." * (1 + int(now * 2.5) % 3)
        self.status.setText(f"{self._busy_base}{dots}  ({int(now - self._busy_started)} с)")

    def _elapsed_text(self) -> str:
        return f" · {int(time.monotonic() - self._busy_started)} с" if self._busy_started else ""

    def _is_running(self) -> bool:
        return self._db_task is not None or self._ai_task is not None

    def _run(self):
        if self._is_running():
            return
        channels = self._selected_channels()
        prompt = self.prompt_edit.toPlainText().strip()
        if not channels:
            QMessageBox.warning(self, "Режим ИИ", "Выберите хотя бы один канал.")
            return
        if not prompt:
            QMessageBox.warning(self, "Режим ИИ", "Введите промт.")
            return
        self._save_config_ui()
        if not self.config.data.get("base_url") or not self.config.data.get("model"):
            QMessageBox.warning(self, "Режим ИИ", "Укажите адрес сервера и модель.")
            return
        now = time.time()
        self._run_id += 1
        rid = self._run_id
        self._set_busy(True, "Получаю новости из БД…")
        task = DbTask(
            self.storage.settings,
            "ai_news",
            {
                "channels": channels,
                "since_ts": now - self._interval_seconds(),
                "until_ts": now,
                "limit": int(self.config.data.get("max_news", 500) or 500),
            },
            parent=QApplication.instance(),
        )
        self._db_task = task

        def ok(_op, news):
            if rid != self._run_id or self._db_task is not task:
                return
            self._db_task = None
            try:
                if not news:
                    self._set_busy(False, "За выбранный интервал новостей нет.")
                    return
                max_chars = max(10000, int(self.config.data.get("max_chars", 120000) or 120000))
                chunks = []
                used = 0
                for n in news:
                    block = f"[{n.date}] [{n.channel}]\n{n.title}\n{n.text}\n"
                    if used + len(block) > max_chars:
                        break
                    chunks.append(block)
                    used += len(block)
                user_text = (
                    f"Ниже новости за выбранный интервал. Сообщений загружено: {len(news)}. "
                    f"В запрос вошло: {len(chunks)}.\n\n" + "\n---\n".join(chunks)
                )
            except Exception as e:
                self._set_busy(False, f"Ошибка подготовки запроса: {e}")
                return
            self._start_ai(prompt, user_text, rid)

        def err(_op, msg):
            if rid != self._run_id or self._db_task is not task:
                return
            self._db_task = None
            self._set_busy(False, "Ошибка БД: " + msg)

        task.finished_ok.connect(ok)
        task.failed.connect(err)
        _track_thread(task)
        task.start()

    def _start_ai(self, prompt: str, user_text: str, rid: int):
        self._set_busy(True, "Отправляю запрос ИИ…")
        self.answer.clear()
        task = AIRequestTask(self.config.data, prompt, user_text, parent=QApplication.instance())
        self._ai_task = task

        def current() -> bool:
            return rid == self._run_id and self._ai_task is task

        def done(text):
            if not current():
                return
            self._ai_task = None
            took = self._elapsed_text()
            try:
                self._answer_raw_text = text or ""
                self._render_answer()
                msg = "Ответ получен" + took
            except Exception as e:
                msg = f"Не удалось показать ответ: {e}"
            self._set_busy(False, msg)

        def failed(msg):
            if not current():
                return
            self._ai_task = None
            self._set_busy(False, "Ошибка ИИ: " + msg)

        def cancelled():
            if not current():
                return
            self._ai_task = None
            self._set_busy(False, "Операция отменена.")

        task.finished_ok.connect(done)
        task.failed.connect(failed)
        task.cancelled.connect(cancelled)
        _track_thread(task)
        task.start()

    def _abort_running(self, status: str):
        self._run_id += 1
        db_task, ai_task = self._db_task, self._ai_task
        self._db_task = None
        self._ai_task = None
        if ai_task is not None:
            try:
                ai_task.cancel()
            except Exception:
                pass
        if db_task is not None and ai_task is None:
            status = "Получение данных отменено; текущий SQL-запрос завершится в фоне."
        self._set_busy(False, status)

    def _cancel(self):
        if self._is_running():
            self._abort_running("Операция отменена.")

    def _change_answer_font(self, delta: int):
        self._answer_font_size = max(10, min(22, self._answer_font_size + int(delta)))
        self.config.data["answer_font_size"] = self._answer_font_size
        try:
            self.config.save()
        except Exception:
            pass
        self._render_answer()
        self.status.setText(f"Размер шрифта ответа: {self._answer_font_size}")

    @staticmethod
    def _is_list_or_code_paragraph(text: str) -> bool:
        stripped = text.lstrip()
        prefixes = ("- ", "* ", "• ", "> ", "```", "    ")
        if stripped.startswith(prefixes):
            return True
        head = stripped[:6]
        return any(head.startswith(f"{n}.") or head.startswith(f"{n})") for n in range(1, 10))

    def _render_answer(self):
        text = (self._answer_raw_text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
        self.answer.clear()
        if not text:
            return
        doc = self.answer.document()
        doc.setDocumentMargin(14)
        cursor = QTextCursor(doc)
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
        for idx, para in enumerate(paragraphs):
            block = QTextBlockFormat()
            block.setTopMargin(2 if idx == 0 else 7)
            block.setBottomMargin(7)
            block.setLineHeight(135, QTextBlockFormat.ProportionalHeight)
            is_list = self._is_list_or_code_paragraph(para) or "\n- " in para or "\n• " in para
            short_heading = "\n" not in para and len(para) <= 70 and (para.endswith(":") or para.startswith("#"))
            if is_list or short_heading:
                block.setAlignment(Qt.AlignLeft)
                block.setTextIndent(0)
            else:
                block.setAlignment(Qt.AlignJustify)
                block.setTextIndent(22)
            cursor.setBlockFormat(block)
            char = QTextCharFormat()
            char.setForeground(QColor(Theme.TEXT))
            char.setFontPointSize(self._answer_font_size)
            if short_heading:
                char.setFontWeight(QFont.DemiBold)
            cursor.setCharFormat(char)
            clean = para.lstrip("# ") if short_heading else para
            cursor.insertText(clean)
            if idx < len(paragraphs) - 1:
                cursor.insertBlock()
        self.answer.moveCursor(QTextCursor.Start)

    def _reset(self):
        self._answer_raw_text = ""
        self.answer.clear()
        self.status.setText("Готово")

    def showEvent(self, event):
        super().showEvent(event)
        fade_in(self, 180)

    def closeEvent(self, event):
        if self._is_running():
            self._abort_running("Операция отменена.")
        event.accept()

    def wait_for_workers(self, timeout_ms=10000):
        tasks = [t for t in (self._db_task, self._ai_task) if t is not None]
        ok = True
        for task in tasks:
            try:
                if task.isRunning():
                    if task is self._ai_task:
                        task.cancel()
                    task.wait(timeout_ms)
                ok = ok and not task.isRunning()
            except RuntimeError:
                pass
        return ok


# ---------------------------------------------------------------------------
# Main window / Toast / Tray
# ---------------------------------------------------------------------------


class MainWindow(QMainWindow):
    def __init__(self, storage: NewsStorage, tray_app=None):
        super().__init__()
        self.storage = storage
        self.tray_app = tray_app
        self.current_channel = None
        self.selected_channel_name = None
        self._search = ""
        self._page_offset = 0
        self._first = True
        self._workers: List[DbTask] = []
        self._busy = False
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(350)
        self._search_timer.timeout.connect(self._execute_search)
        self._pending_search = ""
        self._search_generation = 0
        self._ai_window = None
        self._in_favorites = False

        self.setWindowTitle("Telegram News (SQL Server)")
        self.setGeometry(120, 80, 1180, 740)
        self.setMinimumSize(920, 620)
        self.setObjectName("mainWindow")
        self.setStyleSheet(f"QMainWindow#mainWindow {{ background: {Theme.WINDOW}; }}")

        central = QWidget()
        self.setCentralWidget(central)
        lay = QHBoxLayout(central)
        lay.setContentsMargins(0, 0, 0, 0)
        self.sidebar = Sidebar(storage)
        lay.addWidget(self.sidebar)
        self.content = MainContent(storage.settings.font_size, storage.settings.sound_enabled)
        lay.addWidget(self.content)

        self.sidebar.channelSelected.connect(self.onChannelSelected)
        self.sidebar.settingsChanged.connect(self.refresh)
        self.sidebar.favoritesSelected.connect(self.onFavoritesSelected)
        self.sidebar.favoritesClearRequested.connect(self.clearFavorites)
        self.content.refreshRequested.connect(self.refresh)
        self.content.searchRequested.connect(self.onSearch)
        self.content.settingsRequested.connect(self.open_settings)
        self.content.soundToggleRequested.connect(self.toggle_sound)
        self.content.themeToggleRequested.connect(self.toggle_theme)
        self.content.loadMoreRequested.connect(self.on_load_more)
        self.content.aiRequested.connect(self.open_ai_mode)
        self.content.markAllReadRequested.connect(self.mark_all_read)
        self.content.newsActivated.connect(self.open_reader)
        self.content.favoriteToggled.connect(self._toggle_favorite)
        self.sidebar.set_favorites_count(len(self.storage.favorites.items))
        self.content.set_favorites(self.storage.favorites.checksum_set())
        self.content.showPlaceholder()

    def open_reader(self, news: News):
        dlg = ReaderDialog(news, self.storage.settings.font_size, self.storage.favorites, self)
        dlg.favoriteToggled.connect(self._toggle_favorite)
        dlg.exec_()

    def _run_db(self, op: str, params: Optional[dict] = None, on_ok=None, on_err=None):
        task = DbTask(self.storage.settings, op, params, parent=self)

        def _ok(o, result):
            try:
                if on_ok:
                    on_ok(result)
            finally:
                self._cleanup_worker(task)

        def _err(o, msg):
            try:
                if on_err:
                    on_err(msg)
                else:
                    self.content.placeholder.setText(f"Ошибка БД: {msg}")
                    self.content.showPlaceholder()
            finally:
                self._cleanup_worker(task)

        task.finished_ok.connect(_ok)
        task.failed.connect(_err)
        _track_thread(task)
        self._workers.append(task)
        task.start()

    def _cleanup_worker(self, task: DbTask):
        try:
            self._workers.remove(task)
        except ValueError:
            pass

    def apply_theme(self):
        self.setStyleSheet(f"QMainWindow#mainWindow {{ background: {Theme.WINDOW}; }}")
        self.sidebar.apply_theme()
        self.content.apply_theme()

    def onFavoritesSelected(self):
        self._in_favorites = True
        self.current_channel = None
        self.selected_channel_name = None
        self._search = ""
        self.content.search.blockSignals(True)
        self.content.search.clear()
        self.content.search.blockSignals(False)
        self._load_favorites_view()

    def _load_favorites_view(self, query: str = "", in_place: bool = False):
        news = self.storage.favorites.search(query) if query else self.storage.favorites.to_news_list()
        self.content.showNewsPage(news, len(news), scroll_top=not in_place, reveal=not in_place)
        title = "⭐ Избранное · поиск" if query else "⭐ Избранное"
        self.content.setChannelInfo(title, len(news))
        self._page_offset = len(news)

    def _toggle_favorite(self, news: News):
        cs = news.checksum or news.cs()
        if self.storage.favorites.contains(cs):
            self.storage.favorites.remove(cs)
        else:
            self.storage.favorites.add(news)
        self.sidebar.set_favorites_count(len(self.storage.favorites.items))
        self.content.set_favorites(self.storage.favorites.checksum_set())
        if self._in_favorites:
            self._load_favorites_view(self._search, in_place=True)

    def clearFavorites(self):
        if not self.storage.favorites.items:
            return
        if QMessageBox.question(
            self, "Избранное", "Удалить все новости из избранного? Это действие нельзя отменить.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        ) != QMessageBox.Yes:
            return
        self.storage.favorites.clear()
        self.sidebar.set_favorites_count(0)
        self.content.set_favorites(set())
        if self._in_favorites:
            self._load_favorites_view()

    def showEvent(self, e):
        if self._first:
            self._first = False
            if dwm_composition_enabled():
                self.setWindowOpacity(0)
                a = QPropertyAnimation(self, b"windowOpacity", self)
                a.setDuration(250)
                a.setStartValue(0.0)
                a.setEndValue(1.0)
                a.setEasingCurve(QEasingCurve.OutCubic)
                a.finished.connect(lambda: self.setWindowOpacity(1.0))
                self._fade_anim = a
                a.start()
                self._anim = a
        super().showEvent(e)

    def refresh(self):
        def ok(channels):
            self.storage.channels = channels
            self.sidebar.setChannels(channels)
            if self._in_favorites:
                self.sidebar.set_favorites_active(True)
                self._load_favorites_view(self._search)
            elif self.selected_channel_name:
                self._reload_async(preserve=True)
            else:
                self.content.showPlaceholder()
                self.sidebar.selectNoChannel()

        self._run_db("load_channels", on_ok=ok)

    def _reload_async(self, preserve=False):
        name = self.selected_channel_name
        search = self._search or None
        need = PAGE_SIZE
        if preserve:
            need = max(PAGE_SIZE, self.content.news_model.rowCount())

        def ok(result):
            news, total = result
            self.content.showNewsPage(news, total, scroll_top=not preserve)
            self.content.setChannelInfo("Поиск" if search else (name or "—"), total)
            self._page_offset = len(news)
            if name:
                self.sidebar.select_channel_by_name(name)

        self._run_db(
            "news_page",
            {"channel_name": name, "offset": 0, "limit": need, "search": search},
            on_ok=ok,
        )

    def onChannelSelected(self, channel: Channel):
        self._in_favorites = False
        self.sidebar.set_favorites_active(False)
        self._search = ""
        self.content.search.blockSignals(True)
        self.content.search.clear()
        self.content.search.blockSignals(False)
        self.selected_channel_name = channel.name

        def ok(result):
            channels, news, total = result
            self.storage.channels = channels
            self.sidebar.setChannels(channels)
            updated = next((c for c in channels if c.name == channel.name), None)
            if not updated:
                self.current_channel = None
                self.selected_channel_name = None
                self.content.showPlaceholder()
                return
            self.current_channel = updated
            self.selected_channel_name = updated.name
            self.content.showNewsPage(news, total)
            self.content.setChannelInfo(updated.name, total)
            self._page_offset = len(news)
            self.sidebar.select_channel_by_name(updated.name)

        def err(msg):
            QMessageBox.warning(self, "БД", msg)

        self._run_db(
            "mark_read_and_page",
            {"channel_name": channel.name, "limit": PAGE_SIZE},
            on_ok=ok,
            on_err=err,
        )

    def on_load_more(self):
        if self._busy or self._in_favorites:
            return
        self._busy = True
        offset = self._page_offset
        name = self.selected_channel_name
        search = self._search or None

        def ok(result):
            self._busy = False
            more, _ = result
            if more:
                self.content.appendNewsPage(more)
                self._page_offset += len(more)

        def err(msg):
            self._busy = False

        self._run_db(
            "news_page",
            {"channel_name": name, "offset": offset, "limit": PAGE_SIZE, "search": search},
            on_ok=ok,
            on_err=err,
        )

    def onSearch(self, text):
        self._pending_search = text.strip()
        self._search_generation += 1
        self._search_timer.start()

    def _execute_search(self):
        self._search = self._pending_search
        generation = self._search_generation
        if self._in_favorites:
            self._load_favorites_view(self._search)
            return
        if not self._search:
            self._reload_async(preserve=False) if self.selected_channel_name else self.refresh()
            return
        name = self.current_channel.name if self.current_channel else None
        query = self._search

        def ok(result):
            if generation != self._search_generation or query != self._search:
                return
            news, total = result
            self.content.showNewsPage(news, total)
            self.content.setChannelInfo("Поиск", total)
            self._page_offset = len(news)

        self._run_db(
            "news_page",
            {"channel_name": name, "offset": 0, "limit": PAGE_SIZE, "search": query},
            on_ok=ok,
        )

    def mark_all_read(self):
        if not self.content.mark_all_btn.isEnabled():
            return
        self.content.mark_all_btn.setEnabled(False)
        self.content.mark_all_btn.setToolTip("Отмечаю все новости прочитанными…")

        def ok(_result):
            def channels_ok(channels):
                self.storage.channels = channels
                self.sidebar.setChannels(channels)
                if self.selected_channel_name:
                    self._reload_async(preserve=True)
                self.content.mark_all_btn.setEnabled(True)
                self.content.mark_all_btn.setToolTip("Все новости отмечены прочитанными")
                if self.tray_app:
                    self.tray_app.update_tray_icon()
                QTimer.singleShot(1800, lambda: self.content.mark_all_btn.setToolTip("Отметить все новости прочитанными"))

            def channels_err(msg):
                self.content.mark_all_btn.setEnabled(True)
                self.content.mark_all_btn.setToolTip("Отметить все новости прочитанными")
                QMessageBox.warning(self, "Прочитано", "Не удалось обновить список каналов:\n" + msg)

            self._run_db("load_channels", on_ok=channels_ok, on_err=channels_err)

        def err(msg):
            self.content.mark_all_btn.setEnabled(True)
            self.content.mark_all_btn.setToolTip("Отметить все новости прочитанными")
            QMessageBox.warning(self, "Прочитано", "Не удалось отметить новости:\n" + msg)

        self._run_db("mark_all_read", on_ok=ok, on_err=err)

    def open_ai_mode(self):
        if self._ai_window is None:
            self._ai_window = AIModeDialog(self.storage, self)
        else:
            self._ai_window._load_channels()
        self._ai_window.apply_theme()
        self._ai_window.show()
        self._ai_window.raise_()
        self._ai_window.activateWindow()

    def toggle_sound(self):
        self.storage.settings.sound_enabled = not self.storage.settings.sound_enabled
        self.storage.settings.save()
        self.content.set_sound_icon(self.storage.settings.sound_enabled)
        if self.tray_app:
            self.tray_app.sound_action.setChecked(self.storage.settings.sound_enabled)

    def toggle_theme(self):
        if self.storage.settings.theme == "dark":
            self.storage.settings.theme = "light"
            apply_theme(LightTheme)
        else:
            self.storage.settings.theme = "dark"
            apply_theme(DarkTheme)
        self.storage.settings.save()
        self.apply_theme()
        if self._ai_window is not None:
            self._ai_window.apply_theme()
            self._ai_window._render_answer()

    def open_settings(self):
        def open_with_names(names):
            dlg = SettingsDialog(names or [], self.storage.settings, self.storage, self)
            try:
                if dlg.exec_() == QDialog.Accepted:
                    apply_theme(LightTheme if self.storage.settings.theme == "light" else DarkTheme)
                    self.apply_theme()
                    self.content.set_font_size(self.storage.settings.font_size)
                    self.content.set_sound_icon(self.storage.settings.sound_enabled)
                    self.storage._working_driver = None
                    self.refresh()
                    if self.tray_app:
                        self.tray_app.restart_poll_timer()
                        self.tray_app.sound_action.setChecked(self.storage.settings.sound_enabled)
                        self.tray_app.notify_action.setChecked(self.storage.settings.notifications_enabled)
                        self.tray_app.sync_notification_detail_actions()
            finally:
                dlg.deleteLater()

        def ok(names):
            open_with_names(names)

        def err(_msg):
            open_with_names(list(self.storage.settings.enabled_channels.keys()))

        if self.storage.settings.mssql_server:
            self._run_db("channel_names", on_ok=ok, on_err=err)
        else:
            open_with_names([])


class ToastNotification(QWidget):
    """
    Всплывающее уведомление.

    detail='full'    — имя канала + текст новости + две кнопки (520×280).
    detail='minimal' — компактный вариант: «Уведомление Telegram» + «Открыть» (368×129).

    На Win7 без Aero полупрозрачность и opacity-анимации не работают: окно либо
    не появляется, либо чёрное. Проверяем DWM один раз и в этом случае работаем
    как обычный непрозрачный виджет без fade-in/fade-out.
    """

    readRequested = pyqtSignal(str)

    def __init__(self, channel: str, full_text: str, sound_enabled: bool = True, detail: str = "full"):
        super().__init__()
        self.channel = channel
        self._closing = False
        self.detail = detail if detail in ("full", "minimal") else "full"
        self._composition = dwm_composition_enabled()

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_DeleteOnClose, True)

        if self._composition:
            self.setAttribute(Qt.WA_TranslucentBackground, True)
        else:
            self.setAutoFillBackground(True)
            pal = self.palette()
            pal.setColor(QPalette.Window, QColor(Theme.TOAST_GRAD_TOP))
            self.setPalette(pal)

        main = QVBoxLayout(self)
        main.setContentsMargins(0, 0, 0, 0)
        frame = QFrame()
        if self._composition:
            frame.setStyleSheet(f"""
                QFrame {{ background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 {Theme.TOAST_GRAD_TOP}, stop:1 {Theme.TOAST_GRAD_BOTTOM});
                    border-radius: 16px; border: none; }}
            """)
        else:
            frame.setStyleSheet(f"""
                QFrame {{ background: {Theme.TOAST_GRAD_TOP};
                    border-radius: 0px; border: none; }}
            """)

        if self.detail == "minimal":
            self._build_minimal(frame)
            w, h = 368, 129
        else:
            self._build_full(frame, full_text)
            w, h = 520, 280
        main.addWidget(frame)

        self.setFixedSize(w, h)
        screen = QApplication.primaryScreen().availableGeometry()
        self.tx = screen.right() - w - 24
        self.ty = screen.bottom() - h - 30
        self.move(self.tx, screen.bottom() + 40)

        if self._composition:
            self.setWindowOpacity(0)
        self.show()

        pos = QPropertyAnimation(self, b"pos", self)
        pos.setDuration(400)
        pos.setStartValue(QPoint(self.tx, screen.bottom() + 40))
        pos.setEndValue(QPoint(self.tx, self.ty))
        pos.setEasingCurve(QEasingCurve.OutBack)
        g = QParallelAnimationGroup(self)
        g.addAnimation(pos)
        if self._composition:
            fade = QPropertyAnimation(self, b"windowOpacity", self)
            fade.setDuration(300)
            fade.setStartValue(0)
            fade.setEndValue(1)
            g.addAnimation(fade)
        g.start()
        self._anim = g
        self.auto = QTimer(self)
        self.auto.setSingleShot(True)
        self.auto.timeout.connect(self.close_animation)
        self.auto.start(18000)

    def _build_minimal(self, frame: QFrame):
        fl = QVBoxLayout(frame)
        fl.setContentsMargins(18, 14, 18, 14)
        fl.setSpacing(10)
        row = QHBoxLayout()
        row.setSpacing(12)
        icon = QLabel("💬")
        icon.setFont(emoji_font(20))
        icon.setStyleSheet("background: transparent;")
        row.addWidget(icon)
        text_box = QVBoxLayout()
        text_box.setSpacing(1)
        lab = QLabel("Уведомление Telegram")
        lab.setFont(font_s(12, True))
        lab.setStyleSheet(f"color: {Theme.TEXT}; background: transparent;")
        text_box.addWidget(lab)
        sub = QLabel("Получено новое сообщение")
        sub.setFont(font_s(10))
        sub.setStyleSheet(f"color: {Theme.SUBTEXT}; background: transparent;")
        text_box.addWidget(sub)
        row.addLayout(text_box, 1)
        cx = QPushButton("✕")
        cx.setCursor(Qt.PointingHandCursor)
        cx.setFixedSize(24, 24)
        cx.setStyleSheet(
            f"QPushButton {{ background: transparent; border: none; border-radius: 12px; "
            f"color: {Theme.SUBTEXT}; }}"
            f"QPushButton:hover {{ background: {Theme.CARD_HOVER}; color: {Theme.TEXT}; }}"
        )
        cx.clicked.connect(self.close_animation)
        row.addWidget(cx)
        fl.addLayout(row)
        br = QHBoxLayout()
        br.addStretch()
        open_b = QPushButton("Открыть")
        open_b.setCursor(Qt.PointingHandCursor)
        open_b.setStyleSheet(primary_btn_qss(radius=12, padding="6px 16px"))
        open_b.clicked.connect(lambda: (self.close_animation(), self.readRequested.emit(self.channel)))
        br.addWidget(open_b)
        fl.addLayout(br)

    def _build_full(self, frame: QFrame, full_text: str):
        fl = QVBoxLayout(frame)
        fl.setContentsMargins(24, 16, 24, 16)
        top = QHBoxLayout()
        lab = QLabel(truncate(self.channel, 35))
        lab.setFont(font_s(12, True))
        lab.setStyleSheet(f"color: {Theme.BLUE}; background: transparent;")
        top.addWidget(lab)
        top.addStretch()
        cx = QPushButton("✕")
        cx.setCursor(Qt.PointingHandCursor)
        cx.setFixedSize(28, 28)
        cx.setStyleSheet(
            f"QPushButton {{ background: transparent; border: none; border-radius: 14px; "
            f"color: {Theme.SUBTEXT}; }}"
            f"QPushButton:hover {{ background: {Theme.CARD_HOVER}; color: {Theme.TEXT}; }}"
        )
        cx.clicked.connect(self.close_animation)
        top.addWidget(cx)
        fl.addLayout(top)
        prev = QLabel(full_text)
        prev.setWordWrap(True)
        prev.setFont(font_s(12))
        prev.setStyleSheet(f"color: {Theme.TEXT}; background: transparent;")
        prev.setMaximumHeight(140)
        fl.addWidget(prev, 1)
        br = QHBoxLayout()
        br.addStretch()
        close_b = QPushButton("Закрыть")
        close_b.setCursor(Qt.PointingHandCursor)
        close_b.setStyleSheet(secondary_btn_qss(radius=16, padding="8px 20px"))
        close_b.clicked.connect(self.close_animation)
        read_b = QPushButton("Прочитать")
        read_b.setCursor(Qt.PointingHandCursor)
        read_b.setStyleSheet(primary_btn_qss(radius=16, padding="8px 20px"))
        read_b.clicked.connect(lambda: (self.close_animation(), self.readRequested.emit(self.channel)))
        br.addWidget(close_b)
        br.addWidget(read_b)
        fl.addLayout(br)

    def close_animation(self):
        if self._closing:
            return
        self._closing = True
        self.auto.stop()
        slide = QPropertyAnimation(self, b"pos", self)
        slide.setDuration(250)
        slide.setStartValue(self.pos())
        slide.setEndValue(QPoint(self.pos().x(), self.pos().y() + 50))
        g = QParallelAnimationGroup(self)
        g.addAnimation(slide)
        if self._composition:
            fade = QPropertyAnimation(self, b"windowOpacity", self)
            fade.setDuration(250)
            fade.setStartValue(self.windowOpacity())
            fade.setEndValue(0)
            g.addAnimation(fade)
        g.finished.connect(self.close)
        self._c = g
        g.start()


class TrayApp(QApplication):
    INSTANCE_NAME = "TelegramNewsMSSQL_single_instance_v2"

    def __init__(self, argv):
        super().__init__(argv)
        self._secondary_instance = False
        self._instance_server = None
        self._pending_instance_show = False
        if self._activate_existing_instance():
            self._secondary_instance = True
            QTimer.singleShot(0, self.quit)
            return

        load_bundled_fonts()
        if pyodbc is None:
            QMessageBox.critical(
                None,
                "Ошибка",
                "Установите pyodbc:\npip install pyodbc\nи ODBC Driver for SQL Server.",
            )
            sys.exit(1)

        self.settings = Settings()
        if not self.settings.user_id.strip():
            nick, ok = QInputDialog.getText(
                None,
                "Первый запуск",
                "Придумай свой ник (в свободной форме) для индивидуальной настройки:",
            )
            nick = nick.strip()
            while ok and not nick:
                QMessageBox.warning(None, "Ник", "Ник не должен быть пустым.")
                nick, ok = QInputDialog.getText(
                    None, "Первый запуск",
                    "Придумай свой ник (в свободной форме) для индивидуальной настройки:"
                )
                nick = nick.strip()
            if not ok:
                self.quit()
                raise SystemExit(0)
            self.settings.user_id = nick
            self.settings.save()

        apply_theme(LightTheme if self.settings.theme == "light" else DarkTheme)
        self.storage = NewsStorage(self.settings)
        self.current_toast = None
        self.player = QMediaPlayer(self)
        self.loading_complete = False
        self._last_max_id = 0
        self._poll_busy = False
        self._workers: List[DbTask] = []

        self.main_window = MainWindow(self.storage, self)
        self.main_window.setVisible(False)
        self.setup_tray()
        if self._pending_instance_show:
            QTimer.singleShot(0, self.show_window)

        self.poll_timer = QTimer(self)
        self.poll_timer.setTimerType(Qt.PreciseTimer)
        self.poll_timer.timeout.connect(self.poll_db)
        self.restart_poll_timer()

        QTimer.singleShot(800, self.finish_loading)

    def _activate_existing_instance(self) -> bool:
        socket = QLocalSocket(self)
        socket.connectToServer(self.INSTANCE_NAME, QIODevice.WriteOnly)
        if socket.waitForConnected(250):
            socket.write(b"SHOW\n")
            socket.flush()
            socket.waitForBytesWritten(250)
            socket.disconnectFromServer()
            return True

        QLocalServer.removeServer(self.INSTANCE_NAME)
        server = QLocalServer(self)
        if server.listen(self.INSTANCE_NAME):
            server.newConnection.connect(self._instance_message)
            self._instance_server = server
        return False

    def _instance_message(self):
        if self._instance_server is None:
            return
        while self._instance_server.hasPendingConnections():
            sock = self._instance_server.nextPendingConnection()
            try:
                sock.waitForReadyRead(100)
                _ = bytes(sock.readAll())
            except Exception:
                pass
            sock.disconnectFromServer()
        if hasattr(self, "main_window"):
            self.show_window()
        else:
            self._pending_instance_show = True

    def _run_db(self, op: str, params: Optional[dict] = None, on_ok=None, on_err=None):
        task = DbTask(self.settings, op, params, parent=self)

        def _ok(o, result):
            try:
                if on_ok:
                    on_ok(result)
            finally:
                self._cleanup(task)

        def _err(o, msg):
            try:
                if on_err:
                    on_err(msg)
            finally:
                self._cleanup(task)

        task.finished_ok.connect(_ok)
        task.failed.connect(_err)
        _track_thread(task)
        self._workers.append(task)
        task.start()

    def _cleanup(self, task: DbTask):
        try:
            self._workers.remove(task)
        except ValueError:
            pass

    def restart_poll_timer(self):
        self.poll_timer.stop()
        interval_ms = max(250, int(self.settings.poll_interval_sec * 1000))
        self.poll_timer.setInterval(interval_ms)
        self.poll_timer.start()

    def finish_loading(self):
        self.loading_complete = True
        self.main_window.show()
        if not self.settings.mssql_server:
            self.main_window.open_settings()
            self.update_tray_icon()
            return

        def after_init(_):
            def on_poll_init(result):
                max_id, _new, channels = result
                self._last_max_id = max_id
                self.storage.channels = channels
                self.main_window.sidebar.setChannels(channels)
                self.main_window.refresh()
                self.update_tray_icon()

            def on_err(msg):
                QMessageBox.warning(
                    self.main_window,
                    "Подключение",
                    f"Не удалось открыть БД:\n{msg}\n\nПроверьте настройки.",
                )
                self.main_window.open_settings()
                self.update_tray_icon()

            self._run_db("poll", {"after_id": 0, "load_new": False}, on_ok=on_poll_init, on_err=on_err)

        if not self.settings.initialized:
            def marked(_):
                self.settings.initialized = True
                self.settings.save()
                after_init(None)

            self._run_db("mark_all_read", on_ok=marked, on_err=lambda m: after_init(None))
        else:
            after_init(None)

    def poll_db(self):
        if not self.settings.mssql_server or not self.loading_complete or self._poll_busy:
            return
        self._poll_busy = True
        after_id = self._last_max_id

        def ok(result):
            self._poll_busy = False
            max_id, new_items, channels = result
            self.storage.channels = channels
            self.main_window.sidebar.setChannels(channels)
            if max_id > self._last_max_id:
                self._last_max_id = max_id
                if self.main_window.selected_channel_name:
                    self.main_window._reload_async(preserve=True)
                self.update_tray_icon()
                if self.settings.notifications_enabled and new_items:
                    notifiable = [n for n in new_items if self.settings.is_notify(n.channel)]
                    if notifiable:
                        by = defaultdict(int)
                        for n in notifiable:
                            by[n.channel] += 1
                        if len(by) == 1:
                            ch, cnt = next(iter(by.items()))
                            if cnt == 1:
                                self.show_toast(
                                    ch, notifiable[0].text, notifiable[0].title,
                                    self.settings.is_sound(ch),
                                )
                            else:
                                self.show_toast(
                                    ch, f"Новых новостей: {cnt}", ch,
                                    self.settings.is_sound(ch),
                                )
                        else:
                            lines = [
                                f"{c}: {n}"
                                for c, n in sorted(by.items(), key=lambda x: -x[1])[:5]
                            ]
                            self.show_toast(
                                "Несколько каналов",
                                "Новые:\n" + "\n".join(lines),
                                sound_enabled_for_channel=all(
                                    self.settings.is_sound(c) for c in by
                                ),
                            )
            else:
                self.update_tray_icon()

        def err(_msg):
            self._poll_busy = False

        self._run_db("poll", {"after_id": after_id}, on_ok=ok, on_err=err)

    def play_sound(self):
        if not self.settings.sound_enabled:
            return
        if SOUND_FILE.exists():
            self.player.stop()
            self.player.setMedia(QMediaContent(QUrl.fromLocalFile(str(SOUND_FILE))))
            self.player.setVolume(100)
            self.player.play()
        else:
            QApplication.beep()

    def show_toast(self, channel, message, title="", sound_enabled_for_channel=None):
        if self.current_toast:
            try:
                self.current_toast.close()
            except Exception:
                pass
        if sound_enabled_for_channel is None:
            sound_enabled_for_channel = self.settings.is_sound(channel)
        final = self.settings.sound_enabled and sound_enabled_for_channel
        if final:
            self.play_sound()
        full = f"{title}\n\n{message}" if title else message
        self.current_toast = ToastNotification(
            channel, full, final, detail=self.settings.notification_detail
        )
        self.current_toast.readRequested.connect(self.open_from_toast)

    def open_from_toast(self, channel_name):
        self.show_window(refresh=False)
        if channel_name == "Несколько каналов":
            self.main_window.refresh()
            return

        def select_target():
            for ch in self.storage.channels:
                if ch.name == channel_name:
                    self.main_window.onChannelSelected(ch)
                    return

            def loaded(channels):
                self.storage.channels = channels
                self.main_window.sidebar.setChannels(channels)
                for ch in channels:
                    if ch.name == channel_name:
                        self.main_window.onChannelSelected(ch)
                        break
            self._run_db("load_channels", on_ok=loaded)

        QTimer.singleShot(80, select_target)

    def update_tray_icon(self):
        pix = QPixmap(64, 64)
        pix.fill(Qt.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.Antialiasing)
        p.setBrush(QColor("#2288dd"))
        p.setPen(Qt.NoPen)
        p.drawEllipse(8, 8, 48, 48)
        p.setPen(QColor(255, 255, 255))
        p.setFont(QFont("Segoe UI", 26, QFont.Bold))
        p.drawText(pix.rect(), Qt.AlignCenter, "N")
        p.end()
        self.tray.setIcon(QIcon(pix))

    def setup_tray(self):
        self.tray = QSystemTrayIcon(self)
        self.update_tray_icon()
        self.tray.setToolTip("Telegram News")
        menu = QMenu()
        menu.setStyleSheet(
            f"QMenu {{ background: {Theme.CARD}; color: {Theme.TEXT}; border: 1px solid {Theme.BORDER}; "
            f"border-radius: 8px; padding: 6px; }}"
            f"QMenu::item:selected {{ background: {Theme.CARD_ACTIVE}; }}"
            f"QMenu::separator {{ height: 1px; background: {Theme.BORDER}; margin: 4px 8px; }}"
        )
        menu.addAction(QAction("Открыть", self, triggered=self.show_window))
        self.sound_action = QAction("Звук", self)
        self.sound_action.setCheckable(True)
        self.sound_action.setChecked(self.settings.sound_enabled)
        self.sound_action.triggered.connect(self._tog_sound)
        menu.addAction(self.sound_action)
        self.notify_action = QAction("Уведомления", self)
        self.notify_action.setCheckable(True)
        self.notify_action.setChecked(self.settings.notifications_enabled)
        self.notify_action.triggered.connect(self._tog_notify)
        menu.addAction(self.notify_action)

        notif_type_menu = menu.addMenu("Вид уведомления")
        self.detail_full_action = QAction("Полное — текст новости", self, checkable=True)
        self.detail_minimal_action = QAction("Минимальное — без текста", self, checkable=True)
        self._notif_action_group = QActionGroup(self)
        self._notif_action_group.setExclusive(True)
        self._notif_action_group.addAction(self.detail_full_action)
        self._notif_action_group.addAction(self.detail_minimal_action)
        self.detail_full_action.triggered.connect(lambda: self._set_notif_detail("full"))
        self.detail_minimal_action.triggered.connect(lambda: self._set_notif_detail("minimal"))
        self.sync_notification_detail_actions()
        notif_type_menu.addAction(self.detail_full_action)
        notif_type_menu.addAction(self.detail_minimal_action)

        menu.addSeparator()
        menu.addAction(QAction("Настройки", self, triggered=lambda: self.main_window.open_settings()))
        menu.addSeparator()
        menu.addAction(QAction("Выход", self, triggered=self.quit_app))
        self.tray.setContextMenu(menu)
        self.tray.show()
        self.tray.activated.connect(
            lambda r: self.show_window() if r in (QSystemTrayIcon.DoubleClick, QSystemTrayIcon.Trigger) else None
        )

    def sync_notification_detail_actions(self):
        full = self.settings.notification_detail != "minimal"
        self.detail_full_action.setChecked(full)
        self.detail_minimal_action.setChecked(not full)

    def _set_notif_detail(self, detail: str):
        self.settings.notification_detail = "minimal" if detail == "minimal" else "full"
        self.settings.save()
        self.sync_notification_detail_actions()

    def _tog_sound(self, c):
        self.settings.sound_enabled = c
        self.settings.save()
        self.main_window.content.set_sound_icon(c)

    def _tog_notify(self, c):
        self.settings.notifications_enabled = c
        self.settings.save()

    def show_window(self, refresh=True):
        if self.main_window.isMinimized():
            self.main_window.showNormal()
        else:
            self.main_window.show()
        self.main_window.setWindowState(
            (self.main_window.windowState() & ~Qt.WindowMinimized) | Qt.WindowActive
        )
        self.main_window.raise_()
        self.main_window.activateWindow()
        if refresh:
            self.main_window.refresh()

    def _all_running_workers(self):
        workers = []
        seen = set()

        def add(task):
            if task is None:
                return
            ident = id(task)
            if ident in seen:
                return
            seen.add(ident)
            try:
                if task.isRunning():
                    workers.append(task)
            except RuntimeError:
                pass

        for task in list(getattr(self, "_workers", [])):
            add(task)

        main = getattr(self, "main_window", None)
        if main is not None:
            for task in list(getattr(main, "_workers", [])):
                add(task)
            ai = getattr(main, "_ai_window", None)
            if ai is not None:
                add(getattr(ai, "_db_task", None))
                add(getattr(ai, "_ai_task", None))
        for task in list(_LIVE_THREADS):
            add(task)
        return workers

    def quit_app(self):
        if getattr(self, "_shutting_down", False):
            return
        self._shutting_down = True

        try:
            self.settings.save()
        except Exception:
            pass

        try:
            self.poll_timer.stop()
        except Exception:
            pass

        main = getattr(self, "main_window", None)
        ai = getattr(main, "_ai_window", None) if main is not None else None
        if ai is not None:
            ai_task = getattr(ai, "_ai_task", None)
            if ai_task is not None:
                try:
                    ai_task.cancel()
                except Exception:
                    pass

        try:
            if self.current_toast:
                self.current_toast.close()
        except Exception:
            pass
        try:
            self.tray.hide()
        except Exception:
            pass
        try:
            if main is not None:
                main.hide()
        except Exception:
            pass
        try:
            if ai is not None:
                ai.hide()
        except Exception:
            pass

        deadline = time.monotonic() + 12.0
        while time.monotonic() < deadline:
            running = self._all_running_workers()
            if not running:
                break
            for task in running:
                try:
                    task.wait(100)
                except RuntimeError:
                    pass
            QCoreApplication.processEvents()

        running = self._all_running_workers()
        if running:
            self._exit_pending_threads = list(running)
            for task in self._exit_pending_threads:
                try:
                    task.finished.connect(self._finish_quit_when_ready, Qt.UniqueConnection)
                except (TypeError, RuntimeError):
                    pass
            QTimer.singleShot(100, self._finish_quit_when_ready)
            return

        self._final_quit()

    def _finish_quit_when_ready(self):
        if not getattr(self, "_shutting_down", False):
            return
        if self._all_running_workers():
            QTimer.singleShot(100, self._finish_quit_when_ready)
            return
        self._final_quit()

    def _final_quit(self):
        if getattr(self, "_quit_finalized", False):
            return
        self._quit_finalized = True
        try:
            self.storage.close()
        except Exception:
            pass
        server = getattr(self, "_instance_server", None)
        if server is not None:
            try:
                server.close()
            except Exception:
                pass
        self.quit()


if __name__ == "__main__":
    app = TrayApp(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    if getattr(app, "_secondary_instance", False):
        sys.exit(app.exec_())
    try:
        sys.exit(app.exec_())
    except Exception as e:
        print("Критическая ошибка:", e)
        sys.exit(1)