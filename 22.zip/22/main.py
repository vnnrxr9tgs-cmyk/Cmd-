from flask import Flask, render_template, jsonify, request
import json, os
from datetime import datetime, timedelta
import markdown
import re

app = Flask(__name__)

OUTPUTS_DIR = "outputs"


@app.route("/")
def index():
    files = [f for f in os.listdir(OUTPUTS_DIR) if f.endswith(".json")]
    news_list = []

    # Текущее время для сравнения
    now = datetime.now()

    for f in files:
        with open(os.path.join(OUTPUTS_DIR, f), "r", encoding="utf-8") as file:
            data = json.load(file)

            text = data["processed_text"]

            # анализ
            blocks = [b for b in text.split("\n\n") if b.strip()]
            articles_count = len(blocks)
            chars_count = len(text)

            # 🔥 извлекаем заголовки (**...**)
            titles = re.findall(r"\*\*(.*?)\*\*", text)

            # Парсим дату обработки
            processed_date = datetime.fromisoformat(data["processed_at"])

            # Проверяем, старше ли статья 24 часов
            is_old = (now - processed_date) > timedelta(hours=24)

            news_list.append({
                "id": f,
                "title": data["original_filename"].replace(".docx", ""),
                "date": processed_date.strftime("%d.%m.%Y %H:%M"),
                "language": data.get("language", "unknown"),
                "articles_count": articles_count,
                "chars_count": chars_count,
                "titles": titles[:5],
                "full_text": text,
                "is_old": is_old  # Добавляем флаг "старости"
            })

    news_list.sort(key=lambda x: datetime.strptime(x["date"], "%d.%m.%Y %H:%M"), reverse=True)

    return render_template("index.html", news=news_list)


@app.route("/news/<filename>")
def detail(filename):
    path = os.path.join(OUTPUTS_DIR, filename)

    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        html_text = markdown.markdown(data["processed_text"], extensions=["extra"])

        return render_template("detail.html", data=data, html_text=html_text, filename=filename)

    return "Файл не найден", 404


@app.route("/api/search")
def search():
    query = request.args.get('q', '').lower().strip()
    if not query:
        return jsonify([])

    files = [f for f in os.listdir(OUTPUTS_DIR) if f.endswith(".json")]
    results = []
    search_terms = query.split()

    for f in files:
        with open(os.path.join(OUTPUTS_DIR, f), "r", encoding="utf-8") as file:
            data = json.load(file)
            text = data["processed_text"].lower()

            # проверяем, содержит ли текст все слова
            if all(term in text for term in search_terms):
                # находим позицию первого совпадения для якоря
                first_pos = -1
                for term in search_terms:
                    pos = text.find(term)
                    if pos != -1 and (first_pos == -1 or pos < first_pos):
                        first_pos = pos

                results.append({
                    "id": f,
                    "title": data["original_filename"].replace(".docx", ""),
                    "language": data.get("language", "unknown"),
                    "date": datetime.fromisoformat(data["processed_at"]).strftime("%d.%m.%Y %H:%M"),
                    "first_match_pos": first_pos
                })

    return jsonify(results)


if __name__ == "__main__":
    app.run(debug=True, port=5000)