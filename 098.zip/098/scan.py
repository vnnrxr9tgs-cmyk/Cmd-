"""
Сервис синхронизации файлов по дате
Сканирует только папку с сегодняшней датой: ГОД/МЕСЯЦ/ДЕНЬ/ЧАС
"""
import os
import shutil
import hashlib
import json
import logging
import time
from datetime import datetime
from typing import Set, Optional

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('file_sync.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class FileSyncService:

    def __init__(self, config_file='sync_config.json'):
        self.config_file = config_file
        self.config = self.load_config()
        self.target_folder = self.config.get('target_folder', 'documents')
        self.source_folders = self.config.get('source_folders', [])
        self.state_file = self.config.get('state_file', 'sync_state.json')
        self.sync_state = self.load_state()
        self.supported_extensions = self.config.get('supported_extensions', [])
        self.max_file_size = self.config.get('max_file_size', 500 * 1024 * 1024)
        self.scan_interval = self.config.get('scan_interval', 60)

        # Настройки структуры папок
        self.folder_structure = self.config.get('folder_structure', 'year/month/day/hour')

        logger.info(f'📁 FileSyncService инициализирован')
        logger.info(f'📂 Целевая папка: {self.target_folder}')
        logger.info(f'📂 Исходных папок: {len(self.source_folders)}')
        logger.info(f'⏱️  Интервал: {self.scan_interval} сек')
        logger.info(f'📅 Структура: {self.folder_structure}')

    def load_config(self) -> dict:
        default_config = {
            'target_folder': 'documents',
            'source_folders': [
                'D:/data',
                '//server/archive'
            ],
            'state_file': 'sync_state.json',
            'scan_interval': 60,
            'max_file_size': 500 * 1024 * 1024,
            'preserve_structure': False,
            'conflict_resolution': 'rename',
            'folder_structure': 'year/month/day/hour',
            'scan_current_hour': True,
            'scan_previous_hour': True,
            'supported_extensions': [
                '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
                '.txt', '.csv', '.log', '.md', '.py', '.js', '.html', '.css',
                '.json', '.xml', '.yaml', '.yml', '.ini', '.cfg',
                '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg',
                '.wav', '.mp3', '.ogg', '.flac', '.m4a', '.aac',
                '.mp4', '.webm', '.avi', '.mov', '.mkv',
                '.zip', '.rar', '.7z'
            ]
        }

        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                default_config.update(config)
            else:
                self.save_config(default_config)
        except Exception as e:
            logger.error(f'Ошибка загрузки конфигурации: {e}')

        return default_config

    def save_config(self, config: dict = None):
        if config:
            self.config = config
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f'Ошибка сохранения конфигурации: {e}')

    def load_state(self) -> dict:
        try:
            if os.path.exists(self.state_file):
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    state = json.load(f)
                logger.info(f'📊 Состояние загружено: {len(state)} файлов')
                return state
        except Exception as e:
            logger.error(f'Ошибка загрузки состояния: {e}')
        return {}

    def save_state(self):
        try:
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(self.sync_state, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f'Ошибка сохранения состояния: {e}')

    def get_today_paths(self) -> list:
        """
        Формирует пути для сегодняшней даты

        Структура: ГОД/МЕСЯЦ/ДЕНЬ/ЧАС

        Returns:
            список путей для сканирования (текущий час + предыдущий)
        """
        now = datetime.now()
        paths = []

        # Текущий час
        current_hour_path = os.path.join(
            str(now.year),
            f"{now.month:02d}",
            f"{now.day:02d}",
            f"{now.hour:02d}"
        )
        paths.append(current_hour_path)

        # Предыдущий час (если включено в настройках)
        if self.config.get('scan_previous_hour', True):
            if now.hour == 0:
                # Если сейчас 00:XX — предыдущий час был вчера в 23:XX
                yesterday = datetime(now.year, now.month, now.day) - time.timedelta(days=1)
                previous_hour_path = os.path.join(
                    str(yesterday.year),
                    f"{yesterday.month:02d}",
                    f"{yesterday.day:02d}",
                    "23"
                )
            else:
                previous_hour_path = os.path.join(
                    str(now.year),
                    f"{now.month:02d}",
                    f"{now.day:02d}",
                    f"{now.hour - 1:02d}"
                )
            paths.append(previous_hour_path)

        logger.info(f'📅 Сегодня: {now.strftime("%Y-%m-%d %H:%M")}')
        logger.info(f'📂 Пути для сканирования:')
        for p in paths:
            logger.info(f'   📁 {p}')

        return paths

    def get_file_hash(self, file_path: str) -> str:
        """Быстрый хеш файла (первые 8 КБ)"""
        try:
            hasher = hashlib.md5()
            with open(file_path, 'rb') as f:
                chunk = f.read(8192)
                hasher.update(chunk)
            return hasher.hexdigest()
        except:
            return ''

    def is_supported_file(self, file_path: str) -> bool:
        """Проверка, поддерживается ли файл"""
        ext = os.path.splitext(file_path)[1].lower()
        if ext not in self.supported_extensions:
            return False

        try:
            size = os.path.getsize(file_path)
            if size > self.max_file_size:
                logger.debug(f'Файл {file_path} слишком большой ({size} байт)')
                return False
        except:
            return False

        return True

    def scan_folder(self, folder_path: str) -> Set[str]:
        """
        Сканирование конкретной папки (без подпапок)
        """
        files = set()

        if not os.path.exists(folder_path):
            return files

        try:
            for item in os.listdir(folder_path):
                item_path = os.path.join(folder_path, item)

                # Пропускаем скрытые
                if item.startswith('.'):
                    continue

                # Только файлы, не папки
                if os.path.isfile(item_path):
                    if self.is_supported_file(item_path):
                        files.add(item_path)

        except Exception as e:
            logger.error(f'Ошибка сканирования {folder_path}: {e}')

        return files

    def should_sync_file(self, file_path: str) -> bool:
        """Проверка, нужно ли копировать файл"""
        try:
            file_stat = os.stat(file_path)
            file_info = {
                'size': file_stat.st_size,
                'modified': file_stat.st_mtime,
                'hash': self.get_file_hash(file_path)
            }
        except:
            return False

        # Проверяем состояние
        if file_path in self.sync_state:
            stored = self.sync_state[file_path]
            if (stored.get('size') == file_info['size'] and
                    stored.get('modified') == file_info['modified'] and
                    stored.get('hash') == file_info['hash']):
                return False  # Не изменился

        # Обновляем состояние
        self.sync_state[file_path] = {
            'size': file_info['size'],
            'modified': file_info['modified'],
            'hash': file_info['hash'],
            'synced_at': datetime.now().isoformat()
        }

        return True

    def copy_file(self, source_path: str, source_root: str) -> bool:
        """
        Копирование файла в целевую папку

        Args:
            source_path: полный путь к исходному файлу
            source_root: корневая папка источника (для формирования имени)
        """
        try:
            filename = os.path.basename(source_path)

            # Если нужно сохранить структуру
            if self.config.get('preserve_structure', False):
                rel_path = os.path.relpath(os.path.dirname(source_path), source_root)
                safe_path = rel_path.replace(os.sep, '_')
                target_name = f"{safe_path}_{filename}" if safe_path != '.' else filename
            else:
                # Плоская структура — только имя файла
                target_name = filename

            target_path = os.path.join(self.target_folder, target_name)

            # Создаем целевую папку
            os.makedirs(self.target_folder, exist_ok=True)

            # Обработка конфликтов
            if os.path.exists(target_path):
                conflict = self.config.get('conflict_resolution', 'rename')

                if conflict == 'skip':
                    logger.debug(f'⏭️ Пропущен (существует): {target_name}')
                    return False
                elif conflict == 'rename':
                    base, ext = os.path.splitext(target_name)
                    counter = 1
                    while os.path.exists(os.path.join(self.target_folder, f'{base}_{counter}{ext}')):
                        counter += 1
                    target_name = f'{base}_{counter}{ext}'
                    target_path = os.path.join(self.target_folder, target_name)
                # 'overwrite' — просто перезаписываем

            # Копируем
            shutil.copy2(source_path, target_path)

            logger.info(f'✅ {os.path.basename(source_path)} → {target_name}')
            return True

        except Exception as e:
            logger.error(f'❌ Ошибка копирования {source_path}: {e}')
            return False

    def cleanup_old_files(self):
        """Удаление файлов, которых больше нет в исходных папках"""
        to_remove = []

        for source_path, info in self.sync_state.items():
            if isinstance(info, dict) and 'target' in info:
                if not os.path.exists(source_path):
                    target_path = info['target']
                    if os.path.exists(target_path):
                        try:
                            os.remove(target_path)
                            logger.info(f'🗑️ Удален: {os.path.basename(target_path)}')
                        except Exception as e:
                            logger.error(f'Ошибка удаления {target_path}: {e}')
                    to_remove.append(source_path)

        for path in to_remove:
            del self.sync_state[path]

    def sync(self):
        """Основной метод синхронизации"""
        logger.info('=' * 60)
        logger.info(f'🚀 Синхронизация — {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        start_time = time.time()

        total_found = 0
        total_copied = 0

        # Создаем целевую папку
        os.makedirs(self.target_folder, exist_ok=True)

        # Получаем пути для сегодняшней даты
        today_paths = self.get_today_paths()

        # Сканируем каждую исходную папку
        for source_root in self.source_folders:
            if not os.path.exists(source_root):
                logger.warning(f'❌ Исходная папка не найдена: {source_root}')
                continue

            logger.info(f'📂 Источник: {source_root}')

            for date_path in today_paths:
                full_path = os.path.join(source_root, date_path)

                if not os.path.exists(full_path):
                    logger.info(f'   📁 {date_path} — не существует')
                    continue

                logger.info(f'   📁 {date_path} — сканирование...')
                files = self.scan_folder(full_path)

                if not files:
                    logger.info(f'      (пусто)')
                    continue

                logger.info(f'      Найдено файлов: {len(files)}')
                total_found += len(files)

                for file_path in sorted(files):
                    if self.should_sync_file(file_path):
                        if self.copy_file(file_path, source_root):
                            total_copied += 1

        # Удаляем старые
        if self.config.get('cleanup_on_sync', True):
            self.cleanup_old_files()

        # Сохраняем состояние
        self.save_state()

        elapsed = time.time() - start_time
        logger.info(f'✅ Синхронизация завершена за {elapsed:.2f} сек')
        logger.info(f'📊 Найдено: {total_found} | Скопировано: {total_copied}')
        logger.info('=' * 60)

        return total_found, total_copied

    def run_continuous(self):
        """Непрерывная синхронизация"""
        logger.info(f'🔄 Запуск непрерывной синхронизации')
        logger.info(f'⏱️  Интервал: {self.scan_interval} сек')
        logger.info(f'📅 Сканируем только сегодняшнюю дату')
        logger.info('Нажмите Ctrl+C для остановки\n')

        try:
            while True:
                self.sync()

                # Ждем до следующего сканирования
                logger.info(f'⏳ Ожидание {self.scan_interval} сек...\n')
                time.sleep(self.scan_interval)

        except KeyboardInterrupt:
            logger.info('\n⏹️ Синхронизация остановлена')

    def show_status(self):
        """Показать текущий статус"""
        now = datetime.now()
        today_paths = self.get_today_paths()

        print('\n' + '=' * 60)
        print('📊 СТАТУС СИНХРОНИЗАЦИИ')
        print('=' * 60)
        print(f'📅 Сегодня: {now.strftime("%Y-%m-%d %H:%M")}')
        print(f'📂 Целевая папка: {self.target_folder}')
        print(f'📂 Исходных папок: {len(self.source_folders)}')
        print(f'📁 Сканируемые пути:')
        for p in today_paths:
            print(f'   📁 {p}')
        print(f'📊 Файлов в состоянии: {len(self.sync_state)}')
        print(f'⏱️  Интервал: {self.scan_interval} сек')
        print('=' * 60 + '\n')

        # Проверяем существование папок
        for source_root in self.source_folders:
            exists = '✅' if os.path.exists(source_root) else '❌'
            print(f'{exists} {source_root}')
            for date_path in today_paths:
                full_path = os.path.join(source_root, date_path)
                if os.path.exists(full_path):
                    file_count = len([f for f in os.listdir(full_path) if os.path.isfile(os.path.join(full_path, f))])
                    print(f'   📁 {date_path} — {file_count} файлов')
                else:
                    print(f'   📁 {date_path} — не существует')


def create_default_config():
    """Создание файла конфигурации по умолчанию"""
    config = {
        'target_folder': 'documents',
        'source_folders': [
            'D:/data/archive',
            '//server/share/docs'
        ],
        'state_file': 'sync_state.json',
        'scan_interval': 60,
        'max_file_size': 524288000,
        'preserve_structure': False,
        'conflict_resolution': 'rename',
        'folder_structure': 'year/month/day/hour',
        'scan_current_hour': True,
        'scan_previous_hour': True,
        'cleanup_on_sync': True,
        'supported_extensions': [
            '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
            '.txt', '.csv', '.log', '.md', '.py', '.js', '.html', '.css',
            '.json', '.xml', '.yaml', '.yml', '.ini', '.cfg',
            '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg',
            '.wav', '.mp3', '.ogg', '.flac', '.m4a', '.aac',
            '.mp4', '.webm', '.avi', '.mov', '.mkv',
            '.zip', '.rar', '.7z'
        ]
    }

    with open('sync_config.json', 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4, ensure_ascii=False)

    print('✅ Создан файл sync_config.json')
    print('📝 Настройте source_folders под вашу систему')


if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1:
        command = sys.argv[1]

        if command == '--init':
            create_default_config()
        elif command == '--once':
            service = FileSyncService()
            service.sync()
        elif command == '--status':
            service = FileSyncService()
            service.show_status()
        elif command == '--config':
            service = FileSyncService()
            print(json.dumps(service.config, indent=4, ensure_ascii=False))
        else:
            print('Использование:')
            print('  python file_sync_service.py --init    - создать конфигурацию')
            print('  python file_sync_service.py --once    - однократная синхронизация')
            print('  python file_sync_service.py --status  - показать статус')
            print('  python file_sync_service.py --config  - показать конфигурацию')
            print('  python file_sync_service.py           - запустить сервис')
    else:
        service = FileSyncService()
        service.run_continuous()