import os
from datetime import timedelta


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-here-change-in-production'

    # Настройки сессии
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=30)
    SESSION_COOKIE_SECURE = True  # В production включить HTTPS
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'

    # Защита от брутфорса
    MAX_LOGIN_ATTEMPTS = 5
    LOCKOUT_TIME = 300  # 5 минут в секундах

    # Список пользователей (username: password)
    USERS = {
        'admin': 'admin123',
        'user': 'user123',
        'manager': 'manager123',
        'guest':'guest'
        # Добавьте новых пользователей здесь
    }
    PAGE_ACCESS = {
        '/': ['admin', 'user', 'manager', 'guest'],  # Доступно всем
        '/dashboard': ['admin', 'user', 'manager'],  # Все кроме гостей
        '/admin': ['admin'],  # Только админ
        '/manager': ['admin', 'manager'],  # Админ и менеджер
        '/users': ['admin'],  # Только админ
        '/settings': ['admin', 'manager'],  # Админ и менеджер
        '/reports': ['admin', 'manager', 'user'],  # Все кроме гостя
        '/analytics': ['admin', 'user', 'manager'],
        '/test': ['user', 'manager'],
    }