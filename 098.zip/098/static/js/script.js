// Глобальные переменные
let mapInstance = null;
let marker = null;
let currentCoords = null;

// Загрузка координат с сервера
async function loadCoordinates() {
    try {
        const response = await fetch('/api/coordinates');
        const data = await response.json();
        renderTable(data);
        updateBadge(data.length);
        return data;
    } catch (error) {
        console.error('Ошибка загрузки координат:', error);
        document.getElementById('coordsBody').innerHTML = `
            <tr>
                <td colspan="4" style="text-align:center; padding: 30px; color: #e53e3e;">
                    ❌ Ошибка загрузки данных
                </td>
            </tr>
        `;
    }
}

// Рендер таблицы
function renderTable(coords) {
    const tbody = document.getElementById('coordsBody');

    if (!coords || coords.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" style="text-align:center; padding: 30px; color: #718096;">
                    📭 Нет данных
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = coords.map((item, index) => `
        <tr>
            <td class="num-cell">${index + 1}</td>
            <td class="coord-cell">${item.latitude.toFixed(5)}</td>
            <td class="coord-cell">${item.longitude.toFixed(5)}</td>
            <td class="action-cell">
                <button class="btn-show" data-id="${item.id}">
                    👁️ Показать
                </button>
            </td>
        </tr>
    `).join('');

    // Обработчики для кнопок "Показать"
    document.querySelectorAll('.btn-show').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = parseInt(this.dataset.id);
            const coord = coords.find(c => c.id === id);
            if (coord) {
                openMap(coord.latitude, coord.longitude);
            }
        });
    });
}

// Обновление счетчика
function updateBadge(count) {
    const badge = document.getElementById('countBadge');
    badge.textContent = `📍 ${count} записей`;
}

// Открытие карты в модальном окне
function openMap(lat, lng) {
    const modal = document.getElementById('mapModal');
    const label = document.getElementById('modalCoordLabel');

    // Обновляем подпись
    label.textContent = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;

    // Показываем модальное окно
    modal.classList.add('active');

    // Если карта уже создана - обновляем
    if (mapInstance) {
        mapInstance.setView([lat, lng], 13);
        if (marker) {
            marker.setLatLng([lat, lng]);
        } else {
            marker = L.marker([lat, lng]).addTo(mapInstance);
        }
        // Обновляем размер карты
        setTimeout(() => mapInstance.invalidateSize(), 100);
        return;
    }

    // Создаем карту в первый раз
    mapInstance = L.map('map').setView([lat, lng], 13);

    // Базовый слой OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(mapInstance);

    // Добавляем маркер
    marker = L.marker([lat, lng]).addTo(mapInstance);

    // Загружаем границы стран из статического файла
    fetch('/static/data/countries.geo.json')
        .then(response => response.json())
        .then(data => {
            L.geoJSON(data, {
                style: {
                    color: '#2c3e50',
                    weight: 1.5,
                    opacity: 0.7,
                    fillColor: 'transparent',
                    fillOpacity: 0
                }
            }).addTo(mapInstance);
        })
        .catch(err => {
            console.warn('Не удалось загрузить границы стран:', err);
        });

    // Обновляем размер после отображения
    setTimeout(() => mapInstance.invalidateSize(), 200);
}

// Закрытие модального окна
function closeModal() {
    document.getElementById('mapModal').classList.remove('active');
}

// Инициализация
document.addEventListener('DOMContentLoaded', function() {
    // Загружаем координаты
    loadCoordinates();

    // Обработчики закрытия модального окна
    document.getElementById('modalCloseBtn').addEventListener('click', closeModal);
    document.getElementById('modalCloseBtn2').addEventListener('click', closeModal);
    document.getElementById('mapModal').addEventListener('click', function(e) {
        if (e.target === this) closeModal();
    });

    // Кнопка обновления
    document.getElementById('refreshBtn').addEventListener('click', function() {
        this.textContent = '⏳ Загрузка...';
        this.disabled = true;
        loadCoordinates().finally(() => {
            this.textContent = '🔄 Обновить';
            this.disabled = false;
        });
    });

    // Закрытие по ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeModal();
    });
});

// Экспортируем функции для возможного использования извне
window.loadCoordinates = loadCoordinates;
window.openMap = openMap;
window.closeModal = closeModal;