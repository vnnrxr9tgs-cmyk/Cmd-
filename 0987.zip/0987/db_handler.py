"""
Простой модуль для SQL Server + логирование изменений в CSV
"""
import pyodbc
import csv
import os
from datetime import datetime

DB = {
    'server': 'localhost\\SQLEXPRESS',
    'database': 'YourDatabase',
    'username': 'sa',
    'password': 'your_password',
    'driver': '{ODBC Driver 17 for SQL Server}',
}

LOG_FILE = 'change_log.csv'

# ===== ТАБЛИЦА ДЛЯ ВКЛАДКИ 1 (поиск) =====
TABLE1 = 'files'
COL_FILENAME = 'filename'
COL_DIGITS = 'digits'
COL_SECONDNAME = 'secondname'
COL_DATE='COL_DATE' #реальноеназвание

# ===== ТАБЛИЦА ДЛЯ ВКЛАДКИ 2 (поиск + изменение) =====
TABLE2 = 'descriptions'
COL2_SECONDNAME = 'secondname'
COL2_3NAME = '3name'


# ✅ ДОБАВЬ ЭТУ ФУНКЦИЮ
def _get_conn():
    """Подключение к SQL Server"""
    return pyodbc.connect(
        f"DRIVER={DB['driver']};SERVER={DB['server']};"
        f"DATABASE={DB['database']};UID={DB['username']};PWD={DB['password']}"
    )


def search_by_filename(query_text):
    """Вкладка 1: LIKE по filename → secondname (таблица TABLE1)"""
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute(
        f"SELECT [{COL_SECONDNAME}] FROM {TABLE1} WHERE [{COL_FILENAME}] LIKE ?",
        [f"%{query_text}%"]
    )
    result = [dict(zip([c[0] for c in cursor.description], row)) for row in cursor.fetchall()]
    conn.close()
    return result


def search_by_digits(query_text):
    """Вкладка 1: точный поиск по digits → secondname (таблица TABLE1)"""
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute(
        f"SELECT [{COL_SECONDNAME}] FROM {TABLE1} WHERE [{COL_DIGITS}] = ?",
        [query_text]
    )
    result = [dict(zip([c[0] for c in cursor.description], row)) for row in cursor.fetchall()]
    conn.close()
    return result


def search_by_secondname(query_text):
    """Вкладка 2: точный поиск по secondname → 3name (таблица TABLE2)"""
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute(
        f"SELECT [{COL2_3NAME}] FROM {TABLE2} WHERE [{COL2_SECONDNAME}] = ?",
        [query_text]
    )
    result = [dict(zip([c[0] for c in cursor.description], row)) for row in cursor.fetchall()]
    conn.close()
    return result


def update_3name(secondname_value, new_3name_value, motivation=""):
    """Вкладка 2: изменить 3name (таблица TABLE2)"""
    conn = _get_conn()
    cursor = conn.cursor()

    cursor.execute(
        f"SELECT [{COL2_3NAME}] FROM {TABLE2} WHERE [{COL2_SECONDNAME}] = ?",
        [secondname_value]
    )
    old_row = cursor.fetchone()
    old_value = old_row[0] if old_row else "НЕ НАЙДЕНО"

    cursor.execute(
        f"UPDATE {TABLE2} SET [{COL2_3NAME}] = ? WHERE [{COL2_SECONDNAME}] = ?",
        [new_3name_value, secondname_value]
    )
    conn.commit()
    rows_affected = cursor.rowcount
    conn.close()

    file_exists = os.path.exists(LOG_FILE)
    with open(LOG_FILE, 'a', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f, delimiter=';')
        if not file_exists:
            writer.writerow(['Дата и время', 'Старое значение', 'Новое значение', 'Мотивация'])
        writer.writerow([
            datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            old_value,
            new_3name_value,
            motivation
        ])

    return rows_affected > 0, str(old_value)


def get_data_by_date(days=1, search_text=""):
    """
    Получение данных за указанное количество дней с поиском
    days: 1, 3, 7, 30
    search_text: текст для LIKE поиска (пустая строка = все)
    """
    conn = _get_conn()
    cursor = conn.cursor()

    # Базовый запрос
    sql = f"""
        SELECT * FROM {TABLE1} 
        WHERE [{COL_DATE}] >= DATEADD(DAY, -?, GETDATE())
    """
    params = [days]

    # Добавляем LIKE если есть текст поиска
    if search_text:
        sql += f" AND ([{COL_FILENAME}] LIKE ? OR [{COL_SECONDNAME}] LIKE ?)"
        params.append(f"%{search_text}%")
        params.append(f"%{search_text}%")

    sql += " ORDER BY [{COL_DATE}] DESC"

    cursor.execute(sql, params)
    columns = [c[0] for c in cursor.description]
    result = [dict(zip(columns, row)) for row in cursor.fetchall()]
    conn.close()
    return result