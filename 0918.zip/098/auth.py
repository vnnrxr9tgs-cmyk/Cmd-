import bcrypt
import time
from datetime import datetime, timedelta
from flask import session, request, abort
from functools import wraps
from config import Config


class AuthManager:
    def __init__(self):
        self.failed_attempts = {}  # Хранит попытки входа
        self.locked_ips = {}  # Заблокированные IP

    def hash_password(self, password):
        """Хеширование пароля"""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt)

    def verify_password(self, password, hashed):
        """Проверка пароля"""
        return bcrypt.checkpw(password.encode('utf-8'), hashed)

    def check_login_attempts(self, ip):
        """Проверка количества попыток входа"""
        current_time = time.time()

        # Очищаем старые записи
        if ip in self.failed_attempts:
            # Удаляем записи старше блокировки
            self.failed_attempts[ip] = [
                t for t in self.failed_attempts[ip]
                if current_time - t < Config.LOCKOUT_TIME
            ]

        # Проверяем блокировку
        if ip in self.locked_ips:
            if current_time - self.locked_ips[ip] < Config.LOCKOUT_TIME:
                return False
            else:
                del self.locked_ips[ip]

        # Проверяем количество попыток
        if ip in self.failed_attempts:
            if len(self.failed_attempts[ip]) >= Config.MAX_LOGIN_ATTEMPTS:
                self.locked_ips[ip] = current_time
                return False

        return True

    def register_failed_attempt(self, ip):
        """Регистрация неудачной попытки"""
        current_time = time.time()
        if ip not in self.failed_attempts:
            self.failed_attempts[ip] = []
        self.failed_attempts[ip].append(current_time)

        # Если превышен лимит - блокируем
        if len(self.failed_attempts[ip]) >= Config.MAX_LOGIN_ATTEMPTS:
            self.locked_ips[ip] = current_time


# Создаем экземпляр менеджера
auth_manager = AuthManager()


# Декоратор для защиты маршрутов
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            abort(401)
        return f(*args, **kwargs)

    return decorated_function


# Декоратор для ограничения скорости запросов
def rate_limit(max_requests=60, window=60):
    """Ограничение количества запросов"""
    requests = {}

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            ip = request.remote_addr
            current_time = time.time()

            # Очищаем старые записи
            if ip in requests:
                requests[ip] = [t for t in requests[ip] if current_time - t < window]

            # Проверяем лимит
            if ip in requests and len(requests[ip]) >= max_requests:
                abort(429)  # Too Many Requests

            # Регистрируем запрос
            if ip not in requests:
                requests[ip] = []
            requests[ip].append(current_time)

            return f(*args, **kwargs)

        return decorated_function

    return decorator