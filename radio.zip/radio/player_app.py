#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UDP Radio Player — PyQt5 клиент для приёма и воспроизведения аудиопотока
от GNU Radio (напрямую или через relay-сервер).

Зависимости: pip install PyQt5 sounddevice numpy
"""

import json
import os
import socket
import sys
import threading
import time
from pathlib import Path

import numpy as np
import sounddevice as sd

from PyQt5.QtCore import (
    Qt, QTimer, pyqtSignal, QObject, QSettings
)
from PyQt5.QtGui import QFont, QCloseEvent
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QLineEdit, QPushButton,
    QCheckBox, QComboBox, QSlider, QProgressBar, QGroupBox, QFormLayout,
    QVBoxLayout, QHBoxLayout, QGridLayout, QMessageBox, QFrame, QSizePolicy
)


APP_TITLE = "UDP Radio Player"
CONFIG_PATH = Path.home() / ".udp_radio_player.json"

FORMAT_OPTIONS = {
    "float32 (GNU Radio: Float)": np.float32,
    "int16 (GNU Radio: Short)": np.int16,
    "int8 (GNU Radio: Byte)": np.int8,
}

DEFAULT_CONFIG = {
    "use_relay": True,
    "host": "192.168.1.10",
    "port": 7355,
    "samplerate": 48000,
    "channels": 1,
    "format": "float32 (GNU Radio: Float)",
    "buffer_sec": 2.0,
    "volume": 1.0,
}


# ---------------------------------------------------------------------------
# Конфиг
# ---------------------------------------------------------------------------

def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    try:
        if CONFIG_PATH.exists():
            with CONFIG_PATH.open("r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    if k in cfg:
                        cfg[k] = v
    except (OSError, ValueError):
        pass
    return cfg


def save_config(cfg: dict) -> None:
    """Атомарная запись, чтобы не потерять настройки при сбое."""
    tmp = CONFIG_PATH.with_suffix(".json.tmp")
    try:
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CONFIG_PATH)
    except OSError:
        # Не критично — просто не сохранили
        pass


# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------

def is_multicast(ip: str) -> bool:
    try:
        first = int(ip.split(".")[0])
        return 224 <= first <= 239
    except (ValueError, IndexError):
        return False


# ---------------------------------------------------------------------------
# Кольцевой буфер (без изменений, но с защитой от гонок)
# ---------------------------------------------------------------------------

class RingBuffer:
    def __init__(self, capacity_frames: int, channels: int):
        self.channels = channels
        self.capacity = max(1, capacity_frames)
        self.buf = np.zeros((self.capacity, channels), dtype=np.float32)
        self.write_pos = 0
        self.read_pos = 0
        self.available = 0
        self.lock = threading.Lock()
        self.underruns = 0
        self.overruns = 0

    def write(self, data: np.ndarray) -> None:
        n = data.shape[0]
        if n == 0:
            return
        with self.lock:
            if n > self.capacity:
                data = data[-self.capacity:]
                n = data.shape[0]
            free = self.capacity - self.available
            if n > free:
                drop = n - free
                self.read_pos = (self.read_pos + drop) % self.capacity
                self.available -= drop
                self.overruns += 1
            end = self.write_pos + n
            if end <= self.capacity:
                self.buf[self.write_pos:end] = data
            else:
                first = self.capacity - self.write_pos
                self.buf[self.write_pos:] = data[:first]
                self.buf[: end - self.capacity] = data[first:]
            self.write_pos = end % self.capacity
            self.available = min(self.capacity, self.available + n)

    def read(self, n: int) -> np.ndarray:
        with self.lock:
            out = np.zeros((n, self.channels), dtype=np.float32)
            if self.available <= 0:
                self.underruns += 1
                return out
            got = min(n, self.available)
            end = self.read_pos + got
            if end <= self.capacity:
                out[:got] = self.buf[self.read_pos:end]
            else:
                first = self.capacity - self.read_pos
                out[:first] = self.buf[self.read_pos:]
                out[first:got] = self.buf[: end - self.capacity]
            self.read_pos = end % self.capacity
            self.available -= got
            if got < n:
                self.underruns += 1
            return out

    def level(self) -> float:
        with self.lock:
            return self.available / self.capacity

    def reset_counters(self) -> None:
        with self.lock:
            self.underruns = 0
            self.overruns = 0


# ---------------------------------------------------------------------------
# Приёмник UDP
# ---------------------------------------------------------------------------

class UdpReceiver(threading.Thread):
    KEEPALIVE_INTERVAL = 3.0
    KEEPALIVE_PAYLOAD = b"HELLO"

    def __init__(self, host: str, port: int, ring: RingBuffer, dtype,
                 channels: int, stats: dict, use_relay: bool,
                 on_error=None):
        super().__init__(daemon=True, name="UdpReceiver")
        self.host = host
        self.port = port
        self.ring = ring
        self.dtype = dtype
        self.channels = channels
        self.stats = stats
        self.use_relay = use_relay
        self.on_error = on_error
        # ВАЖНО: НЕ self._stop — конфликтует с Thread._stop!
        self._stop_event = threading.Event()
        self.sock = None

    def stop(self) -> None:
        self._stop_event.set()
        # Закрываем сокет, чтобы разблокировать recvfrom
        s = self.sock
        if s is not None:
            try:
                s.close()
            except OSError:
                pass

    def _fail(self, msg: str) -> None:
        self.stats["error"] = msg
        if self.on_error:
            try:
                self.on_error(msg)
            except Exception:
                pass

    def run(self) -> None:
        multicast = is_multicast(self.host)
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except (AttributeError, OSError):
                pass
            self.sock.settimeout(0.5)
            if self.use_relay:
                self.sock.bind(("", 0))
            elif multicast:
                self.sock.bind(("", self.port))
                mreq = socket.inet_aton(self.host) + socket.inet_aton("0.0.0.0")
                self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            else:
                self.sock.bind((self.host, self.port))
        except OSError as e:
            self._fail(f"Не удалось открыть {self.host}:{self.port} — {e}")
            return

        relay_addr = (self.host, self.port)
        last_keepalive = 0.0

        while not self._stop_event.is_set():
            if self.use_relay:
                now = time.time()
                if now - last_keepalive >= self.KEEPALIVE_INTERVAL:
                    try:
                        self.sock.sendto(self.KEEPALIVE_PAYLOAD, relay_addr)
                    except OSError:
                        pass
                    last_keepalive = now
            try:
                data, _ = self.sock.recvfrom(65536)
            except socket.timeout:
                continue
            except OSError:
                break
            if not data:
                continue
            try:
                arr = np.frombuffer(data, dtype=self.dtype)
            except ValueError:
                continue
            n_frames = len(arr) // self.channels
            if n_frames == 0:
                continue
            arr = arr[: n_frames * self.channels].reshape(-1, self.channels)
            if self.dtype == np.int16:
                arr = arr.astype(np.float32) / 32768.0
            elif self.dtype == np.int8:
                arr = arr.astype(np.float32) / 128.0
            else:
                arr = arr.astype(np.float32, copy=False)
            self.ring.write(arr)
            self.stats["packets"] += 1
            self.stats["bytes"] += len(data)

        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass
        self.sock = None


# ---------------------------------------------------------------------------
# Аудиовыход
# ---------------------------------------------------------------------------

class Player:
    def __init__(self, ring: RingBuffer, samplerate: int, channels: int,
                 volume_getter):
        self.ring = ring
        self.samplerate = samplerate
        self.channels = channels
        self.volume_getter = volume_getter
        self.stream = None

    def _callback(self, outdata, frames, time_info, status):
        try:
            data = self.ring.read(frames)
            vol = float(self.volume_getter())
            if vol != 1.0:
                data = data * vol
            outdata[:] = data
        except Exception:
            outdata.fill(0)

    def start(self) -> None:
        self.stream = sd.OutputStream(
            samplerate=self.samplerate,
            channels=self.channels,
            dtype="float32",
            callback=self._callback,
        )
        self.stream.start()

    def stop(self) -> None:
        s = self.stream
        self.stream = None
        if s is not None:
            try:
                s.stop()
            except Exception:
                pass
            try:
                s.close()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Мост для сигналов из потока в UI
# ---------------------------------------------------------------------------

class ReceiverBridge(QObject):
    error = pyqtSignal(str)


# ---------------------------------------------------------------------------
# Главное окно
# ---------------------------------------------------------------------------

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        self.setMinimumWidth(560)
        self.setStyleSheet(self._stylesheet())

        self.cfg = load_config()

        self.receiver: UdpReceiver | None = None
        self.player: Player | None = None
        self.ring: RingBuffer | None = None
        self.stats = {"packets": 0, "bytes": 0, "error": None}
        self.running = False

        self.bridge = ReceiverBridge()
        self.bridge.error.connect(self._on_receiver_error)

        self._build_ui()
        self._apply_config(self.cfg)

        # Таймер обновления UI
        self.timer = QTimer(self)
        self.timer.setInterval(200)
        self.timer.timeout.connect(self._update_ui)
        self.timer.start()

        # Сохранение при любом изменении
        self._connect_autosave()

    # ------------------------------------------------------------------
    # Стили
    # ------------------------------------------------------------------
    @staticmethod
    def _stylesheet() -> str:
        return """
        QMainWindow, QWidget { background-color: #1e1e2e; color: #cdd6f4; }
        QLabel { color: #cdd6f4; }
        QLabel#Title { color: #89b4fa; font-size: 18px; font-weight: bold; }
        QLabel#Hint  { color: #a6adc8; font-size: 11px; }
        QLabel#Status { font-size: 12px; }
        QGroupBox {
            border: 1px solid #45475a; border-radius: 6px;
            margin-top: 10px; padding-top: 8px; font-weight: bold;
        }
        QGroupBox::title {
            subcontrol-origin: margin; left: 10px; padding: 0 4px;
            color: #89b4fa;
        }
        QLineEdit, QComboBox {
            background: #313244; border: 1px solid #45475a;
            border-radius: 4px; padding: 4px 6px; color: #cdd6f4;
        }
        QComboBox::drop-down { border: none; }
        QComboBox QAbstractItemView {
            background: #313244; color: #cdd6f4;
            selection-background-color: #89b4fa; selection-color: #1e1e2e;
        }
        QPushButton {
            background: #313244; border: 1px solid #45475a;
            border-radius: 4px; padding: 6px 14px; color: #cdd6f4;
        }
        QPushButton:hover { background: #45475a; }
        QPushButton:disabled { color: #6c7086; background: #27273a; }
        QPushButton#Play { background: #89b4fa; color: #1e1e2e; font-weight: bold; }
        QPushButton#Play:hover { background: #b4befe; }
        QPushButton#Play:disabled { background: #45475a; color: #6c7086; }
        QPushButton#Stop { background: #f38ba8; color: #1e1e2e; font-weight: bold; }
        QPushButton#Stop:hover { background: #eba0ac; }
        QPushButton#Stop:disabled { background: #45475a; color: #6c7086; }
        QProgressBar {
            background: #313244; border: 1px solid #45475a;
            border-radius: 4px; text-align: center; color: #cdd6f4;
        }
        QProgressBar::chunk { background: #a6e3a1; border-radius: 3px; }
        QSlider::groove:horizontal {
            height: 6px; background: #313244; border-radius: 3px;
        }
        QSlider::handle:horizontal {
            background: #89b4fa; width: 14px; margin: -5px 0;
            border-radius: 7px;
        }
        QSlider::sub-page:horizontal { background: #89b4fa; border-radius: 3px; }
        QCheckBox { color: #cdd6f4; }
        QCheckBox::indicator {
            width: 16px; height: 16px; border-radius: 3px;
            border: 1px solid #45475a; background: #313244;
        }
        QCheckBox::indicator:checked { background: #89b4fa; border: 1px solid #89b4fa; }
        """

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(10)

        title = QLabel(APP_TITLE)
        title.setObjectName("Title")
        root.addWidget(title)

        hint = QLabel("Слушайте радиопоток от GNU Radio — напрямую или через relay")
        hint.setObjectName("Hint")
        root.addWidget(hint)

        # --- Режим ---
        self.chk_relay = QCheckBox("Подключаться через relay-сервер")
        self.chk_relay.toggled.connect(self._on_relay_toggle)
        root.addWidget(self.chk_relay)

        # --- Подключение ---
        conn_box = QGroupBox("Подключение")
        conn_form = QFormLayout(conn_box)
        conn_form.setLabelAlignment(Qt.AlignRight)

        self.lbl_host = QLabel("IP relay-сервера:")
        self.edit_host = QLineEdit()
        conn_form.addRow(self.lbl_host, self.edit_host)

        self.edit_port = QLineEdit()
        conn_form.addRow("Порт:", self.edit_port)

        self.lbl_host_hint = QLabel("IP компьютера, где запущен relay_app.py")
        self.lbl_host_hint.setObjectName("Hint")
        conn_form.addRow("", self.lbl_host_hint)

        root.addWidget(conn_box)

        # --- Аудио ---
        audio_box = QGroupBox("Аудио")
        audio_grid = QGridLayout(audio_box)

        audio_grid.addWidget(QLabel("Частота (Гц):"), 0, 0)
        self.edit_rate = QLineEdit()
        audio_grid.addWidget(self.edit_rate, 0, 1)

        audio_grid.addWidget(QLabel("Каналы:"), 0, 2)
        self.cmb_channels = QComboBox()
        self.cmb_channels.addItems(["1", "2"])
        audio_grid.addWidget(self.cmb_channels, 0, 3)

        audio_grid.addWidget(QLabel("Формат:"), 1, 0)
        self.cmb_format = QComboBox()
        self.cmb_format.addItems(list(FORMAT_OPTIONS.keys()))
        audio_grid.addWidget(self.cmb_format, 1, 1, 1, 3)

        audio_grid.addWidget(QLabel("Буфер (сек):"), 2, 0)
        self.sld_buffer = QSlider(Qt.Horizontal)
        self.sld_buffer.setRange(5, 40)  # 0.5..4.0 сек, шаг 0.1
        self.lbl_buffer_val = QLabel("2.0")
        audio_grid.addWidget(self.sld_buffer, 2, 1, 1, 2)
        audio_grid.addWidget(self.lbl_buffer_val, 2, 3)
        self.sld_buffer.valueChanged.connect(self._on_buffer_change)

        root.addWidget(audio_box)

        # --- Громкость ---
        vol_box = QGroupBox("Громкость")
        vol_layout = QHBoxLayout(vol_box)
        self.sld_volume = QSlider(Qt.Horizontal)
        self.sld_volume.setRange(0, 200)
        self.lbl_vol = QLabel("100 %")
        self.lbl_vol.setFixedWidth(60)
        vol_layout.addWidget(self.sld_volume, 1)
        vol_layout.addWidget(self.lbl_vol)
        self.sld_volume.valueChanged.connect(self._on_volume_change)
        root.addWidget(vol_box)

        # --- Кнопки ---
        btn_row = QHBoxLayout()
        self.btn_start = QPushButton("▶   Слушать")
        self.btn_start.setObjectName("Play")
        self.btn_start.clicked.connect(self.start_stream)
        self.btn_stop = QPushButton("■   Стоп")
        self.btn_stop.setObjectName("Stop")
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self.stop_stream)
        btn_row.addStretch(1)
        btn_row.addWidget(self.btn_start)
        btn_row.addWidget(self.btn_stop)
        btn_row.addStretch(1)
        root.addLayout(btn_row)

        # --- Статус ---
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("color: #45475a;")
        root.addWidget(sep)

        self.lbl_status = QLabel("Статус: остановлено")
        self.lbl_status.setObjectName("Status")
        self.lbl_status.setStyleSheet("color: #a6adc8;")
        root.addWidget(self.lbl_status)

        buf_row = QHBoxLayout()
        buf_row.addWidget(QLabel("Буфер:"))
        self.bar_buffer = QProgressBar()
        self.bar_buffer.setRange(0, 100)
        self.bar_buffer.setTextVisible(False)
        self.bar_buffer.setFixedHeight(14)
        buf_row.addWidget(self.bar_buffer, 1)
        self.lbl_buf_pct = QLabel("0 %")
        self.lbl_buf_pct.setFixedWidth(50)
        buf_row.addWidget(self.lbl_buf_pct)
        root.addLayout(buf_row)

        self.lbl_stats = QLabel("Пакетов: 0  ·  Underrun: 0  ·  Overrun: 0")
        self.lbl_stats.setObjectName("Hint")
        root.addWidget(self.lbl_stats)

        root.addStretch(1)

    # ------------------------------------------------------------------
    # Настройки
    # ------------------------------------------------------------------
    def _apply_config(self, cfg: dict) -> None:
        self.chk_relay.setChecked(bool(cfg["use_relay"]))
        self.edit_host.setText(str(cfg["host"]))
        self.edit_port.setText(str(cfg["port"]))
        self.edit_rate.setText(str(cfg["samplerate"]))

        idx = self.cmb_channels.findText(str(cfg["channels"]))
        self.cmb_channels.setCurrentIndex(idx if idx >= 0 else 0)

        idx = self.cmb_format.findText(str(cfg["format"]))
        self.cmb_format.setCurrentIndex(idx if idx >= 0 else 0)

        self.sld_buffer.setValue(int(round(float(cfg["buffer_sec"]) * 10)))
        self.lbl_buffer_val.setText(f"{float(cfg['buffer_sec']):.1f}")

        self.sld_volume.setValue(int(round(float(cfg["volume"]) * 100)))
        self.lbl_vol.setText(f"{int(round(float(cfg['volume']) * 100))} %")

        self._on_relay_toggle(self.chk_relay.isChecked())

    def _collect_config(self) -> dict:
        try:
            port = int(self.edit_port.text().strip())
        except ValueError:
            port = DEFAULT_CONFIG["port"]
        try:
            rate = int(self.edit_rate.text().strip())
        except ValueError:
            rate = DEFAULT_CONFIG["samplerate"]
        return {
            "use_relay": self.chk_relay.isChecked(),
            "host": self.edit_host.text().strip(),
            "port": port,
            "samplerate": rate,
            "channels": int(self.cmb_channels.currentText()),
            "format": self.cmb_format.currentText(),
            "buffer_sec": self.sld_buffer.value() / 10.0,
            "volume": self.sld_volume.value() / 100.0,
        }

    def _connect_autosave(self) -> None:
        self.chk_relay.toggled.connect(self._autosave)
        self.edit_host.editingFinished.connect(self._autosave)
        self.edit_port.editingFinished.connect(self._autosave)
        self.edit_rate.editingFinished.connect(self._autosave)
        self.cmb_channels.currentIndexChanged.connect(self._autosave)
        self.cmb_format.currentIndexChanged.connect(self._autosave)
        self.sld_buffer.valueChanged.connect(self._autosave)
        self.sld_volume.valueChanged.connect(self._autosave)

    def _autosave(self, *_) -> None:
        self.cfg = self._collect_config()
        save_config(self.cfg)

    # ------------------------------------------------------------------
    # Обработчики UI
    # ------------------------------------------------------------------
    def _on_relay_toggle(self, checked: bool) -> None:
        if checked:
            self.lbl_host.setText("IP relay-сервера:")
            self.lbl_host_hint.setText("IP компьютера, где запущен relay_app.py")
        else:
            self.lbl_host.setText("IP для прослушивания:")
            self.lbl_host_hint.setText(
                "0.0.0.0 — unicast  ·  239.x.x.x — multicast"
            )

    def _on_volume_change(self, value: int) -> None:
        self.lbl_vol.setText(f"{value} %")

    def _on_buffer_change(self, value: int) -> None:
        self.lbl_buffer_val.setText(f"{value / 10.0:.1f}")

    def _on_receiver_error(self, msg: str) -> None:
        QMessageBox.critical(self, APP_TITLE, msg)

    # ------------------------------------------------------------------
    # Старт / стоп
    # ------------------------------------------------------------------
    def start_stream(self) -> None:
        if self.running:
            return

        # Считываем и валидируем
        try:
            host = self.edit_host.text().strip()
            port = int(self.edit_port.text().strip())
            rate = int(self.edit_rate.text().strip())
            channels = int(self.cmb_channels.currentText())
            buffer_sec = self.sld_buffer.value() / 10.0
            dtype = FORMAT_OPTIONS[self.cmb_format.currentText()]
        except (ValueError, KeyError):
            QMessageBox.critical(self, APP_TITLE, "Проверьте корректность параметров.")
            return

        if not (1 <= port <= 65535):
            QMessageBox.critical(self, APP_TITLE, "Порт должен быть в диапазоне 1–65535.")
            return
        if not host:
            QMessageBox.critical(self, APP_TITLE, "Укажите IP.")
            return
        if rate <= 0:
            QMessageBox.critical(self, APP_TITLE, "Частота должна быть > 0.")
            return

        # Сохраняем настройки при старте
        self._autosave()

        capacity = max(1, int(rate * buffer_sec))
        self.ring = RingBuffer(capacity, channels)
        self.stats = {"packets": 0, "bytes": 0, "error": None}

        self.receiver = UdpReceiver(
            host, port, self.ring, dtype, channels, self.stats,
            use_relay=self.chk_relay.isChecked(),
            on_error=self.bridge.error.emit,
        )
        self.receiver.start()

        # Даём потоку время упасть с ошибкой (bind)
        time.sleep(0.15)
        if self.stats.get("error"):
            self.receiver.stop()
            self.receiver.join(timeout=1.0)
            self.receiver = None
            self.ring = None
            QMessageBox.critical(self, APP_TITLE, self.stats["error"])
            return

        # Пытаемся открыть аудио
        try:
            self.player = Player(
                self.ring, rate, channels,
                lambda: self.sld_volume.value() / 100.0,
            )
            self.player.start()
        except Exception as e:
            self.receiver.stop()
            self.receiver.join(timeout=1.0)
            self.receiver = None
            self.ring = None
            self.player = None
            QMessageBox.critical(
                self, APP_TITLE,
                f"Не удалось запустить аудиовыход:\n{e}"
            )
            return

        self.running = True
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self._set_inputs_enabled(False)
        mode = "relay" if self.chk_relay.isChecked() else "direct"
        self.lbl_status.setText(f"Статус: слушаю {host}:{port}  ({mode})")
        self.lbl_status.setStyleSheet("color: #a6e3a1;")

    def stop_stream(self) -> None:
        if not self.running:
            return
        self.running = False

        if self.player is not None:
            self.player.stop()
            self.player = None

        if self.receiver is not None:
            self.receiver.stop()
            self.receiver.join(timeout=1.5)
            # Если поток всё ещё жив (застрял), не держим ссылку
            if self.receiver.is_alive():
                # Дадим ещё чуть-чуть, но всё равно отвяжемся
                self.receiver.join(timeout=0.5)
            self.receiver = None

        self.ring = None

        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self._set_inputs_enabled(True)

        self.lbl_status.setText("Статус: остановлено")
        self.lbl_status.setStyleSheet("color: #a6adc8;")
        self.bar_buffer.setValue(0)
        self.lbl_buf_pct.setText("0 %")
        self.lbl_stats.setText("Пакетов: 0  ·  Underrun: 0  ·  Overrun: 0")

    def _set_inputs_enabled(self, enabled: bool) -> None:
        for w in (self.chk_relay, self.edit_host, self.edit_port,
                  self.edit_rate, self.cmb_channels, self.cmb_format,
                  self.sld_buffer):
            w.setEnabled(enabled)

    # ------------------------------------------------------------------
    # Обновление UI
    # ------------------------------------------------------------------
    def _update_ui(self) -> None:
        if not self.running or self.ring is None:
            return

        level = self.ring.level() * 100.0
        self.bar_buffer.setValue(int(level))
        self.lbl_buf_pct.setText(f"{level:.0f} %")

        self.lbl_stats.setText(
            f"Пакетов: {self.stats.get('packets', 0)}  ·  "
            f"Underrun: {self.ring.underruns}  ·  "
            f"Overrun: {self.ring.overruns}"
        )

    # ------------------------------------------------------------------
    # Закрытие
    # ------------------------------------------------------------------
    def closeEvent(self, event: QCloseEvent) -> None:
        try:
            self._autosave()
        except Exception:
            pass
        self.timer.stop()
        # Отвязываем сигнал, чтобы не было вызовов в разрушенный объект
        try:
            self.bridge.error.disconnect()
        except TypeError:
            pass
        self.stop_stream()
        event.accept()


# ---------------------------------------------------------------------------
# Точка входа
# ---------------------------------------------------------------------------

def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName(APP_TITLE)
    win = MainWindow()
    win.show()
    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())