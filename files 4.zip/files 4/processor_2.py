import configparser, logging, shutil, subprocess, sys, time
from pathlib import Path

BASE = Path(__file__).resolve().parent
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                    handlers=[logging.StreamHandler(), logging.FileHandler(BASE / "processor.log", encoding="utf-8")])
log = logging.getLogger("proc")


def load_config(path=BASE / "config.ini"):
    cfg = configparser.ConfigParser()
    if not cfg.read(path, encoding="utf-8"):
        raise FileNotFoundError(path)
    return cfg


def read_last_id(log_path: Path) -> int:
    if not log_path.exists():
        return 0
    text = log_path.read_text(encoding="utf-8").strip()
    if not text:
        return 0
    try:
        return int(text)
    except ValueError:
        log.warning("Некорректное содержимое %s: %r - считаем last_id=0", log_path, text[:50])
        return 0


def write_last_id(log_path: Path, value: int):
    tmp = log_path.with_suffix(".tmp")
    tmp.write_text(str(value), encoding="utf-8")
    tmp.replace(log_path)  # атомарная замена


def extract_rows(columns, raw_rows, cfg):
    """columns - имена колонок как их вернул курсор (порядок как в SELECT).
    Ищем нужные колонки по именам из [query] id_column/path_column (без учёта регистра),
    поэтому порядок и количество колонок в SELECT (и любой WHERE/JOIN) роли не играют -
    лишние столбцы просто игнорируются."""
    q = cfg["query"]
    id_col = q.get("id_column", "Id")
    path_col = q.get("path_column", "FilePath")
    lower = [c.lower() for c in columns]
    try:
        id_idx = lower.index(id_col.lower())
    except ValueError:
        raise KeyError(f"id_column='{id_col}' не найдена среди колонок запроса: {columns}")
    try:
        path_idx = lower.index(path_col.lower())
    except ValueError:
        raise KeyError(f"path_column='{path_col}' не найдена среди колонок запроса: {columns}")
    return [(int(r[id_idx]), r[path_idx]) for r in raw_rows]


def fetch_rows(cfg, last_id):
    import pyodbc
    db = cfg["db"]
    cs = f"DRIVER={{{db['driver']}}};SERVER={db['server']};DATABASE={db['database']};"
    cs += "Trusted_Connection=yes;" if db.getboolean("trusted") else f"UID={db['user']};PWD={db['password']};"
    with pyodbc.connect(cs) as conn:
        cur = conn.cursor().execute(cfg["query"]["sql"], last_id)
        columns = [d[0] for d in cur.description]
        return extract_rows(columns, cur.fetchall(), cfg)


def resolve_path(cfg, db_path: str) -> Path:
    """БД хранит путь относительно общего диска/корня, например '2\\3'.
    base_path (например 'D:\\1\\') дописывается спереди -> 'D:\\1\\2\\3'."""
    base = cfg["app"].get("base_path", "").strip()
    return Path(base) / db_path if base else Path(db_path)


def find_files(path: Path, ext: str):
    """Путь из БД - папка (файлов несколько) или сам файл. Берём файлы с нужным расширением."""
    ext = "." + ext.lower().lstrip(".")
    if path.is_file():
        return [path] if path.suffix.lower() == ext else []
    if path.is_dir():
        return sorted(f for f in path.iterdir() if f.is_file() and f.suffix.lower() == ext)
    raise FileNotFoundError(f"Путь не найден: {path}")


def process_file(cfg, src: Path):
    """Копия в work_dir -> a.exe <копия> (ждём завершения) ->
    ждём директорию '<имя_файла>.res' в work_dir -> перемещаем в папку исходника.
    Имя результата известно заранее: если его нет - это сбой."""
    app = cfg["app"]
    work = Path(app["work_dir"])
    exe = Path(app.get("exe_path") or work / "a.exe")
    timeout = int(app.get("timeout", 0)) or None
    result_name = src.name + ".res"
    target = src.parent / result_name
    if target.exists():
        log.warning("%s: директория %s уже существует - пропуск", src.name, target)
        return target

    copy = work / src.name
    out = work / result_name  # заранее знаем, что должно появиться
    if out.exists():
        # защита от «зависшего» результата от предыдущего сбоя:
        # иначе shutil.move уедет внутрь существующей папки
        raise RuntimeError(f"В {work} уже существует '{result_name}' до запуска - уберите вручную")

    shutil.copy2(src, copy)
    try:
        res = subprocess.run([str(exe), str(copy)], cwd=work, timeout=timeout,
                             capture_output=True, text=True)
        log.info("%s: код возврата %s", src.name, res.returncode)
        if not out.is_dir():
            raise RuntimeError(
                f"a.exe не создал директорию '{out}' (rc={res.returncode}) "
                f"stderr={res.stderr.strip()[:300]}"
            )
        shutil.move(str(out), str(target))
    finally:
        copy.unlink(missing_ok=True)  # удаляем только копию в work_dir; исходники по пути из БД не трогаем
    return target


def process_id(cfg, row_id, db_path):
    full_path = resolve_path(cfg, db_path)
    files = find_files(full_path, cfg["app"]["extension"])
    if not files:
        raise FileNotFoundError(f"В {full_path} нет файлов *.{cfg['app']['extension']}")
    for f in files:
        process_file(cfg, f)  # исключение любого файла -> id не считается выполненным


def run_cycle(cfg, skip_ids: set):
    log_path = BASE / cfg["app"]["log_file"]
    failed_path = BASE / cfg["app"]["failed_file"]
    last_id = read_last_id(log_path)
    rows = [r for r in fetch_rows(cfg, last_id) if r[0] not in skip_ids]
    if rows:
        log.info("Последний id=%s, к обработке: %s", last_id, len(rows))
    for row_id, path in rows:
        try:
            process_id(cfg, row_id, path)
            write_last_id(log_path, row_id)
            log.info("id=%s готово", row_id)
        except Exception as e:
            log.error("id=%s ошибка: %s", row_id, e)
            skip_ids.add(row_id)  # до перезапуска не долбим этот id каждую минуту
            with open(failed_path, "a", encoding="utf-8") as f:
                f.write(f"{row_id}\t{path}\t{e}\n")


def main(max_cycles=None):
    cfg = load_config()
    interval = int(cfg["app"].get("interval", 60))
    skip_ids, n = set(), 0
    log.info("Старт, интервал %s c. Остановка: Ctrl+C", interval)
    try:
        while max_cycles is None or n < max_cycles:
            try:
                run_cycle(cfg, skip_ids)
            except Exception:
                log.exception("Сбой цикла (БД недоступна?) - повтор через %s c", interval)
            n += 1
            if max_cycles is None or n < max_cycles:
                time.sleep(interval)
    except KeyboardInterrupt:
        log.info("Остановлено пользователем")


if __name__ == "__main__":
    sys.exit(main())