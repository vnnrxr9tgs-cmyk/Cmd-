#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Минимальный клиент relay — для диагностики. Без Flask, без браузера."""

import socket
import sys
import threading
import time

RELAY = ("127.0.0.1", 7355)
KEEPALIVE = b"HELLO"


def listen_once(tag: str, duration: float = 3.0):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("", 0))
    s.settimeout(0.3)
    print(f"[{tag}] bind on port {s.getsockname()[1]}")

    stop = threading.Event()

    def keepalive():
        while not stop.is_set():
            try:
                s.sendto(KEEPALIVE, RELAY)
            except OSError as e:
                print(f"[{tag}] sendto HELLO failed: {e}")
            stop.wait(1.0)

    th = threading.Thread(target=keepalive, daemon=True)
    th.start()

    t0 = time.time()
    n = 0
    total_bytes = 0
    try:
        while time.time() - t0 < duration:
            try:
                data, addr = s.recvfrom(65536)
            except socket.timeout:
                continue
            except OSError as e:
                print(f"[{tag}] recvfrom error: {e}")
                break
            if data == KEEPALIVE:
                continue
            n += 1
            total_bytes += len(data)
            if n % 20 == 0:
                print(f"[{tag}] got {n} packets, {total_bytes} bytes, from {addr}")
    finally:
        stop.set()
        th.join(timeout=1.0)
        s.close()
    print(f"[{tag}] FINISHED: {n} packets, {total_bytes} bytes")
    return n


if __name__ == "__main__":
    print("=== PASS 1 ===")
    n1 = listen_once("A", duration=3.0)
    time.sleep(2.0)  # имитация паузы между Стоп и Плей
    print("=== PASS 2 ===")
    n2 = listen_once("B", duration=3.0)

    print()
    print(f"PASS 1: {n1} packets")
    print(f"PASS 2: {n2} packets")
    if n2 > 0:
        print(">>> relay OK: оба прохода получили данные")
    else:
        print(">>> relay BROKEN: второй проход пустой — проблема в relay")