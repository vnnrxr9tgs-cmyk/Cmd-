#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Relay в консоли, с подробным логом — для диагностики."""
import socket
import sys
import threading
import time

LISTEN = "0.0.0.0"
PORT = 7355
KEEPALIVE = b"HELLO"
SIO_UDP_CONNRESET = 0x9800000C


def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    if sys.platform.startswith("win"):
        try:
            sock.ioctl(SIO_UDP_CONNRESET, False)
            print("[relay] SIO_UDP_CONNRESET disabled (Windows)")
        except Exception as e:
            print("[relay] ioctl failed:", e)
    sock.bind((LISTEN, PORT))
    sock.settimeout(0.3)
    print(f"[relay] listening on {LISTEN}:{PORT}")

    clients = {}
    last_hello_log = 0.0
    last_audio_log = 0.0

    while True:
        try:
            data, addr = sock.recvfrom(65536)
        except socket.timeout:
            continue
        except OSError as e:
            print(f"[relay] recvfrom OSError: {e}")
            continue

        if data == KEEPALIVE:
            now = time.time()
            if now - last_hello_log > 1.0:
                print(f"[relay] HELLO from {addr}, clients={len(clients)}")
                last_hello_log = now
            clients[addr] = now
            continue

        # аудио
        now = time.time()
        if now - last_audio_log > 1.0:
            print(f"[relay] AUDIO {len(data)}b from {addr}, clients={len(clients)}")
            last_audio_log = now

        for c in list(clients.keys()):
            try:
                sock.sendto(data, c)
            except OSError as e:
                print(f"[relay] sendto {c} failed: {e}")
                clients.pop(c, None)


if __name__ == "__main__":
    main()