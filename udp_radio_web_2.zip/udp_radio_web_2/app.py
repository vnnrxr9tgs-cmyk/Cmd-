#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UDP Radio Web Player — Flask + SocketIO клиент для relay_app.

Принимает UDP-поток от relay (keep-alive HELLO), конвертирует в PCM
и раздаёт браузерам через WebSocket. Воспроизведение — Web Audio API
с честным jitter buffer и линейным ресемплером на клиенте.

Запуск:
    pip install flask flask-socketio numpy
    python app.py

Откройте http://127.0.0.1:5000 в браузере (Chrome / Firefox).
Только для локальной сети.
"""

from __future__ import annotations

import argparse
import json
import os
import socket
import sys
import threading
import time
from pathlib import Path

import numpy as np
from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit

# ---------------------------------------------------------------------------
# Константы
# ---------------------------------------------------------------------------

APP_TITLE = "UDP Radio Web"
CONFIG_PATH = Path.home() / ".udp_radio_web.json"
KEEPALIVE_PAYLOAD = b"HELLO"
KEEPALIVE_INTERVAL = 3.0

FORMAT_MAP = {
    "float32": np.float32,
    "int16": np.int16,
    "int8": np.int8,
}

DEFAULT_CONFIG = {
    "relay_host": "127.0.0.1",
    "relay_port": 7355,
    "samplerate": 24000,
    "channels": 1,
    "format": "float32",
    "listen_host": "0.0.0.0",
    "web_port": 5000,
}


# ---------------------------------------------------------------------------
# Конфиг
# ---------------------------------------------------------------------------

def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    try:
        if CONFIG_PATH.exists():
            with CONFIG_PATH.open("r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    if k in cfg:
                        cfg[k] = v
    except (OSError, ValueError):
        pass
    return cfg


def save_config(cfg: dict) -> None:
    tmp = CONFIG_PATH.with_suffix(".json.tmp")
    try:
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CONFIG_PATH)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# UDP-приёмник
# ---------------------------------------------------------------------------

class UdpReceiver(threading.Thread):
    """Принимает аудио от relay и рассылает его в SocketIO."""

    def __init__(
        self,
        host: str,
        port: int,
        dtype: np.dtype,
        channels: int,
        samplerate: int,
        socketio: SocketIO,
        stats: dict,
    ):
        super().__init__(daemon=True, name="UdpReceiver")
        self.host = host
        self.port = port
        self.dtype = dtype
        self.channels = channels
        self.samplerate = samplerate
        self.socketio = socketio
        self.stats = stats

        self._stop_event = threading.Event()
        self.sock: socket.socket | None = None
        self.running = False
        self.error: str | None = None
        self._seq = 0

    def bind(self) -> bool:
        """Синхронно открывает UDP-сокет. Возвращает True/False."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("", 0))
            s.settimeout(0.2)
        except OSError as e:
            self.error = f"Не удалось открыть UDP-сокет: {e}"
            self.stats["error"] = self.error
            try:
                s.close()
            except Exception:
                pass
            return False
        self.sock = s
        return True

    def stop(self) -> None:
        """Ставит стоп-флаг, будит recvfrom через shutdown, закрывает сокет."""
        self._stop_event.set()
        self.running = False
        s = self.sock
        self.sock = None
        if s is not None:
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                s.close()
            except OSError:
                pass

    def run(self) -> None:
        if self.sock is None:
            if not self.bind():
                print(f"[rx] bind failed: {self.error}")
                return

        print(f"[rx] thread started, bound to {self.sock.getsockname()}, "
              f"relay={self.host}:{self.port}")

        self.running = True
        self.stats["error"] = None
        relay_addr = (self.host, self.port)
        last_keepalive = 0.0
        got_any = False

        while not self._stop_event.is_set():
            now = time.time()
            if now - last_keepalive >= KEEPALIVE_INTERVAL:
                try:
                    self.sock.sendto(KEEPALIVE_PAYLOAD, relay_addr)
                except OSError as e:
                    print(f"[rx] HELLO sendto failed: {e}")
                last_keepalive = now

            try:
                data, addr = self.sock.recvfrom(65536)
            except socket.timeout:
                continue
            except OSError as e:
                if self._stop_event.is_set():
                    break
                print(f"[rx] recvfrom OSError: {e}")
                break

            if not data or data == KEEPALIVE_PAYLOAD:
                continue

            if not got_any:
                got_any = True
                print(f"[rx] first packet from {addr}, {len(data)} bytes")

            try:
                arr = np.frombuffer(data, dtype=self.dtype)
            except ValueError:
                continue

            n_frames = len(arr) // self.channels
            if n_frames == 0:
                continue

            arr = arr[: n_frames * self.channels].reshape(-1, self.channels)

            if self.dtype == np.int16:
                arr = arr.astype(np.float32) / 32768.0
            elif self.dtype == np.int8:
                arr = arr.astype(np.float32) / 128.0
            else:
                arr = arr.astype(np.float32)

            np.clip(arr, -1.0, 1.0, out=arr)

            pcm = arr.ravel().astype("<f4").tobytes()
            self._seq += 1

            self.stats["packets"] += 1
            self.stats["bytes"] += len(data)
            self.stats["last_packet"] = time.time()

            try:
                self.socketio.emit(
                    "audio",
                    {
                        "sr": self.samplerate,
                        "ch": self.channels,
                        "seq": self._seq,
                        "ts": now,
                        "pcm": pcm,
                    },
                    namespace="/",
                )
            except Exception as e:
                print(f"[rx] socketio.emit failed: {e}")

        print("[rx] thread exiting")
        self.running = False
        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass
        self.sock = None


# ---------------------------------------------------------------------------
# Flask + SocketIO
# ---------------------------------------------------------------------------

app = Flask(__name__)
app.config["SECRET_KEY"] = os.urandom(24).hex()
app.config["TEMPLATES_AUTO_RELOAD"] = True
socketio = SocketIO(
    app,
    cors_allowed_origins="*",
    async_mode="threading",
    max_http_buffer_size=4 * 1024 * 1024,
    ping_timeout=20,
    ping_interval=10,
    logger=False,
    engineio_logger=False,
)


_state = {
    "receiver": None,
    "config": load_config(),
    "stats": {
        "packets": 0,
        "bytes": 0,
        "clients": 0,
        "error": None,
        "last_packet": 0.0,
        "started_at": None,
    },
    "lock": threading.Lock(),
}


def _get_status() -> dict:
    cfg = _state["config"]
    stats = _state["stats"]
    rx = _state["receiver"]
    running = bool(rx and rx.running)
    return {
        "running": running,
        "relay_host": cfg["relay_host"],
        "relay_port": cfg["relay_port"],
        "samplerate": cfg["samplerate"],
        "channels": cfg["channels"],
        "format": cfg["format"],
        "packets": stats["packets"],
        "bytes": stats["bytes"],
        "clients": stats["clients"],
        "error": stats.get("error"),
        "last_packet_ago": (
            round(time.time() - stats["last_packet"], 1)
            if stats["last_packet"]
            else None
        ),
    }


@app.route("/")
def index():
    return render_template("index.html", title=APP_TITLE)


@app.route("/api/status")
def api_status():
    return jsonify(_get_status())


@app.route("/api/config", methods=["GET", "POST"])
def api_config():
    if request.method == "GET":
        return jsonify(_state["config"])

    data = request.get_json(silent=True) or {}
    cfg = _state["config"]
    for key in ("relay_host", "relay_port", "samplerate", "channels", "format"):
        if key in data:
            cfg[key] = data[key]
    try:
        cfg["relay_port"] = int(cfg["relay_port"])
        cfg["samplerate"] = int(cfg["samplerate"])
        cfg["channels"] = int(cfg["channels"])
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Некорректные числа"}), 400
    if cfg["format"] not in FORMAT_MAP:
        return jsonify({"ok": False, "error": "Неизвестный формат"}), 400
    if not (1 <= cfg["relay_port"] <= 65535):
        return jsonify({"ok": False, "error": "Порт 1–65535"}), 400
    if cfg["channels"] not in (1, 2):
        return jsonify({"ok": False, "error": "Каналы: 1 или 2"}), 400
    if cfg["samplerate"] < 8000:
        return jsonify({"ok": False, "error": "Частота слишком низкая"}), 400

    save_config(cfg)
    return jsonify({"ok": True, "config": cfg})


@socketio.on("connect")
def on_connect():
    with _state["lock"]:
        _state["stats"]["clients"] += 1
    emit("status", _get_status())
    socketio.emit("status", _get_status())


@socketio.on("disconnect")
def on_disconnect():
    with _state["lock"]:
        _state["stats"]["clients"] = max(0, _state["stats"]["clients"] - 1)
    socketio.emit("status", _get_status())


@socketio.on("start")
def on_start(data=None):
    # 1) Убить старый приёмник, дождаться его смерти
    with _state["lock"]:
        old = _state["receiver"]
        _state["receiver"] = None

    if old is not None:
        print("[on_start] stopping old receiver...")
        try:
            old.stop()
            old.join(timeout=3.0)
            if old.is_alive():
                print("[on_start] WARN: old receiver still alive")
                old.join(timeout=2.0)
        except Exception as e:
            print(f"[on_start] old.stop() error: {e}")

    # 2) Создать новый
    cfg = _state["config"]
    dtype = FORMAT_MAP.get(cfg["format"], np.float32)
    stats = _state["stats"]
    stats["packets"] = 0
    stats["bytes"] = 0
    stats["error"] = None
    stats["last_packet"] = 0.0
    stats["started_at"] = time.time()

    receiver = UdpReceiver(
        host=str(cfg["relay_host"]).strip() or "127.0.0.1",
        port=int(cfg["relay_port"]),
        dtype=dtype,
        channels=int(cfg["channels"]),
        samplerate=int(cfg["samplerate"]),
        socketio=socketio,
        stats=stats,
    )

    if not receiver.bind():
        print(f"[on_start] bind failed: {receiver.error}")
        emit("error", {"message": receiver.error or "bind failed"})
        emit("status", _get_status())
        socketio.emit("status", _get_status())
        return

    with _state["lock"]:
        _state["receiver"] = receiver
    receiver.start()
    print("[on_start] new receiver started")

    emit("status", _get_status())
    socketio.emit("status", _get_status())


@socketio.on("stop")
def on_stop():
    with _state["lock"]:
        rx = _state["receiver"]
        _state["receiver"] = None

    if rx is not None:
        print("[on_stop] stopping receiver...")
        try:
            rx.stop()
            rx.join(timeout=3.0)
            if rx.is_alive():
                print("[on_stop] WARN: receiver still alive after 3s")
        except Exception as e:
            print(f"[on_stop] error: {e}")
        print("[on_stop] done")

    emit("status", _get_status())
    socketio.emit("status", _get_status())


@socketio.on("get_status")
def on_get_status():
    emit("status", _get_status())


# ---------------------------------------------------------------------------
# Периодическая рассылка статуса (1 Гц)
# ---------------------------------------------------------------------------

def _status_broadcast_loop():
    while True:
        time.sleep(1.0)
        try:
            socketio.emit("status", _get_status())
        except Exception:
            pass


# ---------------------------------------------------------------------------
# CLI / main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description=APP_TITLE)
    parser.add_argument("--host", default="", help="IP relay")
    parser.add_argument("--port", type=int, default=0, help="UDP-порт relay")
    parser.add_argument("--web-port", type=int, default=0, help="HTTP-порт (по умолчанию 5000)")
    parser.add_argument("--listen", default="", help="Адрес Flask (0.0.0.0)")
    parser.add_argument("--rate", type=int, default=0, help="Sample rate")
    parser.add_argument("--channels", type=int, default=0, help="1 или 2")
    parser.add_argument("--format", default="", choices=["", "float32", "int16", "int8"])
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    cfg = _state["config"]
    if args.host:
        cfg["relay_host"] = args.host
    if args.port:
        cfg["relay_port"] = args.port
    if args.rate:
        cfg["samplerate"] = args.rate
    if args.channels in (1, 2):
        cfg["channels"] = args.channels
    if args.format:
        cfg["format"] = args.format
    if args.listen:
        cfg["listen_host"] = args.listen
    if args.web_port:
        cfg["web_port"] = args.web_port

    save_config(cfg)

    listen = cfg.get("listen_host") or "0.0.0.0"
    web_port = int(cfg.get("web_port") or 5000)

    print(f"{APP_TITLE}")
    print(f"  Web UI  →  http://{'127.0.0.1' if listen == '0.0.0.0' else listen}:{web_port}")
    print(f"  Relay   →  {cfg['relay_host']}:{cfg['relay_port']}")
    print(f"  Audio   →  {cfg['samplerate']} Hz, {cfg['channels']} ch, {cfg['format']}")
    print("  Ctrl+C для выхода.\n")

    threading.Thread(target=_status_broadcast_loop, daemon=True).start()

    socketio.run(
        app,
        host=listen,
        port=web_port,
        debug=args.debug,
        use_reloader=False,
        allow_unsafe_werkzeug=True,
    )
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nОстановлено.")
        sys.exit(0)