@echo off
REM ============================================================
REM  download_deps.bat — скачивает Python-зависимости в папку "1"
REM  для последующей офлайн-установки на другой машине.
REM ============================================================

setlocal

REM --- Папка назначения ---
set "TARGET_DIR=1"

REM --- Файл зависимостей ---
set "REQ_FILE=requirements.txt"

REM --- Проверка: есть ли requirements.txt ---
if not exist "%REQ_FILE%" (
    echo [ERROR] Не найден файл "%REQ_FILE%" в текущей директории.
    echo         Создайте его со списком зависимостей и запустите снова.
    pause
    exit /b 1
)

REM --- Создание папки "1", если её нет ---
if not exist "%TARGET_DIR%" (
    echo [INFO] Создаю папку "%TARGET_DIR%"...
    mkdir "%TARGET_DIR%"
)

REM --- Определяем, какой Python доступен ---
where python >nul 2>nul
if %ERRORLEVEL%==0 (
    set "PY=python"
) else (
    where py >nul 2>nul
    if %ERRORLEVEL%==0 (
        set "PY=py -3"
    ) else (
        echo [ERROR] Python не найден в PATH. Установите Python или добавьте его в PATH.
        pause
        exit /b 1
    )
)

echo.
echo ============================================================
echo  Скачивание зависимостей в папку "%TARGET_DIR%"
echo  Python: %PY%
echo  Файл:   %REQ_FILE%
echo ============================================================
echo.

REM --- Основная команда ---
%PY% -m pip download -r "%REQ_FILE%" -d "%TARGET_DIR%"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] pip download завершился с ошибкой.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo ============================================================
echo  Готово. Пакеты сохранены в: %CD%\%TARGET_DIR%
echo ============================================================
echo.

REM --- Показываем содержимое папки ---
dir /b "%TARGET_DIR%"

echo.
echo Чтобы установить на целевой машине, выполните:
echo   python -m pip install -r %REQ_FILE% --no-index --find-links=%TARGET_DIR%
echo.

pause
endlocal