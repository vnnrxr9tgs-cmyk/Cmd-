/**
 * Local AI Chat — frontend v3.13
 * + универсальная модалка (N кнопок), диалог выбора при "новый чат"
 *   из временного чата.
 */

// ========== DOM ==========
const messagesContainer = document.getElementById('messages');
const userInput         = document.getElementById('user-input');
const sendBtn           = document.getElementById('send-btn');
const stopBtn           = document.getElementById('stop-generation-btn');
const statusDiv         = document.getElementById('status');
const contextCountSpan  = document.getElementById('context-count');
const modelSelect       = document.getElementById('model-select');
const systemPrompt      = document.getElementById('system-prompt');
const promptPreset      = document.getElementById('prompt-preset');
const temperature       = document.getElementById('temperature');
const topP              = document.getElementById('top-p');
const topK              = document.getElementById('top-k');
const frequencyPenalty  = document.getElementById('frequency-penalty');
const presencePenalty   = document.getElementById('presence-penalty');
const repeatPenalty     = document.getElementById('repeat-penalty');
const maxTokens         = document.getElementById('max-tokens');
const seedInput         = document.getElementById('seed');
const soundToggle       = document.getElementById('sound-toggle');
const notifToggle       = document.getElementById('notif-toggle');
const modelBadge        = document.getElementById('model-badge');
const currentChatTitle  = document.getElementById('currentChatTitle');
const chatsList         = document.getElementById('chatsList');
const visionHint        = document.getElementById('vision-hint');

const pendingAttachments = document.getElementById('pendingAttachments');

const imageInput            = document.getElementById('imageInput');
const uploadImageBtn        = document.getElementById('uploadImageBtn');
const imagePreviewContainer = document.getElementById('imagePreviewContainer');
const imagePreview          = document.getElementById('imagePreview');
const removeImageBtn        = document.getElementById('removeImageBtn');
const imageInfo             = document.getElementById('imageInfo');
const imageUploadArea       = document.getElementById('imageUploadArea');

const appEl            = document.getElementById('app');
const mainArea         = document.getElementById('mainArea');
const dropOverlay      = document.getElementById('dropOverlay');
const openSidebarBtn   = document.getElementById('openSidebarBtn');
const sidebarClose     = document.getElementById('sidebarClose');
const drawerMenu       = document.getElementById('drawerMenu');
const openDrawerBtn    = document.getElementById('openDrawerBtn');
const drawerClose      = document.getElementById('drawerClose');
const drawerOverlay    = document.getElementById('drawerOverlay');
const advancedToggle   = document.getElementById('advancedToggle');
const newChatBtn       = document.getElementById('newChatBtn');
const newTempChatBtn   = document.getElementById('newTempChatBtn');
const exportChatBtn    = document.getElementById('exportChatBtn');
const clearAllChatsBtn = document.getElementById('clearAllChatsBtn');
const clearChatBtn     = document.getElementById('clear-chat-btn');
const resetSettingsBtn = document.getElementById('reset-settings-btn');

const tempBadgeWrap    = document.getElementById('tempBadgeWrap');
const promoteTempBtn   = document.getElementById('promoteTempBtn');
const closeTempBtn     = document.getElementById('closeTempBtn');

const lightboxEl    = document.getElementById('lightbox');
const lightboxImg   = document.getElementById('lightboxImg');
const lightboxClose = document.getElementById('lightboxClose');

const modalOverlay = document.getElementById('modalOverlay');
const modalBox     = document.getElementById('modalBox');
const modalIcon    = document.getElementById('modalIcon');
const modalTitle   = document.getElementById('modalTitle');
const modalMessage = document.getElementById('modalMessage');
const modalActions = document.getElementById('modalActions');

// ========== STATE ==========
let modelsInfo = [];
let currentImageBase64 = null;
let currentImageMimeType = null;
let currentImageFull = null;
let currentImageThumb = null;
let currentImageName = '';
let currentImageSize = 0;
let activeRequest = false;
let currentAbortController = null;
let isAdvancedOpen = localStorage.getItem('advanced_open') === 'true';

let audioCtx = null;
let soundEnabled = true;
let notifEnabled = true;
let notificationPermissionGranted = false;

const STORAGE_KEY = 'local_ai_chats_v3';
const OLD_STORAGE_KEY = 'local_ai_chats_v2';
let chats = [];
let currentChatId = null;

let cancelAttempts = [];
let isBlocked = false;
let blockEndTime = null;
const CANCEL_WINDOW_MS = 30000;
const CANCEL_MAX = 3;
const BLOCK_MS = 45000;
const REQUEST_TIMEOUT_MS = 8 * 60 * 1000;

let dragCounter = 0;
const FILE_MAX_BYTES = 5 * 1024 * 1024;
const TEXT_MAX_CHARS = 100000;

// ========== МОДАЛЬНОЕ ОКНО (N кнопок) ==========
let modalResolve = null;

/**
 * Универсальное модальное окно.
 * @param {object} opts
 *   opts.title     {string}
 *   opts.message   {string}
 *   opts.icon      {string}  FA-класс без префикса 'fa'
 *   opts.tone      {'default'|'danger'|'purple'}
 *   opts.buttons   {Array<{id,text,autofocus?,wide?}>}
 * @returns Promise<string|null> — id нажатой кнопки или 'cancel'/'esc'/null
 */
function openModal(opts = {}) {
    return new Promise((resolve) => {
        if (modalResolve) { try { modalResolve(null); } catch (_) {} modalResolve = null; }
        modalResolve = resolve;

        const {
            title = 'Подтверждение',
            message = '',
            icon = 'fa-exclamation-triangle',
            tone = 'default',
            buttons = [
                { id: 'cancel', text: 'Отмена' },
                { id: 'ok', text: 'OK', autofocus: true },
            ],
        } = opts;

        modalTitle.textContent = title;
        modalMessage.textContent = message;
        modalBox.classList.toggle('danger', tone === 'danger');
        modalBox.classList.toggle('purple', tone === 'purple');
        modalIcon.innerHTML = `<i class="fas ${icon}"></i>`;

        modalActions.innerHTML = '';
        buttons.forEach(btn => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'modal-btn';
            b.dataset.id = btn.id;
            b.textContent = btn.text;
            b.addEventListener('click', () => finish(btn.id));
            modalActions.appendChild(b);
        });

        modalOverlay.classList.add('open');
        document.body.style.overflow = 'hidden';

        const focusBtn = buttons.find(b => b.autofocus);
        if (focusBtn) {
            const el = modalActions.querySelector(`[data-id="${focusBtn.id}"]`);
            if (el) setTimeout(() => el.focus(), 60);
        }

        function finish(value) {
            modalOverlay.classList.remove('open');
            document.body.style.overflow = '';
            modalActions.innerHTML = '';
            modalOverlay.onclick = null;
            document.removeEventListener('keydown', keyHandler);
            modalResolve = null;
            resolve(value);
        }

        function keyHandler(e) {
            if (!modalOverlay.classList.contains('open')) return;
            if (e.key === 'Escape') { e.preventDefault(); finish('cancel'); }
            else if (e.key === 'Enter') {
                const primary = buttons.find(b => b.autofocus) || buttons[buttons.length - 1];
                if (primary) { e.preventDefault(); finish(primary.id); }
            }
        }

        modalOverlay.onclick = (e) => { if (e.target === modalOverlay) finish('cancel'); };
        document.addEventListener('keydown', keyHandler);
    });
}

/** Совместимость с прежним API. Возвращает true, если нажали "ok". */
function showConfirm(message, options = {}) {
    const {
        title = 'Подтверждение',
        okText = 'Да',
        cancelText = 'Нет',
        danger = true,
        icon = 'fa-exclamation-triangle',
        tone,
    } = options;
    const finalTone = tone || (danger ? 'danger' : 'default');

    return openModal({
        title, message, icon, tone: finalTone,
        buttons: [
            { id: 'cancel', text: cancelText },
            { id: 'ok', text: okText, autofocus: true },
        ],
    }).then(id => id === 'ok');
}

// ========== ПРЕСЕТЫ ПРОМПТОВ ==========
const PROMPT_PRESETS = {
    translator: `Ты профессиональный переводчик.

ПРАВИЛА:
- Определяй язык исходного текста автоматически. Переводи на язык, который указал пользователь. Если язык не указан — переводи на английский (если исходник русский) или на русский (если исходник на другом языке).
- Сохраняй стиль, тон, регистр и интонацию оригинала. Технические термины — точно и последовательно. Идиомы — адаптируй так, чтобы звучало естественно на целевом языке.
- Никаких пояснений, вступлений и заключений. Выдавай только перевод.
- Если в тексте есть неоднозначности — переводи наиболее вероятный вариант.
- Сохраняй разметку, переносы строк и форматирование оригинала.`,

    programmer: `Ты опытный программист-эксперт.

ПРАВИЛА:
- Давай рабочие, идиоматичные решения на языке из вопроса. Используй современные практики: типизацию, обработку ошибок, понятные имена.
- Сложный код — с короткими комментариями по существу. Длинные ответы оформляй markdown-блоком кода с указанием языка.
- Если задача допускает несколько подходов — предложи лучший и кратко упомяни альтернативы с их плюсами/минусами.
- Не разжёвывай базу, если не просят. Будь лаконичен, но не в ущерб корректности.
- Отвечай на русском, код — на языке задачи.
- Если в задаче есть баг или подводный камень — предупреди.`,

    analyst: `Ты профессиональный аналитик (данные, бизнес, продукт).

ПРАВИЛА:
- Разбивай задачу на факты, метрики, гипотезы и выводы. Отделяй наблюдения от интерпретаций.
- Опирайся на данные пользователя. Если данных нет — чётко обозначь допущения и предложи, что ещё нужно собрать.
- Давай структурированные ответы: списки, таблицы, сравнения. Указывай ключевые метрики и их значение.
- Не выдумывай цифры и не преувеличивай. Если чего-то не хватает — скажи прямо.
- Отвечай на русском.`,

    editor: `Ты опытный редактор и копирайтер.

ПРАВИЛА:
- Улучшай текст, сохраняя смысл и голос автора. Убирай воду, канцелярит, тавтологии, штампы.
- Подстраивай стиль под аудиторию и формат (пост, письмо, статья, документация).
- По запросу — сокращай, удлиняй, меняй тон, переписывай под конкретный стиль.
- Показывай готовый результат сразу, без лишних пояснений. Если просят «до/после» — оформляй явно.
- Отвечай на русском.`,

    teacher: `Ты терпеливый преподаватель.

ПРАВИЛА:
- Объясняй пошагово, от простого к сложному, с примерами и аналогиями.
- Проверяй понимание: в конце давай 1–2 вопроса для самопроверки.
- Если просят «реши задачу» — не выдавай готовый ответ сразу, направляй и задавай наводящие вопросы.
- Разбивай сложные темы на блоки. Используй списки и примеры.
- Отвечай на русском.`,

    default: `Ты полезный ассистент. Отвечай чётко и по существу. Используй markdown для структуры, кода и списков.`,
};

// ========== UTILS ==========
function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function showToast(msg, type = 'info') {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.className = 'toast show' + (type === 'error' ? ' error' : type === 'success' ? ' success' : '');
    setTimeout(() => el.classList.remove('show'), 2800);
}

function setStatus(text, isError = false, isBusy = false) {
    const textEl = statusDiv.querySelector('.status-text') || statusDiv;
    if (textEl.classList && textEl.classList.contains('status-text')) {
        textEl.textContent = text;
    } else {
        const spans = statusDiv.querySelectorAll('span');
        if (spans.length > 1) spans[1].textContent = text;
    }
    statusDiv.classList.toggle('error', !!isError);
    statusDiv.classList.toggle('busy', !!isBusy);
}

function escapeHtml(text) {
    if (!text) return '';
    const d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        const n = document.getElementById('copy-notification');
        n.classList.add('show');
        setTimeout(() => n.classList.remove('show'), 1800);
    }).catch(() => showToast('Не удалось скопировать', 'error'));
}

function formatBytes(bytes) {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} Б`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
    return `${(bytes / 1024 / 1024).toFixed(2)} МБ`;
}

// ========== ПРИВЛЕЧЕНИЕ ВНИМАНИЯ К ОКНУ ==========
let titleFlashInterval = null;
let originalTitle = document.title;

function flashWindowAttention() {
    try { window.focus(); } catch (_) {}
    if (titleFlashInterval) return;
    let on = false;
    originalTitle = document.title;
    titleFlashInterval = setInterval(() => {
        on = !on;
        document.title = on ? '⬇ Отпустите файл в окне' : originalTitle;
    }, 600);

    if (notifEnabled && 'Notification' in window && Notification.permission === 'granted') {
        try {
            const n = new Notification('Перетащите файл в окно браузера', {
                body: 'Отпустите файл над окном Local AI Chat',
                tag: 'drag-hint',
                silent: true,
            });
            setTimeout(() => { try { n.close(); } catch (_) {} }, 3000);
        } catch (_) {}
    }
}

function stopFlashWindowAttention() {
    if (titleFlashInterval) {
        clearInterval(titleFlashInterval);
        titleFlashInterval = null;
    }
    document.title = originalTitle;
}

// ========== ЗВУК ==========
function ensureAudioContext() {
    try {
        if (!audioCtx) {
            const Ctx = window.AudioContext || window.webkitAudioContext;
            if (!Ctx) return null;
            audioCtx = new Ctx();
        }
        if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
        return audioCtx;
    } catch (_) { return null; }
}

function playDoneSound() {
    if (!soundEnabled) return;
    const ctx = ensureAudioContext();
    if (!ctx) return;
    try {
        const now = ctx.currentTime;
        const master = ctx.createGain();
        master.gain.value = 0.18;
        master.connect(ctx.destination);

        const tones = [
            { freq: 659.25, start: 0.00, dur: 0.35 },
            { freq: 880.00, start: 0.10, dur: 0.55 },
        ];
        tones.forEach(t => {
            const osc = ctx.createOscillator();
            osc.type = 'sine';
            osc.frequency.value = t.freq;
            const g = ctx.createGain();
            g.gain.setValueAtTime(0.0001, now + t.start);
            g.gain.linearRampToValueAtTime(1, now + t.start + 0.012);
            g.gain.exponentialRampToValueAtTime(0.0001, now + t.start + t.dur);
            osc.connect(g); g.connect(master);
            osc.start(now + t.start);
            osc.stop(now + t.start + t.dur + 0.05);
        });
    } catch (_) {}
}

// ========== NATIVE NOTIFICATION ==========
async function ensureNotificationPermission() {
    if (!notifEnabled) return false;
    if (!('Notification' in window)) return false;
    if (Notification.permission === 'granted') { notificationPermissionGranted = true; return true; }
    if (Notification.permission === 'denied') { notificationPermissionGranted = false; return false; }
    try {
        const p = await Notification.requestPermission();
        notificationPermissionGranted = (p === 'granted');
        return notificationPermissionGranted;
    } catch (_) { notificationPermissionGranted = false; return false; }
}

function showNativeNotification(title, body) {
    if (!notifEnabled) return;
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;
    try {
        const n = new Notification(title, { body, tag: 'local-ai-done', silent: true });
        n.onclick = () => { window.focus(); n.close(); };
        setTimeout(() => { try { n.close(); } catch (_) {} }, 5000);
    } catch (_) {}
}

// ========== IN-PAGE TRAY ==========
function removeTrayNotification() {
    const el = document.getElementById('tray-notification');
    if (!el) return;
    el.classList.remove('show');
    setTimeout(() => { if (el.parentNode) el.remove(); }, 320);
}

function showTrayNotification(title, body) {
    removeTrayNotification();

    const el = document.createElement('div');
    el.id = 'tray-notification';
    el.className = 'tray-notification';
    el.innerHTML = `
        <div class="tray-icon"><i class="fas fa-robot"></i></div>
        <div class="tray-content">
            <div class="tray-title"></div>
            <div class="tray-body"></div>
        </div>
        <button class="tray-close" title="Закрыть">
            <i class="fas fa-times"></i>
        </button>
    `;
    el.querySelector('.tray-title').textContent = title;
    el.querySelector('.tray-body').textContent = body;

    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));

    let closed = false;
    const close = () => {
        if (closed) return;
        closed = true;
        el.classList.remove('show');
        setTimeout(() => { if (el.parentNode) el.remove(); }, 320);
    };

    el.querySelector('.tray-close').addEventListener('click', (e) => { e.stopPropagation(); close(); });
    el.addEventListener('click', (e) => {
        if (e.target.closest('.tray-close')) return;
        try { window.focus(); } catch (_) {}
        close();
    });

    let autoTimer = setTimeout(close, 5000);
    el.addEventListener('mouseenter', () => clearTimeout(autoTimer));
    el.addEventListener('mouseleave', () => { if (!closed) autoTimer = setTimeout(close, 2000); });
}

// ========== ФИНАЛИЗАЦИЯ ==========
function onModelFinished(previewText) {
    playDoneSound();
    if (!notifEnabled) return;

    const title = 'Готово';
    const raw = (previewText || '').replace(/\s+/g, ' ').trim();
    const body = raw ? (raw.slice(0, 120) + (raw.length > 120 ? '…' : '')) : 'Модель закончила отвечать';
    const awayFromPage = document.hidden || !document.hasFocus();

    if (awayFromPage && notificationPermissionGranted) showNativeNotification(title, body);
    else showTrayNotification(title, body);
}

// ========== LIGHTBOX ==========
function openLightbox(src) {
    if (!lightboxEl || !lightboxImg || !src) return;
    lightboxImg.src = src;
    lightboxEl.classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeLightbox() {
    if (!lightboxEl) return;
    lightboxEl.classList.remove('open');
    document.body.style.overflow = '';
    setTimeout(() => {
        if (lightboxImg && !lightboxEl.classList.contains('open')) lightboxImg.src = '';
    }, 220);
}
function initLightbox() {
    if (!lightboxEl) return;
    lightboxEl.addEventListener('click', (e) => {
        if (e.target === lightboxEl || e.target === lightboxImg) closeLightbox();
    });
    if (lightboxClose) {
        lightboxClose.addEventListener('click', (e) => { e.stopPropagation(); closeLightbox(); });
    }
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && lightboxEl.classList.contains('open')) closeLightbox();
    });
}

// ========== MARKDOWN ==========
function formatMessageWithCode(text) {
    if (!text) return '';
    const codeBlocks = [];
    let processed = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
        const id = codeBlocks.length;
        codeBlocks.push({ lang: lang || 'plaintext', code: code.trimEnd() });
        return `\n%%CODEBLOCK_${id}%%\n`;
    });

    processed = escapeHtml(processed);
    processed = processed.replace(/`([^`\n]+)`/g, '<code class="inline">$1</code>');
    processed = processed.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    processed = processed.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    processed = processed.replace(/\*(.+?)\*/g, '<em>$1</em>');
    processed = processed.replace(/__(.+?)__/g, '<strong>$1</strong>');
    processed = processed.replace(/_(.+?)_/g, '<em>$1</em>');
    processed = processed.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

    processed = processed.replace(/(?:^|\n)([-*] .+(?:\n[-*] .+)*)/g, (block) => {
        const items = block.trim().split(/\n/).map(l => l.replace(/^[-*] /, '').trim());
        return '<ul>' + items.map(i => `<li>${i}</li>`).join('') + '</ul>';
    });
    processed = processed.replace(/(?:^|\n)(\d+\. .+(?:\n\d+\. .+)*)/g, (block) => {
        const items = block.trim().split(/\n/).map(l => l.replace(/^\d+\. /, '').trim());
        return '<ol>' + items.map(i => `<li>${i}</li>`).join('') + '</ol>';
    });

    const parts = processed.split(/\n{2,}/);
    processed = parts.map(p => {
        p = p.trim();
        if (!p) return '';
        if (p.startsWith('<ul>') || p.startsWith('<ol>') || p.startsWith('%%CODEBLOCK_')) return p;
        return '<p>' + p.replace(/\n/g, '<br>') + '</p>';
    }).join('');

    codeBlocks.forEach((cb, i) => {
        const html = `
            <div class="code-container">
                <div class="code-header">
                    <div class="code-lang"><i class="fas fa-code"></i> ${escapeHtml(cb.lang.toUpperCase())}</div>
                    <button class="copy-code-btn" type="button"><i class="fas fa-copy"></i> Копировать</button>
                </div>
                <pre class="code-block"><code class="language-${escapeHtml(cb.lang)}">${escapeHtml(cb.code)}</code></pre>
            </div>`;
        processed = processed.replace(`%%CODEBLOCK_${i}%%`, html);
    });
    return processed;
}

function addCopyButtonsToCodeBlocks(container) {
    if (!container) return;
    container.querySelectorAll('.code-container').forEach(box => {
        if (box.querySelector('.copy-code-btn')?.dataset.bound) return;
        const btn = box.querySelector('.copy-code-btn');
        const code = box.querySelector('pre code');
        if (btn && code) {
            btn.dataset.bound = '1';
            btn.onclick = (e) => { e.stopPropagation(); copyToClipboard(code.innerText); };
        }
    });
}

function highlightCode(container) {
    if (!container || !window.hljs) return;
    container.querySelectorAll('pre code').forEach(block => {
        try { hljs.highlightElement(block); } catch (_) {}
    });
}

// ========== МИГРАЦИЯ ==========
function migrateOldStorage() {
    try {
        const old = localStorage.getItem(OLD_STORAGE_KEY);
        if (!old) return;
        if (localStorage.getItem(STORAGE_KEY)) return;
        const data = JSON.parse(old);
        const newChats = (data.chats || []).map(c => ({
            id: c.id, title: c.title, created: c.created, updated: c.updated,
            favorite: false,
            temporary: false,
            history: (c.history || []).map(m => {
                if (m.role === 'assistant') {
                    return {
                        role: 'assistant',
                        variants: [{ content: m.content || '', reasoning: '', stats: null, createdAt: Date.now() }],
                        activeVariant: 0,
                    };
                }
                return m;
            })
        }));
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ chats: newChats, currentChatId: data.currentChatId }));
    } catch (_) {}
}

function stripImageMarker(content) {
    if (typeof content !== 'string') return content || '';
    return content
        .replace(/\n?🖼️ Изображение прикреплено\s*$/g, '')
        .replace(/^🖼️ Анализ изображения\s*$/g, '')
        .trim();
}

function normalizeHistory(history) {
    return (history || []).map(m => {
        if (m.role === 'divider') {
            return { role: 'divider', type: m.type || 'model', text: m.text || '' };
        }
        if (m.role === 'assistant') {
            if (Array.isArray(m.variants) && m.variants.length) {
                return { ...m, variants: m.variants.map(v => ({ ...v, streaming: false })) };
            }
            return {
                role: 'assistant',
                variants: [{ content: m.content || '', reasoning: '', stats: null, createdAt: Date.now() }],
                activeVariant: 0,
            };
        }
        const img = m.image || null;
        return {
            role: 'user',
            content: stripImageMarker(m.content || ''),
            image: img ? { thumb: img.thumb || null, full: img.full || null } : null,
        };
    });
}

// ========== MULTI-CHAT ==========
function sortChats() {
    chats.sort((a, b) => {
        const af = a.favorite ? 1 : 0;
        const bf = b.favorite ? 1 : 0;
        if (af !== bf) return bf - af;
        return (b.updated || b.created || 0) - (a.updated || a.created || 0);
    });
}

function loadChatsFromStorage() {
    migrateOldStorage();
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
            const data = JSON.parse(raw);
            chats = (data.chats || [])
                .filter(c => !c.temporary)
                .map(c => ({
                    ...c,
                    favorite: !!c.favorite,
                    temporary: false,
                    history: normalizeHistory(c.history),
                }));
            currentChatId = data.currentChatId || null;
        }
    } catch (_) { chats = []; currentChatId = null; }
    if (!chats.length) createNewChat(false);
    else if (!currentChatId || !chats.find(c => c.id === currentChatId)) currentChatId = chats[0].id;
    sortChats();
}

function chatsForStorage() {
    return chats
        .filter(c => !c.temporary)
        .map(c => ({
            ...c,
            favorite: !!c.favorite,
            temporary: false,
            history: (c.history || []).map(m => {
                if (m.role === 'user' && m.image) {
                    return { ...m, image: { thumb: m.image.thumb || null } };
                }
                return m;
            })
        }));
}

function saveChatsToStorage() {
    try {
        const current = chats.find(c => c.id === currentChatId);
        const persistCurrentId = (current && !current.temporary) ? currentChatId : null;

        localStorage.setItem(STORAGE_KEY, JSON.stringify({
            chats: chatsForStorage(),
            currentChatId: persistCurrentId,
        }));
    } catch (e) {
        showToast('Не удалось сохранить (localStorage переполнен?)', 'error');
    }
}

function getCurrentChat() { return chats.find(c => c.id === currentChatId) || null; }
function getTemporaryChat() { return chats.find(c => c.temporary) || null; }

function createNewChat(switchTo = true) {
    const chat = {
        id: uid(), title: 'Новый чат',
        created: Date.now(), updated: Date.now(),
        favorite: false,
        temporary: false,
        history: [],
    };
    chats.unshift(chat);
    if (switchTo) {
        currentChatId = chat.id;
        renderMessages();
        updateChatTitle();
        updateTempModeUI();
    }
    sortChats();
    saveChatsToStorage();
    renderChatsList();
    return chat;
}

function openOrCreateTemporaryChat() {
    if (activeRequest) {
        showToast('Дождитесь окончания генерации', 'error');
        return;
    }
    const existing = getTemporaryChat();
    if (existing) {
        switchChat(existing.id);
        showToast('Временный чат открыт', 'info');
        return;
    }
    const chat = {
        id: uid(),
        title: 'Временный чат',
        created: Date.now(),
        updated: Date.now(),
        favorite: false,
        temporary: true,
        history: [],
    };
    chats.unshift(chat);
    currentChatId = chat.id;
    renderMessages();
    updateChatTitle();
    updateTempModeUI();
    saveChatsToStorage();
    renderChatsList();
    showToast('Временный чат создан', 'success');
}

async function promoteTemporaryChat() {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    if (!chat || !chat.temporary) return;

    const ok = await showConfirm(
        'Сохранить временный чат?\n\nОн появится в списке чатов и будет сохранён как обычный.',
        { title: 'Сохранить чат', okText: 'Сохранить', cancelText: 'Отмена',
          danger: false, tone: 'purple', icon: 'fa-bookmark' }
    );
    if (!ok) return;

    chat.temporary = false;
    chat.updated = Date.now();
    if (chat.title === 'Временный чат' && chat.history.length) {
        const firstUser = chat.history.find(m => m.role === 'user');
        if (firstUser) {
            let t = (firstUser.content || '').trim();
            if (!t && firstUser.image) t = '🖼️ Изображение';
            t = t.slice(0, 42) + (t.length > 42 ? '…' : '');
            if (t) chat.title = t;
        }
    } else if (!chat.history.length) {
        chat.title = 'Новый чат';
    }

    updateTempModeUI();
    updateChatTitle();
    sortChats();
    saveChatsToStorage();
    renderChatsList();
    showToast('Чат сохранён как обычный', 'success');
}

async function closeTemporaryChat(skipConfirm = false) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    if (!chat || !chat.temporary) return;

    if (!skipConfirm) {
        const ok = await showConfirm(
            'Закрыть временный чат?\n\nДиалог будет удалён без возможности восстановления.',
            { title: 'Закрыть временный чат', okText: 'Закрыть', cancelText: 'Отмена',
              danger: true, icon: 'fa-clock' }
        );
        if (!ok) return;
    }

    chats = chats.filter(c => c.id !== chat.id);

    if (chats.length) {
        const target = chats.find(c => !c.temporary) || chats[0];
        currentChatId = target.id;
    } else {
        const newChat = {
            id: uid(), title: 'Новый чат',
            created: Date.now(), updated: Date.now(),
            favorite: false, temporary: false, history: [],
        };
        chats.unshift(newChat);
        currentChatId = newChat.id;
    }

    saveChatsToStorage();
    renderMessages();
    updateChatTitle();
    updateTempModeUI();
    renderChatsList();
    updateContextCount();
    showToast('Временный чат закрыт', 'success');
}

function switchChat(id) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    currentChatId = id;
    saveChatsToStorage();
    renderMessages();
    updateChatTitle();
    updateTempModeUI();
    renderChatsList();
    if (window.innerWidth <= 900) appEl.classList.add('sidebar-collapsed');
}

function toggleFavorite(id, e) {
    if (e) { e.stopPropagation(); }
    const chat = chats.find(c => c.id === id);
    if (!chat) return;
    chat.favorite = !chat.favorite;
    sortChats();
    saveChatsToStorage();
    renderChatsList();
    showToast(chat.favorite ? 'Добавлено в избранное' : 'Убрано из избранного', 'success');
}

async function requestDeleteChat(id, e) {
    if (e) e.stopPropagation();
    const chat = chats.find(c => c.id === id);
    if (!chat) return;

    if (chat.favorite) {
        showToast('Сначала уберите чат из избранного', 'error');
        return;
    }

    const ok = await showConfirm(
        `Удалить чат "${chat.title || 'Новый чат'}"?`,
        { title: 'Удаление чата', okText: 'Да', cancelText: 'Нет', danger: true, icon: 'fa-trash-alt' }
    );
    if (!ok) return;

    if (chats.length <= 1) {
        chat.history = []; chat.title = 'Новый чат'; chat.updated = Date.now();
        currentChatId = chat.id;
        saveChatsToStorage(); renderMessages(); updateChatTitle(); renderChatsList();
        return;
    }
    chats = chats.filter(c => c.id !== id);
    if (currentChatId === id) {
        const next = chats.find(c => !c.temporary) || chats[0];
        currentChatId = next.id;
    }
    sortChats();
    saveChatsToStorage();
    renderMessages();
    updateChatTitle();
    updateTempModeUI();
    renderChatsList();
}

function startRenameChat(id, e) {
    if (e) { e.stopPropagation(); }
    const chat = chats.find(c => c.id === id);
    if (!chat) return;
    const el = chatsList.querySelector(`.chat-item[data-id="${id}"]`);
    if (!el) return;

    const titleSpan = el.querySelector('.chat-title');
    if (!titleSpan || el.querySelector('.chat-title-input')) return;

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'chat-title-input';
    input.value = chat.title === 'Новый чат' ? '' : chat.title;
    input.maxLength = 80;
    titleSpan.replaceWith(input);
    input.focus();
    input.select();

    let finished = false;
    const finish = (save) => {
        if (finished) return;
        finished = true;
        if (save) {
            const val = input.value.trim();
            if (val && val !== chat.title) {
                chat.title = val.slice(0, 80);
                chat.updated = Date.now();
                saveChatsToStorage();
                if (currentChatId === id) updateChatTitle();
                sortChats();
            }
        }
        renderChatsList();
    };

    input.addEventListener('click', (ev) => ev.stopPropagation());
    input.addEventListener('keydown', (ev) => {
        ev.stopPropagation();
        if (ev.key === 'Enter') { ev.preventDefault(); finish(true); }
        else if (ev.key === 'Escape') { ev.preventDefault(); finish(false); }
    });
    input.addEventListener('blur', () => finish(true));
}

function updateChatTitleFromHistory() {
    const chat = getCurrentChat();
    if (!chat || !chat.history.length) return;
    if (chat.title !== 'Новый чат' && chat.title !== 'Временный чат') return;
    const firstUser = chat.history.find(m => m.role === 'user');
    if (firstUser) {
        let t = (firstUser.content || '').trim();
        if (!t && firstUser.image) t = '🖼️ Изображение';
        t = t.slice(0, 42) + (t.length > 42 ? '…' : '');
        chat.title = t || (chat.temporary ? 'Временный чат' : 'Новый чат');
        chat.updated = Date.now();
        sortChats();
        saveChatsToStorage(); updateChatTitle(); renderChatsList();
    }
}

function updateChatTitle() {
    const chat = getCurrentChat();
    currentChatTitle.textContent = chat ? (chat.title || '💬 Чат') : '💬 Чат';
}

function updateTempModeUI() {
    const chat = getCurrentChat();
    const isTemp = !!(chat && chat.temporary);
    if (mainArea) mainArea.classList.toggle('temp-mode', isTemp);
    if (tempBadgeWrap) tempBadgeWrap.classList.toggle('visible', isTemp);
}

function renderChatsList() {
    if (!chatsList) return;
    chatsList.innerHTML = '';
    const visibleChats = chats.filter(c => !c.temporary);
    sortChats();

    visibleChats.sort((a, b) => {
        const af = a.favorite ? 1 : 0;
        const bf = b.favorite ? 1 : 0;
        if (af !== bf) return bf - af;
        return (b.updated || b.created || 0) - (a.updated || a.created || 0);
    });

    visibleChats.forEach(chat => {
        const el = document.createElement('div');
        el.className = 'chat-item' + (chat.id === currentChatId ? ' active' : '') + (chat.favorite ? ' favorite' : '');
        el.dataset.id = chat.id;
        el.onclick = () => switchChat(chat.id);

        const date = new Date(chat.updated || chat.created);
        const dateStr = date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
        const favTitle = chat.favorite ? 'Убрать из избранного' : 'В избранное';
        const deleteBtnHtml = chat.favorite
            ? `<button class="chat-lock" title="Чат в избранном — уберите, чтобы удалить">
                   <i class="fas fa-lock"></i>
               </button>`
            : `<button class="chat-delete" title="Удалить"><i class="fas fa-trash-alt"></i></button>`;

        el.innerHTML = `
            <button class="chat-fav-btn" title="${favTitle}">
                <i class="fas fa-star"></i>
            </button>
            <span class="chat-title">${escapeHtml(chat.title)}</span>
            <span class="chat-date">${dateStr}</span>
            <button class="chat-rename" title="Переименовать"><i class="fas fa-pencil-alt"></i></button>
            ${deleteBtnHtml}
        `;
        el.querySelector('.chat-fav-btn').onclick = (ev) => toggleFavorite(chat.id, ev);
        el.querySelector('.chat-rename').onclick = (ev) => startRenameChat(chat.id, ev);
        const delBtn = el.querySelector('.chat-delete');
        if (delBtn) delBtn.onclick = (ev) => requestDeleteChat(chat.id, ev);
        const lockBtn = el.querySelector('.chat-lock');
        if (lockBtn) lockBtn.onclick = (ev) => {
            ev.stopPropagation();
            showToast('Сначала уберите чат из избранного', 'info');
        };

        chatsList.appendChild(el);
    });
}

function updateContextCount() {
    const chat = getCurrentChat();
    if (!chat) { if (contextCountSpan) contextCountSpan.textContent = 0; return; }
    const n = (chat.history || []).filter(m => m.role === 'user' || m.role === 'assistant').length;
    if (contextCountSpan) contextCountSpan.textContent = n;
}

// ========== ОЧИСТКА РАЗДЕЛИТЕЛЕЙ ==========
function cleanupDividers(chat) {
    if (!chat || !Array.isArray(chat.history)) return false;
    const h = chat.history;
    const before = h.length;

    let startIdx = 0;
    while (startIdx < h.length && h[startIdx].role === 'divider') startIdx++;

    let endIdx = h.length - 1;
    while (endIdx >= 0 && h[endIdx].role === 'divider') endIdx--;

    if (startIdx > 0 || endIdx < h.length - 1) {
        chat.history = h.slice(startIdx, endIdx + 1);
    }
    return chat.history.length !== before;
}

// ========== ИСТОРИЯ ДЛЯ API ==========
function historyForApi(history) {
    const out = [];
    for (const m of history) {
        if (m.role === 'user') out.push({ role: 'user', content: m.content || '' });
        else if (m.role === 'assistant') {
            const v = m.variants?.[m.activeVariant];
            if (v && v.content) out.push({ role: 'assistant', content: v.content });
        }
    }
    return out;
}

function hasAssistantAfter(chat, userIdx) {
    if (!chat) return false;
    for (let i = userIdx + 1; i < chat.history.length; i++) {
        const r = chat.history[i].role;
        if (r === 'assistant') return true;
        if (r === 'user') return false;
    }
    return false;
}

// ========== PENDING ATTACHMENT ==========
function renderPendingAttachment() {
    if (!pendingAttachments) return;
    if (!currentImageBase64) {
        pendingAttachments.style.display = 'none';
        pendingAttachments.innerHTML = '';
        return;
    }
    const name = currentImageName || 'изображение.jpg';
    const sizeStr = currentImageSize ? formatBytes(currentImageSize) : '';
    const thumb = currentImageThumb || currentImageFull || '';

    pendingAttachments.style.display = 'flex';
    pendingAttachments.innerHTML = `
        <div class="pending-attachment" id="pendingAttachEl">
            <img src="${thumb}" alt="">
            <div class="pending-attachment-info">
                <span class="pending-attachment-name"></span>
                <span class="pending-attachment-size">${escapeHtml(sizeStr)}</span>
            </div>
            <span class="pending-attachment-badge">IMG</span>
            <button class="pending-attachment-remove" title="Убрать">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    pendingAttachments.querySelector('.pending-attachment-name').textContent = name;

    const img = pendingAttachments.querySelector('img');
    img.addEventListener('click', (e) => {
        e.stopPropagation();
        openLightbox(currentImageFull || currentImageThumb);
    });

    pendingAttachments.querySelector('.pending-attachment-remove').addEventListener('click', (e) => {
        e.stopPropagation();
        removeImage();
    });
}

// ========== CHAT DIVIDER ==========
function renderDivider(msg, idx) {
    const el = document.createElement('div');
    el.className = 'chat-divider';
    el.dataset.role = 'divider';
    el.dataset.msgIdx = String(idx);

    const textHtml = escapeHtml(msg.text || '').replace(/→/g, '<strong>→</strong>');

    el.innerHTML = `
        <div class="chat-divider-content">
            <i class="fas fa-exchange-alt"></i>
            <span class="divider-text">${textHtml}</span>
            <button class="divider-new-chat" title="Начать новый чат с последним ответом">
                <i class="fas fa-plus"></i> новый чат
            </button>
        </div>
    `;
    el.querySelector('.divider-new-chat').addEventListener('click', (e) => {
        e.stopPropagation();
        promptNewChatFromDivider();
    });
    return el;
}

function addModelDivider(oldModel, newModel) {
    const chat = getCurrentChat();
    if (!chat) return;
    const hasMessages = chat.history.some(m => m.role === 'user' || m.role === 'assistant');
    if (!hasMessages) return;

    chat.history.push({
        role: 'divider',
        type: 'model',
        text: `Модель изменена: ${oldModel || '—'} → ${newModel || '—'}`,
    });
    chat.updated = Date.now();
    saveChatsToStorage();
    renderMessages();
}

/**
 * Возвращает клонированное последнее assistant-сообщение или null.
 */
function takeLastAssistantMessage(chat) {
    if (!chat || !Array.isArray(chat.history)) return null;
    for (let i = chat.history.length - 1; i >= 0; i--) {
        if (chat.history[i].role === 'assistant') {
            const cloned = JSON.parse(JSON.stringify(chat.history[i]));
            if (cloned.variants) {
                cloned.variants = cloned.variants.map(v => ({ ...v, streaming: false }));
            }
            return cloned;
        }
    }
    return null;
}

/**
 * Клик по "новый чат" на разделителе.
 *  - Обычный чат: создаём новый постоянный чат с переносом последнего ответа.
 *  - Временный чат: спрашиваем, куда перенести — во временный или постоянный.
 */
async function promptNewChatFromDivider() {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }

    const chat = getCurrentChat();
    const inTemp = !!(chat && chat.temporary);

    if (!inTemp) {
        // Прежнее поведение: сразу создаём постоянный чат с переносом
        const carry = takeLastAssistantMessage(chat);
        const newChat = createNewChat(true);
        if (carry) {
            newChat.history.push(carry);
            newChat.updated = Date.now();
            saveChatsToStorage();
            renderMessages();
            updateContextCount();
            showToast('Новый чат (перенесён последний ответ)', 'success');
        } else {
            showToast('Новый чат', 'success');
        }
        return;
    }

    // Во временном чате — спрашиваем
    const choice = await openModal({
        title: 'Новый чат',
        message: 'Текущий временный чат будет удалён.\nПоследний ответ модели перенесётся в новый чат.\n\nКуда перенести?',
        icon: 'fa-exchange-alt',
        tone: 'purple',
        buttons: [
            { id: 'cancel', text: 'Отмена' },
            { id: 'temp', text: 'Временный' },
            { id: 'perm', text: 'Постоянный', autofocus: true },
        ],
    });

    if (choice === 'cancel' || choice === null) return;

    const carry = takeLastAssistantMessage(chat);

    // Удаляем старый временный чат
    chats = chats.filter(c => !c.temporary);

    if (choice === 'temp') {
        const newChat = {
            id: uid(),
            title: 'Временный чат',
            created: Date.now(), updated: Date.now(),
            favorite: false, temporary: true, history: [],
        };
        chats.unshift(newChat);
        currentChatId = newChat.id;
        if (carry) newChat.history.push(carry);

        saveChatsToStorage();
        renderMessages();
        updateChatTitle();
        updateTempModeUI();
        renderChatsList();
        updateContextCount();
        showToast('Новый временный чат' + (carry ? ' (перенесён ответ)' : ''), 'success');
    } else {
        // perm
        const newChat = {
            id: uid(),
            title: 'Новый чат',
            created: Date.now(), updated: Date.now(),
            favorite: false, temporary: false, history: [],
        };
        chats.unshift(newChat);
        currentChatId = newChat.id;
        if (carry) newChat.history.push(carry);

        // Название по первому пользователю — если перенесли ответ, там его нет,
        // оставим "Новый чат" и дадим авто-названию сработать при следующем сообщении.
        sortChats();
        saveChatsToStorage();
        renderMessages();
        updateChatTitle();
        updateTempModeUI();
        renderChatsList();
        updateContextCount();
        showToast('Новый постоянный чат' + (carry ? ' (перенесён ответ)' : ''), 'success');
    }
}

// ========== РЕНДЕР ==========
function renderWelcome() {
    messagesContainer.innerHTML = `
        <div class="welcome">
            <h2>👋 Локальный AI-чат</h2>
            <p>Работает через LM Studio. История сохраняется в браузере.</p>
            <div class="features">
                <div class="feature">🧠 Несколько чатов</div>
                <div class="feature">⏱ Временный чат</div>
                <div class="feature">📎 Drag & Drop файлов</div>
                <div class="feature">⭐ Избранное</div>
            </div>
        </div>
    `;
}

function renderThinkingBlock(variant, isStreaming) {
    if (!variant.reasoning) return '';
    let status;
    if (!isStreaming) status = 'Размышления';
    else if (variant.content) status = 'Отвечает…';
    else status = 'Думает…';
    const meta = `${variant.reasoning.length} симв.`;
    const streamingClass = (isStreaming && !variant.content) ? 'streaming' : '';
    const openAttr = isStreaming ? 'open' : '';
    return `
        <details class="thinking-block ${streamingClass}" ${openAttr}>
            <summary>
                <i class="fas fa-brain"></i>
                <span class="thinking-status">${status}</span>
                <span class="thinking-meta">${meta}</span>
                <i class="fas fa-chevron-down expand-icon"></i>
            </summary>
            <div class="thinking-text">${escapeHtml(variant.reasoning)}</div>
        </details>
    `;
}

function statsToBadge(stats) {
    if (!stats) return '';
    const parts = [];
    if (stats.tokens_per_sec) parts.push(`${stats.tokens_per_sec} t/s`);
    if (stats.completion_tokens) parts.push(`${stats.completion_tokens} tok`);
    if (stats.ttft_sec != null) parts.push(`TTFT ${stats.ttft_sec}s`);
    if (stats.elapsed_sec) parts.push(`${stats.elapsed_sec}s`);
    return parts.join(' · ');
}

function renderAssistantMessage(msg, idx) {
    const el = document.createElement('div');
    el.className = 'message assistant';
    el.dataset.role = 'assistant';
    el.dataset.msgIdx = String(idx);

    const v = msg.variants[msg.activeVariant];
    const isStreaming = !!v.streaming;
    const thinkingHtml = renderThinkingBlock(v, isStreaming);

    let contentHtml;
    if (v.content) contentHtml = formatMessageWithCode(v.content);
    else if (isStreaming) contentHtml = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
    else contentHtml = '';

    el.innerHTML = `
        <div class="avatar">🤖</div>
        <div class="message-content">
            ${thinkingHtml}
            <div class="message-text">${contentHtml}</div>
            <div class="message-actions"></div>
        </div>
    `;

    const actions = el.querySelector('.message-actions');
    actions.innerHTML = `
        <button class="msg-btn copy-btn" title="Копировать"><i class="fas fa-copy"></i></button>
        <button class="msg-btn regenerate-btn" title="Перегенерировать" ${isStreaming ? 'disabled' : ''}>
            <i class="fas fa-rotate-right"></i>
        </button>
        <button class="msg-btn delete-msg-btn" title="Удалить ответ" ${isStreaming ? 'disabled' : ''}>
            <i class="fas fa-trash-alt"></i>
        </button>
        <div class="variant-switcher" style="display:${msg.variants.length > 1 ? 'inline-flex' : 'none'};">
            <button class="variant-prev" ${msg.activeVariant === 0 ? 'disabled' : ''}>
                <i class="fas fa-chevron-left"></i>
            </button>
            <span class="variant-counter">${msg.activeVariant + 1} / ${msg.variants.length}</span>
            <button class="variant-next" ${msg.activeVariant >= msg.variants.length - 1 ? 'disabled' : ''}>
                <i class="fas fa-chevron-right"></i>
            </button>
            <button class="variant-delete" title="Удалить этот вариант" ${isStreaming ? 'disabled' : ''}>
                <i class="fas fa-times"></i>
            </button>
        </div>
        <span class="stats-badge">${statsToBadge(v.stats)}</span>
    `;

    actions.querySelector('.copy-btn').onclick = () => {
        const vv = msg.variants[msg.activeVariant];
        copyToClipboard(vv.content || '');
    };
    actions.querySelector('.regenerate-btn').onclick = () => regenerateMessage(idx);
    actions.querySelector('.delete-msg-btn').onclick = () => deleteAssistantMessage(idx);

    const prevBtn = actions.querySelector('.variant-prev');
    const nextBtn = actions.querySelector('.variant-next');
    const delVarBtn = actions.querySelector('.variant-delete');
    if (prevBtn) prevBtn.onclick = () => switchVariant(idx, -1);
    if (nextBtn) nextBtn.onclick = () => switchVariant(idx, +1);
    if (delVarBtn) delVarBtn.onclick = () => deleteVariant(idx, msg.activeVariant);

    if (!isStreaming) { highlightCode(el); addCopyButtonsToCodeBlocks(el); }
    return el;
}

function renderUserMessage(msg, idx) {
    const el = document.createElement('div');
    el.className = 'message user';
    el.dataset.role = 'user';
    el.dataset.msgIdx = String(idx);

    const chat = getCurrentChat();
    const canRetry = chat ? !hasAssistantAfter(chat, idx) : false;

    const textHtml = msg.content
        ? `<div class="message-text">${escapeHtml(msg.content).replace(/\n/g, '<br>')}</div>`
        : '';
    const thumbSrc = msg.image?.thumb || msg.image?.full || null;
    const imgHtml = thumbSrc
        ? `<img src="${thumbSrc}" class="msg-image-thumb" alt="Вложение">`
        : '';

    el.innerHTML = `
        <div class="avatar">👤</div>
        <div class="message-content">
            ${textHtml}
            ${imgHtml}
            <div class="message-actions">
                <button class="msg-btn copy-btn" title="Копировать"><i class="fas fa-copy"></i></button>
                ${canRetry ? `<button class="msg-btn retry-btn" title="Выполнить запрос заново"><i class="fas fa-redo"></i> Повторить</button>` : ''}
                <button class="msg-btn delete-msg-btn" title="Удалить"><i class="fas fa-trash-alt"></i></button>
            </div>
        </div>
    `;
    el.querySelector('.copy-btn').onclick = () => copyToClipboard(msg.content || '');
    el.querySelector('.delete-msg-btn').onclick = () => deleteUserMessage(idx);

    const retryBtn = el.querySelector('.retry-btn');
    if (retryBtn) retryBtn.onclick = () => executeUserRequest(idx);

    const thumb = el.querySelector('.msg-image-thumb');
    if (thumb) {
        const fullSrc = (msg.image && (msg.image.full || msg.image.thumb)) || thumb.src;
        thumb.addEventListener('click', (e) => {
            e.stopPropagation();
            openLightbox(fullSrc);
        });
    }
    return el;
}

function renderMessages() {
    const chat = getCurrentChat();
    messagesContainer.innerHTML = '';
    if (!chat || !chat.history.length) {
        renderWelcome();
        updateContextCount();
        return;
    }
    chat.history.forEach((msg, idx) => {
        if (msg.role === 'user') messagesContainer.appendChild(renderUserMessage(msg, idx));
        else if (msg.role === 'assistant') messagesContainer.appendChild(renderAssistantMessage(msg, idx));
        else if (msg.role === 'divider') messagesContainer.appendChild(renderDivider(msg, idx));
    });
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    updateContextCount();
}

// ========== УДАЛЕНИЕ ==========
function deleteUserMessage(idx) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    if (!chat) return;
    chat.history.splice(idx, 1);
    cleanupDividers(chat);
    chat.updated = Date.now();
    saveChatsToStorage();
    renderMessages();
}

function deleteAssistantMessage(idx) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    if (!chat) return;
    chat.history.splice(idx, 1);
    cleanupDividers(chat);
    chat.updated = Date.now();
    saveChatsToStorage();
    renderMessages();
}

function deleteVariant(assistantIdx, variantIdx) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    const chat = getCurrentChat();
    if (!chat) return;
    const msg = chat.history[assistantIdx];
    if (!msg || msg.role !== 'assistant') return;

    if (msg.variants.length <= 1) {
        chat.history.splice(assistantIdx, 1);
    } else {
        msg.variants.splice(variantIdx, 1);
        if (variantIdx < msg.activeVariant) msg.activeVariant--;
        else if (msg.activeVariant >= msg.variants.length) msg.activeVariant = msg.variants.length - 1;
    }
    cleanupDividers(chat);
    chat.updated = Date.now();
    saveChatsToStorage();
    renderMessages();
}

// ========== ОБНОВЛЕНИЕ STREAMING ==========
function updateStreamingAssistantInDom(msgIdx) {
    const chat = getCurrentChat();
    if (!chat) return;
    const msg = chat.history[msgIdx];
    if (!msg || msg.role !== 'assistant') return;
    const el = messagesContainer.querySelector(`[data-msg-idx="${msgIdx}"]`);
    if (!el) return;

    const v = msg.variants[msg.activeVariant];
    const contentBox = el.querySelector('.message-content');

    let tb = contentBox.querySelector('.thinking-block');
    if (v.reasoning && !tb) {
        const tmp = document.createElement('div');
        tmp.innerHTML = renderThinkingBlock(v, v.streaming);
        tb = tmp.firstElementChild;
        contentBox.insertBefore(tb, contentBox.firstChild);
    }
    if (tb) {
        const textEl = tb.querySelector('.thinking-text');
        if (textEl && textEl.textContent !== v.reasoning) textEl.textContent = v.reasoning;
        const st = tb.querySelector('.thinking-status');
        if (st) {
            let s;
            if (!v.streaming) s = 'Размышления';
            else if (v.content) s = 'Отвечает…';
            else s = 'Думает…';
            if (st.textContent !== s) st.textContent = s;
        }
        const meta = tb.querySelector('.thinking-meta');
        if (meta) {
            const m = `${v.reasoning.length} симв.`;
            if (meta.textContent !== m) meta.textContent = m;
        }
        if (v.streaming && !v.content) tb.classList.add('streaming');
        else tb.classList.remove('streaming');
    }

    const textDiv = el.querySelector('.message-text');
    if (textDiv) {
        if (v.content) {
            textDiv.innerHTML = formatMessageWithCode(v.content);
            highlightCode(textDiv);
            addCopyButtonsToCodeBlocks(textDiv);
        } else if (v.streaming) {
            if (!textDiv.querySelector('.typing-indicator')) {
                textDiv.innerHTML = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
            }
        } else {
            if (textDiv.querySelector('.typing-indicator')) textDiv.innerHTML = '';
        }
    }

    const badge = el.querySelector('.stats-badge');
    if (badge) badge.textContent = statsToBadge(v.stats);

    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// ========== IMAGE ==========
function createThumbnail(dataUrl, maxSize = 800, quality = 0.82) {
    return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => {
            let { width, height } = img;
            if (width > height && width > maxSize) {
                height = Math.round(height * maxSize / width); width = maxSize;
            } else if (height >= width && height > maxSize) {
                width = Math.round(width * maxSize / height); height = maxSize;
            }
            const canvas = document.createElement('canvas');
            canvas.width = width; canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);
            try { resolve(canvas.toDataURL('image/jpeg', quality)); }
            catch (_) { resolve(dataUrl); }
        };
        img.onerror = () => resolve(dataUrl);
        img.src = dataUrl;
    });
}

async function handleImageUpload(file) {
    if (!file || !file.type.startsWith('image/')) { showToast('Нужен файл изображения', 'error'); return; }
    if (file.size > 5 * 1024 * 1024) { showToast('Максимум 5 МБ', 'error'); return; }
    const reader = new FileReader();
    reader.onload = async (e) => {
        const dataUrl = e.target.result;
        currentImageBase64 = dataUrl.split(',')[1];
        currentImageMimeType = file.type;
        currentImageFull = dataUrl;
        currentImageName = file.name || 'изображение';
        currentImageSize = file.size || 0;
        try { currentImageThumb = await createThumbnail(dataUrl, 800, 0.82); }
        catch (_) { currentImageThumb = dataUrl; }
        imagePreview.src = dataUrl;
        imagePreviewContainer.style.display = 'block';
        imageInfo.textContent = `${file.name} · ${(file.size / 1024).toFixed(0)} КБ`;
        renderPendingAttachment();
        showToast('Изображение прикреплено', 'success');
    };
    reader.readAsDataURL(file);
}

function removeImage() {
    currentImageBase64 = null;
    currentImageMimeType = null;
    currentImageFull = null;
    currentImageThumb = null;
    currentImageName = '';
    currentImageSize = 0;
    imagePreview.src = '';
    imagePreviewContainer.style.display = 'none';
    imageInfo.textContent = '';
    if (imageInput) imageInput.value = '';
    renderPendingAttachment();
}

function updateImageUploadAccess() {
    const model = modelSelect.value;
    const info = modelsInfo.find(m => m.id === model);
    const canVision = info ? !!info.supports_vision : false;
    if (uploadImageBtn) uploadImageBtn.disabled = !canVision || !model;
    if (imageUploadArea) {
        imageUploadArea.style.opacity = canVision && model ? '1' : '0.5';
        imageUploadArea.style.pointerEvents = canVision && model ? 'auto' : 'none';
    }
    if (visionHint) {
        if (!model) visionHint.textContent = 'Сначала выберите модель';
        else if (canVision) visionHint.textContent = '✓ Модель поддерживает Vision';
        else visionHint.textContent = 'Эта модель без Vision (только текст)';
    }
}

// ========== DROP FILES ==========
function bindDropZone() {
    if (!mainArea) return;

    ['dragover', 'drop'].forEach(evt => {
        window.addEventListener(evt, (e) => {
            if (!mainArea.contains(e.target)) e.preventDefault();
        });
    });

    mainArea.addEventListener('dragenter', (e) => {
        if (!e.dataTransfer) return;
        const hasFiles = Array.from(e.dataTransfer.types || []).includes('Files');
        if (!hasFiles) return;
        e.preventDefault();
        dragCounter++;
        dropOverlay?.classList.add('open');
        flashWindowAttention();
    });

    mainArea.addEventListener('dragover', (e) => {
        if (!e.dataTransfer) return;
        const hasFiles = Array.from(e.dataTransfer.types || []).includes('Files');
        if (!hasFiles) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
        if (dragCounter === 1) {
            try { window.focus(); } catch (_) {}
        }
    });

    mainArea.addEventListener('dragleave', (e) => {
        dragCounter--;
        if (dragCounter <= 0) {
            dragCounter = 0;
            dropOverlay?.classList.remove('open');
            stopFlashWindowAttention();
        }
    });

    mainArea.addEventListener('drop', (e) => {
        e.preventDefault();
        dragCounter = 0;
        dropOverlay?.classList.remove('open');
        stopFlashWindowAttention();
        const files = Array.from(e.dataTransfer?.files || []);
        if (files.length) handleDroppedFiles(files);
    });
}

async function handleDroppedFiles(files) {
    for (const file of files) {
        const name = (file.name || '').toLowerCase();
        const isImage = file.type.startsWith('image/') || /\.(jpe?g|png|webp|gif|bmp)$/.test(name);
        const isTxt  = file.type === 'text/plain' || name.endsWith('.txt') || name.endsWith('.md');
        const isDocx = name.endsWith('.docx');
        const isDoc  = name.endsWith('.doc') && !name.endsWith('.docx');
        const isPdf  = name.endsWith('.pdf');

        if (isImage)       await handleDroppedImage(file);
        else if (isTxt)    await handleDroppedText(file);
        else if (isDocx)   await handleDroppedDocx(file);
        else if (isDoc)    showToast('.doc не поддерживается — сохраните как .docx или .txt', 'error');
        else if (isPdf)    showToast('PDF пока не поддерживается', 'error');
        else               showToast(`Формат не поддерживается: ${file.name}`, 'error');
    }
}

async function handleDroppedImage(file) {
    if (file.size > 5 * 1024 * 1024) {
        showToast(`"${file.name}": больше 5 МБ`, 'error');
        return;
    }

    const currentModel = modelSelect.value;
    const currentInfo = modelsInfo.find(m => m.id === currentModel);
    const canVision = currentInfo ? !!currentInfo.supports_vision : false;

    if (!canVision) {
        const visionModel = modelsInfo.find(m => m.supports_vision);
        if (!visionModel) {
            showToast('Нет доступных Vision-моделей', 'error');
            return;
        }
        const oldName = currentModel || '—';
        modelSelect.value = visionModel.id;
        localStorage.setItem('selected_model', visionModel.id);
        updateModelBadge();
        updateImageUploadAccess();
        addModelDivider(oldName, visionModel.id);
        showToast(`Модель переключена: ${visionModel.id} (Vision)`, 'success');
    }

    handleImageUpload(file);
}

async function handleDroppedText(file) {
    if (file.size > 2 * 1024 * 1024) {
        showToast(`"${file.name}": больше 2 МБ — слишком много для контекста`, 'error');
        return;
    }
    try {
        const text = await file.text();
        insertFileContent(file.name, text);
    } catch (err) {
        console.error(err);
        showToast('Не удалось прочитать файл', 'error');
    }
}

async function handleDroppedDocx(file) {
    if (file.size > FILE_MAX_BYTES) {
        showToast(`"${file.name}": больше 5 МБ`, 'error');
        return;
    }
    if (!window.mammoth) {
        showToast('Библиотека mammoth.js не загружена. Сохраните файл как .txt', 'error');
        return;
    }
    try {
        const arrayBuffer = await file.arrayBuffer();
        const result = await window.mammoth.extractRawText({ arrayBuffer });
        insertFileContent(file.name, result.value || '');
    } catch (err) {
        console.error(err);
        showToast('Не удалось прочитать DOCX', 'error');
    }
}

function insertFileContent(filename, text) {
    const cleaned = (text || '').replace(/\r\n/g, '\n').trim();
    if (!cleaned) { showToast('Файл пуст', 'error'); return; }
    const truncated = cleaned.length > TEXT_MAX_CHARS
        ? cleaned.slice(0, TEXT_MAX_CHARS) + '\n…[файл обрезан]'
        : cleaned;

    const header = `📎 ${filename}\n`;
    const block = `${header}\`\`\`\n${truncated}\n\`\`\`\n\n`;

    const current = userInput.value || '';
    userInput.value = current ? (current + '\n\n' + block) : block;
    userInput.style.height = 'auto';
    userInput.style.height = Math.min(userInput.scrollHeight, 160) + 'px';
    userInput.focus();

    showToast(`Файл "${filename}" добавлен`, 'success');
}

// ========== MODELS & SETTINGS ==========
async function loadModels() {
    try {
        const response = await fetch('/get_models');
        const data = await response.json();
        if (data.models && data.models.length) {
            modelsInfo = data.models;
            modelSelect.innerHTML = '<option value="">— Выберите модель —</option>' +
                modelsInfo.map(m => `<option value="${m.id}">${m.id}${m.supports_vision ? ' 🖼️' : ''}</option>`).join('');
            const saved = localStorage.getItem('selected_model');
            if (saved && modelsInfo.some(m => m.id === saved)) modelSelect.value = saved;
            else if (modelsInfo.length === 1) modelSelect.value = modelsInfo[0].id;
            updateModelBadge();
            updateImageUploadAccess();
        } else {
            modelSelect.innerHTML = '<option value="">— Модели не найдены —</option>';
            visionHint.textContent = 'Добавьте модели в app.py (LM_SERVERS)';
        }
    } catch (err) {
        console.error(err);
        modelSelect.innerHTML = '<option value="">— Ошибка загрузки —</option>';
        visionHint.textContent = 'Сервер недоступен';
    }
}

function updateModelBadge() {
    const v = modelSelect.value;
    modelBadge.textContent = v || 'Модель не выбрана';
}

function saveSettings() {
    const settings = {
        system_prompt: systemPrompt.value,
        temperature: temperature.value,
        top_p: topP.value,
        top_k: topK.value,
        frequency_penalty: frequencyPenalty.value,
        presence_penalty: presencePenalty.value,
        repeat_penalty: repeatPenalty.value,
        max_tokens: maxTokens.value,
        seed: seedInput.value,
        sound_enabled: soundEnabled,
        notif_enabled: notifEnabled,
    };
    localStorage.setItem('chat_settings', JSON.stringify(settings));
}

function loadSettings() {
    const saved = localStorage.getItem('chat_settings');
    if (!saved) {
        if (soundToggle) soundEnabled = soundToggle.checked;
        if (notifToggle) notifEnabled = notifToggle.checked;
        return;
    }
    try {
        const s = JSON.parse(saved);
        systemPrompt.value = s.system_prompt || '';
        temperature.value = s.temperature ?? 0.7;
        topP.value = s.top_p ?? 0.9;
        topK.value = s.top_k ?? 50;
        frequencyPenalty.value = s.frequency_penalty ?? 0.0;
        presencePenalty.value = s.presence_penalty ?? 0.0;
        repeatPenalty.value = s.repeat_penalty ?? 1.1;
        maxTokens.value = s.max_tokens ?? 2048;
        seedInput.value = s.seed || '';
        soundEnabled = s.sound_enabled !== false;
        notifEnabled = s.notif_enabled !== false;
        if (soundToggle) soundToggle.checked = soundEnabled;
        if (notifToggle) notifToggle.checked = notifEnabled;
        syncRangeLabels();
    } catch (_) {}
}

function syncRangeLabels() {
    document.getElementById('temp-value').textContent = temperature.value;
    document.getElementById('topp-value').textContent = topP.value;
    document.getElementById('topk-value').textContent = topK.value;
    document.getElementById('freq-value').textContent = frequencyPenalty.value;
    document.getElementById('presence-value').textContent = presencePenalty.value;
    document.getElementById('repeat-value').textContent = repeatPenalty.value;
    document.getElementById('max-tokens-value').textContent = maxTokens.value;
}

function applyPreset(key) {
    if (!promptPreset) return;
    if (key === 'empty') {
        systemPrompt.value = '';
        saveSettings();
        promptPreset.value = '';
        showToast('Промпт очищен', 'success');
        return;
    }
    const text = PROMPT_PRESETS[key];
    if (text) {
        systemPrompt.value = text;
        saveSettings();
        showToast('Пресет применён', 'success');
    }
    promptPreset.value = '';
}

function resetSettings() {
    temperature.value = 0.7;
    topP.value = 0.9;
    topK.value = 50;
    frequencyPenalty.value = 0.0;
    presencePenalty.value = 0.0;
    repeatPenalty.value = 1.1;
    maxTokens.value = 2048;
    seedInput.value = '';
    systemPrompt.value = '';
    if (promptPreset) promptPreset.value = '';
    soundEnabled = true; notifEnabled = true;
    if (soundToggle) soundToggle.checked = true;
    if (notifToggle) notifToggle.checked = true;
    syncRangeLabels();
    saveSettings();
    showToast('Настройки сброшены', 'success');
}

// ========== CANCEL / BLOCK ==========
function checkCancelLimit() {
    const now = Date.now();
    cancelAttempts = cancelAttempts.filter(t => now - t < CANCEL_WINDOW_MS);
    if (cancelAttempts.length >= CANCEL_MAX) {
        isBlocked = true;
        blockEndTime = now + BLOCK_MS;
        return false;
    }
    cancelAttempts.push(now);
    return true;
}

function isSendBlocked() {
    if (!isBlocked) return false;
    if (Date.now() >= blockEndTime) { isBlocked = false; cancelAttempts = []; return false; }
    return true;
}

async function stopGeneration() {
    if (!activeRequest) return;
    if (!checkCancelLimit()) { showToast('Слишком много отмен — подождите', 'error'); return; }
    if (currentAbortController) currentAbortController.abort();
    try { await fetch('/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); } catch (_) {}
}

// ========== СТРИМЕР ==========
async function streamIntoVariant({ message, history, variant, msgIdx, imageBase64, imageMimeType, onFinish }) {
    const chat = getCurrentChat();
    if (!chat) return;

    variant.content = '';
    variant.reasoning = '';
    variant.stats = null;
    variant.createdAt = Date.now();
    variant.streaming = true;

    updateStreamingAssistantInDom(msgIdx);

    const payload = {
        message, history,
        model: modelSelect.value,
        system_prompt: systemPrompt.value || 'Ты полезный ассистент.',
        temperature: parseFloat(temperature.value),
        top_p: parseFloat(topP.value),
        top_k: parseInt(topK.value, 10),
        frequency_penalty: parseFloat(frequencyPenalty.value),
        presence_penalty: parseFloat(presencePenalty.value),
        repeat_penalty: parseFloat(repeatPenalty.value),
        max_tokens: parseInt(maxTokens.value, 10),
    };
    if (imageBase64) {
        payload.image = imageBase64;
        payload.image_mime_type = imageMimeType;
    }
    if (seedInput.value !== '') payload.seed = parseInt(seedInput.value, 10);

    currentAbortController = new AbortController();
    const timeoutId = setTimeout(() => {
        if (currentAbortController) currentAbortController.abort();
    }, REQUEST_TIMEOUT_MS);

    let cancelled = false;
    let errored = false;
    let phase = 'idle';

    try {
        const response = await fetch('/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            signal: currentAbortController.signal,
        });
        clearTimeout(timeoutId);

        if (!response.ok) {
            let errMsg = `HTTP ${response.status}`;
            try { const j = await response.json(); errMsg = j.error || errMsg; } catch (_) {}
            throw new Error(errMsg);
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let rafPending = false;

        const scheduleDom = () => {
            if (rafPending) return;
            rafPending = true;
            requestAnimationFrame(() => {
                rafPending = false;
                updateStreamingAssistantInDom(msgIdx);
            });
        };

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            for (const line of lines) {
                if (!line.startsWith('data: ')) continue;
                let data;
                try { data = JSON.parse(line.slice(6)); } catch (_) { continue; }

                if (data.error) throw new Error(data.error);

                if (data.cancelled) {
                    cancelled = true;
                    if (data.partial) variant.content = data.partial;
                    if (data.reasoning_partial) variant.reasoning = data.reasoning_partial;
                    if (data.stats) variant.stats = data.stats;
                    break;
                }

                if (data.reasoning) {
                    variant.reasoning += data.reasoning;
                    if (phase !== 'thinking') { phase = 'thinking'; setStatus('Думает…', false, true); }
                    scheduleDom();
                }

                if (data.content != null) {
                    if (data.full != null) variant.content = data.full;
                    else variant.content += data.content;
                    if (phase !== 'answering') { phase = 'answering'; setStatus('Отвечает…', false, true); }
                    scheduleDom();
                }

                if (data.stats) {
                    variant.stats = data.stats;
                    const el = messagesContainer.querySelector(`[data-msg-idx="${msgIdx}"]`);
                    const badge = el?.querySelector('.stats-badge');
                    if (badge) badge.textContent = statsToBadge(variant.stats);
                }

                if (data.done) {
                    if (data.full != null) variant.content = data.full;
                    if (data.reasoning != null) variant.reasoning = data.reasoning;
                    if (data.stats) variant.stats = data.stats;
                }
            }
            if (cancelled) break;
        }

    } catch (error) {
        if (error.name === 'AbortError') cancelled = true;
        else { errored = true; variant.content += `\n\n❌ ${error.message || 'Ошибка'}`; }
    } finally {
        clearTimeout(timeoutId);
        variant.streaming = false;
        activeRequest = false;
        currentAbortController = null;
        sendBtn.disabled = false;
        if (stopBtn) stopBtn.style.display = 'none';
        setStatus(errored ? 'Ошибка' : (cancelled ? 'Отменено' : 'Готов'), errored);

        const oldEl = messagesContainer.querySelector(`[data-msg-idx="${msgIdx}"]`);
        const oldTb = oldEl?.querySelector('.thinking-block');
        const wasOpen = oldTb ? oldTb.open : false;

        const newEl = renderAssistantMessage(chat.history[msgIdx], msgIdx);
        if (oldEl) oldEl.replaceWith(newEl);

        const newTb = newEl.querySelector('.thinking-block');
        if (newTb && oldTb) newTb.open = wasOpen;

        saveChatsToStorage();
        if (typeof onFinish === 'function') onFinish(cancelled);
    }
}

// ========== SEND ==========
function isModelSelected() {
    if (!modelSelect.value) {
        showToast('Выберите модель в настройках', 'error');
        openDrawer();
        return false;
    }
    return true;
}

async function sendMessage() {
    if (!isModelSelected()) return;
    if (isSendBlocked()) {
        const rem = Math.ceil((blockEndTime - Date.now()) / 1000);
        showToast(`Блокировка ещё ${rem} с`, 'error');
        return;
    }
    if (activeRequest) { setStatus('Идёт генерация…', false, true); return; }

    const chat = getCurrentChat();
    if (!chat) return;

    const message = userInput.value.trim();
    if (!message && !currentImageBase64) {
        showToast('Введите сообщение или загрузите изображение', 'error');
        return;
    }

    ensureAudioContext();
    if (notifEnabled && 'Notification' in window && Notification.permission === 'default') ensureNotificationPermission();

    activeRequest = true;
    setStatus('Генерация…', false, true);
    sendBtn.disabled = true;
    if (stopBtn) stopBtn.style.display = 'flex';

    const hadImage = !!currentImageBase64;
    const imageB64 = currentImageBase64;
    const imageMime = currentImageMimeType;
    const imageFull = currentImageFull;
    const imageThumb = currentImageThumb;

    chat.history.push({
        role: 'user',
        content: message,
        image: (imageThumb || imageFull) ? { thumb: imageThumb || imageFull, full: imageFull || null } : null,
    });
    const userMsgIdx = chat.history.length - 1;

    chat.history.push({
        role: 'assistant',
        variants: [{ content: '', reasoning: '', stats: null, createdAt: Date.now(), streaming: true }],
        activeVariant: 0,
    });
    const assistantIdx = chat.history.length - 1;

    if (messagesContainer.querySelector('.welcome')) messagesContainer.innerHTML = '';
    renderMessages();
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    userInput.value = '';
    userInput.style.height = 'auto';
    updateChatTitleFromHistory();

    const history = historyForApi(chat.history.slice(0, userMsgIdx));

    await streamIntoVariant({
        message: message || '',
        history,
        variant: chat.history[assistantIdx].variants[0],
        msgIdx: assistantIdx,
        imageBase64: imageB64,
        imageMimeType: imageMime,
        onFinish: (cancelled) => {
            if (hadImage) removeImage();
            updateContextCount();
            if (!cancelled) {
                const asstMsg = chat.history[assistantIdx];
                const v = asstMsg?.variants[asstMsg.activeVariant];
                onModelFinished(v?.content || '');
            }
        }
    });
}

// ========== EXECUTE USER REQUEST (retry) ==========
async function executeUserRequest(userIdx) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    if (!isModelSelected()) return;

    const chat = getCurrentChat();
    if (!chat) return;

    const userMsg = chat.history[userIdx];
    if (!userMsg || userMsg.role !== 'user') return;

    const userText = (userMsg.content || '').trim();
    if (!userText && userMsg.image) {
        showToast('Запрос содержал только изображение — повтор невозможен', 'error');
        return;
    }
    if (!userText) { showToast('Пустой запрос — нечего выполнять', 'error'); return; }

    ensureAudioContext();
    if (notifEnabled && 'Notification' in window && Notification.permission === 'default') ensureNotificationPermission();

    const newAsstMsg = {
        role: 'assistant',
        variants: [{ content: '', reasoning: '', stats: null, createdAt: Date.now(), streaming: true }],
        activeVariant: 0,
    };
    chat.history.splice(userIdx + 1, 0, newAsstMsg);
    const assistantIdx = userIdx + 1;

    activeRequest = true;
    setStatus('Генерация…', false, true);
    sendBtn.disabled = true;
    if (stopBtn) stopBtn.style.display = 'flex';

    renderMessages();
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    const history = historyForApi(chat.history.slice(0, userIdx));

    await streamIntoVariant({
        message: userText,
        history,
        variant: newAsstMsg.variants[0],
        msgIdx: assistantIdx,
        imageBase64: null,
        imageMimeType: null,
        onFinish: (cancelled) => {
            updateContextCount();
            if (!cancelled) {
                const v = newAsstMsg.variants[newAsstMsg.activeVariant];
                onModelFinished(v?.content || '');
            }
        },
    });
}

// ========== REGENERATE ==========
async function regenerateMessage(assistantIdx) {
    if (activeRequest) { showToast('Дождитесь окончания генерации', 'error'); return; }
    if (!isModelSelected()) return;

    const chat = getCurrentChat();
    if (!chat) return;

    const asstMsg = chat.history[assistantIdx];
    if (!asstMsg || asstMsg.role !== 'assistant') return;

    let userIdx = -1;
    for (let i = assistantIdx - 1; i >= 0; i--) {
        if (chat.history[i].role === 'user') { userIdx = i; break; }
    }
    if (userIdx < 0) { showToast('Не найден исходный вопрос', 'error'); return; }

    const userMsg = chat.history[userIdx];
    const userText = (userMsg.content || '').trim();

    if (!userText && userMsg.image) {
        showToast('Исходный запрос содержал только изображение — перегенерация невозможна', 'error');
        return;
    }
    if (!userText) { showToast('Пустой запрос — нечего перегенерировать', 'error'); return; }

    ensureAudioContext();
    if (notifEnabled && 'Notification' in window && Notification.permission === 'default') ensureNotificationPermission();

    const history = historyForApi(chat.history.slice(0, userIdx));

    const newVariant = { content: '', reasoning: '', stats: null, createdAt: Date.now(), streaming: true };
    asstMsg.variants.push(newVariant);
    asstMsg.activeVariant = asstMsg.variants.length - 1;

    activeRequest = true;
    setStatus('Регенерация…', false, true);
    sendBtn.disabled = true;
    if (stopBtn) stopBtn.style.display = 'flex';

    const oldEl = messagesContainer.querySelector(`[data-msg-idx="${assistantIdx}"]`);
    if (oldEl) oldEl.replaceWith(renderAssistantMessage(asstMsg, assistantIdx));

    await streamIntoVariant({
        message: userText,
        history,
        variant: newVariant,
        msgIdx: assistantIdx,
        imageBase64: null,
        imageMimeType: null,
        onFinish: (cancelled) => {
            updateContextCount();
            if (!cancelled) {
                const v = asstMsg.variants[asstMsg.activeVariant];
                onModelFinished(v?.content || '');
            }
        },
    });
}

// ========== SWITCH VARIANT ==========
function switchVariant(assistantIdx, direction) {
    const chat = getCurrentChat();
    if (!chat) return;
    const msg = chat.history[assistantIdx];
    if (!msg || msg.role !== 'assistant') return;

    const newIdx = msg.activeVariant + direction;
    if (newIdx < 0 || newIdx >= msg.variants.length) return;
    msg.activeVariant = newIdx;

    const oldEl = messagesContainer.querySelector(`[data-msg-idx="${assistantIdx}"]`);
    if (oldEl) oldEl.replaceWith(renderAssistantMessage(msg, assistantIdx));
    saveChatsToStorage();
}

// ========== EXPORT ==========
function exportCurrentChat() {
    const chat = getCurrentChat();
    if (!chat || !chat.history.length) { showToast('Нечего экспортировать', 'error'); return; }
    let md = `# ${chat.title}\n\n`;
    if (chat.temporary) md += `_Временный чат (не сохраняется)._\n\n`;
    chat.history.forEach(m => {
        if (m.role === 'user') {
            md += `**Вы:**\n${m.content || ''}\n\n`;
            if (m.image?.thumb) md += `_(приложено изображение)_\n\n`;
        } else if (m.role === 'assistant') {
            const v = m.variants[m.activeVariant];
            if (v?.reasoning) md += `<details><summary>Размышления</summary>\n\n${v.reasoning}\n\n</details>\n\n`;
            md += `**Ассистент:**\n${v?.content || ''}\n\n`;
            if (m.variants.length > 1) md += `_Вариант ${m.activeVariant + 1} из ${m.variants.length}_\n\n`;
        } else if (m.role === 'divider') {
            md += `---\n*${m.text}*\n\n`;
        }
    });
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${(chat.title || 'chat').replace(/[^\wа-яё\-]+/gi, '_').slice(0, 40)}.md`;
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('Экспортировано', 'success');
}

// ========== DRAWER ==========
function openDrawer() { drawerMenu.classList.add('open'); drawerOverlay.classList.add('open'); }
function closeDrawer() { drawerMenu.classList.remove('open'); drawerOverlay.classList.remove('open'); }

// ========== EVENTS ==========
function bindEvents() {
    [temperature, topP, topK, frequencyPenalty, presencePenalty, repeatPenalty, maxTokens].forEach(el => {
        if (el) el.addEventListener('input', () => { syncRangeLabels(); saveSettings(); });
    });
    systemPrompt?.addEventListener('change', saveSettings);
    seedInput?.addEventListener('change', saveSettings);

    promptPreset?.addEventListener('change', () => {
        if (promptPreset.value) applyPreset(promptPreset.value);
    });

    soundToggle?.addEventListener('change', () => {
        soundEnabled = soundToggle.checked;
        if (soundEnabled) { ensureAudioContext(); playDoneSound(); }
        saveSettings();
    });

    notifToggle?.addEventListener('change', () => {
        notifEnabled = notifToggle.checked;
        saveSettings();
        if (notifEnabled && 'Notification' in window && Notification.permission === 'default') {
            ensureNotificationPermission();
        }
        if (!notifEnabled) removeTrayNotification();
    });

    let previousModel = modelSelect.value;
    modelSelect?.addEventListener('change', () => {
        const newModel = modelSelect.value;
        const oldModel = previousModel;
        previousModel = newModel;

        localStorage.setItem('selected_model', newModel);
        updateModelBadge();
        updateImageUploadAccess();

        if (currentImageBase64) {
            const info = modelsInfo.find(m => m.id === newModel);
            const canVision = info ? !!info.supports_vision : false;
            if (!canVision) {
                removeImage();
                showToast('Эта модель не поддерживает изображения — файл удалён', 'error');
            }
        }

        if (oldModel !== newModel) {
            addModelDivider(oldModel, newModel);
        }

        showToast(`Модель: ${newModel}`, 'success');
    });

    if (isAdvancedOpen) advancedToggle?.parentElement?.classList.add('open');
    advancedToggle?.addEventListener('click', () => {
        const sec = advancedToggle.parentElement;
        sec.classList.toggle('open');
        localStorage.setItem('advanced_open', sec.classList.contains('open'));
    });

    openDrawerBtn?.addEventListener('click', openDrawer);
    drawerClose?.addEventListener('click', closeDrawer);
    drawerOverlay?.addEventListener('click', closeDrawer);

    openSidebarBtn?.addEventListener('click', () => appEl.classList.toggle('sidebar-collapsed'));
    sidebarClose?.addEventListener('click', () => appEl.classList.add('sidebar-collapsed'));

    newChatBtn?.addEventListener('click', () => {
        if (activeRequest) return showToast('Дождитесь генерации', 'error');
        createNewChat(true);
        showToast('Новый чат', 'success');
    });

    newTempChatBtn?.addEventListener('click', () => {
        openOrCreateTemporaryChat();
    });

    promoteTempBtn?.addEventListener('click', () => promoteTemporaryChat());
    closeTempBtn?.addEventListener('click', () => closeTemporaryChat());

    exportChatBtn?.addEventListener('click', exportCurrentChat);

    clearAllChatsBtn?.addEventListener('click', async () => {
        const favorites = chats.filter(c => c.favorite && !c.temporary);
        const msg = favorites.length
            ? `Удалить все чаты?\n\nИзбранные чаты (${favorites.length}) останутся на месте.\nВременный чат (если есть) будет закрыт.\nЭто действие нельзя отменить.`
            : 'Удалить все чаты?\n\nВременный чат (если есть) будет закрыт.\nЭто действие нельзя отменить.';
        const ok = await showConfirm(msg, {
            title: 'Очистить всё', okText: 'Да', cancelText: 'Нет',
            danger: true, icon: 'fa-trash-alt',
        });
        if (!ok) return;

        chats = favorites.slice();

        if (!chats.length) {
            const newChat = {
                id: uid(), title: 'Новый чат',
                created: Date.now(), updated: Date.now(),
                favorite: false, temporary: false, history: [],
            };
            chats.unshift(newChat);
            currentChatId = newChat.id;
        } else {
            if (!chats.find(c => c.id === currentChatId)) currentChatId = chats[0].id;
            sortChats();
        }
        saveChatsToStorage();
        renderChatsList();
        renderMessages();
        updateChatTitle();
        updateTempModeUI();
        updateContextCount();
        showToast('Чаты очищены', 'success');
    });

    clearChatBtn?.addEventListener('click', async () => {
        const chat = getCurrentChat();
        if (!chat) return;
        const ok = await showConfirm(
            'Очистить текущий диалог?',
            { title: 'Очистить диалог', okText: 'Да', cancelText: 'Нет', danger: true, icon: 'fa-eraser' }
        );
        if (!ok) return;
        chat.history = [];
        chat.title = chat.temporary ? 'Временный чат' : 'Новый чат';
        chat.updated = Date.now();
        saveChatsToStorage();
        renderMessages();
        updateChatTitle();
        renderChatsList();
        closeDrawer();
        showToast('Диалог очищен', 'success');
    });

    resetSettingsBtn?.addEventListener('click', resetSettings);

    uploadImageBtn?.addEventListener('click', () => imageInput?.click());
    imageInput?.addEventListener('change', (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) { showToast('Только изображения', 'error'); return; }

        const cur = modelSelect.value;
        const curInfo = modelsInfo.find(m => m.id === cur);
        const canVision = curInfo ? !!curInfo.supports_vision : false;
        if (!canVision) {
            const visionModel = modelsInfo.find(m => m.supports_vision);
            if (!visionModel) { showToast('Нет доступных Vision-моделей', 'error'); return; }
            const oldName = cur || '—';
            modelSelect.value = visionModel.id;
            localStorage.setItem('selected_model', visionModel.id);
            updateModelBadge();
            updateImageUploadAccess();
            addModelDivider(oldName, visionModel.id);
            showToast(`Модель переключена: ${visionModel.id}`, 'success');
        }
        handleImageUpload(file);
    });
    removeImageBtn?.addEventListener('click', removeImage);

    imageUploadArea?.addEventListener('dragover', (e) => { e.preventDefault(); imageUploadArea.classList.add('drag-over'); });
    imageUploadArea?.addEventListener('dragleave', () => imageUploadArea.classList.remove('drag-over'));
    imageUploadArea?.addEventListener('drop', (e) => {
        e.preventDefault();
        imageUploadArea.classList.remove('drag-over');
        if (e.dataTransfer.files?.[0]) handleDroppedFiles(Array.from(e.dataTransfer.files));
    });

    userInput?.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 160) + 'px';
    });
    userInput?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
    });
    sendBtn?.addEventListener('click', sendMessage);
    stopBtn?.addEventListener('click', stopGeneration);

    bindDropZone();

    window.addEventListener('dragend', stopFlashWindowAttention);
    window.addEventListener('blur', () => { setTimeout(stopFlashWindowAttention, 200); });

    setInterval(() => {
        fetch('/heartbeat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ session_id: currentChatId || '' })
        }).catch(() => {});
    }, 45000);
}

// ========== INIT ==========
function init() {
    loadChatsFromStorage();
    loadSettings();
    loadModels();
    renderChatsList();
    renderMessages();
    updateChatTitle();
    updateTempModeUI();
    updateContextCount();
    bindEvents();
    updateImageUploadAccess();
    initLightbox();

    if ('Notification' in window && Notification.permission === 'granted') notificationPermissionGranted = true;
    if (window.innerWidth <= 900) appEl.classList.add('sidebar-collapsed');
    if (window.hljs) hljs.highlightAll();
    console.log('Local AI Chat v3.13 ready');
}

init();