# Local AI Chat (LM Studio)

Веб-чат для локальных моделей через LM Studio.

## Возможности

- Несколько независимых чатов (история в localStorage)
- Стриминг ответов + кнопка «Стоп»
- Vision (изображения) — если модель поддерживает
- Параметры: temperature, top_p, top_k, penalties, max_tokens, seed, system prompt
- Подсветка кода, копирование, экспорт в Markdown
- Тёмная тема, адаптивный UI

## Быстрый старт

1. Установите зависимости:
   ```bash
   pip install -r requirements.txt
   ```

2. Запустите LM Studio и загрузите модель. Включите локальный сервер (обычно `http://127.0.0.1:1234`).

3. Отредактируйте `main21.py`:
   - `LM_SERVERS` — имена моделей и URL (обычно `http://127.0.0.1:1234/v1`)
   - `VISION_SUPPORT` — `True` для vision-моделей

4. Запуск:
   ```bash
   python main21.py
   ```
   Откройте http://127.0.0.1:5000

## Структура

```
├── main21.py          # Flask backend
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   ├── js/scii.js
│   └── cdn/           # highlight.js, fontawesome (локально)
├── requirements.txt
└── README.md
```

## Заметки

- История и настройки хранятся только в браузере.
- Для продакшена: `gunicorn -w 1 -k gevent --timeout 600 main21:app`
- При нескольких воркерах in-memory состояние (active_requests) лучше заменить на Redis.
