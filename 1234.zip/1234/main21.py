from flask import Flask, render_template, request, jsonify, Response, stream_with_context
import requests
import time
import json
import uuid
from functools import wraps
from datetime import datetime, timedelta
import base64
import imghdr
import io
from PIL import Image
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)
app.config['SESSION_PERMANENT'] = False
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10MB

# ========== КОНФИГУРАЦИЯ LM STUDIO ==========
LM_SERVERS = {
    "qwen3-8b": "http://127.0.0.1:1234/v1",
    "gemma-4-e2b-it-ud": "http://127.0.0.1:1234/v1",
    "qwen3vl-2b-instruct": "http://127.0.0.1:1234/v1",
}

VISION_SUPPORT = {
    "qwen3-8b": False,
    "gemma-4-e2b-it-ud": False,
    "qwen3vl-2b-instruct": True,
}
# ===========================================

RATE_LIMIT_SECONDS = 2.5
MAX_TOKENS_LIMIT = 8192
MAX_HISTORY_MESSAGES = 24

REQUEST_TIMEOUT_CONNECT = 20
REQUEST_TIMEOUT_READ = 600

CANCEL_LIMIT_WINDOW = 30
CANCEL_MAX_ATTEMPTS = 3
CANCEL_BLOCK_DURATION = 45

MAX_IMAGE_SIZE_MB = 5
MAX_IMAGE_SIZE_BYTES = MAX_IMAGE_SIZE_MB * 1024 * 1024
MAX_IMAGE_WIDTH = 4096
MAX_IMAGE_HEIGHT = 4096
ALLOWED_IMAGE_FORMATS = ['jpeg', 'jpg', 'png', 'webp']

cancel_attempts = {}
cancel_blocked_until = {}
last_request_time = {}
active_requests = {}
user_sessions = {}


# ========== ХЕЛПЕРЫ ==========
def sse(obj):
    return f"data: {json.dumps(obj, ensure_ascii=False)}\n\n"


def validate_image_safe(base64_string, client_mime_type):
    base64_size = len(base64_string)
    estimated_bytes = int(base64_size * 0.75)
    if estimated_bytes > MAX_IMAGE_SIZE_BYTES:
        return False, f"Изображение слишком большое. Максимум {MAX_IMAGE_SIZE_MB}MB", None
    try:
        image_bytes = base64.b64decode(base64_string)
    except Exception as e:
        return False, f"Некорректные данные изображения: {str(e)}", None
    if len(image_bytes) > MAX_IMAGE_SIZE_BYTES:
        return False, f"Изображение слишком большое после декодирования. Максимум {MAX_IMAGE_SIZE_MB}MB", None
    if len(image_bytes) < 100:
        return False, "Файл изображения слишком маленький или пустой", None

    detected_format = imghdr.what(None, h=image_bytes)
    if not detected_format:
        if len(image_bytes) > 4:
            if image_bytes[0:3] == b'\xff\xd8\xff':
                detected_format = 'jpeg'
            elif image_bytes[0:8] == b'\x89PNG\r\n\x1a\n':
                detected_format = 'png'
            elif len(image_bytes) > 12 and image_bytes[0:4] == b'RIFF' and image_bytes[8:12] == b'WEBP':
                detected_format = 'webp'
    if not detected_format:
        return False, "Файл не является изображением или формат не поддерживается", None
    if detected_format not in ALLOWED_IMAGE_FORMATS:
        return False, f"Формат '{detected_format}' не поддерживается. Разрешены: {', '.join(ALLOWED_IMAGE_FORMATS)}", None

    if detected_format in ('jpg', 'jpeg'):
        validated_mime = 'image/jpeg'
    elif detected_format == 'png':
        validated_mime = 'image/png'
    elif detected_format == 'webp':
        validated_mime = 'image/webp'
    else:
        validated_mime = f'image/{detected_format}'

    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            if img.width > MAX_IMAGE_WIDTH or img.height > MAX_IMAGE_HEIGHT:
                return False, f"Изображение слишком большое: {img.width}x{img.height}. Максимум {MAX_IMAGE_WIDTH}x{MAX_IMAGE_HEIGHT}", None
            img.verify()
    except Exception as e:
        return False, f"Ошибка обработки изображения: {str(e)}", None
    return True, None, validated_mime


def extract_text_from_content(content):
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        texts = []
        for item in content:
            if isinstance(item, dict) and item.get('type') == 'text':
                texts.append(item.get('text', ''))
        return ' '.join(texts)
    return str(content) if content else ''


def count_tokens(text):
    if not text:
        return 0
    return max(1, len(text) // 3 + text.count('\n') // 2)


def check_token_limit(messages, system_prompt, user_message):
    total_text = system_prompt or ''
    if isinstance(user_message, list):
        user_text = extract_text_from_content(user_message)
    else:
        user_text = user_message or ''
    total_text += user_text
    for msg in messages:
        content = msg.get('content', '')
        total_text += extract_text_from_content(content)
    token_count = count_tokens(total_text)
    if token_count > MAX_TOKENS_LIMIT:
        return False, f"Превышен лимит токенов: ~{token_count}/{MAX_TOKENS_LIMIT}. Очистите историю или уменьшите max_tokens."
    return True, token_count


def truncate_history(messages, max_messages=MAX_HISTORY_MESSAGES):
    if len(messages) <= max_messages + 1:
        return messages
    system = [m for m in messages if m.get('role') == 'system']
    rest = [m for m in messages if m.get('role') != 'system']
    return system + rest[-(max_messages):]


def build_stats(full_response, full_reasoning, start_ts, first_token_ts, usage, chunks):
    now = time.time()
    elapsed = now - start_ts
    ttft = (first_token_ts - start_ts) if first_token_ts else None
    gen_time = (now - first_token_ts) if first_token_ts else 0.0

    if usage:
        completion_tokens = usage.get('completion_tokens') or 0
        prompt_tokens = usage.get('prompt_tokens') or 0
        total_tokens = usage.get('total_tokens') or (completion_tokens + prompt_tokens)
    else:
        completion_tokens = count_tokens(full_response + full_reasoning)
        prompt_tokens = 0
        total_tokens = completion_tokens

    tps = (completion_tokens / gen_time) if gen_time > 0.05 else 0.0

    return {
        'prompt_tokens': prompt_tokens,
        'completion_tokens': completion_tokens,
        'total_tokens': total_tokens,
        'elapsed_sec': round(elapsed, 2),
        'ttft_sec': round(ttft, 2) if ttft is not None else None,
        'tokens_per_sec': round(tps, 1),
        'chunks': chunks,
        'reasoning_chars': len(full_reasoning),
        'answer_chars': len(full_response),
    }


def check_cancel_limit(user_id):
    now = datetime.now()
    if user_id in cancel_blocked_until:
        if now < cancel_blocked_until[user_id]:
            remaining = int((cancel_blocked_until[user_id] - now).total_seconds())
            return False, f"Слишком много отмен. Блокировка ещё {remaining} с."
        else:
            del cancel_blocked_until[user_id]
            cancel_attempts[user_id] = []
    if user_id not in cancel_attempts:
        cancel_attempts[user_id] = []
    cutoff = now - timedelta(seconds=CANCEL_LIMIT_WINDOW)
    cancel_attempts[user_id] = [ts for ts in cancel_attempts[user_id] if ts > cutoff]
    if len(cancel_attempts[user_id]) >= CANCEL_MAX_ATTEMPTS:
        cancel_blocked_until[user_id] = now + timedelta(seconds=CANCEL_BLOCK_DURATION)
        return False, f"Слишком много отмен ({CANCEL_MAX_ATTEMPTS} за {CANCEL_LIMIT_WINDOW} с). Подождите {CANCEL_BLOCK_DURATION} с."
    cancel_attempts[user_id].append(now)
    return True, None


def rate_limit(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = request.remote_addr or 'unknown'
        now = time.time()
        if user_id in active_requests and active_requests[user_id]:
            return jsonify({'error': 'Предыдущий запрос ещё обрабатывается. Нажмите «Стоп».'}), 429
        if user_id in last_request_time:
            elapsed = now - last_request_time[user_id]
            if elapsed < RATE_LIMIT_SECONDS:
                wait_time = round(RATE_LIMIT_SECONDS - elapsed, 1)
                return jsonify({'error': f'Слишком много запросов. Подождите {wait_time} с.', 'wait_time': wait_time}), 429
        last_request_time[user_id] = now
        return f(*args, **kwargs)
    return decorated_function


# ========== ROUTES ==========
@app.route('/health', methods=['GET'])
def health():
    servers_status = {}
    for model, base in LM_SERVERS.items():
        try:
            r = requests.get(base.rstrip('/') + '/models', timeout=3)
            servers_status[model] = {'ok': r.status_code == 200, 'status': r.status_code}
        except Exception as e:
            servers_status[model] = {'ok': False, 'error': str(e)[:80]}
    return jsonify({
        'status': 'ok',
        'models': list(LM_SERVERS.keys()),
        'servers': servers_status,
        'time': datetime.now().isoformat()
    })


@app.route('/cancel', methods=['POST'])
def cancel_request():
    user_id = request.remote_addr or 'unknown'
    is_allowed, error_message = check_cancel_limit(user_id)
    if not is_allowed:
        return jsonify({'error': error_message, 'blocked': True, 'block_duration': CANCEL_BLOCK_DURATION}), 429
    if user_id in active_requests and active_requests[user_id]:
        active_requests[user_id] = False
        return jsonify({'status': 'cancelled', 'message': 'Генерация отменена'})
    return jsonify({'status': 'no_active_request'})


@app.route('/heartbeat', methods=['POST'])
def heartbeat():
    user_id = request.remote_addr or 'unknown'
    data = request.json or {}
    session_id = data.get('session_id', '')
    user_sessions[user_id] = {
        'session_id': session_id,
        'last_heartbeat': time.time(),
        'active': True
    }
    return jsonify({'status': 'ok'})


@app.route('/cleanup_session', methods=['POST'])
def cleanup_session():
    user_id = request.remote_addr or 'unknown'
    if user_id in active_requests:
        active_requests[user_id] = False
    if user_id in user_sessions:
        user_sessions[user_id]['active'] = False
    return jsonify({'status': 'cleaned'})


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/get_models', methods=['GET'])
def get_models():
    models_list = []
    for model_id in LM_SERVERS.keys():
        models_list.append({
            "id": model_id,
            "supports_vision": VISION_SUPPORT.get(model_id, False)
        })
    return jsonify({'models': models_list, 'server_busy': False})


@app.route('/chat', methods=['POST'])
@rate_limit
def chat():
    user_id = request.remote_addr or 'unknown'
    request_id = str(uuid.uuid4())
    active_requests[user_id] = request_id

    try:
        data = request.json or {}
        user_message = (data.get('message') or '').strip()
        conversation_history = data.get('history') or []
        model_name = data.get('model') or ''

        if not model_name or model_name not in LM_SERVERS:
            active_requests[user_id] = False
            return jsonify({'error': f'Модель "{model_name}" не найдена. Выберите модель из списка.'}), 400

        base_url = LM_SERVERS[model_name].rstrip('/')
        if base_url.endswith('/v1') or base_url.endswith('/api'):
            lm_studio_url = base_url + "/chat/completions"
        else:
            lm_studio_url = base_url + "/v1/chat/completions"

        image_data = data.get('image')
        image_mime_type = data.get('image_mime_type', 'image/jpeg')
        validated_image_data = None
        validated_mime_type = None

        if image_data:
            is_valid, error_msg, validated_mime = validate_image_safe(image_data, image_mime_type)
            if not is_valid:
                active_requests[user_id] = False
                return jsonify({'error': f'Ошибка изображения: {error_msg}'}), 400
            validated_image_data = image_data
            validated_mime_type = validated_mime or image_mime_type

        temperature = float(data.get('temperature', 0.7))
        top_p = float(data.get('top_p', 0.9))
        top_k = int(data.get('top_k', 50))
        presence_penalty = float(data.get('presence_penalty', 0.0))
        frequency_penalty = float(data.get('frequency_penalty', 0.0))
        repeat_penalty = float(data.get('repeat_penalty', 1.0))
        system_prompt = data.get('system_prompt') or 'Ты полезный ассистент.'
        max_tokens = int(data.get('max_tokens', 2048))
        stop_sequences = data.get('stop_sequences') or []
        seed = data.get('seed')

        messages = [{"role": "system", "content": system_prompt}]
        for msg in conversation_history:
            role = msg.get('role')
            content = msg.get('content')
            if role in ('user', 'assistant') and content is not None:
                messages.append({"role": role, "content": content})

        if validated_image_data:
            user_content = []
            if user_message:
                user_content.append({"type": "text", "text": user_message})
            else:
                user_content.append({"type": "text", "text": "Что на этом изображении? Опиши подробно, распознай весь текст."})
            user_content.append({
                "type": "image_url",
                "image_url": {"url": f"data:{validated_mime_type};base64,{validated_image_data}"}
            })
            messages.append({"role": "user", "content": user_content})
        else:
            if not user_message:
                active_requests[user_id] = False
                return jsonify({'error': 'Введите сообщение или загрузите изображение'}), 400
            messages.append({"role": "user", "content": user_message})

        messages = truncate_history(messages)

        check_content = user_message
        is_valid, token_result = check_token_limit(messages, system_prompt, check_content)
        if not is_valid:
            active_requests[user_id] = False
            return jsonify({'error': token_result}), 400

        payload = {
            "model": model_name,
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "top_k": top_k,
            "max_tokens": max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
            # Всегда просим reasoning. Модели без поддержки просто проигнорируют.
            "chat_template_kwargs": {"enable_thinking": True},
        }
        if presence_penalty != 0.0:
            payload["presence_penalty"] = presence_penalty
        if frequency_penalty != 0.0:
            payload["frequency_penalty"] = frequency_penalty
        if repeat_penalty != 1.0:
            payload["repeat_penalty"] = repeat_penalty
        if stop_sequences:
            payload["stop"] = stop_sequences
        if seed is not None and seed != '':
            try:
                payload["seed"] = int(seed)
            except (ValueError, TypeError):
                pass

        def generate():
            full_response = ""
            full_reasoning = ""
            usage = None
            start_ts = time.time()
            first_token_ts = None
            chunks = 0

            try:
                response = requests.post(
                    lm_studio_url,
                    json=payload,
                    stream=True,
                    timeout=(REQUEST_TIMEOUT_CONNECT, REQUEST_TIMEOUT_READ)
                )
                if response.status_code != 200:
                    error_text = (response.text or '')[:300]
                    yield sse({'error': f'Ошибка LM Studio ({response.status_code}): {error_text}'})
                    return

                if validated_image_data:
                    yield sse({'content': '🖼️ **Обработка изображения...** Это может занять время...'})

                for line in response.iter_lines():
                    if active_requests.get(user_id) != request_id:
                        response.close()
                        yield sse({
                            'cancelled': True,
                            'partial': full_response,
                            'reasoning_partial': full_reasoning,
                            'stats': build_stats(full_response, full_reasoning,
                                                 start_ts, first_token_ts, usage, chunks)
                        })
                        return
                    if user_id in user_sessions and not user_sessions[user_id].get('active', True):
                        response.close()
                        yield sse({
                            'cancelled': True,
                            'partial': full_response,
                            'reasoning_partial': full_reasoning,
                            'reason': 'session_closed'
                        })
                        return

                    if not line:
                        continue
                    line = line.decode('utf-8', errors='replace')
                    if not line.startswith('data: '):
                        continue
                    data_str = line[6:].strip()
                    if data_str == '[DONE]':
                        break

                    try:
                        chunk = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    if chunk.get('usage'):
                        usage = chunk['usage']

                    choices = chunk.get('choices') or []
                    if not choices:
                        continue

                    delta = choices[0].get('delta') or {}

                    # 1) Reasoning отдельным полем
                    reasoning_piece = (
                        delta.get('reasoning_content') or
                        delta.get('reasoning') or ''
                    )
                    if reasoning_piece:
                        full_reasoning += reasoning_piece
                        if first_token_ts is None:
                            first_token_ts = time.time()
                        chunks += 1
                        yield sse({'reasoning': reasoning_piece})
                        continue

                    # 2) Обычный content
                    content = delta.get('content') or ''
                    if not content:
                        continue

                    full_response += content
                    if first_token_ts is None:
                        first_token_ts = time.time()
                    chunks += 1
                    yield sse({'content': content, 'full': full_response})

                stats = build_stats(full_response, full_reasoning,
                                    start_ts, first_token_ts, usage, chunks)
                yield sse({
                    'done': True,
                    'full': full_response,
                    'reasoning': full_reasoning,
                    'stats': stats
                })

            except requests.exceptions.Timeout:
                yield sse({'error': f'Таймаут ответа от {model_name} ({REQUEST_TIMEOUT_READ} с).'})
            except requests.exceptions.ConnectionError:
                yield sse({'error': f'Не удалось подключиться к {base_url}. Запущена ли LM Studio?'})
            except Exception as e:
                yield sse({'error': str(e)})
            finally:
                if active_requests.get(user_id) == request_id:
                    active_requests[user_id] = False

        return Response(
            stream_with_context(generate()),
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache',
                'X-Accel-Buffering': 'no',
                'Connection': 'keep-alive'
            }
        )
    except Exception as e:
        active_requests[user_id] = False
        return jsonify({'error': f'Внутренняя ошибка: {str(e)}'}), 500


if __name__ == '__main__':
    print("🚀 AI Chat запущен: http://0.0.0.0:5000")
    print("   Модели:", list(LM_SERVERS.keys()))
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)