from flask import Flask, render_template, request, jsonify, Response, stream_with_context
import requests
import time
import json
import uuid
from functools import wraps
from datetime import datetime, timedelta
import base64
import imghdr
import io
from PIL import Image
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)
app.config['SESSION_PERMANENT'] = False
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10MB

# ========== КОНФИГУРАЦИЯ LM STUDIO ==========
LM_SERVERS = {
    "qwen3-8b": "http://127.0.0.1:1234/v1",
    "gemma-4-e2b-it-ud": "http://127.0.0.1:1234/v1",
    "qwen3vl-2b-instruct": "http://127.0.0.1:1234/v1",
}

VISION_SUPPORT = {
    "qwen3-8b": False,
    "gemma-4-e2b-it-ud": False,
    "qwen3vl-2b-instruct": True,
}
# ===========================================

RATE_LIMIT_SECONDS = 2.5
MAX_TOKENS_LIMIT = 8192
MAX_HISTORY_MESSAGES = 24

REQUEST_TIMEOUT_CONNECT = 120
REQUEST_TIMEOUT_READ = 600

CANCEL_LIMIT_WINDOW = 30
CANCEL_MAX_ATTEMPTS = 3
CANCEL_BLOCK_DURATION = 45

MAX_IMAGE_SIZE_MB = 5
MAX_IMAGE_SIZE_BYTES = MAX_IMAGE_SIZE_MB * 1024 * 1024
MAX_IMAGE_WIDTH = 4096
MAX_IMAGE_HEIGHT = 4096
ALLOWED_IMAGE_FORMATS = ['jpeg', 'jpg', 'png', 'webp']

cancel_attempts = {}
cancel_blocked_until = {}
last_request_time = {}
active_requests = {}
active_requests_started = {}
user_sessions = {}

STALE_REQUEST_SECONDS = 60

# Теги размышлений для Qwen3 (по шаблону — именно одинарные <think>)
THINK_OPEN = ' thinking'
THINK_CLOSE = ''


# ========== ХЕЛПЕРЫ ==========
def sse(obj):
    return f"data: {json.dumps(obj, ensure_ascii=False)}\n\n"


def validate_image_safe(base64_string, client_mime_type):
    base64_size = len(base64_string)
    estimated_bytes = int(base64_size * 0.75)
    if estimated_bytes > MAX_IMAGE_SIZE_BYTES:
        return False, f"Изображение слишком большое. Максимум {MAX_IMAGE_SIZE_MB}MB", None
    try:
        image_bytes = base64.b64decode(base64_string)
    except Exception as e:
        return False, f"Некорректные данные изображения: {str(e)}", None
    if len(image_bytes) > MAX_IMAGE_SIZE_BYTES:
        return False, f"Изображение слишком большое после декодирования. Максимум {MAX_IMAGE_SIZE_MB}MB", None
    if len(image_bytes) < 100:
        return False, "Файл изображения слишком маленький или пустой", None

    detected_format = imghdr.what(None, h=image_bytes)
    if not detected_format:
        if len(image_bytes) > 4:
            if image_bytes[0:3] == b'\xff\xd8\xff':
                detected_format = 'jpeg'
            elif image_bytes[0:8] == b'\x89PNG\r\n\x1a\n':
                detected_format = 'png'
            elif len(image_bytes) > 12 and image_bytes[0:4] == b'RIFF' and image_bytes[8:12] == b'WEBP':
                detected_format = 'webp'
    if not detected_format:
        return False, "Файл не является изображением или формат не поддерживается", None
    if detected_format not in ALLOWED_IMAGE_FORMATS:
        return False, f"Формат '{detected_format}' не поддерживается. Разрешены: {', '.join(ALLOWED_IMAGE_FORMATS)}", None

    if detected_format in ('jpg', 'jpeg'):
        validated_mime = 'image/jpeg'
    elif detected_format == 'png':
        validated_mime = 'image/png'
    elif detected_format == 'webp':
        validated_mime = 'image/webp'
    else:
        validated_mime = f'image/{detected_format}'

    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            if img.width > MAX_IMAGE_WIDTH or img.height > MAX_IMAGE_HEIGHT:
                return False, f"Изображение слишком большое: {img.width}x{img.height}. Максимум {MAX_IMAGE_WIDTH}x{MAX_IMAGE_HEIGHT}", None
            img.verify()
    except Exception as e:
        return False, f"Ошибка обработки изображения: {str(e)}", None
    return True, None, validated_mime


def extract_text_from_content(content):
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        texts = []
        for item in content:
            if isinstance(item, dict) and item.get('type') == 'text':
                texts.append(item.get('text', ''))
        return ' '.join(texts)
    return str(content) if content else ''


def count_tokens(text):
    if not text:
        return 0
    return max(1, len(text) // 3 + text.count('\n') // 2)


def check_token_limit(messages, system_prompt, user_message):
    total_text = system_prompt or ''
    if isinstance(user_message, list):
        user_text = extract_text_from_content(user_message)
    else:
        user_text = user_message or ''
    total_text += user_text
    for msg in messages:
        content = msg.get('content', '')
        total_text += extract_text_from_content(content)
    token_count = count_tokens(total_text)
    if token_count > MAX_TOKENS_LIMIT:
        return False, f"Превышен лимит токенов: ~{token_count}/{MAX_TOKENS_LIMIT}. Очистите историю или уменьшите max_tokens."
    return True, token_count


def truncate_history(messages, max_messages=MAX_HISTORY_MESSAGES):
    if len(messages) <= max_messages + 1:
        return messages
    system = [m for m in messages if m.get('role') == 'system']
    rest = [m for m in messages if m.get('role') != 'system']
    return system + rest[-(max_messages):]


def build_stats(full_response, full_reasoning, start_ts, first_token_ts, usage, chunks):
    now = time.time()
    elapsed = now - start_ts
    ttft = (first_token_ts - start_ts) if first_token_ts else None
    gen_time = (now - first_token_ts) if first_token_ts else 0.0

    if usage:
        completion_tokens = usage.get('completion_tokens') or 0
        prompt_tokens = usage.get('prompt_tokens') or 0
        total_tokens = usage.get('total_tokens') or (completion_tokens + prompt_tokens)
    else:
        completion_tokens = count_tokens(full_response + full_reasoning)
        prompt_tokens = 0
        total_tokens = completion_tokens

    tps = (completion_tokens / gen_time) if gen_time > 0.05 else 0.0

    return {
        'prompt_tokens': prompt_tokens,
        'completion_tokens': completion_tokens,
        'total_tokens': total_tokens,
        'elapsed_sec': round(elapsed, 2),
        'ttft_sec': round(ttft, 2) if ttft is not None else None,
        'tokens_per_sec': round(tps, 1),
        'chunks': chunks,
        'reasoning_chars': len(full_reasoning),
        'answer_chars': len(full_response),
    }


def check_cancel_limit(user_id):
    now = datetime.now()
    if user_id in cancel_blocked_until:
        if now < cancel_blocked_until[user_id]:
            remaining = int((cancel_blocked_until[user_id] - now).total_seconds())
            return False, f"Слишком много отмен. Блокировка ещё {remaining} с."
        else:
            del cancel_blocked_until[user_id]
            cancel_attempts[user_id] = []
    if user_id not in cancel_attempts:
        cancel_attempts[user_id] = []
    cutoff = now - timedelta(seconds=CANCEL_LIMIT_WINDOW)
    cancel_attempts[user_id] = [ts for ts in cancel_attempts[user_id] if ts > cutoff]
    if len(cancel_attempts[user_id]) >= CANCEL_MAX_ATTEMPTS:
        cancel_blocked_until[user_id] = now + timedelta(seconds=CANCEL_BLOCK_DURATION)
        return False, f"Слишком много отмен ({CANCEL_MAX_ATTEMPTS} за {CANCEL_LIMIT_WINDOW} с). Подождите {CANCEL_BLOCK_DURATION} с."
    cancel_attempts[user_id].append(now)
    return True, None


def rate_limit(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = request.remote_addr or 'unknown'
        now = time.time()
        if user_id in active_requests and active_requests[user_id]:
            started = active_requests_started.get(user_id, 0)
            if now - started > STALE_REQUEST_SECONDS:
                print(f"⚠️ Сброс зависшего запроса (>{STALE_REQUEST_SECONDS}с)")
                active_requests[user_id] = False
                active_requests_started.pop(user_id, None)
            else:
                return jsonify({'error': 'Предыдущий запрос ещё обрабатывается. Нажмите «Стоп».'}), 429
        if user_id in last_request_time:
            elapsed = now - last_request_time[user_id]
            if elapsed < RATE_LIMIT_SECONDS:
                wait_time = round(RATE_LIMIT_SECONDS - elapsed, 1)
                return jsonify({'error': f'Слишком много запросов. Подождите {wait_time} с.', 'wait_time': wait_time}), 429
        last_request_time[user_id] = now
        return f(*args, **kwargs)
    return decorated_function


# ========== ПАРСЕР <think>...</think> ==========
class ThinkTagParser:
    """
    Разрезает поток content на (reasoning, content) по тегам  thinking...</think>.
    Корректно обрабатывает теги, разорванные между чанками.
    """

    def __init__(self):
        self.in_think = False
        self.tag_buffer = ''

    def feed(self, piece):
        out = []
        text = self.tag_buffer + piece
        self.tag_buffer = ''

        while text:
            if not self.in_think:
                idx = text.find(THINK_OPEN)
                if idx == -1:
                    # Возможен обрыв " думать" на границе чанка: сохраним префикс тега в буфер.
                    saved = ''
                    for k in range(1, min(len(THINK_OPEN), len(text)) + 1):
                        if text.endswith(THINK_OPEN[:k]):
                            saved = THINK_OPEN[:k]
                    if saved:
                        main = text[:-len(saved)]
                        if main:
                            out.append(('content', main))
                        self.tag_buffer = saved
                        return out
                    out.append(('content', text))
                    return out

                if idx > 0:
                    out.append(('content', text[:idx]))
                text = text[idx + len(THINK_OPEN):]
                self.in_think = True
                continue

            else:
                idx = text.find(THINK_CLOSE)
                if idx == -1:
                    saved = ''
                    for k in range(1, min(len(THINK_CLOSE), len(text)) + 1):
                        if text.endswith(THINK_CLOSE[:k]):
                            saved = THINK_CLOSE[:k]
                    if saved:
                        main = text[:-len(saved)]
                        if main:
                            out.append(('reasoning', main))
                        self.tag_buffer = saved
                        return out
                    out.append(('reasoning', text))
                    return out

                if idx > 0:
                    out.append(('reasoning', text[:idx]))
                text = text[idx + len(THINK_CLOSE):]
                self.in_think = False
                continue

        return out

    def flush(self):
        if not self.tag_buffer:
            return []
        piece = self.tag_buffer
        self.tag_buffer = ''
        return [('reasoning' if self.in_think else 'content', piece)]


# ========== ROUTES ==========
@app.route('/health', methods=['GET'])
def health():
    servers_status = {}
    for model, base in LM_SERVERS.items():
        try:
            r = requests.get(base.rstrip('/') + '/models', timeout=3)
            servers_status[model] = {'ok': r.status_code == 200, 'status': r.status_code}
        except Exception as e:
            servers_status[model] = {'ok': False, 'error': str(e)[:80]}
    return jsonify({
        'status': 'ok',
        'models': list(LM_SERVERS.keys()),
        'servers': servers_status,
        'time': datetime.now().isoformat()
    })


@app.route('/warmup', methods=['POST'])
def warmup():
    data = request.json or {}
    model_name = data.get('model') or ''
    if not model_name or model_name not in LM_SERVERS:
        return jsonify({'status': 'error', 'detail': 'Модель не найдена'}), 400

    base_url = LM_SERVERS[model_name].rstrip('/')
    if base_url.endswith('/v1') or base_url.endswith('/api'):
        url = base_url + "/chat/completions"
    else:
        url = base_url + "/v1/chat/completions"

    payload = {
        "model": model_name,
        "messages": [{"role": "user", "content": "ok"}],
        "max_tokens": 1,
        "stream": False,
        "temperature": 0,
    }

    started = time.time()
    try:
        r = requests.post(url, json=payload, timeout=(120, 180))
        elapsed = round(time.time() - started, 2)
        if r.status_code == 200:
            print(f"✅ Warmup OK: {model_name} за {elapsed} с")
            return jsonify({'status': 'ok', 'warmed': True, 'elapsed': elapsed})
        print(f"⚠️ Warmup HTTP {r.status_code}: {(r.text or '')[:200]}")
        return jsonify({
            'status': 'error',
            'http': r.status_code,
            'detail': (r.text or '')[:200],
            'elapsed': elapsed,
        })
    except requests.exceptions.Timeout:
        print(f"⚠️ Warmup timeout: {model_name}")
        return jsonify({'status': 'error', 'detail': 'timeout'})
    except requests.exceptions.ConnectionError:
        print(f"⚠️ Warmup connection error: {model_name}")
        return jsonify({'status': 'error', 'detail': 'connection refused'})
    except Exception as e:
        print(f"⚠️ Warmup exception: {e}")
        return jsonify({'status': 'error', 'detail': str(e)[:200]})


@app.route('/cancel', methods=['POST'])
def cancel_request():
    user_id = request.remote_addr or 'unknown'
    is_allowed, error_message = check_cancel_limit(user_id)
    if not is_allowed:
        return jsonify({'error': error_message, 'blocked': True, 'block_duration': CANCEL_BLOCK_DURATION}), 429
    if user_id in active_requests and active_requests[user_id]:
        active_requests[user_id] = False
        active_requests_started.pop(user_id, None)
        return jsonify({'status': 'cancelled', 'message': 'Генерация отменена'})
    return jsonify({'status': 'no_active_request'})


@app.route('/heartbeat', methods=['POST'])
def heartbeat():
    user_id = request.remote_addr or 'unknown'
    data = request.json or {}
    session_id = data.get('session_id', '')
    user_sessions[user_id] = {
        'session_id': session_id,
        'last_heartbeat': time.time(),
        'active': True
    }
    return jsonify({'status': 'ok'})


@app.route('/cleanup_session', methods=['POST'])
def cleanup_session():
    user_id = request.remote_addr or 'unknown'
    if user_id in active_requests:
        active_requests[user_id] = False
        active_requests_started.pop(user_id, None)
    if user_id in user_sessions:
        user_sessions[user_id]['active'] = False
    return jsonify({'status': 'cleaned'})


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/get_models', methods=['GET'])
def get_models():
    models_list = []
    for model_id in LM_SERVERS.keys():
        models_list.append({
            "id": model_id,
            "supports_vision": VISION_SUPPORT.get(model_id, False)
        })
    return jsonify({'models': models_list, 'server_busy': False})


@app.route('/chat', methods=['POST'])
@rate_limit
def chat():
    user_id = request.remote_addr or 'unknown'
    request_id = str(uuid.uuid4())
    active_requests[user_id] = request_id
    active_requests_started[user_id] = time.time()

    try:
        data = request.json or {}
        user_message = (data.get('message') or '').strip()
        conversation_history = data.get('history') or []
        model_name = data.get('model') or ''

        if not model_name or model_name not in LM_SERVERS:
            active_requests[user_id] = False
            active_requests_started.pop(user_id, None)
            return jsonify({'error': f'Модель "{model_name}" не найдена. Выберите модель из списка.'}), 400

        base_url = LM_SERVERS[model_name].rstrip('/')
        if base_url.endswith('/v1') or base_url.endswith('/api'):
            lm_studio_url = base_url + "/chat/completions"
        else:
            lm_studio_url = base_url + "/v1/chat/completions"

        image_data = data.get('image')
        image_mime_type = data.get('image_mime_type', 'image/jpeg')
        validated_image_data = None
        validated_mime_type = None

        if image_data:
            is_valid, error_msg, validated_mime = validate_image_safe(image_data, image_mime_type)
            if not is_valid:
                active_requests[user_id] = False
                active_requests_started.pop(user_id, None)
                return jsonify({'error': f'Ошибка изображения: {error_msg}'}), 400
            validated_image_data = image_data
            validated_mime_type = validated_mime or image_mime_type

        temperature = float(data.get('temperature', 0.7))
        top_p = float(data.get('top_p', 0.9))
        top_k = int(data.get('top_k', 50))
        presence_penalty = float(data.get('presence_penalty', 0.0))
        frequency_penalty = float(data.get('frequency_penalty', 0.0))
        repeat_penalty = float(data.get('repeat_penalty', 1.0))
        system_prompt = data.get('system_prompt') or 'Ты полезный ассистент.'
        max_tokens = int(data.get('max_tokens', 2048))
        stop_sequences = data.get('stop_sequences') or []
        seed = data.get('seed')

        messages = [{"role": "system", "content": system_prompt}]
        for msg in conversation_history:
            role = msg.get('role')
            content = msg.get('content')
            if role in ('user', 'assistant') and content is not None:
                messages.append({"role": role, "content": content})

        if validated_image_data:
            user_content = []
            if user_message:
                user_content.append({"type": "text", "text": user_message})
            else:
                user_content.append({"type": "text", "text": "Что на этом изображении? Опиши подробно, распознай весь текст."})
            user_content.append({
                "type": "image_url",
                "image_url": {"url": f"data:{validated_mime_type};base64,{validated_image_data}"}
            })
            messages.append({"role": "user", "content": user_content})
        else:
            if not user_message:
                active_requests[user_id] = False
                active_requests_started.pop(user_id, None)
                return jsonify({'error': 'Введите сообщение или загрузите изображение'}), 400
            messages.append({"role": "user", "content": user_message})

        messages = truncate_history(messages)

        is_valid, token_result = check_token_limit(messages, system_prompt, user_message)
        if not is_valid:
            active_requests[user_id] = False
            active_requests_started.pop(user_id, None)
            return jsonify({'error': token_result}), 400

        payload = {
            "model": model_name,
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "top_k": top_k,
            "max_tokens": max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
            # Qwen3: при false шаблон вставит пустую пару  thinking\n\n,
            # чтобы модель не генерировала reasoning. При true — модель думает.
            "chat_template_kwargs": {"enable_thinking": True},
        }
        if presence_penalty != 0.0:
            payload["presence_penalty"] = presence_penalty
        if frequency_penalty != 0.0:
            payload["frequency_penalty"] = frequency_penalty
        if repeat_penalty != 1.0:
            payload["repeat_penalty"] = repeat_penalty
        if stop_sequences:
            payload["stop"] = stop_sequences
        if seed is not None and seed != '':
            try:
                payload["seed"] = int(seed)
            except (ValueError, TypeError):
                pass

        def generate():
            full_response = ""
            full_reasoning = ""
            usage = None
            start_ts = time.time()
            first_token_ts = None
            chunks = 0
            tag_parser = ThinkTagParser()

            def emit(kind, text):
                nonlocal full_response, full_reasoning, first_token_ts, chunks
                if not text:
                    return None
                if first_token_ts is None:
                    first_token_ts = time.time()
                chunks += 1
                if kind == 'reasoning':
                    full_reasoning += text
                    return sse({'reasoning': text})
                else:
                    full_response += text
                    return sse({'content': text, 'full': full_response})

            response = None
            try:
                # POST с авто-retry один раз
                last_err = None
                for attempt in range(2):
                    if active_requests.get(user_id) != request_id:
                        return
                    try:
                        response = requests.post(
                            lm_studio_url,
                            json=payload,
                            stream=True,
                            timeout=(REQUEST_TIMEOUT_CONNECT, REQUEST_TIMEOUT_READ)
                        )
                        if response.status_code == 200:
                            break

                        last_err = f'HTTP {response.status_code}: {(response.text or "")[:200]}'
                        try: response.close()
                        except Exception: pass
                        response = None

                        if attempt == 0:
                            print(f"⚠️ LM Studio {last_err} — повтор через 2 с")
                            time.sleep(2)
                            continue
                    except (requests.exceptions.Timeout,
                            requests.exceptions.ConnectionError) as e:
                        last_err = str(e)[:200]
                        response = None
                        if attempt == 0:
                            print(f"⚠️ LM Studio {last_err} — повтор через 2 с")
                            time.sleep(2)
                            continue
                        raise

                if response is None or response.status_code != 200:
                    yield sse({'error': f'Ошибка LM Studio: {last_err or "не удалось получить ответ"}'})
                    return

                if validated_image_data:
                    yield sse({'content': '🖼️ **Обработка изображения...** Это может занять время...'})

                for line in response.iter_lines():
                    if active_requests.get(user_id) != request_id:
                        response.close()
                        for k, t in tag_parser.flush():
                            piece = emit(k, t)
                            if piece:
                                yield piece
                        yield sse({
                            'cancelled': True,
                            'partial': full_response,
                            'reasoning_partial': full_reasoning,
                            'stats': build_stats(full_response, full_reasoning,
                                                 start_ts, first_token_ts, usage, chunks)
                        })
                        return
                    if user_id in user_sessions and not user_sessions[user_id].get('active', True):
                        response.close()
                        yield sse({
                            'cancelled': True,
                            'partial': full_response,
                            'reasoning_partial': full_reasoning,
                            'reason': 'session_closed'
                        })
                        return

                    if not line:
                        continue
                    line = line.decode('utf-8', errors='replace')
                    if not line.startswith('data: '):
                        continue
                    data_str = line[6:].strip()
                    if data_str == '[DONE]':
                        break

                    try:
                        chunk = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    if chunk.get('usage'):
                        usage = chunk['usage']

                    choices = chunk.get('choices') or []
                    if not choices:
                        continue

                    delta = choices[0].get('delta') or {}

                    # 1) Reasoning пришёл отдельным полем (на случай другой версии LM Studio)
                    reasoning_piece = (
                        delta.get('reasoning_content') or
                        delta.get('reasoning') or ''
                    )
                    if reasoning_piece:
                        if first_token_ts is None:
                            first_token_ts = time.time()
                        chunks += 1
                        full_reasoning += reasoning_piece
                        yield sse({'reasoning': reasoning_piece})
                        continue

                    # 2) Обычный content — теги  thinking режем парсером
                    content = delta.get('content') or ''
                    if not content:
                        continue

                    for kind, text in tag_parser.feed(content):
                        piece = emit(kind, text)
                        if piece:
                            yield piece

                for kind, text in tag_parser.flush():
                    piece = emit(kind, text)
                    if piece:
                        yield piece

                stats = build_stats(full_response, full_reasoning,
                                    start_ts, first_token_ts, usage, chunks)
                yield sse({
                    'done': True,
                    'full': full_response,
                    'reasoning': full_reasoning,
                    'stats': stats
                })

            except GeneratorExit:
                print(f"⚠️ Клиент отключился до конца ответа ({user_id})")
                try: response.close()
                except Exception: pass
            except requests.exceptions.Timeout:
                try:
                    yield sse({'error': f'Таймаут ответа от {model_name} ({REQUEST_TIMEOUT_READ} с).'})
                except Exception:
                    pass
            except requests.exceptions.ConnectionError:
                try:
                    yield sse({'error': f'Не удалось подключиться к {base_url}. Запущена ли LM Studio?'})
                except Exception:
                    pass
            except Exception as e:
                try:
                    yield sse({'error': str(e)})
                except Exception:
                    pass
            finally:
                if active_requests.get(user_id) == request_id:
                    active_requests[user_id] = False
                    active_requests_started.pop(user_id, None)

        return Response(
            stream_with_context(generate()),
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache, no-transform',
                'X-Accel-Buffering': 'no',
                'Connection': 'keep-alive',
                'Content-Type': 'text/event-stream; charset=utf-8',
                'Transfer-Encoding': 'chunked',
            }
        )
    except Exception as e:
        active_requests[user_id] = False
        active_requests_started.pop(user_id, None)
        return jsonify({'error': f'Внутренняя ошибка: {str(e)}'}), 500


if __name__ == '__main__':
    print("🚀 AI Chat запущен: http://0.0.0.0:5000")
    print("   Модели:", list(LM_SERVERS.keys()))
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)