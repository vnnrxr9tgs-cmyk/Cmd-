# MySQL Query Tool (PyQt5)

Многопоточное GUI-приложение для параметризованных SQL-запросов к **MySQL 8.0**.

## Зависимости

Только две:

```
PyQt5
PyMySQL
```

Конфиг — обычный JSON (стандартная библиотека Python). Никакого PyYAML и cryptography.

## Установка

```bash
cd mysql_query_app
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## Возможности

- Светлый современный интерфейс
- Многопоточность — UI не зависает
- Редактирование конфига прямо из программы (кнопка **Настройки**)
- Настраиваемые таймауты: connect / read / write
- Параметры: дата-время + LIKE (опционально)
- По умолчанию дата = последние 12 часов
- Если параметр выключен/пуст — условие в SQL не добавляется
- JOIN, подзапросы, любые SQL-конструкции — работают
- Статусные лампочки: БД / Готов / Работаю
- BLOB-столбец: ПКМ → «Сохранить как .tar…»

## Конфиг (`config.json`)

```json
{
  "database": {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "root",
    "password": "your_password",
    "database": "your_database",
    "charset": "utf8mb4",
    "connect_timeout": 5,
    "read_timeout": 60,
    "write_timeout": 30
  },
  "sql_query": "SELECT ... FROM ... JOIN ... WHERE 1=1 {and_datetime} {datetime_condition} ...",
  "blob_column": "data_blob",
  "datetime_column": "created_at",
  "like_column": "name"
}
```

### Таймауты

| Параметр          | По умолчанию | Назначение                           |
|-------------------|--------------|--------------------------------------|
| connect_timeout   | 5 сек        | Ожидание установления TCP-соединения |
| read_timeout      | 60 сек       | Ожидание ответа от сервера           |
| write_timeout     | 30 сек       | Ожидание отправки данных на сервер   |

Меняются в **Настройки → База данных** или прямо в `config.json`.

### JOIN

Да, работает. Пишите любой валидный SQL со своими JOIN — плейсхолдеры `{datetime_condition}` / `{like_condition}` просто подставляются в нужное место WHERE.

Пример:

```sql
SELECT t.id, t.created_at, t.name, t.data_blob, u.login
FROM your_table t
LEFT JOIN users u ON u.id = t.user_id
WHERE 1=1
  {and_datetime} {datetime_condition}
  {and_like} {like_condition}
ORDER BY t.created_at DESC
LIMIT 1000
```

## Использование

1. Запустите → автоматически проверяется соединение.
2. При необходимости откройте **Настройки** и укажите host/user/password/SQL.
3. Задайте дату (или оставьте 12 часов) и/или LIKE.
4. **Выполнить запрос**.
5. ПКМ по BLOB-ячейке → сохранить в `.tar`.
