#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MySQL Query Tool — PyQt5 GUI
Многопоточное приложение для выполнения SQL-запросов к MySQL 8.0
с поддержкой BLOB-столбцов и сохранением в .tar
"""

from __future__ import annotations

import sys
import os
import json
import tarfile
import io
import logging
from datetime import datetime, timedelta
from typing import Optional, Any, List, Dict

import pymysql
from pymysql.cursors import DictCursor

from PyQt5.QtCore import (
    Qt, QThread, pyqtSignal, QObject, QDateTime
)
from PyQt5.QtGui import (
    QFont, QColor, QPalette
)
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QDateTimeEdit, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView, QStatusBar,
    QMessageBox, QFileDialog, QGroupBox, QFormLayout,
    QProgressBar, QMenu, QAction, QDialog, QDialogButtonBox,
    QSpinBox, QTextEdit, QTabWidget, QCheckBox
)


# ---------------------------------------------------------------------------
# Логирование
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("MySQLQueryApp")

CONFIG_NAME = "config.json"


# ---------------------------------------------------------------------------
# Конфигурация (JSON, стандартная библиотека)
# ---------------------------------------------------------------------------
def _config_path() -> str:
    base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, CONFIG_NAME)


def load_config() -> dict:
    path = _config_path()
    if not os.path.exists(path):
        raise FileNotFoundError(f"Конфиг не найден: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config(data: dict) -> None:
    path = _config_path()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Worker выполнения запроса
# ---------------------------------------------------------------------------
class QueryWorker(QObject):
    finished = pyqtSignal(list, list)   # rows, columns
    error = pyqtSignal(str)
    status = pyqtSignal(str)

    def __init__(
        self,
        db_cfg: dict,
        sql_template: str,
        datetime_value: Optional[datetime],
        like_value: Optional[str],
        datetime_column: str = "created_at",
        like_column: str = "name",
        parent: Optional[QObject] = None
    ):
        super().__init__(parent)
        self.db_cfg = db_cfg
        self.sql_template = sql_template
        self.datetime_value = datetime_value
        self.like_value = like_value
        self.datetime_column = datetime_column
        self.like_column = like_column
        self._conn: Optional[pymysql.Connection] = None

    def run(self) -> None:
        try:
            self.status.emit("Подключение к БД…")
            self._conn = pymysql.connect(
                host=self.db_cfg.get("host", "127.0.0.1"),
                port=int(self.db_cfg.get("port", 3306)),
                user=self.db_cfg.get("user", "root"),
                password=self.db_cfg.get("password", ""),
                database=self.db_cfg.get("database", ""),
                charset=self.db_cfg.get("charset", "utf8mb4"),
                cursorclass=DictCursor,
                connect_timeout=int(self.db_cfg.get("connect_timeout", 5)),
                read_timeout=int(self.db_cfg.get("read_timeout", 60)),
                write_timeout=int(self.db_cfg.get("write_timeout", 30)),
                autocommit=True,
            )

            datetime_condition = ""
            like_condition = ""
            and_datetime = ""
            and_like = ""
            params: Dict[str, Any] = {}

            if self.datetime_value is not None:
                datetime_condition = f"{self.datetime_column} > %(dt)s"
                and_datetime = "AND"
                params["dt"] = self.datetime_value

            if self.like_value and self.like_value.strip():
                like_condition = f"{self.like_column} LIKE %(like_val)s"
                and_like = "AND"
                params["like_val"] = f"%{self.like_value.strip()}%"

            sql = self.sql_template.format(
                datetime_condition=datetime_condition,
                like_condition=like_condition,
                and_datetime=and_datetime,
                and_like=and_like,
            )

            lines = []
            for line in sql.splitlines():
                stripped = line.strip()
                if not stripped or stripped in ("AND", "AND AND"):
                    continue
                lines.append(line)
            sql = "\n".join(lines)
            sql = sql.replace("WHERE 1=1\n    AND", "WHERE")
            sql = sql.replace("WHERE 1=1\n  AND", "WHERE")
            sql = sql.replace("WHERE 1=1 AND", "WHERE")

            logger.info("SQL:\n%s\nParams: %s", sql, params)

            self.status.emit("Выполнение запроса…")
            with self._conn.cursor() as cursor:
                cursor.execute(sql, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description] if cursor.description else []

            self.status.emit(f"Получено строк: {len(rows)}")
            self.finished.emit(list(rows), columns)

        except Exception as e:
            logger.exception("Ошибка запроса")
            self.error.emit(str(e))
        finally:
            self._cleanup()

    def _cleanup(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None


# ---------------------------------------------------------------------------
# Worker проверки соединения
# ---------------------------------------------------------------------------
class ConnectionCheckWorker(QObject):
    finished = pyqtSignal(bool, str)

    def __init__(self, db_cfg: dict, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.db_cfg = db_cfg

    def run(self) -> None:
        conn = None
        try:
            conn = pymysql.connect(
                host=self.db_cfg.get("host", "127.0.0.1"),
                port=int(self.db_cfg.get("port", 3306)),
                user=self.db_cfg.get("user", "root"),
                password=self.db_cfg.get("password", ""),
                database=self.db_cfg.get("database", ""),
                charset=self.db_cfg.get("charset", "utf8mb4"),
                connect_timeout=int(self.db_cfg.get("connect_timeout", 5)),
            )
            conn.ping(reconnect=False)
            self.finished.emit(True, "Подключено")
        except Exception as e:
            self.finished.emit(False, str(e))
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# Лампочка статуса
# ---------------------------------------------------------------------------
class StatusLamp(QWidget):
    COLORS = {
        "off":    "#b0b0b0",
        "green":  "#27ae60",
        "yellow": "#f39c12",
        "red":    "#e74c3c",
        "blue":   "#3498db",
    }

    def __init__(self, title: str, parent: Optional[QWidget] = None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.lamp = QLabel()
        self.lamp.setFixedSize(12, 12)
        self.lamp.setStyleSheet(self._style("off"))
        layout.addWidget(self.lamp)

        self.label = QLabel(title)
        self.label.setStyleSheet("color: #555; font-size: 12px;")
        layout.addWidget(self.label)

    def _style(self, state: str) -> str:
        c = self.COLORS.get(state, self.COLORS["off"])
        return (
            f"background-color: {c}; border-radius: 6px; "
            f"border: 1px solid rgba(0,0,0,0.15);"
        )

    def set_state(self, state: str) -> None:
        self.lamp.setStyleSheet(self._style(state))


# ---------------------------------------------------------------------------
# Диалог настроек (редактирование config.json)
# ---------------------------------------------------------------------------
class SettingsDialog(QDialog):
    def __init__(self, config: dict, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Настройки")
        self.setMinimumSize(640, 520)
        self.resize(700, 560)
        self._config = json.loads(json.dumps(config))  # deep copy

        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        layout.addWidget(tabs)

        # --- Вкладка «База данных» ---
        db_tab = QWidget()
        db_form = QFormLayout(db_tab)
        db_form.setSpacing(10)
        db_form.setContentsMargins(16, 16, 16, 16)

        db = self._config.get("database", {})
        self.ed_host = QLineEdit(str(db.get("host", "127.0.0.1")))
        self.ed_port = QSpinBox()
        self.ed_port.setRange(1, 65535)
        self.ed_port.setValue(int(db.get("port", 3306)))
        self.ed_user = QLineEdit(str(db.get("user", "root")))
        self.ed_password = QLineEdit(str(db.get("password", "")))
        self.ed_password.setEchoMode(QLineEdit.Password)
        self.chk_show_pwd = QCheckBox("Показать пароль")
        self.chk_show_pwd.toggled.connect(
            lambda c: self.ed_password.setEchoMode(
                QLineEdit.Normal if c else QLineEdit.Password
            )
        )
        self.ed_database = QLineEdit(str(db.get("database", "")))
        self.ed_charset = QLineEdit(str(db.get("charset", "utf8mb4")))

        self.sp_connect = QSpinBox()
        self.sp_connect.setRange(1, 300)
        self.sp_connect.setSuffix(" сек")
        self.sp_connect.setValue(int(db.get("connect_timeout", 5)))
        self.sp_read = QSpinBox()
        self.sp_read.setRange(1, 3600)
        self.sp_read.setSuffix(" сек")
        self.sp_read.setValue(int(db.get("read_timeout", 60)))
        self.sp_write = QSpinBox()
        self.sp_write.setRange(1, 600)
        self.sp_write.setSuffix(" сек")
        self.sp_write.setValue(int(db.get("write_timeout", 30)))

        for w in (self.ed_host, self.ed_user, self.ed_password,
                  self.ed_database, self.ed_charset):
            w.setMinimumWidth(280)

        db_form.addRow("Host:", self.ed_host)
        db_form.addRow("Port:", self.ed_port)
        db_form.addRow("User:", self.ed_user)
        db_form.addRow("Password:", self.ed_password)
        db_form.addRow("", self.chk_show_pwd)
        db_form.addRow("Database:", self.ed_database)
        db_form.addRow("Charset:", self.ed_charset)
        db_form.addRow("Connect timeout:", self.sp_connect)
        db_form.addRow("Read timeout:", self.sp_read)
        db_form.addRow("Write timeout:", self.sp_write)
        tabs.addTab(db_tab, "База данных")

        # --- Вкладка «SQL и колонки» ---
        sql_tab = QWidget()
        sql_layout = QVBoxLayout(sql_tab)
        sql_layout.setContentsMargins(16, 16, 16, 16)

        hint = QLabel(
            "Плейсхолдеры: {datetime_condition}, {like_condition}, "
            "{and_datetime}, {and_like}\n"
            "JOIN, подзапросы, любые конструкции SQL — поддерживаются."
        )
        hint.setStyleSheet("color: #666; font-size: 12px;")
        hint.setWordWrap(True)
        sql_layout.addWidget(hint)

        self.txt_sql = QTextEdit()
        self.txt_sql.setPlainText(self._config.get("sql_query", ""))
        self.txt_sql.setFont(QFont("Consolas", 11))
        self.txt_sql.setMinimumHeight(220)
        sql_layout.addWidget(self.txt_sql)

        col_form = QFormLayout()
        self.ed_blob_col = QLineEdit(self._config.get("blob_column", "data_blob"))
        self.ed_dt_col = QLineEdit(self._config.get("datetime_column", "created_at"))
        self.ed_like_col = QLineEdit(self._config.get("like_column", "name"))
        col_form.addRow("BLOB-колонка:", self.ed_blob_col)
        col_form.addRow("Datetime-колонка:", self.ed_dt_col)
        col_form.addRow("LIKE-колонка:", self.ed_like_col)
        sql_layout.addLayout(col_form)
        tabs.addTab(sql_tab, "SQL и колонки")

        # Кнопки
        buttons = QDialogButtonBox(
            QDialogButtonBox.Save | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _on_save(self) -> None:
        self._config["database"] = {
            "host": self.ed_host.text().strip(),
            "port": self.ed_port.value(),
            "user": self.ed_user.text().strip(),
            "password": self.ed_password.text(),
            "database": self.ed_database.text().strip(),
            "charset": self.ed_charset.text().strip() or "utf8mb4",
            "connect_timeout": self.sp_connect.value(),
            "read_timeout": self.sp_read.value(),
            "write_timeout": self.sp_write.value(),
        }
        self._config["sql_query"] = self.txt_sql.toPlainText().strip()
        self._config["blob_column"] = self.ed_blob_col.text().strip() or "data_blob"
        self._config["datetime_column"] = self.ed_dt_col.text().strip() or "created_at"
        self._config["like_column"] = self.ed_like_col.text().strip() or "name"

        if not self._config["sql_query"]:
            QMessageBox.warning(self, "Ошибка", "SQL-запрос не может быть пустым.")
            return
        try:
            save_config(self._config)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка записи", str(e))
            return
        self.accept()

    def get_config(self) -> dict:
        return self._config


# ---------------------------------------------------------------------------
# Главное окно
# ---------------------------------------------------------------------------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MySQL Query Tool")
        self.setMinimumSize(980, 660)
        self.resize(1180, 720)

        self.config: dict = {}
        self.db_cfg: dict = {}
        self.sql_template: str = ""
        self.blob_column: str = "data_blob"
        self.datetime_column: str = "created_at"
        self.like_column: str = "name"

        self._query_thread: Optional[QThread] = None
        self._query_worker: Optional[QueryWorker] = None
        self._check_thread: Optional[QThread] = None
        self._check_worker: Optional[ConnectionCheckWorker] = None

        self._rows_data: List[Dict[str, Any]] = []
        self._columns: List[str] = []

        self._build_ui()
        self._apply_light_theme()
        self._load_config_and_check()

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(14, 12, 14, 8)
        root.setSpacing(10)

        # Заголовок + статусы + настройки
        header = QHBoxLayout()
        title = QLabel("MySQL Query Tool")
        title.setStyleSheet("font-size: 18px; font-weight: 600; color: #2c3e50;")
        header.addWidget(title)
        header.addStretch()

        self.lamp_db = StatusLamp("БД")
        self.lamp_ready = StatusLamp("Готов")
        self.lamp_work = StatusLamp("Работаю")
        header.addWidget(self.lamp_db)
        header.addSpacing(12)
        header.addWidget(self.lamp_ready)
        header.addSpacing(12)
        header.addWidget(self.lamp_work)
        header.addSpacing(16)

        self.btn_settings = QPushButton("⚙  Настройки")
        self.btn_settings.setFixedHeight(32)
        self.btn_settings.clicked.connect(self._open_settings)
        header.addWidget(self.btn_settings)
        root.addLayout(header)

        # Параметры запроса
        params = QGroupBox("Параметры запроса")
        form = QFormLayout(params)
        form.setSpacing(8)
        form.setLabelAlignment(Qt.AlignRight)

        self.dt_edit = QDateTimeEdit()
        self.dt_edit.setCalendarPopup(True)
        self.dt_edit.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
        self.dt_edit.setDateTime(QDateTime.currentDateTime().addSecs(-12 * 3600))
        self.dt_edit.setMinimumWidth(210)

        self.cb_use_dt = QPushButton("Использовать")
        self.cb_use_dt.setCheckable(True)
        self.cb_use_dt.setChecked(True)
        self.cb_use_dt.setFixedWidth(120)
        self.cb_use_dt.toggled.connect(self._on_dt_toggled)

        dt_row = QHBoxLayout()
        dt_row.addWidget(self.dt_edit)
        dt_row.addWidget(self.cb_use_dt)
        dt_row.addStretch()
        form.addRow("Дата / время (с):", dt_row)

        self.like_edit = QLineEdit()
        self.like_edit.setPlaceholderText("Пусто = условие LIKE не используется")
        form.addRow("Значение (LIKE):", self.like_edit)

        btn_row = QHBoxLayout()
        self.btn_run = QPushButton("▶  Выполнить запрос")
        self.btn_run.setFixedHeight(36)
        self.btn_run.clicked.connect(self._on_run_clicked)

        self.btn_check = QPushButton("Проверить соединение")
        self.btn_check.setFixedHeight(36)
        self.btn_check.clicked.connect(self._check_connection)

        self.btn_clear = QPushButton("Очистить таблицу")
        self.btn_clear.setFixedHeight(36)
        self.btn_clear.clicked.connect(self._clear_table)

        btn_row.addWidget(self.btn_run)
        btn_row.addWidget(self.btn_check)
        btn_row.addWidget(self.btn_clear)
        btn_row.addStretch()
        form.addRow("", btn_row)
        root.addWidget(params)

        # Прогресс
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        self.progress.setFixedHeight(3)
        root.addWidget(self.progress)

        # Таблица
        self.table = QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._on_table_context_menu)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.verticalHeader().setDefaultSectionSize(28)
        root.addWidget(self.table, stretch=1)

        # Статус-бар
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_label = QLabel("Готов к работе")
        self.status_bar.addWidget(self.status_label, 1)
        self.rows_label = QLabel("")
        self.status_bar.addPermanentWidget(self.rows_label)

    def _apply_light_theme(self) -> None:
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #f5f6fa;
                color: #2c3e50;
                font-family: "Segoe UI", "Ubuntu", sans-serif;
                font-size: 13px;
            }
            QGroupBox {
                font-weight: 600;
                border: 1px solid #dfe4ea;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 14px;
                background-color: #ffffff;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 6px;
                color: #57606f;
            }
            QLineEdit, QDateTimeEdit, QSpinBox, QTextEdit {
                background-color: #ffffff;
                border: 1px solid #ced6e0;
                border-radius: 5px;
                padding: 6px 8px;
                selection-background-color: #74b9ff;
            }
            QLineEdit:focus, QDateTimeEdit:focus, QSpinBox:focus, QTextEdit:focus {
                border: 1px solid #0984e3;
            }
            QPushButton {
                background-color: #ffffff;
                border: 1px solid #ced6e0;
                border-radius: 5px;
                padding: 6px 14px;
                color: #2c3e50;
            }
            QPushButton:hover {
                background-color: #f1f2f6;
                border-color: #a4b0be;
            }
            QPushButton:pressed {
                background-color: #dfe4ea;
            }
            QPushButton:disabled {
                color: #a4b0be;
                background-color: #f1f2f6;
            }
            QPushButton#primary {
                background-color: #0984e3;
                color: white;
                border: none;
                font-weight: 600;
            }
            QPushButton#primary:hover {
                background-color: #0692f0;
            }
            QPushButton#primary:pressed {
                background-color: #0670c0;
            }
            QPushButton#primary:disabled {
                background-color: #b2bec3;
                color: #ffffff;
            }
            QPushButton:checked {
                background-color: #00b894;
                color: white;
                border: none;
                font-weight: 600;
            }
            QPushButton:!checked {
                background-color: #dfe4ea;
                color: #57606f;
            }
            QTableWidget {
                background-color: #ffffff;
                alternate-background-color: #f8f9fb;
                gridline-color: #e8ecef;
                border: 1px solid #dfe4ea;
                border-radius: 6px;
                color: #2c3e50;
            }
            QTableWidget::item:selected {
                background-color: #74b9ff;
                color: #1e272e;
            }
            QHeaderView::section {
                background-color: #f1f2f6;
                color: #57606f;
                padding: 7px 8px;
                border: none;
                border-bottom: 1px solid #dfe4ea;
                border-right: 1px solid #e8ecef;
                font-weight: 600;
            }
            QProgressBar {
                border: none;
                background: #dfe4ea;
                border-radius: 1px;
            }
            QProgressBar::chunk {
                background: #0984e3;
            }
            QStatusBar {
                background: #ffffff;
                border-top: 1px solid #dfe4ea;
                color: #57606f;
            }
            QMenu {
                background-color: #ffffff;
                border: 1px solid #dfe4ea;
                padding: 4px;
            }
            QMenu::item {
                padding: 6px 24px;
            }
            QMenu::item:selected {
                background-color: #74b9ff;
                color: #1e272e;
            }
            QTabWidget::pane {
                border: 1px solid #dfe4ea;
                border-radius: 6px;
                background: #ffffff;
            }
            QTabBar::tab {
                background: #f1f2f6;
                border: 1px solid #dfe4ea;
                border-bottom: none;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
                padding: 7px 16px;
                margin-right: 2px;
                color: #57606f;
            }
            QTabBar::tab:selected {
                background: #ffffff;
                color: #2c3e50;
                font-weight: 600;
            }
            QDialog {
                background-color: #f5f6fa;
            }
        """)
        self.btn_run.setObjectName("primary")
        self.btn_run.setStyleSheet("")  # подхватит #primary из общего стиля
        # Принудительно применяем стиль primary
        self.btn_run.setStyleSheet("""
            QPushButton {
                background-color: #0984e3;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 6px 18px;
                font-weight: 600;
            }
            QPushButton:hover { background-color: #0692f0; }
            QPushButton:pressed { background-color: #0670c0; }
            QPushButton:disabled { background-color: #b2bec3; color: #fff; }
        """)
        self.cb_use_dt.setStyleSheet("""
            QPushButton:checked {
                background-color: #00b894; color: white; border: none;
                border-radius: 5px; font-weight: 600;
            }
            QPushButton:!checked {
                background-color: #dfe4ea; color: #57606f;
                border: 1px solid #ced6e0; border-radius: 5px;
            }
        """)

    # ------------------------------------------------------------------ Конфиг
    def _load_config_and_check(self) -> None:
        try:
            self.config = load_config()
            self._apply_config(self.config)
            self.status_label.setText("Конфиг загружен")
            self._check_connection()
        except Exception as e:
            logger.exception("Ошибка загрузки конфига")
            QMessageBox.critical(self, "Ошибка конфига", str(e))
            self.lamp_db.set_state("red")
            self.lamp_ready.set_state("off")
            self.btn_run.setEnabled(False)

    def _apply_config(self, cfg: dict) -> None:
        self.config = cfg
        self.db_cfg = cfg.get("database", {})
        self.sql_template = cfg.get("sql_query", "").strip()
        self.blob_column = cfg.get("blob_column", "data_blob")
        self.datetime_column = cfg.get("datetime_column", "created_at")
        self.like_column = cfg.get("like_column", "name")
        if not self.sql_template:
            raise ValueError("В конфиге отсутствует sql_query")

    def _open_settings(self) -> None:
        dlg = SettingsDialog(self.config, self)
        if dlg.exec_() == QDialog.Accepted:
            try:
                self._apply_config(dlg.get_config())
                self.status_label.setText("Настройки сохранены")
                self._check_connection()
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", str(e))

    # ------------------------------------------------------------------ Соединение
    def _check_connection(self) -> None:
        if self._check_thread and self._check_thread.isRunning():
            return
        self.lamp_db.set_state("yellow")
        self.status_label.setText("Проверка соединения…")
        self.btn_check.setEnabled(False)

        self._check_thread = QThread()
        self._check_worker = ConnectionCheckWorker(self.db_cfg)
        self._check_worker.moveToThread(self._check_thread)
        self._check_thread.started.connect(self._check_worker.run)
        self._check_worker.finished.connect(self._on_check_finished)
        self._check_worker.finished.connect(self._check_thread.quit)
        self._check_worker.finished.connect(self._check_worker.deleteLater)
        self._check_thread.finished.connect(self._check_thread.deleteLater)
        self._check_thread.finished.connect(lambda: setattr(self, "_check_thread", None))
        self._check_thread.start()

    def _on_check_finished(self, success: bool, message: str) -> None:
        self.btn_check.setEnabled(True)
        if success:
            self.lamp_db.set_state("green")
            self.lamp_ready.set_state("green")
            timeout = self.db_cfg.get("connect_timeout", 5)
            self.status_label.setText(
                f"Подключено к БД · Готов · timeout={timeout}с"
            )
            self.btn_run.setEnabled(True)
        else:
            self.lamp_db.set_state("red")
            self.lamp_ready.set_state("off")
            self.status_label.setText(f"Ошибка соединения: {message}")
            self.btn_run.setEnabled(False)
            QMessageBox.warning(self, "Соединение", f"Не удалось подключиться:\n{message}")

    # ------------------------------------------------------------------ Запрос
    def _on_dt_toggled(self, checked: bool) -> None:
        self.dt_edit.setEnabled(checked)
        self.cb_use_dt.setText("Использовать" if checked else "Не использовать")

    def _on_run_clicked(self) -> None:
        if self._query_thread and self._query_thread.isRunning():
            return

        dt_value: Optional[datetime] = None
        if self.cb_use_dt.isChecked():
            dt_value = self.dt_edit.dateTime().toPyDateTime()

        like_value = self.like_edit.text().strip() or None

        self._set_working(True)
        self.status_label.setText("Выполнение запроса…")
        self.progress.setVisible(True)

        self._query_thread = QThread()
        self._query_worker = QueryWorker(
            db_cfg=self.db_cfg,
            sql_template=self.sql_template,
            datetime_value=dt_value,
            like_value=like_value,
            datetime_column=self.datetime_column,
            like_column=self.like_column,
        )
        self._query_worker.moveToThread(self._query_thread)
        self._query_thread.started.connect(self._query_worker.run)
        self._query_worker.finished.connect(self._on_query_finished)
        self._query_worker.error.connect(self._on_query_error)
        self._query_worker.status.connect(self._on_query_status)
        self._query_worker.finished.connect(self._query_thread.quit)
        self._query_worker.error.connect(self._query_thread.quit)
        self._query_worker.finished.connect(self._query_worker.deleteLater)
        self._query_worker.error.connect(self._query_worker.deleteLater)
        self._query_thread.finished.connect(self._query_thread.deleteLater)
        self._query_thread.finished.connect(lambda: setattr(self, "_query_thread", None))
        self._query_thread.start()

    def _on_query_status(self, text: str) -> None:
        self.status_label.setText(text)

    def _on_query_finished(self, rows: list, columns: list) -> None:
        self._set_working(False)
        self.progress.setVisible(False)
        self._rows_data = rows
        self._columns = columns
        self._fill_table(rows, columns)
        self.status_label.setText(f"Готово · строк: {len(rows)}")
        self.rows_label.setText(f"{len(rows)} строк")
        self.lamp_ready.set_state("green")

    def _on_query_error(self, message: str) -> None:
        self._set_working(False)
        self.progress.setVisible(False)
        self.status_label.setText("Ошибка запроса")
        self.lamp_ready.set_state("yellow")
        QMessageBox.critical(self, "Ошибка SQL", message)

    def _set_working(self, working: bool) -> None:
        self.btn_run.setEnabled(not working)
        self.btn_check.setEnabled(not working)
        self.btn_clear.setEnabled(not working)
        self.btn_settings.setEnabled(not working)
        self.lamp_work.set_state("blue" if working else "off")
        if working:
            self.lamp_ready.set_state("yellow")

    # ------------------------------------------------------------------ Таблица
    def _fill_table(self, rows: List[Dict], columns: List[str]) -> None:
        self.table.clear()
        self.table.setRowCount(0)
        self.table.setColumnCount(0)
        if not columns:
            return

        self.table.setColumnCount(len(columns))
        self.table.setHorizontalHeaderLabels(columns)
        self.table.setRowCount(len(rows))

        for r, row in enumerate(rows):
            for c, col in enumerate(columns):
                value = row.get(col)
                if value is None:
                    text = ""
                elif isinstance(value, (bytes, bytearray, memoryview)):
                    text = f"<BLOB {len(value)} bytes>"
                elif isinstance(value, datetime):
                    text = value.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    text = str(value)
                item = QTableWidgetItem(text)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                if col == self.blob_column and isinstance(
                    value, (bytes, bytearray, memoryview)
                ):
                    item.setData(Qt.UserRole, bytes(value))
                self.table.setItem(r, c, item)

        self.table.resizeColumnsToContents()
        for i in range(self.table.columnCount()):
            if self.table.columnWidth(i) > 400:
                self.table.setColumnWidth(i, 400)

    def _clear_table(self) -> None:
        self.table.clear()
        self.table.setRowCount(0)
        self.table.setColumnCount(0)
        self._rows_data.clear()
        self._columns.clear()
        self.rows_label.setText("")
        self.status_label.setText("Таблица очищена")

    # ------------------------------------------------------------------ Контекстное меню / BLOB
    def _on_table_context_menu(self, pos) -> None:
        item = self.table.itemAt(pos)
        if item is None:
            return
        col = item.column()
        if col < 0 or col >= len(self._columns):
            return
        col_name = self._columns[col]

        menu = QMenu(self)
        if col_name == self.blob_column:
            act = QAction("Сохранить как .tar…", self)
            act.triggered.connect(lambda: self._save_blob_as_tar(item))
            menu.addAction(act)
        act_copy = QAction("Копировать значение", self)
        act_copy.triggered.connect(
            lambda: QApplication.clipboard().setText(item.text())
        )
        menu.addAction(act_copy)
        menu.exec_(self.table.viewport().mapToGlobal(pos))

    def _save_blob_as_tar(self, item: QTableWidgetItem) -> None:
        data = item.data(Qt.UserRole)
        if not data or not isinstance(data, (bytes, bytearray)):
            QMessageBox.information(
                self, "Сохранение", "Нет бинарных данных в этой ячейке."
            )
            return

        row = item.row()
        default_name = f"blob_row_{row + 1}.tar"
        if self._rows_data and row < len(self._rows_data):
            rid = self._rows_data[row].get("id")
            if rid is not None:
                default_name = f"blob_{rid}.tar"

        path, _ = QFileDialog.getSaveFileName(
            self,
            "Сохранить BLOB как .tar",
            default_name,
            "TAR archives (*.tar);;All files (*)",
        )
        if not path:
            return
        if not path.lower().endswith(".tar"):
            path += ".tar"

        try:
            is_tar = False
            try:
                with tarfile.open(fileobj=io.BytesIO(data), mode="r:*"):
                    is_tar = True
            except Exception:
                is_tar = False

            if is_tar:
                with open(path, "wb") as f:
                    f.write(data)
            else:
                with tarfile.open(path, mode="w") as tf:
                    info = tarfile.TarInfo(name="data.bin")
                    info.size = len(data)
                    tf.addfile(info, io.BytesIO(data))

            self.status_label.setText(f"Сохранено: {path}")
            QMessageBox.information(self, "Успех", f"Файл сохранён:\n{path}")
        except Exception as e:
            logger.exception("Ошибка сохранения")
            QMessageBox.critical(self, "Ошибка сохранения", str(e))

    # ------------------------------------------------------------------ Закрытие
    def closeEvent(self, event) -> None:
        for th in (self._query_thread, self._check_thread):
            if th is not None and th.isRunning():
                th.quit()
                th.wait(2000)
        self._rows_data.clear()
        self._columns.clear()
        super().closeEvent(event)


# ---------------------------------------------------------------------------
def main() -> int:
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setApplicationName("MySQL Query Tool")
    app.setOrganizationName("LocalTools")

    window = MainWindow()
    window.show()
    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())
