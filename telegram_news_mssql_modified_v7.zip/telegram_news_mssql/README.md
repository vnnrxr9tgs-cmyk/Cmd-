# Telegram News — SQL Server 2008

Один SQL Server, 20–30 клиентов по сети. JSON импортируется на ПК с файлами, UI только читает БД.

```
[ПК]  data/*.json  →  json_to_mssql.py  →  SQL Server 2008 (TelegramNews)
                                                    ↑
                                      mainTLG.py × 20–30 пользователей
```

## Файлы

| Файл | Роль |
|------|------|
| `schema_mssql.sql` | Создание БД, таблиц, индексов |
| `json_to_mssql.py` | Импорт JSON → MSSQL (цикл, без дублей) |
| `mainTLG.py` | Клиент PyQt5 |
| `settings/importer.ini.example` | Пример настроек импортёра |

## 1. Создать БД

В SSMS или:

```bat
sqlcmd -S YOUR_SERVER -E -i schema_mssql.sql
```

`-E` = Windows Auth. Для SQL-логина: `-U sa -P ***`.

## 2. Права

**Импортёр** (запись в news/channels/meta):

```sql
CREATE LOGIN news_importer WITH PASSWORD = '***';
USE TelegramNews;
CREATE USER news_importer FOR LOGIN news_importer;
GRANT SELECT, INSERT, UPDATE ON dbo.channels TO news_importer;
GRANT SELECT, INSERT ON dbo.news TO news_importer;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.meta TO news_importer;
```

**Читатели** (доменная группа или SQL-логин):

```sql
-- пример: доменная группа
CREATE LOGIN [DOMAIN\NewsReaders] FROM WINDOWS;
CREATE USER [DOMAIN\NewsReaders] FOR LOGIN [DOMAIN\NewsReaders];
GRANT SELECT ON dbo.channels TO [DOMAIN\NewsReaders];
GRANT SELECT ON dbo.news TO [DOMAIN\NewsReaders];
GRANT SELECT, INSERT, UPDATE ON dbo.read_state TO [DOMAIN\NewsReaders];
```

## 3. Импортёр

```bat
pip install pyodbc

copy settings\importer.ini.example settings\importer.ini
# отредактировать server, auth, data_dir

python json_to_mssql.py --once
python json_to_mssql.py --interval 30
```

CLI:

```bat
python json_to_mssql.py --server 192.168.1.10 --database TelegramNews --auth windows --data-dir D:\news --once
python json_to_mssql.py --server 192.168.1.10 --auth sql --user news_importer --password *** --once
```

Дубли: `UNIQUE(channel_id, checksum)`. Неизменённые JSON пропускаются по хэшу файла в `meta`.

## 4. Клиент

```bat
pip install PyQt5 pyodbc
python mainTLG.py
```

При первом запуске откроются **Настройки → Подключение**:

| Поле | Пример |
|------|--------|
| Сервер | `192.168.1.10` или `SQLHOST\SQLEXPRESS` |
| База | `TelegramNews` |
| Аутентификация | Windows (домен) **или** SQL Server |
| SQL логин / пароль | только для auth=sql |
| ODBC Driver | `SQL Server` или `SQL Server Native Client 10.0` |
| user_id | ваш логин (для «прочитано» отдельно у каждого) |

Кнопка **Проверить подключение**.

## Поведение UI

- Каналы + badge непрочитанных (**свой** `user_id` в `read_state`)
- В канале 10 новостей, скролл вниз → ещё 10 (`ROW_NUMBER`, SQL 2008)
- Опрос БД каждые N сек → тосты о новых
- Темы dark/light, звук, поиск

## Зависимости

- **На ПК с SQL Server / импортёром:** ODBC Driver, `pyodbc`
- **На клиентах:** то же + `PyQt5`

Проверка драйверов:

```bat
python -c "import pyodbc; print(pyodbc.drivers())"
```

Нужен хотя бы `SQL Server` или `SQL Server Native Client 10.0`.

## Таблицы

- `channels` — метаданные канала  
- `news` — новости (`body NVARCHAR(MAX)`, индекс по channel+date, id)  
- `read_state (user_id, channel_id)` — кто что прочитал  
- `meta` — хэши JSON, версия схемы  

## Изменения клиента

- При первом запуске `user_id` больше не берётся автоматически из Windows. Если в `settings/settings.xml` нет `user_id`, приложение обязательно попросит придумать ник и сохранит его для следующих запусков.
- Если канал выключен через **Показ**, для него автоматически выключается **Трей**. Это правило также применяется к старым настройкам, где могло сохраниться `show=false`, `notify=true`.
- Текст новостей в карточке рисуется с выравниванием по ширине.
- Интервал опроса БД и уведомлений теперь один и тот же (1–120 секунд), таймер работает в `PreciseTimer`.
- Кнопка **Прочитать** из уведомления корректно активирует уже открытое окно и после этого переходит в канал.
- Добавлен single-instance: повторный запуск EXE/ярлыка передаёт команду уже запущенному экземпляру и разворачивает его вместо запуска второго процесса.
- Стартовый опрос больше не загружает все новости из БД в память. Обычный опрос обрабатывает новые записи пакетами, не пропуская их.
- Поиск имеет debounce 350 мс, чтобы не создавать отдельный SQL/QThread на каждый введённый символ.
- Проигрыватель звука переиспользуется вместо создания нового `QMediaPlayer` на каждое уведомление.
- Локальные `.ttf`/`.otf` из папки `sounds` регистрируются через `QFontDatabase`. Это позволяет положить туда шрифт с emoji для старых Windows (например, файл Segoe UI Emoji, если у вас есть право его распространять/использовать).

## Режим ИИ

В шапке главного окна появилась кнопка **ИИ**. Окно режима ИИ позволяет:

- выбрать один или несколько видимых каналов;
- задать интервал в минутах, часах или днях;
- выбрать стандартный промт, отредактировать его, сохранить свой или удалить свой;
- асинхронно получить новости из MSSQL и отправить их в ИИ без блокировки интерфейса;
- отменить сетевой запрос;
- скопировать ответ или сбросить окно результата.

Настройки подключения сохраняются рядом с остальными настройками в `settings/ii.json`. Поля: `base_url`, `api_path`, `token`, `model`, `username`. По умолчанию используется OpenAI-совместимый путь `/api/chat/completions`. Если ваша веб-версия Ollama использует другой API-путь, его можно изменить прямо в окне ИИ. Пример находится в `settings/ii.json.example`.

Пользовательские промты сохраняются в `settings/prompts.json`. Два стандартных промта находятся в коде и всегда доступны; удаляются только пользовательские.

Для защиты слабых ПК по умолчанию в один ИИ-запрос берётся не более 500 сообщений и примерно 120000 символов текста. Эти лимиты можно изменить в `ii.json` (`max_news`, `max_chars`).

## Сборка PyInstaller

Добавлен `telegram_news.spec`. Он автоматически включает из папки `sounds` файлы `.mp3`, `.wav`, `.ttf`, `.otf`. Пользовательские `settings.xml`, `ii.json` и `prompts.json` специально не вшиваются в EXE: они создаются/читаются из папки `settings` рядом с EXE.

```bat
pip install PyQt5 pyodbc pyinstaller
pyinstaller --clean telegram_news.spec
```

Для `--onefile` ресурсы из `sounds` также поддерживаются: код сначала ищет внешнюю папку `sounds` рядом с EXE, а затем встроенную папку PyInstaller (`_MEIPASS`). Это позволяет как вшить шрифт при сборке, так и заменить/добавить его рядом с готовым EXE.
