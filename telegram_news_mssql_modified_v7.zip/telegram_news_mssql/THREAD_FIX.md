# QThread lifecycle fix

The previous versions could delete a QThread from `finished_ok` / `failed`. Those signals are emitted from inside `run()`, before the worker thread has actually finished. Qt can then report:

`QThread: Destroyed while thread is still running`

The current version follows this rule everywhere:

1. `finished_ok` / `failed` only deliver results to the UI.
2. `QThread.finished` is the only signal used for cleanup/deletion.
3. AI cancellation does not destroy the worker; it requests cancellation and waits for the thread to finish.
4. Application shutdown stops the poll timer and waits for active DB/AI workers before closing the process.
5. SQL queries cannot be force-killed safely through pyodbc, so if SQL Server does not return, the application remains open rather than destroying a live thread.
