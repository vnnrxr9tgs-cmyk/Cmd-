# Исправление кнопки «Выход» (v7)

Причина: `TrayApp.quit_app()` обращался к `self._ai_window`, хотя AI-диалог хранится в `self.main_window._ai_window`. Обработчик завершался с AttributeError до QApplication.quit().

Дополнительно исправлено:
- при выходе учитываются QThread из TrayApp, MainWindow и AIModeDialog;
- AI HTTP-запрос получает cancel();
- polling останавливается до ожидания потоков;
- интерфейс и tray скрываются сразу после команды «Выход»;
- QApplication.quit() вызывается только после реального завершения всех QThread;
- SQL connection/query timeout ограничен 8 секундами;
- QThread.terminate() не используется.
