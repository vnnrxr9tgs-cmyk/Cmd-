# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path

project_dir = Path(SPECPATH)
datas = []
sounds_dir = project_dir / "sounds"
if sounds_dir.exists():
    for mask in ("*.mp3", "*.wav", "*.ttf", "*.otf"):
        for fp in sounds_dir.glob(mask):
            datas.append((str(fp), "sounds"))

a = Analysis(
    ["mainTLG.py"],
    pathex=[str(project_dir)],
    binaries=[],
    datas=datas,
    hiddenimports=["pyodbc"],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="TelegramNews",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
)
