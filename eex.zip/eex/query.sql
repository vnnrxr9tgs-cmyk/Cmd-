SELECT TOP (12) [id]
      ,[name]
  FROM [Ts].[dbo].[competition]
