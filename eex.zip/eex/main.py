import pyodbc
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Border, Side, Font, Alignment
from openpyxl.utils import get_column_letter
import configparser
import os
import sys
from datetime import datetime


def read_config(config_file='config.ini'):
    """Читает параметры подключения из config.ini"""
    config = configparser.ConfigParser()
    config.read(config_file, encoding='utf-8')
    if 'DB' not in config:
        raise ValueError("В config.ini отсутствует секция [DB]")
    return config['DB']


def read_query(query_file='query.sql'):
    """Читает SQL-запрос из файла"""
    if not os.path.exists(query_file):
        raise FileNotFoundError(f"Файл {query_file} не найден")
    with open(query_file, 'r', encoding='utf-8') as f:
        return f.read()


def build_connection_string(config):
    """Формирует строку подключения на основе конфига"""
    driver = config.get('driver', 'ODBC Driver 17 for SQL Server')
    server = config.get('server')
    database = config.get('database')
    if not server or not database:
        raise ValueError("В конфиге должны быть указаны server и database")

    conn_str = f'DRIVER={{{driver}}};SERVER={server};DATABASE={database};'

    trusted = config.get('trusted_connection', '').lower() in ('yes', 'true', '1')
    if trusted:
        conn_str += 'Trusted_Connection=yes;'
    else:
        username = config.get('username')
        password = config.get('password')
        if username and password:
            conn_str += f'UID={username};PWD={password};'
        else:
            raise ValueError(
                "Не указаны данные для аутентификации. Используйте trusted_connection или username/password.")
    return conn_str


def execute_query(conn_str, query):
    """Выполняет запрос и возвращает DataFrame"""
    try:
        conn = pyodbc.connect(conn_str, timeout=30)
        df = pd.read_sql(query, conn)
        conn.close()
        return df
    except Exception as e:
        raise RuntimeError(f"Ошибка выполнения запроса: {e}")


def save_to_excel(df, output_file):
    """Сохраняет DataFrame в Excel с форматированием"""
    if df.empty:
        print("Предупреждение: запрос не вернул данных. Будет создан пустой файл с заголовками.")

    # Сначала сохраняем через pandas
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Sheet1')

    # Загружаем книгу для форматирования
    wb = load_workbook(output_file)
    ws = wb['Sheet1']

    # Стили
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    header_font = Font(bold=True)
    center_alignment = Alignment(horizontal='center', vertical='center')

    # Автоширина колонок
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            if cell.value is not None:
                try:
                    max_len = max(max_len, len(str(cell.value)))
                except:
                    pass
        ws.column_dimensions[col_letter].width = max_len + 3  # небольшой запас

    # Применяем границы и выравнивание ко всем ячейкам
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
        for cell in row:
            cell.border = thin_border
            cell.alignment = center_alignment
            if cell.row == 1:  # заголовок
                cell.font = header_font

    wb.save(output_file)


def main():
    try:
        print("Чтение конфигурации...")
        config = read_config()
        conn_str = build_connection_string(config)

        print("Чтение SQL-запроса...")
        query = read_query()
        if not query.strip():
            raise ValueError("Файл запроса пуст")

        print("Выполнение запроса к БД...")
        df = execute_query(conn_str, query)

        # Имя выходного файла с меткой времени
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = f"result_{timestamp}.xlsx"

        print("Сохранение в Excel...")
        save_to_excel(df, output_file)

        print(f"Готово! Результат сохранён в {output_file}")
        print(f"Количество записей: {len(df)}")

    except FileNotFoundError as e:
        print(f"Ошибка: {e}")
        sys.exit(1)
    except ValueError as e:
        print(f"Ошибка в конфигурации: {e}")
        sys.exit(1)
    except pyodbc.Error as e:
        print(f"Ошибка подключения к БД: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Непредвиденная ошибка: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()