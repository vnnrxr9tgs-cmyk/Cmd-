import configparser, logging, shutil, subprocess, sys, time
from pathlib import Path

BASE = Path(__file__).resolve().parent
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                    handlers=[logging.StreamHandler(), logging.FileHandler(BASE / "processor.log", encoding="utf-8")])
log = logging.getLogger("proc")


def load_config(path=BASE / "config.ini"):
    cfg = configparser.ConfigParser()
    if not cfg.read(path, encoding="utf-8"):
        raise FileNotFoundError(path)
    return cfg


def read_last_id(log_path: Path) -> int:
    if not log_path.exists() or not log_path.read_text().strip():
        return 0
    return int(log_path.read_text().strip())


def write_last_id(log_path: Path, value: int):
    tmp = log_path.with_suffix(".tmp")
    tmp.write_text(str(value))
    tmp.replace(log_path)  # атомарная замена


def fetch_rows(cfg, last_id):
    import pyodbc
    db = cfg["db"]
    cs = f"DRIVER={{{db['driver']}}};SERVER={db['server']};DATABASE={db['database']};"
    cs += "Trusted_Connection=yes;" if db.getboolean("trusted") else f"UID={db['user']};PWD={db['password']};"
    with pyodbc.connect(cs) as conn:
        return [(int(r[0]), r[1]) for r in conn.cursor().execute(cfg["query"]["sql"], last_id).fetchall()]


def find_files(path: Path, ext: str):
    """Путь из БД - папка (файлов несколько) или сам файл. Берём файлы с нужным расширением."""
    ext = "." + ext.lower().lstrip(".")
    if path.is_file():
        return [path] if path.suffix.lower() == ext else []
    if path.is_dir():
        return sorted(f for f in path.iterdir() if f.is_file() and f.suffix.lower() == ext)
    raise FileNotFoundError(f"Путь не найден: {path}")


def process_file(cfg, src: Path):
    """Копия в work_dir -> a.exe <копия> (ждём завершения) -> директорию с именем файла (test.txt -> test) в папку исходника."""
    app = cfg["app"]
    work = Path(app["work_dir"])
    exe = Path(app.get("exe_path") or work / "a.exe")
    timeout = int(app.get("timeout", 0)) or None
    target = src.parent / src.stem
    if target.exists():
        log.warning("%s: директория %s уже существует - пропуск", src.name, target)
        return target

    copy = work / src.name
    before = {p.name for p in work.iterdir() if p.is_dir()}
    shutil.copy2(src, copy)
    try:
        res = subprocess.run([str(exe), str(copy)], cwd=work, timeout=timeout, capture_output=True, text=True)
        log.info("%s: код возврата %s", src.name, res.returncode)
        new_dirs = [work / n for n in ({p.name for p in work.iterdir() if p.is_dir()} - before)]
        if not new_dirs:
            raise RuntimeError(f"Программа не создала директорию (rc={res.returncode}) stderr={res.stderr.strip()[:300]}")
        if len(new_dirs) > 1:
            raise RuntimeError(f"Появилось несколько директорий: {[d.name for d in new_dirs]}")
        out = new_dirs[0]
        if out.name != src.stem:
            log.warning("%s: программа создала '%s', переименовываем в '%s'", src.name, out.name, src.stem)
        shutil.move(str(out), str(target))  # target не существует -> директория получит имя файла без расширения
    finally:
        copy.unlink(missing_ok=True)  # удаляем только копию в work_dir; исходники по пути из БД не трогаем
    return target


def process_id(cfg, row_id, path):
    files = find_files(Path(path), cfg["app"]["extension"])
    if not files:
        raise FileNotFoundError(f"В {path} нет файлов *.{cfg['app']['extension']}")
    for f in files:
        process_file(cfg, f)  # исключение любого файла -> id не считается выполненным


def run_cycle(cfg, skip_ids: set):
    log_path = BASE / cfg["app"]["log_file"]
    failed_path = BASE / cfg["app"]["failed_file"]
    last_id = read_last_id(log_path)
    rows = [r for r in fetch_rows(cfg, last_id) if r[0] not in skip_ids]
    if rows:
        log.info("Последний id=%s, к обработке: %s", last_id, len(rows))
    for row_id, path in rows:
        try:
            process_id(cfg, row_id, path)
            write_last_id(log_path, row_id)
            log.info("id=%s готово", row_id)
        except Exception as e:
            log.error("id=%s ошибка: %s", row_id, e)
            skip_ids.add(row_id)  # до перезапуска не долбим этот id каждую минуту
            with open(failed_path, "a", encoding="utf-8") as f:
                f.write(f"{row_id}\t{path}\t{e}\n")


def main(max_cycles=None):
    cfg = load_config()
    interval = int(cfg["app"].get("interval", 60))
    skip_ids, n = set(), 0
    log.info("Старт, интервал %s c. Остановка: Ctrl+C", interval)
    try:
        while max_cycles is None or n < max_cycles:
            try:
                run_cycle(cfg, skip_ids)
            except Exception:
                log.exception("Сбой цикла (БД недоступна?) - повтор через %s c", interval)
            n += 1
            if max_cycles is None or n < max_cycles:
                time.sleep(interval)
    except KeyboardInterrupt:
        log.info("Остановлено пользователем")


if __name__ == "__main__":
    sys.exit(main())
