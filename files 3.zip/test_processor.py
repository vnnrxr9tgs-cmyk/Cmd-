import tempfile, configparser
from pathlib import Path
import processor as p

t = Path(tempfile.mkdtemp()); work = t/"x"; work.mkdir(); data = t/"data"; data.mkdir()
exe = work/"a.exe"   # заглушка: bad* -> не создаёт папку; odd* -> создаёт папку с чужим именем; иначе папка <имя без расширения>
exe.write_text('#!/bin/sh\nsleep 1\nb=$(basename "$1")\nn="${b%.*}"\ncase "$b" in bad*) exit 3;; odd*) n=weird;; esac\nmkdir "$(dirname "$1")/$n"\n')
exe.chmod(0o755)

def mk(d, *names):
    (data/d).mkdir(exist_ok=True)
    for n in names: (data/d/n).write_text("x")
    return str(data/d)
rows = [(1, mk("d1", "test.txt", "skip.csv", "pic.png")),   # только txt берётся
        (2, mk("d2", "bad2.txt")),                          # сбой
        (3, mk("d3", "odd3.txt")),                          # папка с чужим именем -> переименуется в odd3
        (4, mk("d4", "a.txt", "b.txt"))]                    # два txt
cfg = configparser.ConfigParser()
cfg.read_dict({"app": {"work_dir": str(work), "exe_path": str(exe), "extension": "txt", "interval": "1",
                       "log_file": "log.txt", "failed_file": "failed.txt", "timeout": "0"}})
p.load_config = lambda *a, **k: cfg
p.BASE = t
p.fetch_rows = lambda c, last: [r for r in rows if r[0] > last]
(t/"log.txt").write_text("0")

p.main(max_cycles=2)                       # цикл 1: всё; цикл 2: новых нет, упавший id=2 не повторяется
assert (data/"d1"/"test").is_dir() and not (data/"d1"/"skip").exists() and not (data/"d1"/"pic").exists()
assert (data/"d1"/"test.txt").exists()                               # исходник цел
assert not (data/"d2"/"bad2").exists()
assert (data/"d3"/"odd3").is_dir() and not (data/"d3"/"weird").exists() and not (work/"weird").exists()
assert (data/"d4"/"a").is_dir() and (data/"d4"/"b").is_dir()
assert (t/"log.txt").read_text() == "4"
assert not any(work.glob("*.txt")) and not any(p_.is_dir() for p_ in work.iterdir())
assert (t/"failed.txt").read_text().count("\n") == 1                 # id=2 записан один раз, а не каждую минуту

rows.append((5, mk("d5", "new.txt")))      # новая строка в БД появилась позже
p.main(max_cycles=1)
assert (data/"d5"/"new").is_dir() and (t/"log.txt").read_text() == "5"

def broken(c, last): raise ConnectionError("db down")
p.fetch_rows = broken
p.main(max_cycles=1)                       # сбой БД не роняет цикл
print("ALL OK")
